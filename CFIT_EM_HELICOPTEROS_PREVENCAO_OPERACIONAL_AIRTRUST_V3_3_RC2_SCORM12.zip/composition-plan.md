# Plano de composição — CFIT em Helicópteros V3.3

Capa editorial + capítulos alternando Visual Explainer, Comparison, Process, Checklist, Briefing, Scenario e Assessment; sem três estímulos idênticos consecutivos. A media raster é contextual, real e licenciada. O curso contém 37 unidades, 4 módulos, 5 cenários de decisão e 40 questões em 4 avaliações, mínimo 80% por módulo. Não usa SVG como mídia nem cockpit gerado por IA. Uma rolagem principal responsiva; menu com preview read-only e retorno à jornada.

Fotografias documentadas em media-registry.json; não constituem evidência de painel, equipamento, método ou aeronave específica.
