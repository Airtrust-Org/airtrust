# S-76C+/++ SOP — CHANGELOG RB6 → RB7

## Escopo
Correção localizada de navegação/runtime e remoção da marca `AirTrust Learning` do cabeçalho do curso. Nenhum conteúdo técnico, gabarito, avaliação, mídia ou layout didático foi reaberto.

## Correções
- Removido `AirTrust Learning` do topbar do SCO; permanece apenas o nome do curso e o progresso.
- Corrigido botão de avanço em **modo Review**: anteriormente aparecia habilitado como `Continuar →`, mas `completeCurrent()` recusava a operação e a tela não mudava.
- Em Review, `Próximo →` agora percorre sequencialmente o conteúdo concluído e retorna automaticamente ao ponto ativo quando alcançado, sem alterar progresso, score, gates ou suspend_data.
- Avaliações abertas em Review passaram a ser estritamente read-only, impedindo criação/persistência acidental de novas respostas.
- Na avaliação final aprovada, o footer não oferece mais um `Continuar →` sem destino; mostra `Treinamento concluído ✓` após a conclusão efetiva.
- Mantida a correção RB6 das práticas opcionais, que permanecem abertas durante a interação e não geram Commit/persistência.

## QA exigido
- Varredura 55/55 dos estados do botão principal.
- Jornada E2E completa da capa à conclusão.
- Review sequencial de unidades concluídas.
- Preview read-only.
- 18 interações A, 9 B e 9 C.
- 6 avaliações, remediação, status final, lifecycle e pós-ZIP.
