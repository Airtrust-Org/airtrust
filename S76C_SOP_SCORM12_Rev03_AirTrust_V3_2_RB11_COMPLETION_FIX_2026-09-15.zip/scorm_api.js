(function(){
'use strict';
const trace=[]; let api=null, initialized=false, finished=false;
function findAPI(win){let tries=0; while(win && tries<10){try{if(win.API)return win.API;if(win.parent&&win.parent!==win){win=win.parent;tries++;continue;}}catch(e){}break;}try{if(window.opener&&window.opener.API)return window.opener.API;}catch(e){}return null;}
function record(method,key,value){trace.push({method,key,value});}
function call(method,...args){if(!api||typeof api[method]!=='function')return null;try{const r=api[method](...args);record(method,args[0],args[1]);return r;}catch(e){record(method,'exception',String(e));return null;}}
function ok(v){return v===true||v==='true'||v==='1'||v===1;}
function init(){if(initialized)return true;api=findAPI(window);if(!api){record('LMSInitialize','no-api','offline');initialized=true;return true;}const r=call('LMSInitialize','');initialized=ok(r);return initialized;}
function get(k){if(!initialized)init(); if(!api)return ''; const v=call('LMSGetValue',k); return v==null?'':String(v);}
function set(k,v){if(finished)return false;if(!initialized)init();if(!api){record('LMSSetValue',k,String(v));return true;}return ok(call('LMSSetValue',k,String(v)));}
function commit(){if(finished)return false;if(!initialized)init();if(!api){record('LMSCommit','','');return true;}return ok(call('LMSCommit',''));}
function finish(){if(finished)return true;if(!initialized)init();if(api){commit();const r=call('LMSFinish','');finished=ok(r);}else{commit();record('LMSFinish','','');finished=true;}return finished;}
function errorInfo(){if(!api)return {code:'0',text:'No LMS API (offline)',diagnostic:''};const code=String(call('LMSGetLastError')||'0');const text=String(call('LMSGetErrorString',code)||'');const diagnostic=String(call('LMSGetDiagnostic',code)||'');return {code,text,diagnostic};}
window.AirTrustSCORM={init,get,set,commit,finish,errorInfo,trace:()=>trace.slice(),isOnline:()=>!!api};
})();
