# CHANGELOG RB9 → RB10

## Escopo
Normalização do critério de aprovação do curso S-76C+/++ SOP de 80% para 70%, conforme requisito aprovado e configuração autoritativa do curso no AirTrust.

## Alterações
- `imsmanifest.xml`: `adlcp:masteryscore` 80 → 70.
- `airtrust-completion-manifest.json`: `assessment.masteryScore` 80 → 70.
- `course-model.js`: mastery dos seis módulos 80 → 70 e `packageVersion` atualizado para RB10.
- `app.js`: aprovação, remediação, diagnostics, navegação pós-avaliação e recovery certificado alinhados a 70%.
- UI learner-facing: capa e critério de avaliação passam a exibir 70%.
- Recovery legado continua fail-closed: exige 60 interações certificantes persistidas e reconstrução independente de todos os seis módulos, agora com mínimo de 70% por módulo.

## Não alterado
- 55 unidades / 60 questões certificantes.
- Gabaritos, enunciados, opções e pesos das questões.
- Conteúdo técnico, fontes, mídia, layout, preview e regras de interação.
- Evidência SCORM histórica de matrículas existentes.
- `auditClosure.certifyingScoreChanged=false`, pois não houve alteração de gabarito, pontuação por questão ou fórmula de score; a mudança é exclusivamente do mastery threshold documentado em `masteryRevision`.
