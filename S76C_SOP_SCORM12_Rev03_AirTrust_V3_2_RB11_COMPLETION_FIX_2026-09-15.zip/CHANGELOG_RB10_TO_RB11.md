# CHANGELOG RB10 → RB11

## Correção definitiva de estado/conclusão
- Reentrada com `cmi.core.lesson_status=passed` ou `completed` passa a tratar o LMS como autoridade de conclusão.
- Um curso já concluído não volta ao checkpoint legado de `suspend_data`/`lesson_location` (caso observado: 17/55).
- Reentrada concluída abre em estado 55/55 e revisão, sem fabricar respostas, sem recriar interações e sem sobrescrever evidência histórica.
- Jornada ainda não concluída continua restaurando normalmente `suspend_data` e `lesson_location`.
- Conclusão normal persiste estado final, `lesson_location=55/55`, score, `lesson_status=passed`, `Commit` e `Finish` uma única vez.
- Fechamento de sessão concluída executa `Commit` antes de `Finish`, sem alterar respostas ou checkpoints históricos.
- Removido listener global que re-renderizava o rodapé a cada clique; atualização do footer permanece apenas nos eventos que realmente mudam estado.

## Critério de aprovação
- Mantido em 70% por módulo, alinhado à configuração autoritativa do curso no AirTrust.

## Conteúdo
- Nenhuma alteração em enunciados, gabaritos, fontes técnicas, mídia ou composição editorial.
