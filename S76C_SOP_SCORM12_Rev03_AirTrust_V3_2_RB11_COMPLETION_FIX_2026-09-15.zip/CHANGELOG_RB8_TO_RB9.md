# S-76C+/++ SOP — RB8 → RB9

## Objetivo

Fortalecer a recuperação de conclusão no AirTrust para matrículas legadas presas em `99%` / `SCORM_STATUS_INCONSISTENT`, sem promover conclusão por score ou progresso isolados.

## Correção

- preservado todo o conteúdo técnico, 55 slides, 60 questões, mastery 80%, navegação e layout da RB8;
- mantida a conclusão normal: `55/55` + `lesson_status=passed` + score + `Commit` + `Finish` imediato;
- adicionada recuperação fail-closed por evidência certificante persistida em `cmi.interactions`;
- a recuperação exige as 60 questões certificantes presentes no CMI e reconstrução independente de nota >=80 em cada um dos 6 módulos;
- score 100%, progresso 99% e localização final/antiga, isoladamente, não autorizam conclusão;
- se faltarem interações ou algum módulo ficar abaixo de 80%, a matrícula permanece incompleta;
- atualizado `auditClosure.liveGateCommit` para `2c84cf047937a31028e5cce2579b023beb6fc643`.

## Caso alvo

O mecanismo foi criado para o padrão observado em produção no S-76: LMS mostra nota 100%, progresso 99% e `SCORM_STATUS_INCONSISTENT`, enquanto o estado de retomada regressa para uma posição anterior. Se as 60 interações certificantes tiverem sido persistidas pelo wrapper, a RB9 reconstrói a conclusão sem exigir que o aluno refaça o treinamento.
