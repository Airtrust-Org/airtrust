# CHANGELOG — S-76C+/++ SOP RB5 → RB6

## Escopo

RB6 é uma revisão controlada de **texto learner-facing** e de **comportamento das práticas opcionais**. Não altera conteúdo técnico validado, layout, arquitetura dos seis módulos, mastery, IDs, gabaritos ou contrato M8.

## Revisão textual

A revisão percorreu capa, 48 unidades, 6 avaliações, 60 questões certificantes, instruções de interação, alternativas e feedbacks.

Principais classes de correção:

- gramática, concordância e regência;
- uso correto do subjuntivo em construções condicionais;
- artigos e paralelismo sintático;
- clareza e naturalidade do português operacional;
- perguntas e instruções didáticas mais diretas;
- feedbacks mais claros sem revelar conteúdo além do necessário;
- remoção de metatexto editorial/autoral learner-facing;
- padronização de pontuação e capitalização.

Exemplos:

- `Se ... contradizer ...` → `Em caso de divergência entre ...`;
- `se altitude publicada e altímetro conferem` → `se a altitude publicada e o altímetro conferirem`;
- `Se o pouso deixou de ser aconselhável` → `Se o pouso deixar de ser aconselhável`;
- `Se a aeronave não está estabilizada` → `Se a aeronave não estiver estabilizada`;
- `O peso e balanceamento` → `O peso e o balanceamento`;
- `a leitura de checklist` → `a leitura do checklist`.

A comparação RB5→RB6 registra **298 campos/fragments learner-facing alterados**. Os gabaritos, IDs das questões, fontes técnicas e parâmetros numéricos permanecem preservados.

## Correção de prática opcional

Problema observado no LMS: ao responder a uma `Prática rápida`, o conteúdo expansível podia fechar e a página podia deslocar, interrompendo a atividade.

Causa: atualização por rerenderização de interface/rodapé durante a interação.

Correção RB6:

- práticas opcionais atualizam o estado da própria interação sem renderizar novamente a Lesson Page;
- o `<details>` permanece aberto durante toda a prática;
- o rodapé é atualizado preservando a posição de rolagem;
- práticas B continuam sem `Commit` e sem alterar `suspend_data`;
- a correção é global para `sequence`, `classify` e `decision` opcionais.

Foram validadas as nove práticas B: M1-04, M1-07, M2-04, M2-05, M3-02, M3-05, M4-03, M4-06 e M4-07.

## Preservação técnica

Comparação automatizada RB5→RB6: PASS.

Preservados:

- 55 IDs de slides;
- 60 questões certificantes e respectivos gabaritos;
- `courseId=s76c-sop-rev03`;
- `navigationGate=module-assessment`;
- tipos/classes/obrigatoriedade das interações A/B/C;
- fontes técnicas, referências e mídias;
- 18 A obrigatórias / 9 B opcionais / 9 C removidas;
- mastery 80%;
- `failureStatus=failed`;
- SCORM 1.2 / Single SCO / M8.
