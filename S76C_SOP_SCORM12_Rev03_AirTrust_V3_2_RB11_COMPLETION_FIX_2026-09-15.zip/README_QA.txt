S-76C+/++ SOP RB8 — correção de conclusão/resume no AirTrust
Package: SCORM 1.2 / Single SCO / AIRTRUST_TRAINING_MODEL_M8
courseId: s76c-sop-rev03
packageVersion: v3.2-rb8-2026-09-15
55 slides = cover + 48 learning units + 6 assessments
60 certifying interactions; mastery 70%
Interaction triage preserved: 18 A required / 9 B optional / 9 C removed
Text/layout/technical content preserved from RB7.
RB8 completion: lesson_location uses N/55; global pass writes passed + 55/55 + score, commits and calls LMSFinish immediately.
RB8 recovery: completed RB7 suspend_data is recognized on reopen and self-healed to explicit SCORM completion without repeating the course.
No SCORM calls after LMSFinish.
AirTrust real: NÃO EXECUTADO após RB8.
Quality Gate AirTrust main consultado: 55205c0e5462e281bc13c779725bd6f5bb6d4844
