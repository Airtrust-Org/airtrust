# Interaction Triage — RB6

Classificação preservada da RB5. A revisão textual e a correção do estado das práticas opcionais não alteram a finalidade cognitiva nem a certificação.

- **A — tarefa cognitiva obrigatória:** 18 unidades; bloqueia progressão até conclusão.
- **B — prática opcional:** 9 unidades; não bloqueia progressão nem certificação e não gera Commit/suspend_data.
- **C — removida:** 9 unidades; conteúdo apresentado diretamente pela composição editorial.

## A — required
M1-02, M1-05, M1-08, M2-03, M2-08, M2-09, M3-06, M3-07, M3-08, M4-05, M4-08, M5-05, M5-06, M5-07, M6-02, M6-04, M6-06, M6-07

## B — optional
M1-04, M1-07, M2-04, M2-05, M3-02, M3-05, M4-03, M4-06, M4-07

## C — removed
M2-02, M2-07, M3-03, M4-04, M4-09, M5-02, M5-03, M6-03, M6-05

As 60 interações certificantes de avaliação permanecem inalteradas.
