# CHANGELOG RB7 → RB8 — conclusão SCORM / aproveitamento de progresso

## Incidente reproduzido
O curso podia exibir 100% e 55/55 internamente enquanto o AirTrust permanecia em 99% com `SCORM_STATUS_INCONSISTENT`. A captura do usuário mostrava posição persistida 12/55 mesmo na avaliação final.

## Causa
1. `cmi.core.lesson_location` era persistido como ID opaco da unidade (ex.: `M6-A01`), enquanto o runtime AirTrust usa marcador numérico `current/total` para progresso/final-location.
2. `LMSFinish` ficava adiado para `beforeunload`, portanto o fechamento da sessão dependia de o navegador disparar a saída após a conclusão.
3. Um aluno com estado interno completo salvo, mas status LMS ainda `incomplete`, não tinha rotina explícita de recuperação ao reabrir.

## Correções
- Todo commit significativo grava localização `N/55`.
- Na conclusão global 6/6: grava `55/55`, `lesson_status=passed`, score, `exit=''`, `suspend_data`; executa `LMSCommit` e em seguida `LMSFinish` imediatamente.
- Após `LMSFinish`, o curso não faz novas chamadas SCORM; revisão visual continua possível sem tocar a API.
- Ao reabrir, se o `suspend_data` comprovar 55/55 internamente e 6/6 módulos aprovados, o pacote promove o estado persistido para `passed` e finaliza a sessão automaticamente, preservando o aproveitamento do aluno.
- Compatibilidade de resume: aceita localização antiga por ID e nova localização numérica.

## Não alterado
Conteúdo técnico, layout, 55 IDs, 60 questões/gabaritos, mastery 80%, 18/9/9 interações, Preview, SCORM courseId e contrato M8.

## Ajuste de fechamento após recuperação
- Quando um aluno já completo é recuperado de um estado legado `99% / incomplete`, a tela final agora mostra explicitamente `Treinamento concluído ✓`, sem reinicializar visualmente uma avaliação vazia após o `LMSFinish`.
- O binding da avaliação fica inativo após `Finish`, preservando a regra de zero chamadas/alterações SCORM pós-finalização.
