import { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Download, Plus } from 'lucide-react';

interface Certificado {
  id: number;
  numero_certificado: string;
  titulo: string;
  data_emissao: string;
  status: 'ativo' | 'revogado' | 'expirado';
  r2_url?: string;
}

export default function CertificadosPage() {
  const [certificados, setCertificados] = useState<Certificado[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    habilitacao_id: '',
    empresa_id: '',
    funcionario_id: '',
  });

  // Carregar certificados
  useEffect(() => {
    async function load() {
      try {
        const response = await fetch('/api/v2/certificados');
        const result = await response.json();
        if (result.success) {
          setCertificados(result.data);
        }
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  // Gerar certificado
  async function handleGerar(e: React.FormEvent) {
    e.preventDefault();

    try {
      const response = await fetch('/api/v2/certificados/gerar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          habilitacao_id: parseInt(formData.habilitacao_id),
          empresa_id: parseInt(formData.empresa_id),
          funcionario_id: parseInt(formData.funcionario_id),
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast.success('Certificado gerado com sucesso!');
        setShowForm(false);
        setFormData({ habilitacao_id: '', empresa_id: '', funcionario_id: '' });

        // Recarregar lista
        const updated = await fetch('/api/v2/certificados');
        const updatedResult = await updated.json();
        if (updatedResult.success) setCertificados(updatedResult.data);
      } else {
        toast.error(result.error || 'Erro ao gerar');
      }
    } catch (e) {
      toast.error('Erro na requisição');
    }
  }

  // Download certificado
  function handleDownload(certificado: Certificado) {
    if (certificado.r2_url) {
      window.open(certificado.r2_url, '_blank');
    }
  }

  const statusColors = {
    ativo: 'bg-green-100 text-green-800',
    revogado: 'bg-red-100 text-red-800',
    expirado: 'bg-yellow-100 text-yellow-800',
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Certificados</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <Plus size={20} />
          Novo Certificado
        </button>
      </div>

      {/* Formulário */}
      {showForm && (
        <form onSubmit={handleGerar} className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Habilitação</label>
              <input
                type="number"
                value={formData.habilitacao_id}
                onChange={(e) => setFormData({ ...formData, habilitacao_id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Empresa</label>
              <input
                type="number"
                value={formData.empresa_id}
                onChange={(e) => setFormData({ ...formData, empresa_id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Funcionário</label>
              <input
                type="number"
                value={formData.funcionario_id}
                onChange={(e) => setFormData({ ...formData, funcionario_id: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg"
                required
              />
            </div>
          </div>
          <button
            type="submit"
            className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Gerar Certificado
          </button>
        </form>
      )}

      {/* Lista */}
      {loading ? (
        <div>Carregando...</div>
      ) : certificados.length === 0 ? (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800">Nenhum certificado gerado ainda</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Número</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Título</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Data</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody>
              {certificados.map((cert) => (
                <tr key={cert.id} className="border-b hover:bg-gray-50">
                  <td className="px-6 py-3 text-sm font-mono">{cert.numero_certificado}</td>
                  <td className="px-6 py-3 text-sm">{cert.titulo}</td>
                  <td className="px-6 py-3 text-sm">
                    {new Date(cert.data_emissao).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-3">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        statusColors[cert.status]
                      }`}
                    >
                      {cert.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-3">
                    <button
                      onClick={() => handleDownload(cert)}
                      className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
                    >
                      <Download size={18} />
                      Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
