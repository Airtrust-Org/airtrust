import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';

interface ConfigEmpresa {
  id: number;
  empresa_id: number;
  nome: string;
  logo_url?: string;
  cor_primaria: string;
  cor_secundaria: string;
  cor_acento: string;
  template_certificado: string;
  email_contato?: string;
  telefone?: string;
  website?: string;
  endereco?: string;
}

export default function ConfiguracaoEmpresa() {
  const { id } = useParams<{ id: string }>();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<ConfigEmpresa>>({});

  // Carregar configurações
  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const response = await fetch(`/api/v2/empresas/${id}/config`);
        const result = await response.json();

        if (result.success && result.data) {
          setFormData(result.data);
        } else {
          toast.error('Erro ao carregar configurações');
        }
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [id]);

  // Salvar configurações
  async function handleSave(e: React.FormEvent) {
    e.preventDefault();

    try {
      setSaving(true);
      const response = await fetch(`/api/v2/empresas/${id}/config`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const result = await response.json();

      if (result.success) {
        toast.success('Configurações salvas com sucesso!');
        // Recarregar para confirmar persistência
        const updated = await fetch(`/api/v2/empresas/${id}/config`);
        const updatedResult = await updated.json();
        if (updatedResult.success) {
          setFormData(updatedResult.data);
        }
      } else {
        toast.error(result.error || 'Erro ao salvar');
      }
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Configurações da Empresa</h1>

      <form onSubmit={handleSave} className="space-y-6 bg-white rounded-lg shadow p-6">
        {/* Nome */}
        <div>
          <label className="block text-sm font-medium mb-2">Nome da Empresa</label>
          <input
            type="text"
            value={formData.nome || ''}
            onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Logo da Empresa */}
        <div>
          <label className="block text-sm font-medium mb-2">Logo da Empresa</label>
          {formData.logo_url && (
            <div className="mb-4 p-3 bg-gray-50 rounded-lg">
              <img
                src={formData.logo_url}
                alt="Logo"
                className="max-height-[120px] max-w-[200px]"
              />
              <span className="text-xs text-green-600 ml-2">✓ Logo configurado</span>
            </div>
          )}

          <div className="flex items-center gap-3">
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              id="logoInput"
              onChange={async (e) => {
                const file = e.currentTarget.files?.[0];
                if (!file) return;

                try {
                  const formDataFile = new FormData();
                  formDataFile.append('logo', file);

                  const response = await fetch(`/api/v2/empresas/${id}/logo/upload`, {
                    method: 'POST',
                    body: formDataFile,
                  });

                  const result = await response.json();
                  if (result.success) {
                    toast.success('✅ Logo enviado com sucesso!');
                    setFormData({ ...formData, logo_url: result.data.logo_url });
                  } else {
                    toast.error(`❌ Erro: ${result.error}`);
                  }
                } catch (err) {
                  toast.error('❌ Erro ao fazer upload');
                  console.error(err);
                }
              }}
              className="px-4 py-2 border rounded-lg text-sm"
            />
            <span className="text-xs text-gray-500">PNG, JPEG ou WebP (máx. 5MB)</span>
          </div>
        </div>

        {/* Cores */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Cor Primária</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={formData.cor_primaria || '#0066cc'}
                onChange={(e) => setFormData({ ...formData, cor_primaria: e.target.value })}
                className="w-12 h-10 rounded"
              />
              <span className="text-sm font-mono">{formData.cor_primaria}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Cor Secundária</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={formData.cor_secundaria || '#333333'}
                onChange={(e) => setFormData({ ...formData, cor_secundaria: e.target.value })}
                className="w-12 h-10 rounded"
              />
              <span className="text-sm font-mono">{formData.cor_secundaria}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Cor Acentuada</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={formData.cor_acento || '#FF6B35'}
                onChange={(e) => setFormData({ ...formData, cor_acento: e.target.value })}
                className="w-12 h-10 rounded"
              />
              <span className="text-sm font-mono">{formData.cor_acento}</span>
            </div>
          </div>
        </div>

        {/* Template */}
        <div>
          <label className="block text-sm font-medium mb-2">Template de Certificado</label>
          <select
            value={formData.template_certificado || 'default'}
            onChange={(e) => setFormData({ ...formData, template_certificado: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="default">Padrão</option>
            <option value="premium">Premium</option>
            <option value="simples">Simples</option>
          </select>
        </div>

        {/* Contato */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Email de Contato</label>
            <input
              type="email"
              value={formData.email_contato || ''}
              onChange={(e) => setFormData({ ...formData, email_contato: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Telefone</label>
            <input
              type="tel"
              value={formData.telefone || ''}
              onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              className="w-full px-4 py-2 border rounded-lg"
            />
          </div>
        </div>

        {/* Website e Endereço */}
        <div>
          <label className="block text-sm font-medium mb-2">Website</label>
          <input
            type="url"
            value={formData.website || ''}
            onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Endereço</label>
          <textarea
            value={formData.endereco || ''}
            onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
            rows={3}
            className="w-full px-4 py-2 border rounded-lg"
          />
        </div>

        {/* Botão Salvar */}
        <button
          type="submit"
          disabled={saving}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
        >
          <Save size={20} />
          {saving ? 'Salvando...' : 'Salvar Configurações'}
        </button>
      </form>

      {/* Preview das cores */}
      <div className="mt-8 bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-bold mb-4">Preview das Cores</h2>
        <div className="flex gap-4">
          <div
            className="w-24 h-24 rounded-lg border-2 border-gray-300"
            style={{ backgroundColor: formData.cor_primaria }}
            title="Cor Primária"
          />
          <div
            className="w-24 h-24 rounded-lg border-2 border-gray-300"
            style={{ backgroundColor: formData.cor_secundaria }}
            title="Cor Secundária"
          />
          <div
            className="w-24 h-24 rounded-lg border-2 border-gray-300"
            style={{ backgroundColor: formData.cor_acento }}
            title="Cor Acentuada"
          />
        </div>
      </div>
    </div>
  );
}
