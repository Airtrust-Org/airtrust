import { useState, useEffect } from 'react';
import { agendamentosService } from '@/services';
import { Agendamento, AgendamentoCreate, AgendamentoUpdate } from '@/types';

export const useAgendamentos = () => {
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await agendamentosService.listar();
      setAgendamentos(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar agendamentos');
    } finally {
      setLoading(false);
    }
  };

  const criar = async (data: AgendamentoCreate) => {
    setLoading(true);
    try {
      const novo = await agendamentosService.criar(data);
      setAgendamentos([...agendamentos, novo]);
      return novo;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const atualizar = async (id: string, data: AgendamentoUpdate) => {
    setLoading(true);
    try {
      const atualizado = await agendamentosService.atualizar(id, data);
      setAgendamentos(agendamentos.map(a => a.id === id ? atualizado : a));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const excluir = async (id: string) => {
    setLoading(true);
    try {
      await agendamentosService.excluir(id);
      setAgendamentos(agendamentos.filter(a => a.id !== id));
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const iniciar = async (id: string) => {
    setLoading(true);
    try {
      const atualizado = await agendamentosService.iniciar(id);
      setAgendamentos(agendamentos.map(a => a.id === id ? atualizado : a));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const finalizar = async (id: string, dados?: any) => {
    setLoading(true);
    try {
      const atualizado = await agendamentosService.finalizar(id, dados);
      setAgendamentos(agendamentos.map(a => a.id === id ? atualizado : a));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const cancelar = async (id: string, motivo?: string) => {
    setLoading(true);
    try {
      const atualizado = await agendamentosService.cancelar(id, motivo);
      setAgendamentos(agendamentos.map(a => a.id === id ? atualizado : a));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return {
    agendamentos,
    loading,
    error,
    carregar,
    criar,
    atualizar,
    excluir,
    iniciar,
    finalizar,
    cancelar
  };
};
