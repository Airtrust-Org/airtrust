import { useState, useEffect } from 'react';

export interface Qualificacao {
  id: number;
  nome: string;
  codigo: string;
  categoria: string;
  descricao?: string;
  carga_horaria: number;
  conteudo_programatico?: string;
  validade_meses: number;
  tipo_vencimento: string;
  ativo: boolean;
  created_at: string;
}

export function useQualificacoes() {
  const [qualificacoes, setQualificacoes] = useState<Qualificacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/v2/qualificacoes');
      if (!res.ok) throw new Error('Erro ao carregar qualificações');
      const data = await res.json();
      setQualificacoes(Array.isArray(data?.data) ? data.data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      setQualificacoes([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return {
    qualificacoes,
    loading,
    error,
    carregar,
  };
}
