import { useState, useEffect } from 'react';
import { funcionariosService } from '@/services';
import { Funcionario, FuncionarioCreate, FuncionarioUpdate } from '@/types';

export const useFuncionarios = () => {
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await funcionariosService.listar();
      setFuncionarios(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar funcionários');
    } finally {
      setLoading(false);
    }
  };

  const criar = async (data: FuncionarioCreate) => {
    setLoading(true);
    try {
      const novo = await funcionariosService.criar(data);
      setFuncionarios([...funcionarios, novo]);
      return novo;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const atualizar = async (id: string, data: FuncionarioUpdate) => {
    setLoading(true);
    try {
      const atualizado = await funcionariosService.atualizar(id, data);
      setFuncionarios(funcionarios.map(f => f.id === id ? atualizado : f));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const excluir = async (id: string) => {
    setLoading(true);
    try {
      await funcionariosService.excluir(id);
      setFuncionarios(funcionarios.filter(f => f.id !== id));
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return {
    funcionarios,
    loading,
    error,
    carregar,
    criar,
    atualizar,
    excluir
  };
};
