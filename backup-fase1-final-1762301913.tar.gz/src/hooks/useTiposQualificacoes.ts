import { useState, useEffect } from 'react';

export interface TipoQualificacao {
  id: number;
  nome: string;
  codigo: string;
  categoria: 'Nenhuma' | 'Profissional' | 'Periódico' | 'Especial';
  descricao?: string;
  carga_horaria: number;
  conteudo_programatico?: string;
  validade_meses: number;
  tipo_vencimento: 'Dia Exato' | 'Aniversário' | 'Mês Seguinte';
  created_at: string;
}

export function useTiposQualificacoes() {
  const [tipos, setTipos] = useState<TipoQualificacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/v2/qualificacoes');
      if (!res.ok) throw new Error('Erro ao carregar');
      const data = await res.json();
      setTipos(Array.isArray(data?.data) ? data.data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      setTipos([]);
    } finally {
      setLoading(false);
    }
  };

  const criar = async (dados: Omit<TipoQualificacao, 'id' | 'created_at'>) => {
    try {
      setError(null);
      const res = await fetch('/api/v2/qualificacoes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados),
      });
      if (!res.ok) throw new Error('Erro ao criar');
      await carregar();
      return await res.json();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao criar';
      setError(msg);
      throw err;
    }
  };

  const editar = async (id: number, dados: Partial<Omit<TipoQualificacao, 'id' | 'created_at'>>) => {
    try {
      setError(null);
      const res = await fetch(`/api/v2/qualificacoes/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados),
      });
      if (!res.ok) throw new Error('Erro ao editar');
      await carregar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao editar');
      throw err;
    }
  };

  const deletar = async (id: number) => {
    try {
      setError(null);
      const res = await fetch(`/api/v2/qualificacoes/${id}`, {
        method: 'DELETE',
      });
      if (!res.ok) throw new Error('Erro ao deletar');
      await carregar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao deletar');
      throw err;
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return { tipos, loading, error, carregar, criar, editar, deletar };
}
