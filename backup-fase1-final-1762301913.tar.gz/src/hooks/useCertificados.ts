import { useState, useEffect } from 'react';

export interface Certificado {
  id: number;
  qualificacao_id: number;
  arquivo_nome: string;
  arquivo_url: string;
  arquivo_hash: string;
  arquivo_tamanho: number;
  tipo: 'UPLOAD' | 'GERADO' | 'RENOVADO';
  data_documento: string;
  validade_ate: string;
  status: 'ATIVO' | 'VENCIDO' | 'REJEITADO' | 'SUBSTITUIDO';
  criado_por: string;
  observacoes: string;
  created_at: string;
  updated_at: string;
}

export function useCertificados(qualificacao_id: number) {
  const [certificados, setCertificados] = useState<Certificado[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch(`/api/v2/certificados/qualificacao/${qualificacao_id}`);
      if (!res.ok) throw new Error('Erro ao carregar');
      const data = await res.json();
      setCertificados(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      setCertificados([]);
    } finally {
      setLoading(false);
    }
  };

  const gerar = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch(`/api/v2/certificados/${qualificacao_id}/gerar`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Erro ao gerar');
      }
      const result = await res.json();
      await carregar();
      return result;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao gerar';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const download = async (id: number, nome: string) => {
    try {
      const res = await fetch(`/api/v2/certificados/${id}/download`);
      if (!res.ok) throw new Error('Erro no download');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = nome || `certificado-${id}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.error('Erro download:', err);
      setError('Erro ao fazer download');
    }
  };

  const deletar = async (id: number) => {
    try {
      const res = await fetch(`/api/v2/certificados/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Erro ao deletar');
      await carregar();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao deletar');
    }
  };

  const upload = async (file: File, qualificacao_id: number, metadata?: Partial<Certificado>) => {
    try {
      setLoading(true);
      setError(null);
      
      const formData = new FormData();
      formData.append('file', file);
      formData.append('qualificacao_id', qualificacao_id.toString());
      if (metadata?.data_documento) formData.append('data_documento', metadata.data_documento);
      if (metadata?.validade_ate) formData.append('validade_ate', metadata.validade_ate);
      if (metadata?.observacoes) formData.append('observacoes', metadata.observacoes);
      
      const res = await fetch('/api/v2/certificados/upload', {
        method: 'POST',
        body: formData
      });
      
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Erro ao fazer upload');
      }
      
      await carregar();
      return await res.json();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao fazer upload';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (qualificacao_id) {
      carregar();
    }
  }, [qualificacao_id]);

  return { certificados, loading, error, gerar, download, deletar, carregar, upload };
}
