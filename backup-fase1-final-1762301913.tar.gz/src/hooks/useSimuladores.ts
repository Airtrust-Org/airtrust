import { useState, useEffect } from 'react';
import { simuladoresService } from '@/services';
import { Simulador, SimuladorCreate, SimuladorUpdate } from '@/types';

export const useSimuladores = () => {
  const [simuladores, setSimuladores] = useState<Simulador[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await simuladoresService.listar();
      setSimuladores(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar simuladores');
    } finally {
      setLoading(false);
    }
  };

  const criar = async (data: SimuladorCreate) => {
    setLoading(true);
    try {
      const novo = await simuladoresService.criar(data);
      setSimuladores([...simuladores, novo]);
      return novo;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const atualizar = async (id: string, data: SimuladorUpdate) => {
    setLoading(true);
    try {
      const atualizado = await simuladoresService.atualizar(id, data);
      setSimuladores(simuladores.map(s => s.id === id ? atualizado : s));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const excluir = async (id: string) => {
    setLoading(true);
    try {
      await simuladoresService.excluir(id);
      setSimuladores(simuladores.filter(s => s.id !== id));
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return {
    simuladores,
    loading,
    error,
    carregar,
    criar,
    atualizar,
    excluir
  };
};
