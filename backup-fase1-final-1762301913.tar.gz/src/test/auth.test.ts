import { describe, it, expect, beforeEach, vi } from 'vitest';
import { AuthService } from '../worker/services/auth-service';

const mockDB = {
  prepare: vi.fn().mockReturnValue({
    bind: vi.fn().mockReturnValue({
      first: vi.fn(),
      all: vi.fn(),
      run: vi.fn()
    })
  })
};

describe('AuthService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('authenticate', () => {
    it('should authenticate valid user', async () => {
      const mockUser = {
        id: 'user123',
        name: 'Test User',
        email: 'test@example.com',
        password_hash: 'password123', // Em produção seria hash bcrypt
        perfil: 'ADMIN',
        funcionario_id: 1,
        active: 1
      };

      mockDB.prepare().bind().first.mockResolvedValue(mockUser);

      const credentials = {
        email: 'test@example.com',
        password: 'password123'
      };

      const result = await AuthService.authenticate(credentials, mockDB);

      expect(result.success).toBe(true);
      expect(result.user).toBeDefined();
      expect(result.token).toBeDefined();
      expect(result.user?.id).toBe('user123');
      expect(result.user?.name).toBe('Test User');
    });

    it('should reject invalid credentials', async () => {
      mockDB.prepare().bind().first.mockResolvedValue(null);

      const credentials = {
        email: 'invalid@example.com',
        password: 'wrongpassword'
      };

      const result = await AuthService.authenticate(credentials, mockDB);

      expect(result.success).toBe(false);
      expect(result.error).toBe('Credenciais inválidas');
      expect(result.user).toBeUndefined();
      expect(result.token).toBeUndefined();
    });

    it('should reject missing email or password', async () => {
      const result1 = await AuthService.authenticate({ email: '', password: 'test' }, mockDB);
      const result2 = await AuthService.authenticate({ email: 'test@test.com', password: '' }, mockDB);

      expect(result1.success).toBe(false);
      expect(result1.error).toBe('Email e senha são obrigatórios');
      expect(result2.success).toBe(false);
      expect(result2.error).toBe('Email e senha são obrigatórios');
    });

    it('should handle database errors gracefully', async () => {
      mockDB.prepare().bind().first.mockRejectedValue(new Error('Database error'));

      const credentials = {
        email: 'test@example.com',
        password: 'password123'
      };

      const result = await AuthService.authenticate(credentials, mockDB);

      expect(result.success).toBe(false);
      expect(result.error).toBe('Erro interno do servidor');
    });
  });

  describe('verifyToken', () => {
    it('should verify valid token', async () => {
      const result = await AuthService.verifyToken('invalid_token');
      expect(result.valid).toBe(false);
    });

    it('should reject empty token', async () => {
      const result = await AuthService.verifyToken('');
      expect(result.valid).toBe(false);
    });
  });

  describe('hasPermission', () => {
    it('should grant access to admin for any role', () => {
      const adminUser = {
        id: '1',
        name: 'Admin',
        perfil: 'ADMIN' as const,
        funcionario_id: 1
      };

      expect(AuthService.hasPermission(adminUser, ['ADMIN'])).toBe(true);
      expect(AuthService.hasPermission(adminUser, ['COMPLIANCE'])).toBe(false);
      expect(AuthService.hasPermission(adminUser, ['ADMIN', 'COMPLIANCE'])).toBe(true);
    });

    it('should grant access based on user role', () => {
      const complianceUser = {
        id: '2',
        name: 'Compliance User',
        perfil: 'COMPLIANCE' as const,
        funcionario_id: 2
      };

      expect(AuthService.hasPermission(complianceUser, ['COMPLIANCE'])).toBe(true);
      expect(AuthService.hasPermission(complianceUser, ['ADMIN'])).toBe(false);
      expect(AuthService.hasPermission(complianceUser, ['COMPLIANCE', 'GESTOR'])).toBe(true);
    });
  });
});
