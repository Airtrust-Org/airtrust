import { describe, it, expect, beforeEach, vi } from 'vitest';
import { Logger, LogLevel } from '../worker/utils/logger';

const originalConsole = {
  log: console.log,
  error: console.error,
  warn: console.warn,
  debug: console.debug
};

describe('Logger', () => {
  beforeEach(() => {
    Logger.setLevel(LogLevel.DEBUG);
    Logger.setProduction(false);
    
    console.log = vi.fn();
    console.error = vi.fn();
    console.warn = vi.fn();
    console.debug = vi.fn();
  });

  afterEach(() => {
    Object.assign(console, originalConsole);
  });

  describe('log levels', () => {
    it('should respect log level filtering', () => {
      Logger.setLevel(LogLevel.WARN);

      Logger.debug('debug message');
      Logger.info('info message');
      Logger.warn('warn message');
      Logger.error('error message');

      expect(console.debug).not.toHaveBeenCalled();
      expect(console.log).not.toHaveBeenCalled();
      expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('warn message'));
      expect(console.error).toHaveBeenCalledWith(expect.stringContaining('error message'));
    });

    it('should log all levels when set to DEBUG', () => {
      Logger.setLevel(LogLevel.DEBUG);

      Logger.debug('debug message');
      Logger.info('info message');
      Logger.warn('warn message');
      Logger.error('error message');

      expect(console.debug).toHaveBeenCalledWith(expect.stringContaining('debug message'));
      expect(console.log).toHaveBeenCalledWith(expect.stringContaining('info message'));
      expect(console.warn).toHaveBeenCalledWith(expect.stringContaining('warn message'));
      expect(console.error).toHaveBeenCalledWith(expect.stringContaining('error message'));
    });
  });

  describe('production mode', () => {
    it('should use structured logging in production', () => {
      Logger.setProduction(true);

      Logger.info('test message', { userId: '123', action: 'test' });

      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('"level":"info"')
      );
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('"message":"test message"')
      );
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('"userId":"123"')
      );
    });

    it('should not log debug messages in production', () => {
      Logger.setProduction(true);

      Logger.debug('debug message');

      expect(console.debug).not.toHaveBeenCalled();
    });
  });

  describe('context logging', () => {
    it('should include context in log messages', () => {
      const context = {
        userId: '123',
        ip: '192.168.1.1',
        path: '/api/test'
      };

      Logger.info('test message', context);

      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('userId')
      );
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('192.168.1.1')
      );
    });
  });

  describe('error logging', () => {
    it('should log error objects with stack trace', () => {
      const error = new Error('Test error');
      error.stack = 'Error: Test error\n    at test.js:1:1';

      Logger.error('Error occurred', error);

      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining('Test error')
      );
      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining('Error: Test error')
      );
    });

    it('should handle non-Error objects', () => {
      const errorData = { code: 'ERR001', message: 'Custom error' };

      Logger.error('Custom error occurred', errorData);

      expect(console.error).toHaveBeenCalledWith(
        expect.stringContaining('Custom error occurred')
      );
    });
  });

  describe('audit logging', () => {
    it('should always log audit events regardless of level', () => {
      Logger.setLevel(LogLevel.ERROR);

      Logger.audit('USER_LOGIN', 'user123', { ip: '192.168.1.1' });

      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('USER_LOGIN')
      );
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('user123')
      );
    });
  });

  describe('performance logging', () => {
    it('should calculate and log duration', () => {
      const startTime = Date.now() - 100; // 100ms ago

      Logger.performance('test_operation', startTime, { operation: 'test' });

      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('Performance: test_operation completed')
      );
      expect(console.log).toHaveBeenCalledWith(
        expect.stringContaining('ms')
      );
    });
  });

  describe('validation logging', () => {
    it('should log valid validations as debug', () => {
      Logger.validation('email', 'test@example.com', true);

      expect(console.debug).toHaveBeenCalledWith(
        expect.stringContaining('Validation VALID: email')
      );
    });

    it('should log invalid validations as warning', () => {
      Logger.validation('email', 'invalid-email', false, ['Invalid format']);

      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('Validation INVALID: email')
      );
      expect(console.warn).toHaveBeenCalledWith(
        expect.stringContaining('Invalid format')
      );
    });
  });
});
