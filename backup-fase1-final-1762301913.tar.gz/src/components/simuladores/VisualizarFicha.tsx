import { useState, useEffect } from 'react';
import { FileText, Download, Edit, CheckCircle, XCircle, AlertTriangle, Printer } from 'lucide-react';

interface FichaCompleta {
  id: number;
  uuid: string;
  status: string;
  aprovado: boolean;
  nota_final: number;
  nota_minima: number;
  aluno_nome: string;
  aluno_matricula: string;
  aluno_nome_validado: string;
  instrutor_nome: string;
  instrutor_codigo_anac: string;
  template_nome: string;
  sessao_numero: number;
  total_sessoes: number;
  funcao_na_sessao: string;
  carga_horaria_total: number;
  carga_horaria_pf: number;
  carga_horaria_pm: number;
  tempo_acumulado: number;
  simulador_nome: string;
  feedback_instrutor?: string;
  pontos_fortes?: string;
  pontos_melhoria?: string;
  observacoes?: string;
  data_inicio: string;
  data_fim: string;
  created_at: string;
  manobras: ManobrasAvaliacao[];
}

interface ManobrasAvaliacao {
  id: number;
  manobra_id: number;
  manobra_codigo: string;
  manobra_nome: string;
  manobra_descricao: string;
  categoria: string;
  nivel_dificuldade: string;
  pontuacao_minima: number;
  nota: number;
  observacoes: string;
  executada: boolean;
  data_execucao: string;
}

interface VisualizarFichaProps {
  fichaUuid: string;
  onClose?: () => void;
}

export function VisualizarFicha({ fichaUuid, onClose }: VisualizarFichaProps) {
  const [ficha, setFicha] = useState<FichaCompleta | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    carregarFicha();
  }, [fichaUuid]);

  const carregarFicha = async () => {
    try {
      setLoading(true);
      setError(null);
      
      
      const res = await fetch(`/api/v2/simulador/fichas/${fichaUuid}`);
      const data = await res.json();
      
      if (data.success) {
        setFicha(data.data);
      } else {
        setError(data.error || 'Erro ao carregar ficha');
      }
    } catch (error) {
      console.error('[VisualizarFicha] Erro:', error);
      setError('Erro ao carregar ficha');
    } finally {
      setLoading(false);
    }
  };

  const gerarPDF = async () => {
    alert('Geração de PDF em desenvolvimento');
  };

  const imprimir = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando ficha...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-12">
        <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Erro ao carregar ficha</h3>
        <p className="text-gray-600 mb-4">{error}</p>
        <button
          onClick={carregarFicha}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="text-center p-12">
        <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Ficha não encontrada</h3>
        <p className="text-gray-600">A ficha solicitada não existe ou foi excluída.</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 print:p-0">
      {/* Cabeçalho da Ficha */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6 print:border-0">
        <div className="flex items-center justify-between mb-6 print:mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 print:text-xl">
              FTV - Ficha de Treinamento de Voo
            </h1>
            <p className="text-gray-600 mt-1">
              {ficha.template_nome || 'Sessão de Simulador'}
              {ficha.sessao_numero && ficha.total_sessoes && (
                <span> - Sessão {ficha.sessao_numero}/{ficha.total_sessoes}</span>
              )}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              UUID: {ficha.uuid}
            </p>
          </div>
          
          <div className="flex gap-3 print:hidden">
            <button
              onClick={imprimir}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Printer className="w-4 h-4" />
              Imprimir
            </button>
            
            <button
              onClick={gerarPDF}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              Gerar PDF
            </button>
            
            {ficha.status === 'PENDENTE' && (
              <button
                onClick={() => window.location.href = `/simuladores/fichas/${fichaUuid}/avaliar`}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Edit className="w-4 h-4" />
                Avaliar
              </button>
            )}
          </div>
        </div>

        {/* Informações do Aluno e Instrutor */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Aluno</h3>
            <div className="space-y-2">
              <div>
                <span className="text-sm text-gray-600">Nome:</span>
                <p className="font-medium">{ficha.aluno_nome_validado || ficha.aluno_nome}</p>
              </div>
              <div>
                <span className="text-sm text-gray-600">Matrícula:</span>
                <p className="font-medium">{ficha.aluno_matricula}</p>
              </div>
              <div>
                <span className="text-sm text-gray-600">Função:</span>
                <p className="font-medium">{ficha.funcao_na_sessao}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Instrutor</h3>
            <div className="space-y-2">
              <div>
                <span className="text-sm text-gray-600">Nome:</span>
                <p className="font-medium">{ficha.instrutor_nome}</p>
              </div>
              {ficha.instrutor_codigo_anac && (
                <div>
                  <span className="text-sm text-gray-600">Código ANAC:</span>
                  <p className="font-medium">{ficha.instrutor_codigo_anac}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Carga Horária */}
        <div className="border-t border-gray-200 pt-6">
          <h3 className="font-semibold text-gray-900 mb-3">Carga Horária</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-2xl font-bold text-blue-600">{ficha.carga_horaria_total || 0}h</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">PF (Pilot Flying)</p>
              <p className="text-2xl font-bold text-green-600">{ficha.carga_horaria_pf || 0}h</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">PM (Pilot Monitoring)</p>
              <p className="text-2xl font-bold text-purple-600">{ficha.carga_horaria_pm || 0}h</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Tempo Acumulado</p>
              <p className="text-2xl font-bold text-orange-600">{ficha.tempo_acumulado || 0}h</p>
            </div>
          </div>
        </div>
      </div>

      {/* Avaliação de Manobras */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6 print:border-0">
        <h3 className="font-semibold text-gray-900 mb-4">Manobras Avaliadas</h3>
        
        {ficha.manobras && ficha.manobras.length > 0 ? (
          <div className="space-y-3">
            {ficha.manobras.map((manobra) => (
              <div key={manobra.id} className="border border-gray-200 rounded-lg p-4 print:break-inside-avoid">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">
                      {manobra.manobra_codigo} - {manobra.manobra_nome}
                    </p>
                    {manobra.manobra_descricao && (
                      <p className="text-sm text-gray-600 mt-1">{manobra.manobra_descricao}</p>
                    )}
                    {manobra.categoria && (
                      <span className="inline-block mt-2 px-2 py-1 text-xs font-semibold rounded bg-gray-100 text-gray-700">
                        {manobra.categoria}
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Nota</p>
                      <p className={`text-2xl font-bold ${
                        manobra.nota >= 5 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {manobra.nota.toFixed(1)}
                      </p>
                      {manobra.nota < 5 && manobra.executada && (
                        <p className="text-xs text-red-600 font-semibold mt-1">
                          ⚠️ Eliminatória
                        </p>
                      )}
                    </div>
                    
                    {manobra.executada ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <XCircle className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                </div>

                {manobra.observacoes && (
                  <div className="mt-3 p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-700">{manobra.observacoes}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">Nenhuma manobra avaliada ainda</p>
        )}

        {/* Resultado Final */}
        {ficha.status === 'CONCLUIDA' && (
          <div className={`mt-6 p-6 rounded-xl border-2 print:break-inside-avoid ${
            ficha.aprovado 
              ? 'bg-green-50 border-green-300' 
              : 'bg-red-50 border-red-300'
          }`}>
            <div className="flex items-center gap-4 mb-4">
              {ficha.aprovado ? (
                <CheckCircle className="w-12 h-12 text-green-600 flex-shrink-0" />
              ) : (
                <XCircle className="w-12 h-12 text-red-600 flex-shrink-0" />
              )}
              
              <div className="flex-1">
                <h4 className={`text-2xl font-bold ${
                  ficha.aprovado ? 'text-green-900' : 'text-red-900'
                }`}>
                  {ficha.aprovado ? 'APROVADO' : 'REPROVADO'}
                </h4>
                
                <div className="mt-2 space-y-1">
                  <p className="text-lg">
                    Média Geral: <span className="font-semibold">
                      {ficha.nota_final?.toFixed(1) || '0.0'}
                    </span>
                  </p>
                  
                  <p className={`text-lg flex items-center gap-2 ${
                    ficha.nota_minima < 5.0 ? 'text-red-600 font-bold' : 'text-green-600'
                  }`}>
                    Nota Mínima: <span className="font-semibold">
                      {ficha.nota_minima?.toFixed(1) || '0.0'}
                    </span>
                    {ficha.nota_minima < 5.0 && (
                      <span className="text-xs bg-red-200 px-2 py-1 rounded">
                        Critério Eliminatório
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </div>

            {!ficha.aprovado && ficha.nota_minima < 5.0 && (
              <div className="flex items-start gap-2 p-4 bg-red-100 border border-red-300 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-700 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-900">Critério Eliminatório Acionado</p>
                  <p className="text-sm text-red-800 mt-1">
                    Nota mínima de {ficha.nota_minima.toFixed(1)} está abaixo do limite de 5.0 
                    estabelecido pela regulação aeronáutica. O aluno deve repetir o treinamento.
                  </p>
                </div>
              </div>
            )}

            {/* Feedback do Instrutor */}
            {ficha.feedback_instrutor && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-gray-200">
                <p className="font-medium text-gray-900 mb-2">Feedback do Instrutor:</p>
                <p className="text-gray-700">{ficha.feedback_instrutor}</p>
              </div>
            )}

            {ficha.pontos_fortes && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-green-200">
                <p className="font-medium text-green-900 mb-2">✅ Pontos Fortes:</p>
                <p className="text-gray-700">{ficha.pontos_fortes}</p>
              </div>
            )}

            {ficha.pontos_melhoria && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-orange-200">
                <p className="font-medium text-orange-900 mb-2">📝 Pontos de Melhoria:</p>
                <p className="text-gray-700">{ficha.pontos_melhoria}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Botão de Fechar */}
      {onClose && (
        <div className="flex justify-end print:hidden">
          <button
            onClick={onClose}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Fechar
          </button>
        </div>
      )}
    </div>
  );
}
