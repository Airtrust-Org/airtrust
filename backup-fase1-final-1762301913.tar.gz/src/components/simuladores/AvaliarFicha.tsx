import { useState, useEffect } from 'react';
import { Save, CheckCircle, AlertTriangle, X } from 'lucide-react';

interface Manobra {
  id?: number;
  manobra_id: number;
  manobra_codigo: string;
  manobra_nome: string;
  manobra_descricao?: string;
  categoria?: string;
  nivel_dificuldade?: string;
  pontuacao_minima?: number;
  nota: number;
  observacoes: string;
  executada: boolean;
}

interface AvaliarFichaProps {
  fichaUuid: string;
  onSalvar?: () => void;
  onCancelar?: () => void;
}

export function AvaliarFicha({ fichaUuid, onSalvar, onCancelar }: AvaliarFichaProps) {
  const [ficha, setFicha] = useState<any>(null);
  const [manobras, setManobras] = useState<Manobra[]>([]);
  const [feedback, setFeedback] = useState({
    observacoes: '',
    feedback_instrutor: '',
    pontos_fortes: '',
    pontos_melhoria: ''
  });
  const [salvando, setSalvando] = useState(false);
  const [notaMinima, setNotaMinima] = useState(10);
  const [notaMedia, setNotaMedia] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    carregarFicha();
  }, [fichaUuid]);

  useEffect(() => {
    calcularNotas();
  }, [manobras]);

  const carregarFicha = async () => {
    try {
      setLoading(true);
      
      const res = await fetch(`/api/v2/simulador/fichas/${fichaUuid}`);
      const data = await res.json();
      
      if (data.success) {
        setFicha(data.data);
        setManobras(data.data.manobras || []);
      } else {
        alert('Erro ao carregar ficha: ' + data.error);
      }
    } catch (error) {
      console.error('[AvaliarFicha] Erro:', error);
      alert('Erro ao carregar ficha');
    } finally {
      setLoading(false);
    }
  };

  const calcularNotas = () => {
    const notasValidas = manobras.filter(m => m.executada).map(m => m.nota);
    if (notasValidas.length > 0) {
      const minima = Math.min(...notasValidas);
      const media = notasValidas.reduce((a, b) => a + b, 0) / notasValidas.length;
      setNotaMinima(minima);
      setNotaMedia(media);
    } else {
      setNotaMinima(10);
      setNotaMedia(0);
    }
  };

  const atualizarNota = (manobraId: number, nota: number) => {
    setManobras(prev => prev.map(m => 
      m.manobra_id === manobraId ? { ...m, nota, executada: true } : m
    ));
  };

  const atualizarObservacao = (manobraId: number, observacoes: string) => {
    setManobras(prev => prev.map(m => 
      m.manobra_id === manobraId ? { ...m, observacoes } : m
    ));
  };

  const toggleExecutada = (manobraId: number, executada: boolean) => {
    setManobras(prev => prev.map(m => 
      m.manobra_id === manobraId ? { ...m, executada } : m
    ));
  };

  const salvarAvaliacao = async () => {
    try {
      setSalvando(true);

      const notasValidas = manobras.filter(m => m.executada).map(m => m.nota);
      
      if (notasValidas.length === 0) {
        alert('⚠️ Marque ao menos uma manobra como executada');
        return;
      }


      const minima = Math.min(...notasValidas);
      const resultado = minima >= 5.0 ? 'APROVADO' : 'REPROVADO';

      console.log('[AvaliarFicha] Salvando avaliação:', {
        total_manobras: notasValidas.length,
        nota_minima: minima,
        resultado,
        criterio_eliminatorio: minima < 5.0
      });

      const res = await fetch(`/api/v2/simulador/fichas/${fichaUuid}/avaliar`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          manobras: manobras.map(m => ({
            manobra_id: m.manobra_id,
            nota: m.nota || 0,
            observacoes: m.observacoes || '',
            executada: m.executada || false
          })),
          ...feedback,
          resultado_final: resultado
        })
      });

      const data = await res.json();

      if (data.success) {
        const msg = `✅ Avaliação salva com sucesso!\n\n` +
                   `Resultado: ${resultado}\n` +
                   `Nota Mínima: ${minima.toFixed(1)}\n` +
                   `Nota Média: ${(notasValidas.reduce((a, b) => a + b, 0) / notasValidas.length).toFixed(1)}\n\n` +
                   (minima < 5.0 ? '⚠️ Critério eliminatório acionado - Aluno deve repetir o treinamento' : '');
        
        alert(msg);
        
        if (onSalvar) {
          onSalvar();
        } else {
          window.location.href = `/simuladores/fichas/${fichaUuid}`;
        }
      } else {
        alert('❌ Erro ao salvar: ' + data.error);
      }
    } catch (error) {
      console.error('[AvaliarFicha] Erro ao salvar:', error);
      alert('❌ Erro ao salvar avaliação');
    } finally {
      setSalvando(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando ficha...</p>
        </div>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="text-center p-12">
        <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">Ficha não encontrada</h3>
        <p className="text-gray-600">A ficha solicitada não existe ou foi excluída.</p>
      </div>
    );
  }

  const aprovado = notaMinima >= 5.0;
  const temManobrasExecutadas = manobras.some(m => m.executada);

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Cabeçalho */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Avaliar Ficha de Treinamento
            </h1>
            <p className="text-gray-600">
              {ficha.aluno_nome_validado || ficha.aluno_nome} - {ficha.template_nome || 'Sessão de Simulador'}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              UUID: {ficha.uuid}
            </p>
          </div>

          {onCancelar && (
            <button
              onClick={onCancelar}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          )}
        </div>

        {/* Preview do Resultado */}
        {temManobrasExecutadas && (
          <div className={`mt-4 p-4 rounded-lg ${
            aprovado ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center gap-3">
              {aprovado ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-red-600" />
              )}
              <div>
                <p className={`font-bold ${aprovado ? 'text-green-900' : 'text-red-900'}`}>
                  {aprovado ? '✅ APROVADO' : '❌ REPROVADO'}
                </p>
                <p className="text-sm text-gray-700">
                  Média: {notaMedia.toFixed(1)} | 
                  Nota Mínima: <span className={notaMinima < 5 ? 'text-red-600 font-bold' : 'text-green-600'}>
                    {notaMinima.toFixed(1)}
                  </span>
                  {notaMinima < 5 && ' (Critério Eliminatório)'}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Lista de Manobras */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
        <h3 className="font-semibold text-gray-900 mb-4">Manobras</h3>
        
        <div className="space-y-4">
          {manobras.map((manobra) => (
            <div key={manobra.manobra_id} className={`border rounded-lg p-4 ${
              manobra.executada && manobra.nota < 5 ? 'border-red-300 bg-red-50' : 'border-gray-200'
            }`}>
              <div className="flex items-center gap-4 mb-3">
                <input
                  type="checkbox"
                  checked={manobra.executada || false}
                  onChange={(e) => toggleExecutada(manobra.manobra_id, e.target.checked)}
                  className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex-1">
                  <p className="font-medium">{manobra.manobra_codigo} - {manobra.manobra_nome}</p>
                  {manobra.manobra_descricao && (
                    <p className="text-sm text-gray-600 mt-1">{manobra.manobra_descricao}</p>
                  )}
                  {manobra.categoria && (
                    <span className="inline-block mt-2 px-2 py-1 text-xs font-semibold rounded bg-gray-100 text-gray-700">
                      {manobra.categoria}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <label className="text-sm text-gray-600 font-medium">Nota:</label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    step="0.5"
                    value={manobra.nota || 0}
                    onChange={(e) => atualizarNota(manobra.manobra_id, parseFloat(e.target.value) || 0)}
                    className={`w-20 px-3 py-2 border rounded-lg text-center font-bold ${
                      manobra.executada && manobra.nota < 5 
                        ? 'border-red-500 text-red-600 bg-red-50' 
                        : 'border-gray-300'
                    }`}
                    disabled={!manobra.executada}
                  />
                </div>
              </div>

              {manobra.executada && manobra.nota < 5 && (
                <div className="mb-2 p-2 bg-red-100 border border-red-300 rounded flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <p className="text-sm text-red-800 font-semibold">
                    ⚠️ Nota abaixo de 5.0 - Critério eliminatório acionado
                  </p>
                </div>
              )}

              <textarea
                placeholder="Observações sobre esta manobra..."
                value={manobra.observacoes || ''}
                onChange={(e) => atualizarObservacao(manobra.manobra_id, e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                rows={2}
                disabled={!manobra.executada}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Feedback Geral */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
        <h3 className="font-semibold text-gray-900 mb-4">Feedback do Instrutor</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Observações Gerais
            </label>
            <textarea
              value={feedback.observacoes}
              onChange={(e) => setFeedback({ ...feedback, observacoes: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
              placeholder="Observações gerais sobre a sessão..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Feedback do Instrutor
            </label>
            <textarea
              value={feedback.feedback_instrutor}
              onChange={(e) => setFeedback({ ...feedback, feedback_instrutor: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
              placeholder="Avaliação geral do desempenho do aluno..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-green-700 mb-2">
                ✅ Pontos Fortes
              </label>
              <textarea
                value={feedback.pontos_fortes}
                onChange={(e) => setFeedback({ ...feedback, pontos_fortes: e.target.value })}
                className="w-full px-3 py-2 border border-green-300 rounded-lg resize-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                rows={3}
                placeholder="Aspectos em que o aluno se destacou..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-orange-700 mb-2">
                📝 Pontos de Melhoria
              </label>
              <textarea
                value={feedback.pontos_melhoria}
                onChange={(e) => setFeedback({ ...feedback, pontos_melhoria: e.target.value })}
                className="w-full px-3 py-2 border border-orange-300 rounded-lg resize-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                rows={3}
                placeholder="Aspectos que precisam ser aprimorados..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* Botões de Ação */}
      <div className="flex justify-end gap-3">
        <button
          onClick={onCancelar || (() => window.history.back())}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          disabled={salvando}
        >
          Cancelar
        </button>
        
        <button
          onClick={salvarAvaliacao}
          disabled={salvando || !temManobrasExecutadas}
          className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {salvando ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
              Salvando...
            </>
          ) : (
            <>
              <CheckCircle className="w-5 h-5" />
              Finalizar Avaliação
            </>
          )}
        </button>
      </div>
    </div>
  );
}
