export interface NavigationStructure {
  main_menu: MainMenuItem[];
  settings_menu: SettingsMenuItem[];
}

export interface MainMenuItem {
  id: string;
  label: string;
  icon: string;
  path?: string;
  expandable: boolean;
  children?: SubMenuItem[];
  badge?: string;
}

export interface SubMenuItem {
  id: string;
  label: string;
  path: string;
  badge?: string;
}

export interface SettingsMenuItem {
  category: string;
  items: SettingsItem[];
}

export interface SettingsItem {
  id: string;
  label: string;
  path: string;
  component: string;
  description: string;
  permissions_required?: string[];
}

export const NAVIGATION_CONFIG: NavigationStructure = {
  main_menu: [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: 'BarChart3', 
      path: '/', 
      expandable: false 
    },
    { 
      id: 'treinamentos', 
      label: 'Treinamentos', 
      icon: 'BookOpen', 
      path: '/treinamentos', 
      expandable: false 
    },
    {
      id: 'pessoas',
      label: 'Pessoas',
      icon: 'Users',
      expandable: true,
      children: [
        { 
          id: 'funcionarios', 
          label: 'Funcionários', 
          path: '/funcionarios' 
        },
        { 
          id: 'pasta-virtual', 
          label: 'Pasta Virtual', 
          path: '/pasta-virtual' 
        }
      ]
    },
    {
      id: 'escalas',
      label: 'Escalas e FRMS',
      icon: 'Calendar',
      expandable: true,
      children: [
        { 
          id: 'escalas', 
          label: 'Planejamento de Escala', 
          path: '/escalas', 
          badge: 'EM BREVE' 
        },
        { 
          id: 'frms', 
          label: 'FRMS', 
          path: '/frms', 
          badge: 'EM BREVE' 
        }
      ]
    },
    {
      id: 'simuladores',
      label: 'Simuladores',
      icon: 'Calendar',
      expandable: true,
      children: [
        { 
          id: 'simuladores-dashboard', 
          label: 'Dashboard', 
          path: '/simuladores' 
        },
        { 
          id: 'simuladores-cadastros', 
          label: 'Cadastros', 
          path: '/admin/simuladores' 
        },
        { 
          id: 'simuladores-templates', 
          label: 'Templates', 
          path: '/simuladores/templates' 
        }
      ]
    },
    { 
      id: 'minhas-assinaturas', 
      label: 'Minhas Assinaturas', 
      icon: 'CheckCircle', 
      path: '/minhas-assinaturas', 
      expandable: false 
    },
    { 
      id: 'hospedagem', 
      label: 'Hospedagem', 
      icon: 'Building', 
      path: '/hospedagem', 
      expandable: false, 
      badge: 'EM BREVE' 
    }
  ],
  settings_menu: [
    {
      category: 'Cadastros',
      items: [
        {
          id: 'funcoes',
          label: 'Gestão de Funções',
          path: '/configuracoes/funcoes',
          component: 'FuncoesManagement',
          description: 'Gerenciar cargos e funções da organização',
          permissions_required: ['admin']
        },
        {
          id: 'empresa',
          label: 'Empresa',
          path: '/configuracoes/empresa',
          component: 'ConfiguracaoEmpresa',
          description: 'Configurações da empresa e logo',
          permissions_required: ['admin']
        },
        {
          id: 'catalogo-aeronaves',
          label: 'Catálogo de Aeronaves',
          path: '/configuracoes/aeronaves',
          component: 'AeronavesCRUD',
          description: 'Gerenciar aeronaves da frota',
          permissions_required: ['admin']
        }
      ]
    },
    {
      category: 'Sistema',
      items: [
        {
          id: 'certificado',
          label: 'Configuração de Certificados',
          path: '/configuracoes/certificado',
          component: 'ConfiguracaoCertificado',
          description: 'Personalizar templates e logos de certificados',
          permissions_required: ['admin']
        },
        {
          id: 'limpar-dados',
          label: 'Limpeza de Dados',
          path: '/configuracoes/limpar-dados',
          component: 'LimparDados',
          description: 'Remover dados por módulo (ADMIN)',
          permissions_required: ['admin']
        },
        {
          id: 'hard-refresh',
          label: 'Hard Refresh',
          path: '/configuracoes/hard-refresh',
          component: 'HardRefresh',
          description: 'Limpar cache do navegador e recarregar a aplicação',
          permissions_required: ['admin']
        },
        {
          id: 'usuarios',
          label: 'Usuários e Permissões',
          path: '/configuracoes/usuarios',
          component: 'UserManagement',
          description: 'Gerenciar usuários e suas permissões',
          permissions_required: ['admin']
        },
        {
          id: 'auditoria',
          label: 'Logs de Auditoria',
          path: '/configuracoes/auditoria',
          component: 'AuditLogs',
          description: 'Visualizar logs de auditoria do sistema',
          permissions_required: ['admin']
        }
      ]
    }
  ]
};
