import '@/react-app/styles/design-system';

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Toaster } from 'react-hot-toast';
import App from '@/react-app/App.tsx';

// 🎨 Design System - Global Styles
import '@/react-app/styles/globals.css';
import '@/react-app/styles/design-tokens.css';
import '@/react-app/index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
    <Toaster position="top-right" />
  </StrictMode>,
);
