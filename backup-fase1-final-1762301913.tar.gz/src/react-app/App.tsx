import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import Layout from '@/react-app/components/Layout';
import ProtectedRoute from '@/react-app/components/ProtectedRoute';
import { ToastProvider } from '@/react-app/contexts/ToastContext';
import ErrorBoundary from '@/react-app/components/ErrorBoundary';

import Dashboard from '@/react-app/pages/Dashboard';
import Login from '@/react-app/pages/Login';

const FuncionariosDashboard = lazy(
  () => import('@/react-app/pages/funcionarios/FuncionariosDashboard'),
);
const Funcoes = lazy(() => import('@/react-app/pages/Funcoes'));
const Sistema = lazy(() => import('@/react-app/pages/Sistema'));
const PastaVirtual = lazy(() => import('@/react-app/pages/PastaVirtual'));
const PastaVirtualLanding = lazy(() => import('@/react-app/pages/PastaVirtualLanding'));
const DashboardTreinamentos = lazy(() => import('@/react-app/pages/DashboardTreinamentos'));
const QualificacoesList = lazy(
  () => import('@/react-app/components/treinamentos/CertificacoesList'),
); // TODO: renomear arquivo
const ComplianceMatrix = lazy(() => import('@/react-app/components/compliance/ComplianceMatrix'));
const RelatoriosDashboard = lazy(() => import('@/react-app/pages/relatorios/Dashboard'));
const Aeronaves = lazy(() => import('@/react-app/pages/Aeronaves'));
const ConfiguracoesLayout = lazy(() => import('@/react-app/pages/ConfiguracoesLayout'));
const Simuladores = lazy(() => import('@/react-app/pages/Simuladores'));

const AgendarSimulador = lazy(() => import('@/react-app/pages/AgendarSimulador'));
const MinhasAssinaturas = lazy(() => import('@/react-app/pages/MinhasAssinaturas'));
const SimuladoresTemplates = lazy(() => import('@/react-app/pages/SimuladoresTemplates'));
const BackupRestore = lazy(() => import('@/react-app/pages/BackupRestoreNovo'));
const VisualizarFichaSimulador = lazy(() => import('@/react-app/pages/VisualizarFichaSimulador'));
const AvaliarFichaSimulador = lazy(() => import('@/react-app/pages/AvaliarFichaSimulador'));
const EditarFichaSimulador = lazy(() => import('@/react-app/pages/EditarFichaSimulador'));
const Agendamento = lazy(() => import('@/react-app/pages/Agendamento'));
const Templates = lazy(() => import('@/react-app/pages/simuladores/Templates'));
const Treinamentos = lazy(() => import('@/react-app/pages/Treinamentos'));
const Manobras = lazy(() => import('@/react-app/pages/Manobras'));
const QualificacoesMain = lazy(() => import('@/react-app/pages/qualificacoes/QualificacoesMain'));
const HabilitacoesMain = lazy(() => import('@/react-app/pages/qualificacoes/HabilitacoesMain'));
const QualificacaoEditar = lazy(() => import('./pages/QualificacaoEditar'));
const PaginaQualificacao = lazy(() => import('@/pages/PaginaQualificacao'));
const LimparDados = lazy(() => import('@/react-app/pages/Configuracoes/LimparDados'));
const ConfiguracaoCertificado = lazy(() => import('@/react-app/pages/ConfiguracaoCertificado'));
const Empresas = lazy(() => import('@/react-app/pages/Empresas'));

const SimuladorDashboard = lazy(() => import('@/react-app/pages/simuladores/Dashboard'));
const SimuladorLista = lazy(() => import('@/react-app/pages/simuladores/Lista'));
const FormSimulador = lazy(() => import('@/react-app/pages/simuladores/FormSimulador'));
const AgendaSemanal = lazy(() => import('@/react-app/pages/simuladores/AgendaSemanal'));
const DetalhesSessao = lazy(() => import('@/react-app/pages/simuladores/DetalhesSessao'));
const ExecutarSessao = lazy(() => import('@/react-app/pages/simuladores/ExecutarSessao'));
const AprovarSessao = lazy(() => import('@/react-app/pages/simuladores/AprovarSessao'));
const HistoricoFuncionario = lazy(
  () => import('@/react-app/pages/simuladores/HistoricoFuncionario'),
);
const NovoAgendamento = lazy(() => import('@/react-app/pages/simuladores/NovoAgendamento'));
const ImportarRelacoesInteligente = lazy(
  () => import('@/react-app/pages/simuladores/ImportarRelacoesInteligente'),
);
const ImportarQualificacoes = lazy(
  () => import('@/react-app/pages/qualificacoes/ImportarQualificacoes'),
);
const EditarModeloSessao = lazy(() => import('@/react-app/pages/simuladores/EditarModeloSessao'));

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="relative">
        <div className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
        <div className="absolute inset-0 w-12 h-12 border-4 border-transparent border-r-blue-400 rounded-full animate-spin animation-delay-150"></div>
      </div>
    </div>
  );
}

function LazyRoute({ children }: { children: React.ReactNode }) {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingSpinner />}>{children}</Suspense>
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Router>
        <Routes>
          {/* Rota pública de login */}
          <Route path="/login" element={<Login />} />

          {/* Rotas protegidas */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route index element={<Dashboard />} />

            {/* Rotas com lazy loading */}
            <Route
              path="funcionarios"
              element={
                <LazyRoute>
                  <FuncionariosDashboard />
                </LazyRoute>
              }
            />
            <Route
              path="funcionarios/:funcionarioId/pasta"
              element={
                <LazyRoute>
                  <PastaVirtual />
                </LazyRoute>
              }
            />
            <Route
              path="pasta-virtual/:funcionarioId"
              element={
                <LazyRoute>
                  <PastaVirtual />
                </LazyRoute>
              }
            />
            <Route
              path="pasta-virtual"
              element={
                <LazyRoute>
                  <PastaVirtualLanding />
                </LazyRoute>
              }
            />
            <Route
              path="funcoes"
              element={
                <LazyRoute>
                  <Funcoes />
                </LazyRoute>
              }
            />
            <Route
              path="sistema"
              element={
                <LazyRoute>
                  <Sistema />
                </LazyRoute>
              }
            />
            <Route
              path="treinamentos"
              element={
                <LazyRoute>
                  <Treinamentos />
                </LazyRoute>
              }
            />
            <Route
              path="treinamentos/dashboard"
              element={
                <LazyRoute>
                  <DashboardTreinamentos />
                </LazyRoute>
              }
            />
            <Route
              path="manobras"
              element={
                <LazyRoute>
                  <Manobras />
                </LazyRoute>
              }
            />
            <Route
              path="empresas"
              element={
                <LazyRoute>
                  <Empresas />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes"
              element={
                <LazyRoute>
                  <QualificacoesMain />
                </LazyRoute>
              }
            />
            <Route
              path="habilitacoes"
              element={
                <LazyRoute>
                  <HabilitacoesMain />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes/:id"
              element={
                <LazyRoute>
                  <PaginaQualificacao />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes/nova"
              element={
                <LazyRoute>
                  <QualificacaoEditar />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes/editar/:id"
              element={
                <LazyRoute>
                  <QualificacaoEditar />
                </LazyRoute>
              }
            />
            <Route
              path="treinamentos/qualificacoes"
              element={
                <LazyRoute>
                  <QualificacoesList />
                </LazyRoute>
              }
            />
            <Route
              path="treinamentos/matriz-compliance"
              element={
                <LazyRoute>
                  <ComplianceMatrix />
                </LazyRoute>
              }
            />
            <Route
              path="relatorios"
              element={
                <LazyRoute>
                  <RelatoriosDashboard />
                </LazyRoute>
              }
            />
            <Route
              path="aeronaves"
              element={
                <LazyRoute>
                  <Aeronaves />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores"
              element={
                <LazyRoute>
                  <Simuladores />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/agendamento"
              element={
                <LazyRoute>
                  <AgendarSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/templates"
              element={
                <LazyRoute>
                  <Templates />
                </LazyRoute>
              }
            />
            <Route
              path="agendamento"
              element={
                <LazyRoute>
                  <Agendamento />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores-templates"
              element={
                <LazyRoute>
                  <SimuladoresTemplates />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores-agendamento-avancado"
              element={
                <LazyRoute>
                  <AgendarSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simulador/agendar"
              element={
                <LazyRoute>
                  <AgendarSimulador />
                </LazyRoute>
              }
            />

            {/* Rotas padronizadas para simuladores */}
            <Route
              path="simuladores/ficha/:uuid"
              element={
                <LazyRoute>
                  <VisualizarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/ficha/:uuid/visualizar"
              element={
                <LazyRoute>
                  <VisualizarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/ficha/:uuid/editar"
              element={
                <LazyRoute>
                  <EditarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/ficha/:uuid/avaliar"
              element={
                <LazyRoute>
                  <AvaliarFichaSimulador />
                </LazyRoute>
              }
            />

            {/* Rotas com fichas (plural) - NOVAS */}
            <Route
              path="simuladores/fichas/:uuid"
              element={
                <LazyRoute>
                  <VisualizarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/fichas/:uuid/visualizar"
              element={
                <LazyRoute>
                  <VisualizarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/fichas/:uuid/editar"
              element={
                <LazyRoute>
                  <EditarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/fichas/:uuid/avaliar"
              element={
                <LazyRoute>
                  <AvaliarFichaSimulador />
                </LazyRoute>
              }
            />

            <Route
              path="simuladores/agendamento/:id/editar"
              element={
                <LazyRoute>
                  <AgendarSimulador />
                </LazyRoute>
              }
            />

            {/* Novo módulo simuladores completo */}
            <Route
              path="simuladores/dashboard"
              element={
                <LazyRoute>
                  <SimuladorDashboard />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/lista"
              element={
                <LazyRoute>
                  <SimuladorLista />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/novo"
              element={
                <LazyRoute>
                  <FormSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/:id/editar"
              element={
                <LazyRoute>
                  <FormSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/agenda"
              element={
                <LazyRoute>
                  <AgendaSemanal />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/sessoes/:id"
              element={
                <LazyRoute>
                  <DetalhesSessao />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/sessoes/:id/executar"
              element={
                <LazyRoute>
                  <ExecutarSessao />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/sessoes/:id/aprovar"
              element={
                <LazyRoute>
                  <AprovarSessao />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/funcionario/:funcionario_id"
              element={
                <LazyRoute>
                  <HistoricoFuncionario />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/:simuladorId/agendar"
              element={
                <LazyRoute>
                  <NovoAgendamento />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/importar-relacoes"
              element={
                <LazyRoute>
                  <ImportarRelacoesInteligente />
                </LazyRoute>
              }
            />
            <Route
              path="simuladores/modelos/:id/editar"
              element={
                <LazyRoute>
                  <EditarModeloSessao />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes/importar"
              element={
                <LazyRoute>
                  <ImportarQualificacoes />
                </LazyRoute>
              }
            />
            <Route
              path="qualificacoes/importar-tipos"
              element={
                <LazyRoute>
                  <ImportarQualificacoes />
                </LazyRoute>
              }
            />

            {/* Rotas de compatibilidade */}
            <Route
              path="visualizar-ficha/:uuid"
              element={
                <LazyRoute>
                  <VisualizarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="editar-ficha/:uuid"
              element={
                <LazyRoute>
                  <EditarFichaSimulador />
                </LazyRoute>
              }
            />
            <Route
              path="avaliar-ficha/:uuid"
              element={
                <LazyRoute>
                  <AvaliarFichaSimulador />
                </LazyRoute>
              }
            />

            <Route
              path="minhas-assinaturas"
              element={
                <LazyRoute>
                  <MinhasAssinaturas />
                </LazyRoute>
              }
            />
            <Route
              path="backup"
              element={
                <LazyRoute>
                  <BackupRestore />
                </LazyRoute>
              }
            />
            <Route
              path="configuracoes/limpar-dados"
              element={
                <LazyRoute>
                  <LimparDados />
                </LazyRoute>
              }
            />
            <Route
              path="configuracoes/certificado"
              element={
                <LazyRoute>
                  <ConfiguracaoCertificado />
                </LazyRoute>
              }
            />
          </Route>

          {/* Configurações em rota separada */}
          <Route
            path="/configuracoes/*"
            element={
              <LazyRoute>
                <ConfiguracoesLayout />
              </LazyRoute>
            }
          />
        </Routes>
      </Router>
    </ToastProvider>
  );
}
