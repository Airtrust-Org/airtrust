/**
 * Serviço de Simuladores - CONSOLIDADO
 * Usa o novo endpoint /api/v2/simuladores-consolidado
 */

import api from './api';

const BASE_URL = '/api/v2/simuladores-consolidado';

export const simuladoresConsolidadoService = {
  listar: async (filtros?: any) => {
    const params = new URLSearchParams();
    if (filtros?.tipo) params.append('tipo', filtros.tipo);
    if (filtros?.status) params.append('status', filtros.status);
    if (filtros?.localizacao) params.append('localizacao', filtros.localizacao);
    
    return api.get(`${BASE_URL}/listar?${params}`);
  },

  buscarPorId: async (id: number) => {
    return api.get(`${BASE_URL}/${id}`);
  },

  criar: async (data: any) => {
    return api.post(`${BASE_URL}`, data);
  },

  atualizar: async (id: number, data: any) => {
    return api.put(`${BASE_URL}/${id}`, data);
  },

  excluir: async (id: number) => {
    return api.delete(`${BASE_URL}/${id}`);
  },

  manobras: {
    listar: async () => {
      return api.get(`${BASE_URL}/manobras/listar`);
    },

    buscarPorId: async (id: number) => {
      return api.get(`${BASE_URL}/manobras/${id}`);
    },

    criar: async (data: any) => {
      return api.post(`${BASE_URL}/manobras`, data);
    },

    atualizar: async (id: number, data: any) => {
      return api.put(`${BASE_URL}/manobras/${id}`, data);
    },

    excluir: async (id: number) => {
      return api.delete(`${BASE_URL}/manobras/${id}`);
    }
  },

  templates: {
    listar: async () => {
      return api.get(`${BASE_URL}/templates-sessao`);
    },

    buscarPorId: async (id: number) => {
      return api.get(`${BASE_URL}/templates-sessao/${id}`);
    }
  },

  agendamentos: {
    listar: async (filtros?: any) => {
      const params = new URLSearchParams();
      if (filtros?.simulador_id) params.append('simulador_id', filtros.simulador_id);
      if (filtros?.data) params.append('data', filtros.data);
      
      return api.get(`${BASE_URL}/agendamentos?${params}`);
    },

    criar: async (data: any) => {
      return api.post(`${BASE_URL}/agendamentos`, data);
    },

    atualizar: async (id: number, data: any) => {
      return api.put(`${BASE_URL}/agendamentos/${id}`, data);
    },

    excluir: async (id: number) => {
      return api.delete(`${BASE_URL}/agendamentos/${id}`);
    }
  },

  fichas: {
    listar: async () => {
      return api.get(`${BASE_URL}/fichas`);
    },

    criar: async (data: any) => {
      return api.post(`${BASE_URL}/fichas`, data);
    }
  },

  sessoes: {
    listar: async () => {
      return api.get(`${BASE_URL}/sessoes`);
    }
  },

  notificacoes: {
    listar: async (usuarioId: number) => {
      return api.get(`${BASE_URL}/notificacoes/${usuarioId}`);
    },

    marcarLida: async (usuarioId: number, notificacaoId: number) => {
      return api.post(`${BASE_URL}/notificacoes/${usuarioId}/marcar-lida/${notificacaoId}`);
    }
  },

  progresso: {
    geral: async (colaboradorId: number) => {
      return api.get(`${BASE_URL}/progresso/${colaboradorId}`);
    },

    especifico: async (colaboradorId: number, treinamentoId: number) => {
      return api.get(`${BASE_URL}/progresso/${colaboradorId}/${treinamentoId}`);
    }
  },

  relatorios: {
    uso: async () => {
      return api.get(`${BASE_URL}/relatorios/uso`);
    },

    estatisticas: async () => {
      return api.get(`${BASE_URL}/relatorios/estatisticas`);
    }
  },

  equipamentos: {
    listar: async () => {
      return api.get(`${BASE_URL}/equipamentos`);
    },

    buscarPorId: async (id: number) => {
      return api.get(`${BASE_URL}/equipamentos/${id}`);
    }
  }
};

export default simuladoresConsolidadoService;
