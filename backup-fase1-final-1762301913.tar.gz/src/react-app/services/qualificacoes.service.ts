import api from './api';
import { Qualificacao, QualificacaoCreate, QualificacaoUpdate, ImportResult, FiltrosQualificacoes, PaginacaoParams, DashboardStats } from '@/types';

export const qualificacoesService = {
  listar: async (filtros?: FiltrosQualificacoes, paginacao?: PaginacaoParams): Promise<Qualificacao[]> => {
    const params = new URLSearchParams();

    if (filtros?.search) params.append('search', filtros.search);
    if (filtros?.tipo_qualificacao) params.append('tipo_qualificacao', filtros.tipo_qualificacao);
    if (filtros?.status) params.append('status', filtros.status);
    if (paginacao?.page) params.append('page', paginacao.page.toString());
    if (paginacao?.limit) params.append('limit', paginacao.limit.toString());

    return api.get(`/qualificacoes?${params}`);
  },

  dashboard: async (): Promise<DashboardStats> => {
    return api.get('/qualificacoes/dashboard');
  },

  buscarPorId: async (id: string): Promise<Qualificacao> => {
    return api.get(`/qualificacoes/${id}`);
  },

  criar: async (data: QualificacaoCreate): Promise<Qualificacao> => {
    return api.post('/qualificacoes', data);
  },

  atualizar: async (id: string, data: QualificacaoUpdate): Promise<Qualificacao> => {
    return api.put(`/qualificacoes/${id}`, data);
  },

  excluir: async (id: string): Promise<void> => {
    return api.delete(`/qualificacoes/${id}`);
  },

  importar: async (data: any[]): Promise<ImportResult> => {
    return api.post('/qualificacoes/import', { qualificacoes: data });
  },

  exportar: async (): Promise<Blob> => {
    return api.get('/qualificacoes/export', { responseType: 'blob' });
  }
};
