
import { useState } from 'react';
import { Upload, Download, X, AlertCircle, CheckCircle } from 'lucide-react';
import Papa from 'papaparse';
import { showToast } from '../utils/toast';

interface ImportarCSVModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  endpoint: string;
  templateEndpoint: string;
  title: string;
}

export default function ImportarCSVModal({
  isOpen,
  onClose,
  onSuccess,
  endpoint,
  templateEndpoint,
  title
}: ImportarCSVModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<any>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (!selectedFile.name.endsWith('.csv')) {
        showToast.error('Por favor, selecione um arquivo CSV');
        return;
      }
      setFile(selectedFile);
      setResult(null);
    }
  };

  const handleImport = async () => {
    if (!file) {
      showToast.error('Selecione um arquivo CSV');
      return;
    }

    setImporting(true);

    try {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: async (results) => {
          try {
            const response = await fetch(endpoint, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ dados: results.data })
            });

            const data = await response.json();

            if (data.success) {
              setResult(data);
              showToast.success(`${data.importados} registros importados com sucesso!`);
              
              if (data.importados > 0) {
                setTimeout(() => {
                  onSuccess();
                  handleClose();
                }, 2000);
              }
            } else {
              showToast.error(data.error || 'Erro ao importar');
            }
          } catch (error) {
            console.error('Erro ao importar:', error);
            showToast.error('Erro ao processar importação');
          } finally {
            setImporting(false);
          }
        },
        error: (error) => {
          console.error('Erro ao ler CSV:', error);
          showToast.error('Erro ao ler arquivo CSV');
          setImporting(false);
        }
      });
    } catch (error) {
      console.error('Erro:', error);
      showToast.error('Erro ao processar arquivo');
      setImporting(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setResult(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Download Template */}
        <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start gap-3">
            <Download className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-medium text-blue-900 mb-1">
                Baixe o template CSV
              </h3>
              <p className="text-sm text-blue-700 mb-3">
                Use nosso template para garantir que os dados estejam no formato correto
              </p>
              <a
                href={templateEndpoint}
                download
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
              >
                <Download className="w-4 h-4" />
                Baixar Template
              </a>
            </div>
          </div>
        </div>

        {/* Upload File */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Selecione o arquivo CSV
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <input
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
              id="csv-upload"
            />
            <label
              htmlFor="csv-upload"
              className="cursor-pointer inline-block px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Escolher Arquivo
            </label>
            {file && (
              <p className="mt-3 text-sm text-gray-600">
                Arquivo selecionado: <span className="font-medium">{file.name}</span>
              </p>
            )}
          </div>
        </div>

        {/* Result */}
        {result && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <h3 className="font-medium text-gray-900 mb-3">Resultado da Importação</h3>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center p-3 bg-white rounded-lg border border-gray-200">
                <div className="text-2xl font-bold text-gray-900">{result.total}</div>
                <div className="text-sm text-gray-600">Total</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="text-2xl font-bold text-green-600">{result.importados}</div>
                <div className="text-sm text-green-700">Importados</div>
              </div>
              <div className="text-center p-3 bg-red-50 rounded-lg border border-red-200">
                <div className="text-2xl font-bold text-red-600">{result.erros}</div>
                <div className="text-sm text-red-700">Erros</div>
              </div>
            </div>

            {result.detalhes?.erros && result.detalhes.erros.length > 0 && (
              <details className="mt-4">
                <summary className="cursor-pointer font-medium text-red-600 hover:text-red-700">
                  Ver erros ({result.detalhes.erros.length})
                </summary>
                <div className="mt-3 max-h-40 overflow-y-auto">
                  {result.detalhes.erros.map((erro: any, i: number) => (
                    <div key={i} className="flex items-start gap-2 py-2 border-b border-gray-200 last:border-0">
                      <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <span className="font-medium">Linha {erro.linha}:</span>{' '}
                        <span className="text-gray-600">{erro.erro}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </details>
            )}

            {result.detalhes?.sucessos && result.detalhes.sucessos.length > 0 && (
              <div className="mt-3 flex items-center gap-2 text-green-600">
                <CheckCircle className="w-5 h-5" />
                <span className="text-sm font-medium">
                  {result.detalhes.sucessos.length} registros importados com sucesso!
                </span>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium"
          >
            Fechar
          </button>
          <button
            onClick={handleImport}
            disabled={!file || importing}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
          >
            {importing ? 'Importando...' : 'Importar'}
          </button>
        </div>
      </div>
    </div>
  );
}
