import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { Upload, Download, FileSpreadsheet, CheckCircle, XCircle, AlertCircle, Clock } from 'lucide-react';

interface ImportacaoPadraoProps {
  titulo: string;
  descricao: string;
  apiEndpoint: string;
  historicoEndpoint?: string;
  templateUrl?: string;
  colunasObrigatorias: string[];
  colunasOpcionais?: string[];
  exemploColunas?: Record<string, string>;
  onImportSuccess?: () => void;
}

export default function ImportacaoPadrao({
  titulo,
  descricao,
  apiEndpoint,
  historicoEndpoint,
  templateUrl,
  colunasObrigatorias,
  colunasOpcionais = [],
  exemploColunas = {},
  onImportSuccess
}: ImportacaoPadraoProps) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [historico, setHistorico] = useState<any[]>([]);

  useEffect(() => {
    if (historicoEndpoint) {
      carregarHistorico();
    }
  }, [historicoEndpoint]);

  const carregarHistorico = async () => {
    try {
      const API_URL = window.location.origin;
      const response = await fetch(`${API_URL}${historicoEndpoint}?limit=10`);
      const data = await response.json();
      if (data.success || data.sucesso) {
        setHistorico(data.importacoes || data.historico || data.data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setResultado(null);
      
      try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        const previewData = jsonData.slice(0, 5).map((row: any) => {
          const newRow = { ...row };
          Object.keys(newRow).forEach(key => {
            const value = newRow[key];
            if (typeof value === 'number' && (key.toLowerCase().includes('data') || key.toLowerCase().includes('validade'))) {
              const date = new Date((value - 25569) * 86400 * 1000);
              const day = String(date.getUTCDate()).padStart(2, '0');
              const month = String(date.getUTCMonth() + 1).padStart(2, '0');
              const year = date.getUTCFullYear();
              newRow[key] = `${day}/${month}/${year}`;
            }
          });
          return newRow;
        });
        
        setPreview(previewData);
        setShowPreview(true);
      } catch (error) {
        console.error('Erro ao gerar preview:', error);
      }
    }
  };

  const handleImport = async () => {
    if (!file) {
      alert('Selecione um arquivo');
      return;
    }

    setLoading(true);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);


      if (jsonData.length > 0) {
        const primeiraLinha: any = jsonData[0];
        const colunasPresentes = Object.keys(primeiraLinha).map(k => k.trim().toLowerCase());
        const colunasObrigatoriasLower = colunasObrigatorias.map(c => c.toLowerCase());
        const colunasFaltando = colunasObrigatoriasLower.filter(col => !colunasPresentes.includes(col));
        
        if (colunasFaltando.length > 0) {
          alert(`❌ Colunas obrigatórias faltando: ${colunasFaltando.join(', ')}\n\n⚠️ Baixe o template correto e use-o como base.`);
          setLoading(false);
          return;
        }
      }

      const todasColunas = [...colunasObrigatorias, ...(colunasOpcionais || [])].map(c => c.toLowerCase());
      
      const processedData = jsonData.map((row: any) => {
        const newRow: any = {};
        Object.keys(row).forEach(key => {
          const cleanKey = key.trim().toLowerCase();
          if (todasColunas.includes(cleanKey)) {
            let value = row[key];
            if (typeof value === 'number' && (cleanKey.includes('data') || cleanKey.includes('validade'))) {
              const date = new Date((value - 25569) * 86400 * 1000);
              const day = String(date.getUTCDate()).padStart(2, '0');
              const month = String(date.getUTCMonth() + 1).padStart(2, '0');
              const year = date.getUTCFullYear();
              value = `${day}/${month}/${year}`;
            }
            newRow[cleanKey] = value;
          }
        });
        return newRow;
      });


      const API_URL = window.location.origin;
      const response = await fetch(`${API_URL}${apiEndpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ dados: processedData }),
      });

      const data = await response.json();

      if (data.success || data.sucesso) {
        setResultado({
          sucesso: true,
          total: data.total || data.importados || processedData.length,
          importados: data.importados || data.total || processedData.length,
          erros: data.erros || 0,
          detalhes: data.detalhes || data.mensagem || 'Importação concluída com sucesso!'
        });
        
        if (onImportSuccess) {
          onImportSuccess();
        }
        
        if (historicoEndpoint) {
          carregarHistorico();
        }
      } else {
        setResultado({
          sucesso: false,
          erro: data.erro || data.error || 'Erro desconhecido',
          detalhes: data.detalhes || data.mensagem || ''
        });
      }
    } catch (error: any) {
      console.error('[IMPORT] Erro:', error);
      setResultado({
        sucesso: false,
        erro: error.message || 'Erro ao processar importação',
        detalhes: 'Verifique o console para mais detalhes'
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadTemplate = () => {
    if (templateUrl) {
      window.open(templateUrl, '_blank');
      return;
    }

    const todasColunas = [...colunasObrigatorias, ...colunasOpcionais];
    const templateData = [exemploColunas];
    
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    XLSX.writeFile(wb, `template_${titulo.toLowerCase().replace(/\s+/g, '_')}.xlsx`);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{titulo}</h1>
        <p className="text-gray-600">{descricao}</p>
      </div>

      {/* Upload Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Importar Arquivo</h2>
          <button
            onClick={downloadTemplate}
            className="flex items-center gap-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            Baixar Template
          </button>
        </div>

        {/* File Input */}
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileChange}
            className="hidden"
            id="file-upload"
          />
          <label htmlFor="file-upload" className="cursor-pointer">
            <FileSpreadsheet className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-lg font-medium text-gray-700 mb-2">
              {file ? file.name : 'Clique para selecionar ou arraste o arquivo Excel'}
            </p>
            <p className="text-sm text-gray-500">
              Apenas arquivos Excel: .xlsx ou .xls
            </p>
          </label>
        </div>

        {/* Colunas Obrigatórias */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">Colunas Obrigatórias:</h3>
          <div className="flex flex-wrap gap-2">
            {colunasObrigatorias.map(col => (
              <span key={col} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {col}
              </span>
            ))}
          </div>
        </div>

        {colunasOpcionais.length > 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-700 mb-2">Colunas Opcionais:</h3>
            <div className="flex flex-wrap gap-2">
              {colunasOpcionais.map(col => (
                <span key={col} className="px-3 py-1 bg-gray-200 text-gray-700 rounded-full text-sm">
                  {col}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Preview */}
        {showPreview && preview.length > 0 && (
          <div className="mt-6">
            <h3 className="font-semibold text-gray-900 mb-3">Preview (primeiras 5 linhas):</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    {Object.keys(preview[0]).map(key => (
                      <th key={key} className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {preview.map((row, idx) => (
                    <tr key={idx}>
                      {Object.values(row).map((value: any, i) => (
                        <td key={i} className="px-4 py-2 whitespace-nowrap text-gray-700">
                          {String(value)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Import Button */}
        <button
          onClick={handleImport}
          disabled={!file || loading}
          className="mt-6 w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors font-medium"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              Processando...
            </>
          ) : (
            <>
              <Upload className="w-5 h-5" />
              Importar Dados
            </>
          )}
        </button>
      </div>

      {/* Resultado */}
      {resultado && (
        <div className={`rounded-lg shadow-sm border p-6 mb-6 ${
          resultado.sucesso ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-start gap-3">
            {resultado.sucesso ? (
              <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
            ) : (
              <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
            )}
            <div className="flex-1">
              <h3 className={`font-semibold mb-2 ${
                resultado.sucesso ? 'text-green-900' : 'text-red-900'
              }`}>
                {resultado.sucesso ? 'Importação Concluída!' : 'Erro na Importação'}
              </h3>
              
              {resultado.sucesso ? (
                <div className="space-y-2">
                  <p className="text-green-800">
                    <strong>Total processado:</strong> {resultado.total || resultado.importados}
                  </p>
                  {resultado.importados && (
                    <p className="text-green-800">
                      <strong>Importados com sucesso:</strong> {resultado.importados}
                    </p>
                  )}
                  {resultado.erros > 0 && (
                    <p className="text-orange-600">
                      <strong>Erros:</strong> {resultado.erros}
                    </p>
                  )}
                  {resultado.detalhes && (
                    <p className="text-green-700 text-sm mt-2">{resultado.detalhes}</p>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-red-800 font-medium">{resultado.erro}</p>
                  {resultado.detalhes && (
                    <p className="text-red-700 text-sm">{resultado.detalhes}</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Histórico */}
      {historicoEndpoint && historico.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Histórico de Importações
          </h2>
          <div className="space-y-3">
            {historico.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">
                    {item.arquivo_nome || item.nome || 'Importação'}
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(item.created_at || item.data).toLocaleString('pt-BR')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {item.total_registros || item.total || item.importados || 0} registros
                  </p>
                  {item.erros > 0 && (
                    <p className="text-sm text-orange-600">{item.erros} erros</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
