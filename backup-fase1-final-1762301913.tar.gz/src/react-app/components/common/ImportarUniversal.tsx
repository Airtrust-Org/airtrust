import React from 'react';
import { Upload, Download } from 'lucide-react';

interface ImportarUniversalProps {
  tipo: 'funcionarios' | 'treinamentos' | 'certificacoes' | 'simuladores' | 'manobras' | 'qualificacoes';
  onImportSuccess: () => void;
}

export const ImportarUniversal: React.FC<ImportarUniversalProps> = ({
  tipo,
  onImportSuccess
}) => {
  const [importing, setImporting] = React.useState(false);
  
  const tipoLabel = {
    funcionarios: 'Funcionários',
    treinamentos: 'Treinamentos',
    certificacoes: 'Certificações',
    simuladores: 'Simuladores',
    manobras: 'Manobras',
    qualificacoes: 'Qualificações'
  }[tipo];
  
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!file.name.endsWith('.csv')) {
      alert('Por favor, selecione um arquivo CSV');
      return;
    }
    
    setImporting(true);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const url = tipo === 'qualificacoes' 
        ? '/api/v2/qualificacoes/importar-json' 
        : `/api/v2/${tipo}/importar`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: formData
      });
      
      const data = await response.json();
      
      if (data.success) {
        onImportSuccess();
      } else {
        alert(`❌ Erro ao importar:\n\n${data.error}`);
      }
    } catch (error) {
      alert(`❌ Erro ao importar:\n\n${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setImporting(false);
      e.target.value = '';
    }
  };
  
  const downloadTemplate = () => {
    window.location.href = `/api/v2/${tipo}/template`;
  };
  
  return (
    <div className="flex gap-2">
      <button
        onClick={downloadTemplate}
        className="flex items-center gap-2 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-50"
        title={`Baixar modelo CSV de ${tipoLabel}`}
      >
        <Download size={18} />
        Baixar Modelo
      </button>
      
      <label className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer ${
        importing 
          ? 'bg-gray-400 cursor-not-allowed'
          : 'bg-blue-600 hover:bg-blue-700'
      } text-white`}>
        {importing ? (
          <>
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            Importando...
          </>
        ) : (
          <>
            <Upload size={18} />
            Importar CSV
          </>
        )}
        <input
          type="file"
          accept=".csv"
          onChange={handleFileSelect}
          disabled={importing}
          className="hidden"
        />
      </label>
    </div>
  );
};
