import { useState, useEffect } from 'react';
import { X, Save, Plus } from 'lucide-react';

const API_BASE_URL = window.location.origin;

interface ModalNovaQualificacaoProps {
  onClose: () => void;
  onSave: () => void;
}

interface TipoQualificacao {
  id: number;
  codigo: string;
  nome: string;
  categoria: string;
  validade_meses: number;
  tipo_vencimento: string;
  carga_horaria: number;
  conteudo_programatico?: string;
}

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  codigo_anac: string;
}

export default function ModalNovaQualificacao({ onClose, onSave }: ModalNovaQualificacaoProps) {
  // Formulário simplificado - versão 2.0
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [tiposQualificacao, setTiposQualificacao] = useState<TipoQualificacao[]>([]);
  const [tipoSelecionado, setTipoSelecionado] = useState<TipoQualificacao | null>(null);

  const [formData, setFormData] = useState({
    funcionario_id: '',
    tipo: '',
    codigo: '',
    nome: '',
    data_conclusao: '',
    data_vencimento: '',
    validade_meses: 12,
    vencimento_tipo: 'DIA_EXATO' as 'DIA_EXATO' | 'FIM_DO_MES',
    resultado: '',
    observacoes: '',
  });

  useEffect(() => {
    carregarDados();
  }, []);

  // Recalcular vencimento quando validade_meses ou vencimento_tipo mudam
  useEffect(() => {
    if (formData.data_conclusao && formData.validade_meses) {
      const novaDataVencimento = calcularVencimento(
        formData.data_conclusao,
        formData.validade_meses,
        formData.vencimento_tipo,
      );
      setFormData((prev) => ({
        ...prev,
        data_vencimento: novaDataVencimento,
      }));
    }
  }, [formData.validade_meses, formData.vencimento_tipo]);

  const carregarDados = async () => {
    try {
      // Carregar funcionários
      const resFuncionarios = await fetch(`${API_BASE_URL}/api/v2/funcionarios?limit=1000`);
      const dataFuncionarios = await resFuncionarios.json();
      if (dataFuncionarios.success) {
        setFuncionarios(dataFuncionarios.data || []);
      }

      // Carregar tipos de qualificação
      const resTipos = await fetch(`${API_BASE_URL}/api/v2/qualificacoes`);
      const dataTipos = await resTipos.json();
      // O endpoint novo retorna o array diretamente
      if (Array.isArray(dataTipos)) {
        setTiposQualificacao(dataTipos || []);
      } else if (dataTipos.data) {
        setTiposQualificacao(dataTipos.data || []);
      } else if (dataTipos.success) {
        setTiposQualificacao(dataTipos.data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      alert('Erro ao carregar dados iniciais');
    } finally {
      setLoading(false);
    }
  };

  const handleTipoChange = (codigo: string) => {
    const tipo = tiposQualificacao.find((t) => t.codigo === codigo);
    setTipoSelecionado(tipo || null);

    if (tipo) {
      const newFormData = {
        ...formData,
        codigo: tipo.codigo,
        tipo: tipo.nome,
        nome: tipo.nome,
        validade_meses: tipo.validade_meses || 12,
        vencimento_tipo: (tipo.tipo_vencimento === 'Mês Seguinte' ? 'FIM_DO_MES' : 'DIA_EXATO') as
          | 'DIA_EXATO'
          | 'FIM_DO_MES',
      };

      // Recalcular vencimento se já tiver data de conclusão
      if (newFormData.data_conclusao) {
        newFormData.data_vencimento = calcularVencimento(
          newFormData.data_conclusao,
          newFormData.validade_meses,
          newFormData.vencimento_tipo,
        );
      }

      setFormData(newFormData);
    }
  };

  const calcularVencimento = (
    dataConclusao: string,
    validadeMeses: number,
    vencimentoTipo: 'DIA_EXATO' | 'FIM_DO_MES',
  ): string => {
    const data = new Date(dataConclusao + 'T00:00:00Z');
    data.setUTCMonth(data.getUTCMonth() + validadeMeses);

    if (vencimentoTipo === 'FIM_DO_MES') {
      const ano = data.getUTCFullYear();
      const mes = data.getUTCMonth();
      const ultimoDia = new Date(Date.UTC(ano, mes + 1, 0));
      return ultimoDia.toISOString().split('T')[0];
    }

    return data.toISOString().split('T')[0];
  };

  const handleDataConclusaoChange = (dataConclusao: string) => {
    const newFormData = { ...formData, data_conclusao: dataConclusao };

    // Calcular vencimento automaticamente se tiver data de conclusão
    if (dataConclusao && newFormData.validade_meses) {
      newFormData.data_vencimento = calcularVencimento(
        dataConclusao,
        newFormData.validade_meses,
        newFormData.vencimento_tipo,
      );
    }

    setFormData(newFormData);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      // Validações
      if (!formData.funcionario_id) {
        alert('Selecione um funcionário');
        setSaving(false);
        return;
      }

      if (!formData.codigo || !formData.tipo) {
        alert('Selecione uma qualificação');
        setSaving(false);
        return;
      }

      if (!formData.data_conclusao) {
        alert('Informe a data de conclusão');
        setSaving(false);
        return;
      }

      const payload = {
        funcionario_id: parseInt(formData.funcionario_id),
        tipo: 'TREINAMENTO', // Tipo padrão
        codigo: formData.codigo,
        nome: formData.nome || null,
        data_conclusao: formData.data_conclusao,
        data_vencimento: formData.data_vencimento || null,
        observacoes: formData.observacoes || null,
      };

      console.log('Enviando payload:', payload);

      const response = await fetch(`${API_BASE_URL}/api/v2/qualificacoes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        alert('Qualificação criada com sucesso!');
        onSave();
        onClose();
      } else {
        console.error('❌ ERRO DA API:', data);
        console.error('📦 Payload enviado:', payload);

        // Mostrar detalhes do erro
        let errorMessage = data.error || 'Erro ao criar qualificação';
        if (data.details && Array.isArray(data.details)) {
          errorMessage +=
            '\n\nDetalhes:\n' +
            data.details
              .map((d: any) => `- ${d.path?.join('.') || 'geral'}: ${d.message}`)
              .join('\n');
        }

        alert(errorMessage);
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('Erro ao salvar qualificação');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2">
            <Plus className="h-5 w-5 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Nova Qualificação</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        {loading ? (
          <div className="p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-600 mt-4">Carregando...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Funcionário - 1 coluna */}
              <div className="md:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Funcionário <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.funcionario_id}
                  onChange={(e) => {
                    setFormData({ ...formData, funcionario_id: e.target.value });
                  }}
                  onBlur={(e) => {
                    // Garantir que o valor permanece
                    if (e.target.value === formData.funcionario_id) {
                      e.target.value = formData.funcionario_id;
                    }
                  }}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione...</option>
                  {funcionarios.map((func) => (
                    <option key={func.id} value={func.id}>
                      {func.nome} - {func.codigo_anac || func.matricula}
                    </option>
                  ))}
                </select>
              </div>

              {/* Qualificação - 2 colunas */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Qualificação <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.codigo}
                  onChange={(e) => {
                    handleTipoChange(e.target.value);
                  }}
                  onBlur={(e) => {
                    // Garantir que o valor permanece
                    if (e.target.value === formData.codigo) {
                      e.target.value = formData.codigo;
                    }
                  }}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione uma qualificação...</option>
                  {tiposQualificacao.map((tipo) => (
                    <option key={tipo.codigo} value={tipo.codigo}>
                      {tipo.codigo} - {tipo.nome}
                    </option>
                  ))}
                </select>
              </div>

              {/* Data de Conclusão - 1 coluna */}
              <div className="md:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data de Conclusão <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={formData.data_conclusao}
                  onChange={(e) => handleDataConclusaoChange(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {tipoSelecionado && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-xs">
                <p className="text-blue-900">
                  <strong>Categoria:</strong> {tipoSelecionado.categoria || 'N/A'} |{' '}
                  <strong className="ml-2">Validade:</strong> {tipoSelecionado.validade_meses}m |{' '}
                  <strong className="ml-2">Vencimento:</strong>{' '}
                  {tipoSelecionado.tipo_vencimento === 'Mês Seguinte'
                    ? 'Fim do Mês'
                    : tipoSelecionado.tipo_vencimento}
                </p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Data de Vencimento - 1 coluna */}
              <div className="md:col-span-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Vencimento (automática)
                </label>
                <input
                  type="date"
                  value={formData.data_vencimento}
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed text-sm"
                />
              </div>

              {/* Observações - 3 colunas */}
              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                <textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  rows={1}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  placeholder="Observações adicionais..."
                />
              </div>
            </div>

            {/* Botões */}
            <div className="flex gap-3 pt-4 border-t">
              <button
                type="button"
                onClick={onClose}
                disabled={saving}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Save className="h-4 w-4" />
                {saving ? 'Salvando...' : 'Criar Qualificação'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
