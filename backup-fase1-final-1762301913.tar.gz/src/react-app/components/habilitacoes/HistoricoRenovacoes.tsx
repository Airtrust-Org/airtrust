/**
 * src/react-app/components/Habilitacoes/HistoricoRenovacoes.tsx
 * Exibe histórico de renovações de uma habilitação
 */

import { Calendar, Check, ChevronDown, RefreshCw } from 'lucide-react';

interface RenovacaoItem {
  id: number;
  data_conclusao: string;
  data_vencimento: string;
  eh_renovada: boolean;
  renovada_em?: string;
}

interface HistoricoRenovacoesProps {
  funcionarioId: number;
  qualificacaoId: number;
  renovacoes: RenovacaoItem[];
  isLoading?: boolean;
  isOpen?: boolean;
  onToggle?: () => void;
}

export function HistoricoRenovacoes({
  renovacoes,
  isLoading,
  isOpen = false,
  onToggle,
}: HistoricoRenovacoesProps) {
  if (isLoading) {
    return <div className="text-gray-500 text-sm">Carregando histórico...</div>;
  }

  if (!renovacoes || renovacoes.length === 0) {
    return <div className="text-gray-500 text-sm">Sem histórico de renovações</div>;
  }

  return (
    <div className="space-y-2">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
      >
        <span className="text-sm font-semibold text-gray-700 flex items-center gap-2">
          <RefreshCw className="w-4 h-4" />
          Histórico de Renovações ({renovacoes.length})
        </span>
        <ChevronDown
          className={`w-4 h-4 transition-transform ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div className="space-y-2 pl-2 border-l-2 border-gray-200">
          {renovacoes.map((r, idx) => (
            <div
              key={r.id}
              className={`p-3 rounded-lg border-l-4 ${
                !r.eh_renovada
                  ? 'bg-green-50 border-green-400'
                  : 'bg-gray-50 border-gray-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    {!r.eh_renovada ? (
                      <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-semibold">
                        <span className="w-2 h-2 rounded-full bg-green-600" />
                        ATIVA
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-semibold">
                        <Check className="w-3 h-3" />
                        RENOVADA
                      </span>
                    )}
                    {idx === 0 && renovacoes.length > 1 && (
                      <span className="text-xs text-gray-500">(Mais recente)</span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Calendar className="w-3 h-3" />
                      <span>
                        Conclusão:{' '}
                        <strong>
                          {new Date(r.data_conclusao).toLocaleDateString(
                            'pt-BR'
                          )}
                        </strong>
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-700">
                      <Calendar className="w-3 h-3" />
                      <span>
                        Vencimento:{' '}
                        <strong>
                          {new Date(r.data_vencimento).toLocaleDateString(
                            'pt-BR'
                          )}
                        </strong>
                      </span>
                    </div>

                    {r.eh_renovada && r.renovada_em && (
                      <div className="text-xs text-gray-600 pt-1 mt-1 border-t border-gray-200">
                        <span className="text-gray-500">Renovada em: </span>
                        <strong>
                          {new Date(r.renovada_em).toLocaleDateString(
                            'pt-BR'
                          )}
                        </strong>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
