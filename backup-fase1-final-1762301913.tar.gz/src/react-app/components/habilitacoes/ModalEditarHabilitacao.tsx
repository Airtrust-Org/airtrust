import { useState, useEffect } from "react";
import { X, Save } from "lucide-react";

const API_BASE_URL = window.location.origin;

interface ModalEditarQualificacaoProps {
  qualificacaoId: number;
  onClose: () => void;
  onSave: () => void;
}

export default function ModalEditarQualificacao({
  qualificacaoId,
  onClose,
  onSave,
}: ModalEditarQualificacaoProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    tipo: "",
    codigo: "",
    nome: "",
    data_realizado: "",
    data_vencimento: "",
    validade_meses: 12,
    status: "VALIDA",
  });

  useEffect(() => {
    carregarQualificacao();
  }, [qualificacaoId]);

  const carregarQualificacao = async () => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/v2/qualificacoes/${qualificacaoId}`,
      );
      const data = await response.json();

      if (data.success) {
        const qual = data.data;
        setFormData({
          tipo: qual.tipo || "",
          codigo: qual.codigo || "",
          nome: qual.nome || "",
          data_realizado: qual.data_realizado?.split("T")[0] || "",
          data_vencimento: qual.data_vencimento?.split("T")[0] || "",
          validade_meses: qual.validade_meses || 12,
          status: qual.status || "VALIDA",
        });
      } else {
        console.error("Erro na resposta:", data);
        alert("Erro ao carregar dados: " + (data.error || "Erro desconhecido"));
      }
    } catch (error) {
      console.error("Erro ao carregar qualificação:", error);
      alert("Erro ao carregar dados da qualificação");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/v2/qualificacoes/${qualificacaoId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        },
      );

      const data = await response.json();

      if (data.success) {
        alert("Qualificação atualizada com sucesso!");
        onSave();
        onClose();
      } else {
        alert(data.error || "Erro ao atualizar qualificação");
      }
    } catch (error) {
      console.error("Erro ao salvar:", error);
      alert("Erro ao salvar qualificação");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white">
          <h2 className="text-xl font-semibold text-gray-900">
            Editar Qualificação
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        {loading ? (
          <div className="p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-600 mt-4">Carregando...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Tipo */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipo <span className="text-red-500">*</span>
              </label>
              <select
                value={formData.tipo}
                onChange={(e) =>
                  setFormData({ ...formData, tipo: e.target.value })
                }
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Selecione...</option>
                <option value="TREINAMENTO">Treinamento</option>
                <option value="EXAME">Exame</option>
                <option value="CHECK">Check</option>
              </select>
            </div>

            {/* Código */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Código <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.codigo}
                onChange={(e) =>
                  setFormData({ ...formData, codigo: e.target.value })
                }
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Ex: OPC, F2, G2"
              />
            </div>

            {/* Nome */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome
              </label>
              <input
                type="text"
                value={formData.nome}
                onChange={(e) =>
                  setFormData({ ...formData, nome: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Nome descritivo da qualificação"
              />
            </div>

            {/* Data Realizado */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Realização
              </label>
              <input
                type="date"
                value={formData.data_realizado}
                onChange={(e) =>
                  setFormData({ ...formData, data_realizado: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Validade em Meses */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Validade (meses)
              </label>
              <input
                type="number"
                value={formData.validade_meses}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    validade_meses: parseInt(e.target.value),
                  })
                }
                min="1"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Data Vencimento */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Vencimento
              </label>
              <input
                type="date"
                value={formData.data_vencimento}
                onChange={(e) =>
                  setFormData({ ...formData, data_vencimento: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({ ...formData, status: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="VALIDA">Válida</option>
                <option value="VENCENDO">Vencendo</option>
                <option value="VENCIDA">Vencida</option>
                <option value="CANCELADA">Cancelada</option>
              </select>
            </div>

            {/* Botões */}
            <div className="flex gap-3 pt-4 border-t">
              <button
                type="button"
                onClick={onClose}
                disabled={saving}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Save className="h-4 w-4" />
                {saving ? "Salvando..." : "Salvar Alterações"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
