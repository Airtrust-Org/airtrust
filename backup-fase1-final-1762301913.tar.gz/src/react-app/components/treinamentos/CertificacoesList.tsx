import { useState } from 'react';
import { Plus, Search, Download, Edit, FileText, Calendar, User, Award, Trash2, UploadCloud, Paperclip } from 'lucide-react';
import Button from '@/react-app/components/Button';
import Badge from '@/react-app/components/Badge';
import Card, { CardContent, CardHeader } from '@/react-app/components/Card';
import AddCertificacaoModal from '@/react-app/components/funcionarios/AddCertificacaoModal';
import EditCertificacaoModal from '@/react-app/components/treinamentos/EditCertificacaoModal';
import QuickUploadModal from '@/react-app/components/treinamentos/QuickUploadModal';
import ImportarCSVModal from '@/react-app/components/ImportarCSVModal';
import ImportarCertificacoes from '@/react-app/components/shared/ImportarCertificacoes';
import { useApi } from '@/react-app/hooks/useApi';

interface HistoricoCertificacao {
  id: number;
  funcionario_id: number;
  treinamento_id: number;
  data_conclusao: string;
  data_vencimento?: string;
  instrutor?: string;
  nota?: number;
  observacoes?: string;
  arquivo_url?: string;
  status: string;
  funcionario_nome?: string;
  treinamento_codigo?: string;
  treinamento_nome?: string;
  anexo_id?: number;
  nome_arquivo?: string;
  url_arquivo?: string;
  tipo_arquivo?: string;
  certificacao_id?: string;
  funcionario_matricula?: string;
  arquivo_github_url?: string;
  sync_id?: number;
  arquivo_pasta_virtual_url?: string;
  nome_arquivo_auditavel?: string;
  status_sincronizacao?: string;
}

interface CatalogoTreinamento {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  ativo: boolean;
}

export default function CertificacoesList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('TODOS');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isQuickUploadModalOpen, setIsQuickUploadModalOpen] = useState(false);
  const [editingCertificacaoId, setEditingCertificacaoId] = useState<number | null>(null);
  const [uploadingCertificacaoId, setUploadingCertificacaoId] = useState<number | null>(null);

  const { data: certificacoes, loading, error, refetch } = useApi<HistoricoCertificacao[]>(
    '/api/v2/qualificacoes?limit=1000&incluir_renovadas=true'
  );
  
  
  const { data: catalogoTreinamentos, loading: catalogoLoading, error: catalogoError } = useApi<CatalogoTreinamento[]>('/api/v2/treinamentos/catalogo-treinamentos');
  
  console.log('🔍 CatalogoTreinamentos debug:', { 
    catalogoTreinamentos, 
    catalogoLoading, 
    catalogoError,
    url: '/api/v2/treinamentos/catalogo-treinamentos'
  });

  const handleAddSuccess = () => {
    setIsAddModalOpen(false);
    refetch(); // Atualizar a lista após adicionar nova certificação
  };

  const handleImportSuccess = () => {
    setIsImportModalOpen(false);
    refetch(); // Atualizar a lista após importação CSV
  };

  const handleEditSuccess = () => {
    setIsEditModalOpen(false);
    setEditingCertificacaoId(null);
    refetch(); // Atualizar a lista após editar certificação
  };

  const handleEditClick = (certificacaoId: number) => {
    setEditingCertificacaoId(certificacaoId);
    setIsEditModalOpen(true);
  };

  const handleQuickUploadClick = (certificacaoId: number) => {
    setUploadingCertificacaoId(certificacaoId);
    setIsQuickUploadModalOpen(true);
  };

  const handleQuickUploadSuccess = () => {
    setIsQuickUploadModalOpen(false);
    setUploadingCertificacaoId(null);
    refetch(); // Atualizar a lista após upload
  };

  const handleDownloadCertificado = async (certificacao: HistoricoCertificacao) => {
    try {
      console.log(`📋 [DOWNLOAD CORRIGIDO] Dados da certificação:`, {
        id: certificacao.id,
        sync_id: certificacao.sync_id,
        funcionario: certificacao.funcionario_nome,
        treinamento: certificacao.treinamento_nome,
        nome_arquivo_auditavel: certificacao.nome_arquivo_auditavel,
        status_sincronizacao: certificacao.status_sincronizacao
      });
      
      if (certificacao.sync_id && certificacao.status_sincronizacao === 'SINCRONIZADO') {
        
        const pastaVirtualUrl = `/api/v2/pasta-virtual-download/download/${certificacao.sync_id}`;
        
        window.open(pastaVirtualUrl, '_blank');
        return;
      }
      
      
      const downloadResponse = await fetch(`/api/v2/treinamentos/historico-certificacoes/${certificacao.id}/certificado`);
      
      
      if (!downloadResponse.ok) {
        let errorMessage = 'Erro desconhecido';
        try {
          const errorData = await downloadResponse.json();
          errorMessage = errorData.error || `HTTP ${downloadResponse.status}`;
          console.error(`❌ [DOWNLOAD CORRIGIDO] Erro detalhado:`, errorData);
        } catch {
          errorMessage = `HTTP ${downloadResponse.status}`;
        }
        
        console.error(`❌ [DOWNLOAD CORRIGIDO] Falha: ${errorMessage}`);
        alert(`Erro ao baixar certificado: ${errorMessage}`);
        return;
      }
      
      const contentType = downloadResponse.headers.get('content-type') || '';
      
      if (contentType.includes('application/json')) {
        const data = await downloadResponse.json();
        
        if (data.success && data.download_url) {
          window.open(data.download_url, '_blank');
          return;
        }
        
        if (!data.success) {
          console.error(`❌ [DOWNLOAD CORRIGIDO] Erro na resposta JSON:`, data.error);
          alert(`Erro: ${data.error}`);
          return;
        }
      }
      
      const blob = await downloadResponse.blob();
      
      if (blob.size === 0) {
        console.error(`❌ [DOWNLOAD CORRIGIDO] Arquivo vazio recebido`);
        alert('Erro: arquivo vazio recebido do servidor');
        return;
      }
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const nomeArquivo = certificacao.nome_arquivo_auditavel || 
        certificacao.nome_arquivo || 
        `Certificado_${certificacao.treinamento_codigo || 'TRM'}_${(certificacao.funcionario_nome || 'Funcionario').replace(/\s+/g, '_')}_${certificacao.id}.pdf`;
      
      a.download = nomeArquivo;
      
      
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      
    } catch (error) {
      console.error('💥 [DOWNLOAD CORRIGIDO] Erro crítico:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao baixar certificado: ${errorMessage}`);
    }
  };

  

  const [modalPastaVirtual, setModalPastaVirtual] = useState({
    open: false,
    funcionarioId: null as number | null,
    nomeFuncionario: ''
  });

  const handleDeleteClick = async (certificacaoId: number) => {
    const cert = filteredCertificacoes.find(c => c.id === certificacaoId);
    const nomeDisplay = cert?.treinamento_nome || `Certificação ${certificacaoId}`;
    const funcionarioDisplay = cert?.funcionario_nome || 'Funcionário';
    
    const confirmacao = confirm(
      `Tem certeza que deseja excluir a certificação "${nomeDisplay}" do funcionário "${funcionarioDisplay}"?\n\n` +
      'Esta ação não pode ser desfeita.'
    );
    
    if (!confirmacao) return;

    try {
      const response = await fetch(`/api/v2/treinamentos/historico-certificacoes/${certificacaoId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const contentType = response.headers.get('content-type');
      
      let result;
      if (contentType && contentType.includes('application/json')) {
        try {
          result = await response.json();
        } catch (jsonError) {
          console.error('Erro ao fazer parse do JSON:', jsonError);
          if (response.ok) {
            result = { success: true };
          } else {
            throw new Error('Resposta inválida do servidor');
          }
        }
      } else {
        if (response.ok) {
          result = { success: true };
        } else {
          const textResponse = await response.text();
          throw new Error(`Erro do servidor: ${textResponse || response.status}`);
        }
      }

      if (!response.ok) {
        const errorMessage = result?.error || `Erro HTTP ${response.status}`;
        throw new Error(errorMessage);
      }

      await refetch();
      
      
    } catch (err) {
      console.error('Erro ao remover certificação:', err);
      alert(`Erro ao excluir certificação: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const calcularDiasParaVencimento = (dataVencimento?: string) => {
    if (!dataVencimento) return null;
    const hoje = new Date();
    const vencimento = new Date(dataVencimento);
    return Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
  };

  const getStatusBadgeVariant = (status: string, diasVencimento?: number | null) => {
    if (status === 'ATIVO') {
      if (diasVencimento !== null && diasVencimento !== undefined) {
        if (diasVencimento < 0) return 'danger';
        if (diasVencimento <= 30) return 'warning';
      }
      return 'success';
    }
    switch (status) {
      case 'SUBSTITUIDO': return 'warning';
      case 'CANCELADO': return 'danger';
      default: return 'neutral';
    }
  };

  const getStatusLabel = (status: string, diasVencimento?: number | null) => {
    if (status === 'ATIVO') {
      if (diasVencimento !== null && diasVencimento !== undefined) {
        if (diasVencimento < 0) return 'VENCIDO';
        if (diasVencimento <= 30) return 'VENCENDO';
      }
      return 'VÁLIDO';
    }
    return status;
  };

  const temArquivoAnexado = (cert: HistoricoCertificacao): boolean => {
    console.log(`🔍 [ANEXO CHECK CORRIGIDO] Certificação ${cert.id}:`, {
      sync_id: cert.sync_id,
      status_sincronizacao: cert.status_sincronizacao,
      nome_arquivo_auditavel: cert.nome_arquivo_auditavel,
      anexo_id: cert.anexo_id,
      url_arquivo: cert.url_arquivo,
      arquivo_github_url: cert.arquivo_github_url,
      arquivo_url: cert.arquivo_url
    });
    
    if (cert.sync_id && cert.status_sincronizacao === 'SINCRONIZADO' && cert.nome_arquivo_auditavel) {
      return true;
    }
    
    const temAnexoReal = !!(cert.anexo_id || cert.url_arquivo || cert.arquivo_github_url);
    
    if (temAnexoReal) {
      const urlParaVerificar = cert.arquivo_github_url || cert.url_arquivo || '';
      const ehGenerico = urlParaVerificar.includes('desenvolvimento') || 
                         urlParaVerificar.includes('generic') || 
                         urlParaVerificar.includes('placeholder');
      
      return temAnexoReal && !ehGenerico;
    }
    
    return false;
  };

  const filteredCertificacoes = certificacoes?.filter(cert => {
    const matchesSearch = !searchTerm || 
      cert.funcionario_nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cert.treinamento_nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cert.treinamento_codigo?.toLowerCase().includes(searchTerm.toLowerCase());

    const diasVencimento = calcularDiasParaVencimento(cert.data_vencimento);
    const statusAtual = getStatusLabel(cert.status, diasVencimento);
    
    const matchesStatus = statusFilter === 'TODOS' || statusAtual === statusFilter;
    
    return matchesSearch && matchesStatus;
  }) || [];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-16 bg-gray-200 rounded mb-6"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 mb-4">Erro ao carregar certificações: {error}</p>
        <Button variant="primary" onClick={refetch}>
          Tentar Novamente
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header com Ações */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Gestão de Qualificações
              </h2>
              <p className="text-sm text-gray-600">
                Lista completa do histórico de qualificações
              </p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="secondary" 
                className="text-sm"
                onClick={() => setIsImportModalOpen(true)}
              >
                <Download className="w-4 h-4 mr-2" />
                Importar CSV
              </Button>
              <Button variant="primary" onClick={() => setIsAddModalOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Nova Certificação
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Busca */}
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar qualificações..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Filtro de Status */}
            <div className="sm:w-48">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="TODOS">Todos os status</option>
                <option value="VÁLIDO">Válidos</option>
                <option value="VENCENDO">Vencendo</option>
                <option value="VENCIDO">Vencidos</option>
                <option value="SUBSTITUIDO">Substituídos</option>
                <option value="CANCELADO">Cancelados</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Qualificações */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium text-gray-900">
              Qualificações ({filteredCertificacoes.length})
            </h3>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {filteredCertificacoes.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg font-medium mb-2">
                {searchTerm || statusFilter !== 'TODOS' 
                  ? 'Nenhuma qualificação encontrada com os filtros aplicados'
                  : 'Nenhuma qualificação encontrada'
                }
              </p>
              {(!searchTerm && statusFilter === 'TODOS') && (
                <Button variant="primary" onClick={() => setIsAddModalOpen(true)} className="mt-4">
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Primeira Qualificação
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full table-auto">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="text-center py-3 px-4 font-medium text-gray-900 w-20">ID</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Funcionário</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Qualificação</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Conclusão</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Vencimento</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-center py-3 px-4 font-medium text-gray-900 w-40">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredCertificacoes.map((cert) => {
                    const diasVencimento = calcularDiasParaVencimento(cert.data_vencimento);
                    const statusLabel = getStatusLabel(cert.status, diasVencimento);
                    const statusVariant = getStatusBadgeVariant(cert.status, diasVencimento);
                    const possuiArquivoReal = temArquivoAnexado(cert);

                    return (
                      <tr key={cert.id} className="hover:bg-gray-50">
                        {/* ✅ CORREÇÃO 4: ID da Certificação com ano correto */}
                        <td className="py-4 px-4 text-center">
                          <span className="inline-block bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-3 py-1 rounded-lg text-xs font-mono font-semibold shadow-sm min-w-[120px]">
                            {cert.certificacao_id || `${cert.funcionario_matricula || '00000'}-${cert.treinamento_codigo || 'TRM'}-${new Date(cert.data_conclusao).getFullYear()}-01`}
                          </span>
                        </td>

                        {/* Funcionário */}
                        <td className="py-4 px-4">
                          <div>
                            <div className="font-medium text-gray-900">{cert.funcionario_nome || 'N/A'}</div>
                            <div className="text-sm text-gray-500">ID: {cert.funcionario_id}</div>
                          </div>
                        </td>

                        {/* Certificação */}
                        <td className="py-4 px-4">
                          <div>
                            <div className="font-medium text-gray-900">
                              {cert.treinamento_nome || `Treinamento ID ${cert.treinamento_id}`}
                            </div>
                            <div className="text-sm text-gray-500">
                              {cert.treinamento_codigo || 'N/A'}
                            </div>
                          </div>
                        </td>

                        {/* Realizado */}
                        <td className="py-4 px-4">
                          <div className="flex items-center text-sm text-gray-600">
                            <Calendar className="w-4 h-4 mr-2" />
                            {formatDate(cert.data_conclusao)}
                          </div>
                          {cert.instrutor && (
                            <div className="flex items-center text-xs text-gray-500 mt-1">
                              <User className="w-3 h-3 mr-1" />
                              {cert.instrutor}
                            </div>
                          )}
                        </td>

                        {/* Vencimento */}
                        <td className="py-4 px-4">
                          {cert.data_vencimento ? (
                            <div>
                              <div className="text-sm text-gray-900">
                                {formatDate(cert.data_vencimento)}
                              </div>
                              {diasVencimento !== null && (
                                <div className={`text-xs ${
                                  diasVencimento < 0 ? 'text-red-600' : 
                                  diasVencimento <= 30 ? 'text-yellow-600' : 'text-green-600'
                                }`}>
                                  {diasVencimento < 0 
                                    ? `${Math.abs(diasVencimento)} dias atrás`
                                    : `em ${diasVencimento} dias`
                                  }
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-sm text-gray-400">Sem vencimento</span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-4 px-4">
                          <Badge variant={statusVariant}>
                            {statusLabel}
                          </Badge>
                          {cert.nota && (
                            <div className="flex items-center text-xs text-gray-500 mt-1">
                              <Award className="w-3 h-3 mr-1" />
                              Nota: {cert.nota.toFixed(1)}
                            </div>
                          )}
                        </td>

                        {/* Ações */}
                        <td className="py-4 px-4 text-center">
                          <div className="flex justify-center items-center space-x-2">
                            {/* ÍCONE CERTIFICADO ANEXADO - VERDE CORRIGIDO */}
                            {possuiArquivoReal && (
                              <button
                                onClick={() => handleDownloadCertificado(cert)}
                                className="text-green-600 hover:text-green-800 hover:bg-green-50 p-2 rounded-lg border border-green-300 hover:border-green-400 transition-all duration-200 shadow-sm hover:shadow-md"
                                title={`Baixar Certificado Anexado${cert.nome_arquivo ? ` (${cert.nome_arquivo})` : ''}`}
                              >
                                <Paperclip className="w-4 h-4" />
                              </button>
                            )}
                            
                            {/* Botões de Ação */}
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-1"
                              onClick={() => handleEditClick(cert.id)}
                              data-testid={`edit-certificacao-${cert.id}`}
                              title="Editar qualificação"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-1 text-blue-600 hover:text-blue-800"
                              onClick={() => handleQuickUploadClick(cert.id)}
                              data-testid={`upload-certificacao-${cert.id}`}
                              title="Anexar certificado"
                            >
                              <UploadCloud className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-1 text-red-600 hover:text-red-800"
                              onClick={() => handleDeleteClick(cert.id)}
                              data-testid={`delete-certificacao-${cert.id}`}
                              title="Remover qualificação"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Adicionar Certificação */}
      <AddCertificacaoModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={handleAddSuccess}
        funcionarioId={1} // Valor padrão - seria ideal ter um seletor de funcionário
        catalogoTreinamentos={catalogoTreinamentos || []}
        key={`add-modal-${isAddModalOpen}`} // Force re-render para garantir dados atualizados
      />

      {/* Modal de Editar Certificação */}
      <EditCertificacaoModal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setEditingCertificacaoId(null);
        }}
        onSuccess={handleEditSuccess}
        certificacaoId={editingCertificacaoId}
      />

      {/* Modal de Upload Rápido */}
      <QuickUploadModal
        isOpen={isQuickUploadModalOpen}
        onClose={() => {
          setIsQuickUploadModalOpen(false);
          setUploadingCertificacaoId(null);
        }}
        onSuccess={handleQuickUploadSuccess}
        historicoId={uploadingCertificacaoId || 0}
        certificacaoNome={
          uploadingCertificacaoId 
            ? filteredCertificacoes.find(c => c.id === uploadingCertificacaoId)?.treinamento_nome 
            : undefined
        }
      />

      {/* ✅ CORREÇÃO: Modal de Importação CSV Corrigido */}
      <ImportarCertificacoes
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={handleImportSuccess}
      />

      <ImportarCSVModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSuccess={() => {
          setIsImportModalOpen(false);
          refetch();
        }}
        endpoint="/api/v2/treinamentos/historico-certificacoes/batch-import"
        title="Importar Histórico de Certificações"
        description="Faça upload de um arquivo CSV para importar certificações em lote"
        formatoExemplo={[
          'funcionario_matricula,treinamento_codigo,treinamento_nome,data_conclusao,data_vencimento,instrutor,nota,observacoes',
          'FUNC001,TRN-001,Nome do Treinamento,2024-01-15,Nome Instrutor,2025-01-15,8.5,Observações da certificação'
        ]}
      />

      {/* ✅ MODAL DA PASTA VIRTUAL FUNCIONAL */}
      {modalPastaVirtual.open && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setModalPastaVirtual({...modalPastaVirtual, open: false})}>
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold mb-4">📂 Pasta Virtual - {modalPastaVirtual.nomeFuncionario}</h3>
            
            <div className="pasta-virtual-content mb-6">
              <p className="text-gray-600 mb-2">Funcionalidade em desenvolvimento...</p>
              <p className="text-sm text-gray-500">Funcionário ID: {modalPastaVirtual.funcionarioId}</p>
            </div>
            
            <button 
              onClick={() => setModalPastaVirtual({...modalPastaVirtual, open: false})}
              className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
