import { useState, useEffect } from 'react';
import { Plus, Search, Edit, Trash2 } from 'lucide-react';
import Button from '../Button';
import { BaseModal as Modal } from '../modals/BaseModal';
import Badge from '../Badge';

interface CatalogoTreinamento {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  tipo_vencimento: 'DIA_EXATO' | 'FINAL_MES';
  ativo: boolean;
  created_at: string;
  updated_at: string;
}

interface CatalogoFormData {
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  tipo_vencimento: 'DIA_EXATO' | 'FINAL_MES';
  ativo: boolean;
}

const CatalogoManagement: React.FC = () => {
  const [treinamentos, setTreinamentos] = useState<CatalogoTreinamento[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTreinamento, setEditingTreinamento] = useState<CatalogoTreinamento | null>(null);
  const [formData, setFormData] = useState<CatalogoFormData>({
    codigo: '',
    nome: '',
    descricao: '',
    categoria: '',
    periodicidade_meses: 12,
    tipo_vencimento: 'FINAL_MES',
    ativo: true
  });

  const categorias = [
    'SEGURANÇA',
    'OPERACIONAL', 
    'MÉDICO',
    'REGULATÓRIO',
    'PROFICIÊNCIA',
    'LICENÇA',
    'IMPORTADO'
  ];

  useEffect(() => {
    fetchTreinamentos();
  }, []);

  const fetchTreinamentos = async () => {
    try {
      const response = await fetch('/api/v2/treinamentos/catalogo-treinamentos');
      const data = await response.json();
      
      if (data.success) {
        setTreinamentos(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar treinamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: value ? parseInt(value) : undefined }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingTreinamento 
        ? `/api/v2/treinamentos/catalogo-treinamentos/${editingTreinamento.id}`
        : '/api/v2/treinamentos/catalogo-treinamentos';
      
      const method = editingTreinamento ? 'PUT' : 'POST';
      
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();
      
      if (data.success) {
        fetchTreinamentos();
        handleCloseModal();
      } else {
        throw new Error(data.error || 'Erro ao salvar treinamento');
      }
    } catch (error: any) {
      console.error('❌ Erro detalhado ao salvar treinamento:', error);
      
      let errorMessage = 'Erro ao salvar treinamento';
      
      if (error.response?.data?.error) {
        errorMessage += ': ' + error.response.data.error;
      } else if (error.message) {
        errorMessage += ': ' + error.message;
      }
      
      alert(errorMessage);
    }
  };

  const handleDelete = async (id: number, nome: string) => {
    if (confirm(`Tem certeza que deseja excluir o treinamento "${nome}"?`)) {
      try {
        const response = await fetch(`/api/v2/treinamentos/catalogo-treinamentos/${id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) {
          throw new Error('Erro ao excluir treinamento');
        }
        
        await fetchTreinamentos();
        
      } catch (error) {
        alert(`Erro: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
      }
    }
  };

  const handleEdit = (treinamento: CatalogoTreinamento) => {
    setEditingTreinamento(treinamento);
    setFormData({
      codigo: treinamento.codigo,
      nome: treinamento.nome,
      descricao: treinamento.descricao || '',
      categoria: treinamento.categoria,
      periodicidade_meses: treinamento.periodicidade_meses,
      tipo_vencimento: treinamento.tipo_vencimento || 'FINAL_MES',
      ativo: treinamento.ativo
    });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTreinamento(null);
    setFormData({
      codigo: '',
      nome: '',
      descricao: '',
      categoria: '',
      periodicidade_meses: 12,
      tipo_vencimento: 'FINAL_MES',
      ativo: true
    });
  };

  const filteredTreinamentos = treinamentos.filter(treinamento =>
    treinamento.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    treinamento.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    treinamento.categoria.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatPeriodicidade = (meses?: number) => {
    if (!meses) return 'Não especificado';
    if (meses === 1) return '1 mês';
    if (meses < 12) return `${meses} meses`;
    if (meses === 12) return '1 ano';
    return `${Math.floor(meses / 12)} anos`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Treinamentos
          </h2>
          <p className="text-sm text-gray-600">
            Gestão completa dos treinamentos obrigatórios
          </p>
        </div>
        
        <Button
          onClick={() => setIsModalOpen(true)}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Treinamento
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Buscar treinamentos..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Tabela */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Código/Nome
                </th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Categoria
                </th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Validade
                </th>
                <th className="py-3 px-6 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTreinamentos.map((treinamento) => (
                <tr key={treinamento.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div className="space-y-1">
                      <div className="font-medium text-gray-900">{treinamento.nome}</div>
                      <div className="text-sm text-gray-600">{treinamento.codigo}</div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <Badge variant="neutral">{treinamento.categoria}</Badge>
                  </td>
                  <td className="py-4 px-6">
                    <div className="space-y-1">
                      <div className="text-sm text-gray-600">
                        {formatPeriodicidade(treinamento.periodicidade_meses)}
                      </div>
                      <div className="text-xs text-gray-500">
                        {treinamento.tipo_vencimento === 'FINAL_MES' ? 'Final do mês' : 'Dia exato'}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <Badge variant={treinamento.ativo ? 'success' : 'danger'}>
                      {treinamento.ativo ? 'Ativo' : 'Inativo'}
                    </Badge>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(treinamento)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(treinamento.id, treinamento.nome)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTreinamentos.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">Nenhum treinamento encontrado</p>
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingTreinamento ? 'Editar Treinamento' : 'Novo Treinamento'}
      >
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Nome do Treinamento - Prioridade máxima */}
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <label className="block text-sm font-semibold text-blue-900 mb-3">
              Nome do Treinamento *
            </label>
            <input
              type="text"
              name="nome"
              value={formData.nome}
              onChange={handleInputChange}
              required
              className="w-full px-4 py-3 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white text-lg font-medium"
              placeholder="Sistema de Gerenciamento de Segurança"
            />
          </div>

          {/* Código e Categoria */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Código *
              </label>
              <input
                type="text"
                name="codigo"
                value={formData.codigo}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
                placeholder="TRN-001"
              />
              <p className="text-xs text-gray-500 mt-2">Código único identificador</p>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Categoria *
              </label>
              <select
                name="categoria"
                value={formData.categoria}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
              >
                <option value="">Selecione uma categoria</option>
                {categorias.map(categoria => (
                  <option key={categoria} value={categoria}>
                    {categoria}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-2">Classificação do treinamento</p>
            </div>
          </div>

          {/* Descrição */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Descrição
            </label>
            <textarea
              name="descricao"
              value={formData.descricao}
              onChange={handleInputChange}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm resize-none"
              placeholder="Descrição detalhada do treinamento, objetivos e conteúdo..."
            />
            <p className="text-xs text-gray-500 mt-2">Informações complementares sobre o treinamento</p>
          </div>

          {/* Periodicidade e Tipo de Vencimento */}
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">Configurações de Validade</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Validade (meses) *
                </label>
                <input
                  type="number"
                  name="periodicidade_meses"
                  value={formData.periodicidade_meses || ''}
                  onChange={handleInputChange}
                  min="1"
                  max="120"
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
                  placeholder="12"
                />
                <p className="text-xs text-gray-600 mt-2">
                  Período entre 1 e 120 meses
                </p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Tipo de Vencimento *
                </label>
                <select
                  name="tipo_vencimento"
                  value={formData.tipo_vencimento}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
                >
                  <option value="FINAL_MES">Final do Mês</option>
                  <option value="DIA_EXATO">Dia Exato</option>
                </select>
                <div className="text-xs text-gray-600 mt-2 leading-relaxed">
                  <div><strong>Final do Mês:</strong> vence no último dia do mês</div>
                  <div><strong>Dia Exato:</strong> vence exatamente após X meses</div>
                </div>
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                name="ativo"
                checked={formData.ativo}
                onChange={handleInputChange}
                className="w-5 h-5 rounded border-green-300 text-green-600 focus:ring-green-500 focus:ring-2"
              />
              <div>
                <span className="text-sm font-semibold text-green-900">Treinamento ativo</span>
                <p className="text-xs text-green-700">Disponível para uso no sistema</p>
              </div>
            </label>
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="secondary"
              onClick={handleCloseModal}
              className="px-6 py-3"
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              {editingTreinamento ? 'Atualizar' : 'Criar'} Treinamento
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CatalogoManagement;
