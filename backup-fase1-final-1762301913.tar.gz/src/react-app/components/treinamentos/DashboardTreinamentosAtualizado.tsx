import { useState, useEffect } from 'react';
import { RefreshCw, Users, BookOpen, Award, AlertTriangle, CheckCircle, XCircle, Clock, TrendingUp } from 'lucide-react';
import Card, { CardContent, CardHeader } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import Button from '@/react-app/components/Button';

interface DashboardMetrics {
  resumo: {
    total_funcionarios: number;
    funcionarios_ativos: number;
    funcionarios_inativos: number;
    total_treinamentos: number;
    treinamentos_ativos: number;
    treinamentos_inativos: number;
    total_categorias: number;
    total_certificacoes: number;
    certificacoes_validas: number;
    certificacoes_vencidas: number;
    certificacoes_vencendo: number;
  };
  compliance: {
    percentual: number;
    funcionarios_ok: number;
    funcionarios_pendentes: number;
    funcionarios_sem_certificacao: number;
    funcionarios_total: number;
  };
  certificacoes_status: {
    validas: number;
    vencidas: number;
    vencendo_30_dias: number;
    total: number;
    detalhamento: {
      v2_total: number;
      v2_validas: number;
      v2_vencidas: number;
      v3_total: number;
      v3_validas: number;
      v3_vencidas: number;
    };
  };
  top_treinamentos: Array<{
    treinamento_nome: string;
    treinamento_codigo: string;
    categoria: string;
    total_certificacoes: number;
  }>;
  evolucao_mensal: Array<{
    mes: string;
    total: number;
    total_v2: number;
    total_v3: number;
  }>;
  funcionarios_criticos: Array<{
    funcionario_nome: string;
    matricula: string;
    total_certificacoes: number;
    certificacoes_vencidas: number;
    certificacoes_ok: number;
  }>;
  alertas: {
    certificacoes_vencendo: number;
    certificacoes_vencidas: number;
    funcionarios_sem_certificacao: number;
    treinamentos_inativos: number;
    funcionarios_criticos: number;
  };
  metadata: {
    ultima_atualizacao: string;
    processing_time_ms: number;
    fontes_dados: string[];
    versao_dashboard: string;
  };
}

const useDashboardMetrics = () => {
  const [metricas, setMetricas] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const carregarMetricas = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('/api/v2/dashboard-treinamentos/treinamentos-certificacoes');
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        setMetricas(data.data);
      } else {
        throw new Error(data.error || 'Erro desconhecido');
      }
    } catch (err) {
      console.error('❌ Erro ao carregar métricas:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarMetricas();
    
    const interval = setInterval(carregarMetricas, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return { metricas, loading, error, recarregar: carregarMetricas };
};

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color?: 'blue' | 'green' | 'purple' | 'red' | 'yellow';
  trend?: string;
}

const MetricCard = ({ title, value, subtitle, icon, color = 'blue', trend }: MetricCardProps) => {
  const colorClasses = {
    blue: 'bg-gradient-to-br from-blue-500 to-blue-600 text-white',
    green: 'bg-gradient-to-br from-green-500 to-green-600 text-white',
    purple: 'bg-gradient-to-br from-purple-500 to-purple-600 text-white',
    red: 'bg-gradient-to-br from-red-500 to-red-600 text-white',
    yellow: 'bg-gradient-to-br from-yellow-500 to-yellow-600 text-white'
  };

  return (
    <Card className="overflow-hidden">
      <CardContent className={`p-6 ${colorClasses[color]}`}>
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-white/90 mb-1">{title}</h3>
            <div className="text-2xl font-bold mb-1">{value}</div>
            {subtitle && <p className="text-sm text-white/75">{subtitle}</p>}
            {trend && <p className="text-xs text-white/60 mt-1">{trend}</p>}
          </div>
          <div className="text-white/80 ml-4">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

interface AlertCardProps {
  type: 'error' | 'warning' | 'info';
  title: string;
  value: number;
  message: string;
}

const AlertCard = ({ type, title, value, message }: AlertCardProps) => {
  const typeClasses = {
    error: 'border-red-200 bg-red-50 text-red-800',
    warning: 'border-yellow-200 bg-yellow-50 text-yellow-800',
    info: 'border-blue-200 bg-blue-50 text-blue-800'
  };

  const iconMap = {
    error: <XCircle className="w-5 h-5" />,
    warning: <AlertTriangle className="w-5 h-5" />,
    info: <Clock className="w-5 h-5" />
  };

  return (
    <Card className={`border ${typeClasses[type]}`}>
      <CardContent className="p-4">
        <div className="flex items-center space-x-3">
          {iconMap[type]}
          <div className="flex-1">
            <h4 className="font-semibold">{title}</h4>
            <p className="text-sm opacity-90">
              <span className="font-bold text-lg mr-1">{value}</span>
              {message}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

interface TopTreinamentoItemProps {
  position: number;
  nome: string;
  codigo: string;
  categoria: string;
  total: number;
}

const TopTreinamentoItem = ({ position, nome, codigo, categoria, total }: TopTreinamentoItemProps) => (
  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white
      ${position === 1 ? 'bg-yellow-500' : position === 2 ? 'bg-gray-400' : position === 3 ? 'bg-orange-400' : 'bg-blue-500'}`}>
      {position}
    </div>
    <div className="flex-1">
      <div className="font-medium text-gray-900">{nome}</div>
      <div className="text-sm text-gray-600">
        {codigo} • {categoria}
      </div>
    </div>
    <div className="text-right">
      <div className="font-bold text-gray-900">{total}</div>
      <div className="text-xs text-gray-500">certificações</div>
    </div>
  </div>
);

export default function DashboardTreinamentosAtualizado() {
  const { metricas, loading, error, recarregar } = useDashboardMetrics();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <p className="text-gray-600 font-medium">Carregando métricas do dashboard...</p>
        <p className="text-sm text-gray-500">Coletando dados de funcionários, treinamentos e certificações</p>
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Erro ao Carregar Dashboard</h3>
          <p className="text-gray-600 mb-4">Não foi possível carregar as métricas: {error}</p>
          <Button variant="primary" onClick={recarregar}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Tentar Novamente
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!metricas) {
    return <div className="text-center py-8 text-gray-500">Nenhuma métrica disponível</div>;
  }

  const formatDateTime = (isoString: string) => {
    return new Date(isoString).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getComplianceColor = (percentual: number): 'red' | 'yellow' | 'green' => {
    if (percentual >= 80) return 'green';
    if (percentual >= 60) return 'yellow';
    return 'red';
  };

  const hasAlertas = metricas.alertas.certificacoes_vencidas > 0 || 
                   metricas.alertas.certificacoes_vencendo > 0 ||
                   metricas.alertas.funcionarios_sem_certificacao > 0;

  return (
    <div className="space-y-6">
      {/* Header com informações e ação de refresh */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Dashboard de Treinamentos & Certificações
          </h1>
          <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
            <span>Última atualização: {formatDateTime(metricas.metadata.ultima_atualizacao)}</span>
            <span>•</span>
            <span>Processado em {metricas.metadata.processing_time_ms}ms</span>
            <span>•</span>
            <Badge variant="neutral" size="sm">v{metricas.metadata.versao_dashboard}</Badge>
          </div>
        </div>
        <Button variant="secondary" onClick={recarregar}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar Métricas
        </Button>
      </div>

      {/* Cards de visão geral */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Funcionários Ativos"
          value={metricas.resumo.funcionarios_ativos}
          subtitle={`${metricas.resumo.total_funcionarios} total`}
          icon={<Users className="w-8 h-8" />}
          color="blue"
        />
        <MetricCard
          title="Treinamentos Ativos"
          value={metricas.resumo.treinamentos_ativos}
          subtitle={`${metricas.resumo.total_categorias} categorias`}
          icon={<BookOpen className="w-8 h-8" />}
          color="green"
        />
        <MetricCard
          title="Total de Certificações"
          value={metricas.resumo.total_certificacoes}
          subtitle={`${metricas.resumo.certificacoes_validas} válidas`}
          icon={<Award className="w-8 h-8" />}
          color="purple"
        />
        <MetricCard
          title="Compliance Geral"
          value={`${metricas.compliance.percentual}%`}
          subtitle={`${metricas.compliance.funcionarios_ok} funcionários OK`}
          icon={<CheckCircle className="w-8 h-8" />}
          color={getComplianceColor(metricas.compliance.percentual)}
        />
      </div>

      {/* Alertas - Só mostra se houver alertas */}
      {hasAlertas && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-900 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
            Alertas Críticos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {metricas.alertas.certificacoes_vencidas > 0 && (
              <AlertCard
                type="error"
                title="Certificações Vencidas"
                value={metricas.alertas.certificacoes_vencidas}
                message="certificações precisam ser renovadas urgentemente"
              />
            )}
            {metricas.alertas.certificacoes_vencendo > 0 && (
              <AlertCard
                type="warning"
                title="Vencendo em 30 dias"
                value={metricas.alertas.certificacoes_vencendo}
                message="certificações vencem em breve"
              />
            )}
            {metricas.alertas.funcionarios_sem_certificacao > 0 && (
              <AlertCard
                type="info"
                title="Sem Certificações"
                value={metricas.alertas.funcionarios_sem_certificacao}
                message="funcionários sem certificações registradas"
              />
            )}
          </div>
        </div>
      )}

      {/* Status detalhado das certificações */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-gray-900">Status das Certificações</h2>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {metricas.certificacoes_status.validas}
              </div>
              <div className="text-sm font-medium text-green-800">Certificações Válidas</div>
              <div className="text-xs text-green-600 mt-1">
                V2: {metricas.certificacoes_status.detalhamento.v2_validas} | 
                V3: {metricas.certificacoes_status.detalhamento.v3_validas}
              </div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-3xl font-bold text-red-600 mb-2">
                {metricas.certificacoes_status.vencidas}
              </div>
              <div className="text-sm font-medium text-red-800">Certificações Vencidas</div>
              <div className="text-xs text-red-600 mt-1">
                V2: {metricas.certificacoes_status.detalhamento.v2_vencidas} | 
                V3: {metricas.certificacoes_status.detalhamento.v3_vencidas}
              </div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-3xl font-bold text-yellow-600 mb-2">
                {metricas.certificacoes_status.vencendo_30_dias}
              </div>
              <div className="text-sm font-medium text-yellow-800">Vencendo em 30 dias</div>
              <div className="text-xs text-yellow-600 mt-1">
                Requerem atenção imediata
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grid com duas colunas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Treinamentos */}
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-500" />
              Treinamentos Mais Realizados
            </h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metricas.top_treinamentos.length > 0 ? (
                metricas.top_treinamentos.map((treinamento, index) => (
                  <TopTreinamentoItem
                    key={treinamento.treinamento_codigo}
                    position={index + 1}
                    nome={treinamento.treinamento_nome}
                    codigo={treinamento.treinamento_codigo}
                    categoria={treinamento.categoria}
                    total={treinamento.total_certificacoes}
                  />
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">Nenhum treinamento encontrado</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Funcionários Críticos */}
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
              Funcionários Críticos ({metricas.funcionarios_criticos.length})
            </h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metricas.funcionarios_criticos.length > 0 ? (
                metricas.funcionarios_criticos.map((funcionario) => (
                  <div key={funcionario.matricula} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{funcionario.funcionario_nome}</div>
                      <div className="text-sm text-gray-600">Matrícula: {funcionario.matricula}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm">
                        <span className="text-red-600 font-bold">{funcionario.certificacoes_vencidas}</span> vencidas
                      </div>
                      <div className="text-xs text-gray-500">
                        {funcionario.total_certificacoes} total
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <p className="text-green-600 font-medium">Nenhum funcionário crítico!</p>
                  <p className="text-sm text-gray-500">Todos os funcionários estão em compliance</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Evolução mensal - Se houver dados */}
      {metricas.evolucao_mensal.length > 0 && (
        <Card>
          <CardHeader>
            <h2 className="text-xl font-semibold text-gray-900">Evolução Mensal de Certificações</h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metricas.evolucao_mensal.map((item) => (
                <div key={item.mes} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="font-medium text-gray-900">
                    {new Date(item.mes + '-01').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
                  </div>
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-blue-600">V2: {item.total_v2}</span>
                    <span className="text-green-600">V3: {item.total_v3}</span>
                    <span className="font-bold text-gray-900">Total: {item.total}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Rodapé com informações técnicas */}
      <div className="text-center text-xs text-gray-500 py-4 border-t">
        Dashboard v{metricas.metadata.versao_dashboard} • Fontes: {metricas.metadata.fontes_dados.join(', ')} • 
        Processamento: {metricas.metadata.processing_time_ms}ms
      </div>
    </div>
  );
}
