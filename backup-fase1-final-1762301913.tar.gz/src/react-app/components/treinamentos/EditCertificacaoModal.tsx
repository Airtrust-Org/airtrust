import { useState, useEffect } from 'react';
import { User, FileText, AlertCircle } from 'lucide-react';
import { BaseModal as Modal } from '../modals/BaseModal';
import Button from '../Button';
import { InputDataBrasil, useDateBrasil } from '../common/InputDataBrasil';

interface CertificacaoEdicao {
  id: number;
  funcionario_id: number;
  treinamento_id: number;
  funcionario_nome: string;
  treinamento_codigo: string;
  treinamento_nome: string;
  data_conclusao: string;
  data_vencimento?: string;
  instrutor?: string;
  nota?: number;
  observacoes?: string;
  arquivo_url?: string;
  status: string;
}

interface CertificacaoFormData {
  data_conclusao: string; // Formato brasileiro dd/mm/aaaa
  data_vencimento: string; // Formato brasileiro dd/mm/aaaa
  instrutor: string;
  nota: number | '';
  observacoes: string;
  arquivo_url: string;
  status: string;
}

interface EditCertificacaoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  certificacaoId: number | null;
}

export default function EditCertificacaoModal({
  isOpen,
  onClose,
  onSuccess,
  certificacaoId
}: EditCertificacaoModalProps) {
  const [certificacao, setCertificacao] = useState<CertificacaoEdicao | null>(null);
  
  const dataConclusao = useDateBrasil();
  const dataVencimento = useDateBrasil();
  
  const [formData, setFormData] = useState<CertificacaoFormData>({
    data_conclusao: '',
    data_vencimento: '',
    instrutor: '',
    nota: '',
    observacoes: '',
    arquivo_url: '',
    status: 'ATIVO'
  });
  
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  useEffect(() => {
    if (isOpen && certificacaoId) {
      loadCertificacao();
    }
  }, [isOpen, certificacaoId]);

  const loadCertificacao = async () => {
    if (!certificacaoId) return;

    try {
      setLoadingData(true);
      setError(null);

      const response = await fetch(`/api/v2/treinamentos/historico-certificacoes/${certificacaoId}`);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `Erro HTTP ${response.status}`);
      }

      if (!result.success) {
        throw new Error(result.error || 'Erro ao carregar dados da certificação');
      }

      const data = result.data;
      setCertificacao(data);
      
      dataConclusao.setDataBrasil(data.data_conclusao || '');
      dataVencimento.setDataBrasil(data.data_vencimento || '');
      
      setFormData({
        data_conclusao: data.data_conclusao || '',
        data_vencimento: data.data_vencimento || '',
        instrutor: data.instrutor || '',
        nota: data.nota || '',
        observacoes: data.observacoes || '',
        arquivo_url: data.arquivo_url || '',
        status: data.status || 'ATIVO'
      });

    } catch (err) {
      console.error('Erro ao carregar certificação:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoadingData(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'nota' 
        ? (value === '' ? '' : Number(value))
        : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!certificacaoId || !dataConclusao.dataBrasil) {
      setError('Data de conclusão é obrigatória');
      return;
    }
    
    if (!dataConclusao.isValid) {
      setError('Data de conclusão inválida');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const payload: any = {};
      
      if (dataConclusao.dataBrasil !== certificacao?.data_conclusao) {
        payload.data_conclusao = dataConclusao.dataBrasil;
      }
      if (dataVencimento.dataBrasil !== (certificacao?.data_vencimento || '')) {
        payload.data_vencimento = dataVencimento.dataBrasil || undefined;
      }
      if (formData.instrutor !== (certificacao?.instrutor || '')) {
        payload.instrutor = formData.instrutor || undefined;
      }
      if (formData.nota !== (certificacao?.nota || '')) {
        payload.nota = formData.nota || undefined;
      }
      if (formData.observacoes !== (certificacao?.observacoes || '')) {
        payload.observacoes = formData.observacoes || undefined;
      }
      if (formData.arquivo_url !== (certificacao?.arquivo_url || '')) {
        payload.arquivo_url = formData.arquivo_url || undefined;
      }
      if (formData.status !== certificacao?.status) {
        payload.status = formData.status;
      }

      const response = await fetch(`/api/v2/treinamentos/historico-certificacoes/${certificacaoId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `Erro HTTP ${response.status}`);
      }

      if (!result.success) {
        throw new Error(result.error || 'Erro desconhecido na atualização');
      }

      if (selectedFile && certificacaoId) {
        await uploadCertificateFile(certificacaoId, selectedFile);
      }

      onSuccess();
      onClose();
    } catch (err) {
      console.error('Erro ao atualizar certificação:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  const uploadCertificateFile = async (historicoId: number, file: File) => {
    try {
      const formData = new FormData();
      formData.append('arquivo', file);
      formData.append('historico_id', historicoId.toString());

      const response = await fetch('/api/v2/certificados-upload', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `Erro no upload: ${response.status}`);
      }

      if (!result.success) {
        throw new Error(result.error || 'Erro no upload do certificado');
      }

    } catch (err) {
      console.error('Erro no upload do certificado:', err);
      alert(`Certificação atualizada, mas erro no upload do arquivo: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const maxSize = 25 * 1024 * 1024;
      if (file.size > maxSize) {
        setError('Arquivo muito grande. Máximo 25MB permitido.');
        return;
      }

      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
      if (!allowedTypes.includes(file.type)) {
        setError('Tipo de arquivo não suportado. Use PDF, JPG ou PNG.');
        return;
      }

      setSelectedFile(file);
      setError(null);
    }
  };

  const handleDelete = async () => {
    if (!certificacaoId || !certificacao) return;

    const confirmacao = confirm(
      `Tem certeza que deseja excluir a certificação "${certificacao.treinamento_nome}" do funcionário "${certificacao.funcionario_nome}"?\n\n` +
      'Esta ação não pode ser desfeita.'
    );
    
    if (!confirmacao) return;

    try {
      setLoading(true);
      setError(null);

      const response = await fetch(`/api/v2/treinamentos/historico-certificacoes/${certificacaoId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `Erro HTTP ${response.status}`);
      }

      if (!result.success) {
        throw new Error(result.error || 'Erro ao excluir certificação');
      }

      onSuccess();
      onClose();
      
    } catch (err) {
      console.error('Erro ao excluir certificação:', err);
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setError(null);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleCancel} title="Editar Certificação">
      <div className="p-6 space-y-6" data-testid="edit-certificacao-modal">
        {loadingData ? (
          <div className="text-center py-8">
            <div className="inline-flex items-center px-4 py-2 text-sm font-medium text-blue-700 bg-blue-100 rounded-lg">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Carregando dados da certificação...
            </div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4" data-testid="load-error">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-red-600 text-sm">{error}</p>
            </div>
            <div className="mt-3">
              <Button variant="secondary" onClick={loadCertificacao} size="sm">
                Tentar Novamente
              </Button>
            </div>
          </div>
        ) : certificacao ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Cabeçalho com informações da certificação */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <FileText className="w-5 h-5 text-blue-600 mr-2" />
                <h4 className="font-medium text-blue-900">Informações da Certificação</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="font-medium text-blue-700">Funcionário:</span>
                  <span className="ml-2 text-blue-600">{certificacao.funcionario_nome}</span>
                </div>
                <div>
                  <span className="font-medium text-blue-700">Treinamento:</span>
                  <span className="ml-2 text-blue-600">{certificacao.treinamento_codigo} - {certificacao.treinamento_nome}</span>
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4" data-testid="form-error">
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Data de Conclusão - 🇧🇷 Formato Brasileiro */}
              <InputDataBrasil
                label="Data de Conclusão"
                value={dataConclusao.dataBrasil}
                onChange={dataConclusao.setDataBrasil}
                required
                maxDate={dataConclusao.hoje}
                id="data-conclusao-input"
              />

              {/* Data de Vencimento - 🇧🇷 Formato Brasileiro */}
              <InputDataBrasil
                label="Data de Vencimento"
                value={dataVencimento.dataBrasil}
                onChange={dataVencimento.setDataBrasil}
                minDate={dataConclusao.dataBrasil || dataConclusao.hoje}
                id="data-vencimento-input"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Instrutor */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <User className="w-4 h-4 inline mr-2" />
                  Instrutor
                </label>
                <input
                  type="text"
                  name="instrutor"
                  value={formData.instrutor}
                  onChange={handleInputChange}
                  placeholder="Nome do instrutor"
                  data-testid="instrutor-input"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              {/* Nota Final removida conforme especificação */}
            </div>

            {/* Status removido conforme especificação */}

            {/* URL do Certificado */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                URL do Certificado
              </label>
              <input
                type="url"
                name="arquivo_url"
                value={formData.arquivo_url}
                onChange={handleInputChange}
                placeholder="https://exemplo.com/certificado.pdf"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Observações */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Observações
              </label>
              <textarea
                name="observacoes"
                value={formData.observacoes}
                onChange={handleInputChange}
                rows={3}
                placeholder="Observações adicionais sobre a certificação"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Upload de Certificado */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Novo Certificado (PDF/Imagem) - Opcional
              </label>
              <input
                type="file"
                onChange={handleFileChange}
                accept=".pdf,.jpg,.jpeg,.png"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              {selectedFile && (
                <p className="text-sm text-green-600 mt-1">
                  Arquivo selecionado: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                </p>
              )}
              <p className="text-xs text-gray-500 mt-1">
                Máximo 25MB. Formatos: PDF, JPG, PNG. Substituirá certificado anterior se existir.
              </p>
            </div>

            {/* Botões */}
            <div className="flex justify-between items-center pt-4 border-t border-gray-200">
              <Button 
                variant="ghost" 
                onClick={handleDelete} 
                disabled={loading}
                className="text-red-600 hover:text-red-800 hover:bg-red-50"
                data-testid="delete-certificacao-btn"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                Excluir Certificação
              </Button>
              <div className="flex space-x-3">
                <Button 
                  variant="secondary" 
                  onClick={handleCancel} 
                  disabled={loading}
                  data-testid="cancel-edit-btn"
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  variant="primary" 
                  loading={loading}
                  data-testid="save-edit-btn"
                >
                  Salvar Alterações
                </Button>
              </div>
            </div>
          </form>
        ) : null}
      </div>
    </Modal>
  );
}
