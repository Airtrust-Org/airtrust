import { useState } from 'react';
import { UploadCloud } from 'lucide-react';
import { BaseModal as Modal } from '../modals/BaseModal';
import Button from '../Button';

interface QuickUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  historicoId: number;
  certificacaoNome?: string;
}

export default function QuickUploadModal({
  isOpen,
  onClose,
  onSuccess,
  historicoId,
  certificacaoNome
}: QuickUploadModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validTypes = ['application/pdf', 'image/jpeg', 'image/png'];
  
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!validTypes.includes(file.type)) {
        setError("Apenas PDF, JPG ou PNG permitidos");
        event.target.value = '';
        return;
      }
      if (file.size <= 10 * 1024 * 1024) {
        setSelectedFile(file);
        setError(null);
      } else {
        setError("Arquivo deve ter no máximo 10MB");
        event.target.value = '';
      }
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError('Selecione um arquivo para enviar');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('arquivo', selectedFile);
      formData.append('historico_id', historicoId.toString());
      
      const response = await fetch('/api/v2/certificados-upload', {
        method: 'POST',
        body: formData
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Erro no upload');
      }
      
      handleClose();
      onSuccess();
      
    } catch (error: any) {
      console.error('Erro no upload:', error);
      setError(error.message || 'Erro desconhecido no upload');
    } finally {
      setUploading(false);
    }
  };

  const handleClose = () => {
    setSelectedFile(null);
    setError(null);
    setUploading(false);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Upload Rápido de Certificado">
      <div className="p-6 space-y-6">
        {/* Informações da Certificação */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center">
            <UploadCloud className="w-5 h-5 text-blue-600 mr-2" />
            <div>
              <p className="text-sm font-medium text-blue-900">
                Anexar certificado para:
              </p>
              <p className="text-sm text-blue-700">
                {certificacaoNome || `Certificação ID ${historicoId}`}
              </p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {/* Upload de Arquivo */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Selecionar Arquivo (PDF/JPG/PNG)
          </label>
          <input
            type="file"
            accept=".pdf,.jpg,.jpeg,.png"
            onChange={handleFileSelect}
            disabled={uploading}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 disabled:opacity-50"
          />
          <p className="text-xs text-gray-500 mt-1">
            Máximo 10MB. Formatos aceitos: PDF, JPG, PNG
          </p>
        </div>

        {selectedFile && (
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-sm text-green-700">
              <strong>Arquivo selecionado:</strong> {selectedFile.name}
            </p>
            <p className="text-xs text-green-600">
              Tamanho: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
        )}

        {uploading && (
          <div className="text-center py-4">
            <div className="inline-flex items-center text-blue-600">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Enviando arquivo...
            </div>
          </div>
        )}

        {/* Botões */}
        <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
          <Button 
            variant="secondary" 
            onClick={handleClose} 
            disabled={uploading}
          >
            Cancelar
          </Button>
          <Button 
            variant="primary" 
            onClick={handleUpload}
            disabled={!selectedFile || uploading}
            loading={uploading}
          >
            <UploadCloud className="w-4 h-4 mr-2" />
            {uploading ? 'Enviando...' : 'Anexar Certificado'}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
