import { useState, useEffect } from 'react';
import { useApi } from '../../hooks/useApi';
import Card from '../Card';
import Button from '../Button';
import Badge from '../Badge';
import { BaseModal as Modal } from '../modals/BaseModal';
import { Plus, FileText, Users, AlertTriangle, Clock, Edit, Trash2 } from 'lucide-react';

interface Treinamento {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  instrutor_obrigatorio: boolean;
  nota_minima: number;
  carga_horaria?: number;
  ativo: boolean;
  created_at: string;
  updated_at: string;
}

interface Certificacao {
  id: number;
  funcionario_id: number;
  treinamento_id: number;
  data_conclusao: string;
  data_vencimento?: string;
  instrutor?: string;
  nota?: number;
  observacoes?: string;
  status: string;
  funcionario_nome: string;
  treinamento_codigo: string;
  treinamento_nome: string;
  created_at: string;
  updated_at: string;
}

export function DashboardTreinamentos() {
  const [activeTab, setActiveTab] = useState<'catalogo' | 'certificacoes'>('catalogo');
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<'treinamento' | 'certificacao'>('treinamento');
  const [dashboardStats, setDashboardStats] = useState({
    totalCertificacoes: 0,
    funcionariosAtivos: 0,
    vencendoEm30Dias: 0,
    vencidas: 0
  });

  const { 
    data: treinamentos, 
    loading: loadingTreinamentos, 
    error: errorTreinamentos,
    refetch: refetchTreinamentos 
  } = useApi<Treinamento[]>('/api/v2/treinamentos/catalogo-treinamentos');

  const { 
    data: certificacoes, 
    loading: loadingCertificacoes, 
    error: errorCertificacoes,
    refetch: refetchCertificacoes 
  } = useApi<Certificacao[]>('/api/v2/treinamentos/historico-certificacoes');

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await fetch('/api/v2/treinamentos/dashboard');
        const data = await response.json();
        
        if (data.success) {
          setDashboardStats({
            totalCertificacoes: data.dashboard?.estatisticas?.totalCertificacoes || 0,
            funcionariosAtivos: data.dashboard?.estatisticas?.funcionariosAtivos || 0,
            vencendoEm30Dias: data.dashboard?.estatisticas?.vencendoEm30Dias || 0,
            vencidas: data.dashboard?.estatisticas?.vencidas || 0
          });
        }
      } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
        setDashboardStats({
          totalCertificacoes: 0,
          funcionariosAtivos: 0,
          vencendoEm30Dias: 0,
          vencidas: 0
        });
      }
    };
    
    fetchDashboardData();
  }, []);

  const stats = {
    totalTreinamentos: treinamentos?.length || 0,
    treinamentosAtivos: treinamentos?.filter(t => t.ativo).length || 0,
    totalCertificacoes: dashboardStats.totalCertificacoes || certificacoes?.length || 0,
    certificacoesAtivas: certificacoes?.filter(c => c.status === 'ATIVO').length || 0,
    certificacoesVencendo: dashboardStats.vencendoEm30Dias || certificacoes?.filter(c => {
      if (!c.data_vencimento) return false;
      const vencimento = new Date(c.data_vencimento);
      const hoje = new Date();
      const diasParaVencimento = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
      return diasParaVencimento <= 30 && diasParaVencimento > 0;
    }).length || 0,
    certificacoesVencidas: dashboardStats.vencidas || certificacoes?.filter(c => {
      if (!c.data_vencimento) return false;
      const vencimento = new Date(c.data_vencimento);
      const hoje = new Date();
      return vencimento < hoje;
    }).length || 0,
    funcionariosAtivos: dashboardStats.funcionariosAtivos || 0
  };

  const getBadgeColor = (categoria: string) => {
    const cores = {
      'SEGURANÇA': 'bg-red-100 text-red-800',
      'OPERACIONAL': 'bg-blue-100 text-blue-800',
      'COMPLIANCE': 'bg-purple-100 text-purple-800',
      'EMERGÊNCIA': 'bg-yellow-100 text-yellow-800',
      'MANUTENÇÃO': 'bg-green-100 text-green-800',
      'LICENCA_MEDICA': 'bg-pink-100 text-pink-800',
      'PROFICIENCIA': 'bg-indigo-100 text-indigo-800'
    };
    return cores[categoria as keyof typeof cores] || 'bg-gray-100 text-gray-800';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ATIVO':
        return <Badge variant="success">Ativo</Badge>;
      case 'VENCIDO':
        return <Badge variant="danger">Vencido</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const diasParaVencimento = (dataVencimento?: string) => {
    if (!dataVencimento) return null;
    const vencimento = new Date(dataVencimento);
    const hoje = new Date();
    const dias = Math.ceil((vencimento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    return dias;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard de Treinamentos</h1>
          <p className="text-gray-600">Gestão completa de treinamentos e certificações</p>
        </div>
        <Button 
          onClick={() => {
            setModalType('treinamento');
            setShowModal(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Treinamento
        </Button>
      </div>

      {/* Cards de estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-blue-100">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Treinamentos</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalTreinamentos}</p>
              <p className="text-xs text-gray-500">{stats.treinamentosAtivos} ativos</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-green-100">
              <Users className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Funcionários Ativos</p>
              <p className="text-2xl font-bold text-gray-900">{stats.funcionariosAtivos}</p>
              <p className="text-xs text-gray-500">no sistema</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-yellow-100">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Vencendo (30 dias)</p>
              <p className="text-2xl font-bold text-gray-900">{stats.certificacoesVencendo}</p>
              <p className="text-xs text-gray-500">atenção necessária</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-red-100">
              <AlertTriangle className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Vencidas</p>
              <p className="text-2xl font-bold text-gray-900">{stats.certificacoesVencidas}</p>
              <p className="text-xs text-gray-500">ação imediata</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('catalogo')}
            className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'catalogo'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <FileText className="inline-block w-4 h-4 mr-2" />
            Catálogo de Treinamentos
          </button>
          <button
            onClick={() => setActiveTab('certificacoes')}
            className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'certificacoes'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Users className="inline-block w-4 h-4 mr-2" />
            Histórico de Certificações
          </button>
        </nav>
      </div>

      {/* Conteúdo das tabs */}
      {activeTab === 'catalogo' && (
        <div className="space-y-4">
          {loadingTreinamentos && (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="mt-2 text-gray-600">Carregando treinamentos...</p>
            </div>
          )}

          {errorTreinamentos && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">Erro ao carregar treinamentos: {errorTreinamentos}</p>
              <Button 
                variant="secondary" 
                size="sm" 
                className="mt-2"
                onClick={() => refetchTreinamentos()}
              >
                Tentar novamente
              </Button>
            </div>
          )}

          {treinamentos && treinamentos.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {treinamentos.map((treinamento) => (
                <Card key={treinamento.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{treinamento.nome}</h3>
                      <p className="text-sm text-gray-600">{treinamento.codigo}</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setModalType('treinamento');
                          setShowModal(true);
                        }}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${getBadgeColor(treinamento.categoria)}`}>
                      {treinamento.categoria}
                    </span>
                    
                    {treinamento.descricao && (
                      <p className="text-sm text-gray-600">{treinamento.descricao}</p>
                    )}
                    
                    <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                      {treinamento.periodicidade_meses && (
                        <span>Periodicidade: {treinamento.periodicidade_meses} meses</span>
                      )}
                      {treinamento.carga_horaria && (
                        <span>Carga horária: {treinamento.carga_horaria}h</span>
                      )}
                      <span>Nota mínima: {treinamento.nota_minima}</span>
                      {treinamento.instrutor_obrigatorio && (
                        <span className="text-yellow-600">Instrutor obrigatório</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    {treinamento.ativo ? (
                      <Badge variant="success">Ativo</Badge>
                    ) : (
                      <Badge variant="neutral">Inativo</Badge>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'certificacoes' && (
        <div className="space-y-4">
          {loadingCertificacoes && (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <p className="mt-2 text-gray-600">Carregando certificações...</p>
            </div>
          )}

          {errorCertificacoes && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">Erro ao carregar certificações: {errorCertificacoes}</p>
              <Button 
                variant="secondary" 
                size="sm" 
                className="mt-2"
                onClick={() => refetchCertificacoes()}
              >
                Tentar novamente
              </Button>
            </div>
          )}

          {certificacoes && certificacoes.length > 0 && (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Funcionário
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Treinamento
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Conclusão
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Vencimento
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {certificacoes.map((certificacao) => {
                      const dias = diasParaVencimento(certificacao.data_vencimento);
                      return (
                        <tr key={certificacao.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {certificacao.funcionario_nome}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {certificacao.treinamento_nome}
                              </div>
                              <div className="text-sm text-gray-500">{certificacao.treinamento_codigo}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatDate(certificacao.data_conclusao)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {certificacao.data_vencimento ? formatDate(certificacao.data_vencimento) : 'Sem vencimento'}
                            </div>
                            {dias !== null && (
                              <div className={`text-xs ${
                                dias < 0 ? 'text-red-600' : 
                                dias <= 30 ? 'text-yellow-600' : 
                                'text-green-600'
                              }`}>
                                {dias < 0 ? `Vencido há ${Math.abs(dias)} dias` :
                                 dias <= 30 ? `Vence em ${dias} dias` :
                                 `${dias} dias restantes`}
                              </div>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getStatusBadge(certificacao.status)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div className="flex space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setModalType('certificacao');
                                  setShowModal(true);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal placeholder - aqui você pode implementar os formulários */}
      {showModal && (
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title={modalType === 'treinamento' ? 'Gerenciar Treinamento' : 'Gerenciar Certificação'}
        >
          <div className="p-4">
            <p className="text-gray-600">
              Formulário para {modalType === 'treinamento' ? 'treinamento' : 'certificação'} em desenvolvimento...
            </p>
          </div>
        </Modal>
      )}
    </div>
  );
}
