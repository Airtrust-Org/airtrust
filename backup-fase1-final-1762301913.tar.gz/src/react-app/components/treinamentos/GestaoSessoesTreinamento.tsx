/**
 * Tela: Gestão de Sessões de Treinamento
 * Permite adicionar, editar e remover sessões vinculadas a treinamentos SIMULADOR
 */

import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

interface Treinamento {
  id: number;
  codigo: string;
  nome: string;
  categoria: string;
  descricao?: string;
}

interface Sessao {
  id: number;
  sessao_numero: number;
  nome_sessao: string;
  descricao?: string;
  template_id: number;
  template_nome?: string;
  template_codigo?: string;
  duracao_estimada_horas: number;
  obrigatoria: boolean;
  ordem: number;
  pontuacao_minima: number;
  total_manobras?: number;
}

interface Template {
  id: number;
  codigo: string;
  nome: string;
  duracao_horas: number;
  tipo: string;
}

export default function GestaoSessoesTreinamento() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [treinamento, setTreinamento] = useState<Treinamento | null>(null);
  const [sessoes, setSessoes] = useState<Sessao[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  
  const [modalAberto, setModalAberto] = useState(false);
  const [sessaoEditando, setSessaoEditando] = useState<Sessao | null>(null);
  const [formData, setFormData] = useState({
    template_id: '',
    nome_sessao: '',
    descricao: '',
    duracao_estimada_horas: 4,
    obrigatoria: true,
    pontuacao_minima: 5
  });
  
  useEffect(() => {
    if (id) {
      carregarDados();
    }
  }, [id]);
  
  const carregarDados = async () => {
    try {
      setLoading(true);
      
      const resTreinamento = await fetch(`/api/v2/treinamentos/${id}`);
      const dataTreinamento = await resTreinamento.json();
      
      if (dataTreinamento.success) {
        setTreinamento(dataTreinamento.data);
        
        if (dataTreinamento.data.categoria !== 'SIMULADOR') {
          alert('⚠️ Apenas treinamentos da categoria SIMULADOR podem ter sessões');
          navigate('/treinamentos');
          return;
        }
      }
      
      const resSessoes = await fetch(`/api/v2/treinamentos/${id}/sessoes`);
      const dataSessoes = await resSessoes.json();
      
      if (dataSessoes.success) {
        setSessoes(dataSessoes.sessoes || []);
      }
      
      const resTemplates = await fetch('/api/v2/simuladores-consolidado/templates');
      const dataTemplates = await resTemplates.json();
      
      if (dataTemplates.success) {
        setTemplates(dataTemplates.data || []);
      }
      
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      alert('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };
  
  const abrirModalAdicionar = () => {
    setSessaoEditando(null);
    setFormData({
      template_id: '',
      nome_sessao: '',
      descricao: '',
      duracao_estimada_horas: 4,
      obrigatoria: true,
      pontuacao_minima: 5
    });
    setModalAberto(true);
  };
  
  const abrirModalEditar = (sessao: Sessao) => {
    setSessaoEditando(sessao);
    setFormData({
      template_id: sessao.template_id.toString(),
      nome_sessao: sessao.nome_sessao,
      descricao: sessao.descricao || '',
      duracao_estimada_horas: sessao.duracao_estimada_horas,
      obrigatoria: sessao.obrigatoria,
      pontuacao_minima: sessao.pontuacao_minima
    });
    setModalAberto(true);
  };
  
  const handleSalvar = async () => {
    if (!formData.template_id || !formData.nome_sessao) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }
    
    try {
      setSalvando(true);
      
      if (sessaoEditando) {
        const response = await fetch(`/api/v2/treinamentos/${id}/sessoes/${sessaoEditando.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        
        if (response.ok) {
          setModalAberto(false);
          carregarDados();
        } else {
          const error = await response.json();
          alert(`❌ Erro: ${error.error}`);
        }
      } else {
        const response = await fetch(`/api/v2/treinamentos/${id}/sessoes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        
        if (response.ok) {
          setModalAberto(false);
          carregarDados();
        } else {
          const error = await response.json();
          alert(`❌ Erro: ${error.error}`);
        }
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
    } finally {
      setSalvando(false);
    }
  };
  
  const handleRemover = async (sessaoId: number) => {
    if (!confirm('Tem certeza que deseja remover esta sessão?')) {
      return;
    }
    
    try {
      const response = await fetch(`/api/v2/treinamentos/${id}/sessoes/${sessaoId}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        carregarDados();
      } else {
        const error = await response.json();
        alert(`❌ Erro: ${error.error}`);
      }
    } catch (error) {
      console.error('Erro ao remover:', error);
      alert('Erro ao remover sessão');
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }
  
  if (!treinamento) {
    return (
      <div className="container mx-auto p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">❌ Treinamento não encontrado</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-6 max-w-6xl">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              📋 Gestão de Sessões
            </h1>
            <p className="text-lg text-gray-700 mb-1">
              <strong>{treinamento.codigo}</strong> - {treinamento.nome}
            </p>
            {treinamento.descricao && (
              <p className="text-sm text-gray-600">{treinamento.descricao}</p>
            )}
            <div className="mt-3 flex items-center gap-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {treinamento.categoria}
              </span>
              <span className="text-sm text-gray-600">
                📊 {sessoes.length} sessão(ões) cadastrada(s)
              </span>
            </div>
          </div>
          <button
            onClick={() => navigate('/treinamentos')}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
          >
            ← Voltar
          </button>
        </div>
      </div>
      
      {/* Botão Adicionar */}
      <div className="mb-6">
        <button
          onClick={abrirModalAdicionar}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2"
        >
          ➕ Adicionar Sessão
        </button>
      </div>
      
      {/* Lista de Sessões */}
      {sessoes.length === 0 ? (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-6 text-center">
          <p className="text-amber-800 font-medium mb-2">
            ⚠️ Nenhuma sessão cadastrada
          </p>
          <p className="text-amber-700 text-sm">
            Adicione sessões para este treinamento usando o botão acima
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {sessoes.map((sessao) => (
            <div
              key={sessao.id}
              className="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-bold text-gray-900">
                      Sessão {sessao.sessao_numero}
                    </h3>
                    {sessao.obrigatoria && (
                      <span className="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-medium">
                        OBRIGATÓRIA
                      </span>
                    )}
                  </div>
                  
                  <p className="text-lg text-gray-800 mb-3">{sessao.nome_sessao}</p>
                  
                  {sessao.descricao && (
                    <p className="text-sm text-gray-600 mb-3">{sessao.descricao}</p>
                  )}
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Template:</span>
                      <p className="font-medium text-gray-900">
                        {sessao.template_codigo || sessao.template_nome}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-500">Duração:</span>
                      <p className="font-medium text-gray-900">
                        {sessao.duracao_estimada_horas}h
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-500">Pontuação Mínima:</span>
                      <p className="font-medium text-gray-900">
                        {sessao.pontuacao_minima}
                      </p>
                    </div>
                    {sessao.total_manobras !== undefined && (
                      <div>
                        <span className="text-gray-500">Manobras:</span>
                        <p className="font-medium text-gray-900">
                          {sessao.total_manobras}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => abrirModalEditar(sessao)}
                    className="px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                  >
                    ✏️ Editar
                  </button>
                  <button
                    onClick={() => handleRemover(sessao.id)}
                    className="px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200"
                  >
                    🗑️ Remover
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Modal Adicionar/Editar */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {sessaoEditando ? '✏️ Editar Sessão' : '➕ Adicionar Sessão'}
              </h2>
              
              <div className="space-y-4">
                {/* Template */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Template * {!sessaoEditando && '(define as manobras)'}
                  </label>
                  <select
                    value={formData.template_id}
                    onChange={(e) => setFormData({ ...formData, template_id: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    disabled={!!sessaoEditando}
                  >
                    <option value="">Selecione o template...</option>
                    {templates.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.codigo} - {t.nome} ({t.duracao_horas}h)
                      </option>
                    ))}
                  </select>
                  {sessaoEditando && (
                    <p className="text-xs text-gray-500 mt-1">
                      ℹ️ Template não pode ser alterado após criação
                    </p>
                  )}
                </div>
                
                {/* Nome */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome da Sessão *
                  </label>
                  <input
                    type="text"
                    value={formData.nome_sessao}
                    onChange={(e) => setFormData({ ...formData, nome_sessao: e.target.value })}
                    placeholder="Ex: Sessão 1: Procedimentos IFR"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* Descrição */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descrição
                  </label>
                  <textarea
                    value={formData.descricao}
                    onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                    placeholder="Descrição detalhada da sessão..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* Duração e Pontuação */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Duração (horas) *
                    </label>
                    <input
                      type="number"
                      value={formData.duracao_estimada_horas}
                      onChange={(e) => setFormData({ ...formData, duracao_estimada_horas: parseInt(e.target.value) })}
                      min="1"
                      max="12"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pontuação Mínima *
                    </label>
                    <input
                      type="number"
                      value={formData.pontuacao_minima}
                      onChange={(e) => setFormData({ ...formData, pontuacao_minima: parseInt(e.target.value) })}
                      min="1"
                      max="10"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                
                {/* Obrigatória */}
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="obrigatoria"
                    checked={formData.obrigatoria}
                    onChange={(e) => setFormData({ ...formData, obrigatoria: e.target.checked })}
                    className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <label htmlFor="obrigatoria" className="ml-2 text-sm text-gray-700">
                    Sessão obrigatória
                  </label>
                </div>
              </div>
              
              {/* Botões */}
              <div className="flex gap-3 mt-6 pt-6 border-t">
                <button
                  onClick={() => setModalAberto(false)}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                  disabled={salvando}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSalvar}
                  disabled={salvando}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
                >
                  {salvando ? 'Salvando...' : 'Salvar'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
