import React, { useState, useEffect } from 'react';
import { FileUp, Download, Loader, AlertCircle, X, CheckCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface Certificado {
  id: number;
  versao: number;
  arquivo_url: string;
  tipo_certificado: 'GERADO' | 'UPLOADED';
  eh_anterior: boolean;
  created_at: string;
  nome_arquivo: string;
  data_geracao?: string;
  data_upload?: string;
}

interface CertificadoGestaoModalProps {
  qualificacaoId: number;
  funcionarioId: number;
  habilitacaoId: number;
  isOpen: boolean;
  onClose: () => void;
}

export function CertificadoGestaoModal({
  qualificacaoId,
  funcionarioId,
  habilitacaoId,
  isOpen,
  onClose,
}: CertificadoGestaoModalProps) {
  const [abaSelecionada, setAbaSelecionada] = useState<'upload' | 'gerar'>('gerar');
  const [certificados, setCertificados] = useState<Certificado[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploadando, setUploadando] = useState(false);
  const [gerando, setGerando] = useState(false);
  const [arquivo, setArquivo] = useState<File | null>(null);

  // Carregar histórico de certificados
  useEffect(() => {
    if (isOpen) {
      carregarCertificados();
    }
  }, [isOpen, qualificacaoId]);

  async function carregarCertificados() {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Sessão expirada');
        return;
      }

      const res = await fetch(
        `/api/v2/certificados/qualificacao/${qualificacaoId}`,
        { 
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          } 
        }
      );
      
      if (!res.ok) {
        throw new Error(`Erro ${res.status}: ${res.statusText}`);
      }

      const data = await res.json();
      setCertificados(data.data || []);
    } catch (err) {
      console.error('Erro ao carregar certificados:', err);
      toast.error('Erro ao carregar histórico de certificados');
    } finally {
      setLoading(false);
    }
  }

  async function handleUpload(files: FileList | null) {
    if (!files || files.length === 0) {
      toast.error('Selecione um arquivo');
      return;
    }

    const file = files[0];

    if (!file.type.includes('pdf')) {
      toast.error('Apenas arquivos PDF são permitidos');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Arquivo muito grande (máximo 5MB)');
      return;
    }

    try {
      setUploadando(true);
      const formData = new FormData();
      formData.append('file', file);

      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Sessão expirada');
        return;
      }

      formData.append('habilitacao_id', habilitacaoId.toString());
      formData.append('funcionario_id', funcionarioId.toString());
      formData.append('qualificacao_id', qualificacaoId.toString());

      const res = await fetch(
        `/api/v2/certificados/upload`,
        {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` },
          body: formData,
        }
      );

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || 'Erro ao enviar certificado');
      }

      toast.success('Certificado enviado com sucesso');
      setArquivo(null);
      carregarCertificados();
      // Limpar input
      const input = document.getElementById('upload-file') as HTMLInputElement;
      if (input) input.value = '';
    } catch (err) {
      console.error('Erro ao enviar:', err);
      toast.error(`Erro ao enviar certificado: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
    } finally {
      setUploadando(false);
    }
  }

  async function handleGerar() {
    try {
      setGerando(true);
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Sessão expirada');
        return;
      }

      const res = await fetch(
        `/api/v2/certificados/${qualificacaoId}/gerar`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            habilitacao_id: habilitacaoId,
            funcionario_id: funcionarioId
          }),
        }
      );

      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(errorText || 'Erro ao gerar certificado');
      }

      const data = await res.json();
      toast.success('Certificado gerado com sucesso');
      carregarCertificados();
    } catch (err) {
      console.error('Erro ao gerar:', err);
      toast.error(`Erro ao gerar certificado: ${err instanceof Error ? err.message : 'Erro desconhecido'}`);
    } finally {
      setGerando(false);
    }
  }

  async function handleBaixar(arquivo_url: string, nome: string) {
    try {
      const token = localStorage.getItem('token');
      const headers: HeadersInit = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch(arquivo_url, { headers });
      if (!res.ok) {
        throw new Error('Erro ao baixar');
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = nome || 'certificado.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success('Download iniciado');
    } catch (err) {
      console.error('Erro ao baixar:', err);
      toast.error('Erro ao baixar certificado');
    }
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-6 border-b flex justify-between items-center flex-shrink-0">
          <h2 className="text-2xl font-bold">Gestão de Certificados</h2>
          <button 
            onClick={onClose} 
            className="text-white hover:opacity-80 transition"
            aria-label="Fechar"
          >
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b bg-gray-50 flex-shrink-0">
          <button
            onClick={() => setAbaSelecionada('gerar')}
            className={`flex-1 py-3 font-semibold transition text-center ${
              abaSelecionada === 'gerar'
                ? 'bg-white text-orange-600 border-b-2 border-orange-600'
                : 'text-gray-600 hover:bg-white'
            }`}
          >
            📄 Gerar Certificado
          </button>
          <button
            onClick={() => setAbaSelecionada('upload')}
            className={`flex-1 py-3 font-semibold transition text-center ${
              abaSelecionada === 'upload'
                ? 'bg-white text-orange-600 border-b-2 border-orange-600'
                : 'text-gray-600 hover:bg-white'
            }`}
          >
            📤 Upload Manual
          </button>
        </div>

        {/* Conteúdo Scrollável */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            {/* Tab: Gerar */}
            {abaSelecionada === 'gerar' && (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                  <AlertCircle className="text-blue-600 flex-shrink-0" size={20} />
                  <div className="text-sm text-blue-800">
                    <p className="font-semibold">Geração Automática</p>
                    <p>O certificado será gerado com base no template padrão da empresa, com dados da qualificação e funcionário.</p>
                  </div>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center bg-gray-50">
                  <div className="text-6xl mb-3">📜</div>
                  <p className="text-gray-600 font-semibold mb-2">Certificado Automático</p>
                  <p className="text-sm text-gray-500">Será gerado no formato padrão com logo e dados dinâmicos</p>
                </div>

                <button
                  onClick={handleGerar}
                  disabled={gerando}
                  className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition"
                >
                  {gerando ? (
                    <>
                      <Loader className="animate-spin" size={20} />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <CheckCircle size={20} />
                      Gerar Certificado Agora
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Tab: Upload */}
            {abaSelecionada === 'upload' && (
              <div className="space-y-4">
                <div className="relative">
                  <label htmlFor="upload-file" className="block">
                    <div className="border-2 border-dashed border-orange-300 rounded-lg p-12 text-center bg-orange-50 hover:bg-orange-100 transition cursor-pointer group">
                      <FileUp className="mx-auto text-orange-600 mb-3" size={48} />
                      <p className="text-gray-700 font-semibold mb-1">Clique ou arraste um arquivo PDF</p>
                      <p className="text-sm text-gray-500">Máximo 5MB, apenas PDF</p>
                      {arquivo && (
                        <p className="text-sm text-green-600 mt-2 font-semibold">📎 {arquivo.name}</p>
                      )}
                    </div>
                    <input
                      id="upload-file"
                      type="file"
                      accept=".pdf"
                      disabled={uploadando}
                      onChange={(e) => {
                        setArquivo(e.target.files?.[0] || null);
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      aria-label="Upload arquivo PDF"
                    />
                  </label>
                </div>

                <div className="text-sm text-gray-600 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <p className="font-semibold mb-1">📋 Nomenclatura Automática</p>
                  <p>O arquivo será armazenado com a nomenclatura:</p>
                  <p className="font-mono text-xs mt-1 text-orange-700">CERT-{'{matricula}'}-{'{codigo}'}-{'{data}'}.pdf</p>
                </div>

                <button
                  onClick={() => {
                    const input = document.getElementById('upload-file') as HTMLInputElement;
                    if (input && arquivo) handleUpload(input.files);
                  }}
                  disabled={uploadando || !arquivo}
                  className="w-full bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition"
                >
                  {uploadando ? (
                    <>
                      <Loader className="animate-spin" size={20} />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <FileUp size={20} />
                      Enviar Certificado
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Histórico de Certificados */}
          <div className="border-t bg-gray-50 p-6">
            <h3 className="font-bold text-lg mb-4">📋 Histórico de Versões</h3>

            {loading ? (
              <div className="flex justify-center py-8">
                <Loader className="animate-spin text-orange-600" size={32} />
              </div>
            ) : certificados.length === 0 ? (
              <p className="text-gray-500 text-center py-6">Nenhum certificado gerado ainda</p>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {certificados.map((cert) => (
                  <div
                    key={cert.id}
                    className={`flex items-center justify-between p-4 rounded-lg border transition ${
                      cert.eh_anterior
                        ? 'bg-gray-100 border-gray-300 opacity-75'
                        : 'bg-white border-green-300 hover:border-green-500 shadow-sm'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">v{cert.versao}</span>
                        {cert.eh_anterior && (
                          <span className="text-xs bg-gray-300 text-gray-800 px-2 py-1 rounded whitespace-nowrap">
                            [ANTERIOR]
                          </span>
                        )}
                        <span className="text-sm text-gray-600 whitespace-nowrap">
                          {cert.tipo_certificado === 'GERADO' ? '🤖 Gerado' : '📤 Enviado'}
                        </span>
                        <span className="text-xs text-gray-500 whitespace-nowrap">
                          {new Date(cert.created_at).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1 truncate">{cert.nome_arquivo}</p>
                    </div>

                    <button
                      onClick={() => handleBaixar(cert.arquivo_url, cert.nome_arquivo)}
                      className="ml-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition whitespace-nowrap flex-shrink-0"
                      aria-label={`Baixar ${cert.nome_arquivo}`}
                    >
                      <Download size={18} />
                      <span className="hidden sm:inline">Baixar</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t bg-gray-100 p-4 flex justify-end gap-2 flex-shrink-0">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gray-600 hover:bg-gray-700 text-white font-semibold rounded-lg transition"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}

export default CertificadoGestaoModal;
