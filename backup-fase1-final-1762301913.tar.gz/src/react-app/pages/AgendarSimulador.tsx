import { Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import FormularioAgendamento from '../components/simuladores/FormularioAgendamento';

const AgendarSimulador: React.FC = () => {
  const navigate = useNavigate();

  const LoadingFallback = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Carregando formulário de agendamento...</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Suspense fallback={<LoadingFallback />}>
        <FormularioAgendamento 
          onCancelar={() => navigate('/simuladores')}
        />
      </Suspense>
    </div>
  );
};

export default AgendarSimulador;
