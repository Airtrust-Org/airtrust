import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, ClipboardCheck, Star, Save, CheckCircle, AlertTriangle } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

interface Manobra {
  id: number;
  nome: string;
  pontuacao: number | null;
  status: string;
  observacoes?: string;
}

interface FichaAvaliacao {
  uuid: string;
  participante_nome: string;
  template_nome: string;
  instrutor_nome: string;
  status: string;
  manobras: Manobra[];
  observacoes_gerais?: string;
  nota?: number;
}

const AvaliarFicha: React.FC = () => {
  const { fichaUuid } = useParams<{ fichaUuid: string }>();
  const navigate = useNavigate();
  const [ficha, setFicha] = useState<FichaAvaliacao | null>(null);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [observacoesGerais, setObservacoesGerais] = useState('');

  useEffect(() => {
    if (fichaUuid) {
      carregarFicha();
    }
  }, [fichaUuid]);

  const carregarFicha = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/v2/simulador/fichas/${fichaUuid}`);
      const data = await response.json();
      
      if (data.success) {
        const fichaData = data.data;
        setFicha(fichaData);
        setObservacoesGerais(fichaData.observacoes_gerais || '');
      } else {
        const fichaSimulada: FichaAvaliacao = {
          uuid: fichaUuid!,
          participante_nome: 'Pedro Henrique Alves',
          template_nome: 'Check IFR Básico',
          instrutor_nome: 'João Silva Santos',
          status: 'EM_AVALIACAO',
          manobras: [
            { id: 1, nome: 'Decolagem Normal', pontuacao: null, status: 'PENDENTE' },
            { id: 2, nome: 'Aproximação ILS', pontuacao: null, status: 'PENDENTE' },
            { id: 3, nome: 'Pane de Motor', pontuacao: null, status: 'PENDENTE' },
            { id: 4, nome: 'Pouso com Vento', pontuacao: null, status: 'PENDENTE' },
            { id: 5, nome: 'Navegação RNAV', pontuacao: null, status: 'PENDENTE' }
          ]
        };
        setFicha(fichaSimulada);
      }
    } catch (error) {
      console.error('Erro ao carregar ficha:', error);
      alert('Erro ao carregar dados da ficha');
    } finally {
      setLoading(false);
    }
  };

  const atualizarPontuacaoManobra = (manobraId: number, pontuacao: number) => {
    if (!ficha) return;

    setFicha(prev => {
      if (!prev) return prev;
      
      return {
        ...prev,
        manobras: prev.manobras.map(manobra =>
          manobra.id === manobraId
            ? { 
                ...manobra, 
                pontuacao, 
                status: pontuacao >= 5 ? 'APROVADO' : 'REPROVADO' 
              }
            : manobra
        )
      };
    });
  };

  const calcularNotaFinal = () => {
    if (!ficha) return 0;
    
    const manobrasPontuadas = ficha.manobras.filter(m => m.pontuacao !== null);
    if (manobrasPontuadas.length === 0) return 0;
    
    const soma = manobrasPontuadas.reduce((acc, m) => acc + (m.pontuacao || 0), 0);
    return Number((soma / manobrasPontuadas.length).toFixed(1));
  };

  const finalizarAvaliacao = async () => {
    if (!ficha) return;

    const manobrasPendentes = ficha.manobras.filter(m => m.pontuacao === null);
    if (manobrasPendentes.length > 0) {
      alert(`Ainda há ${manobrasPendentes.length} manobra(s) sem pontuação. Avalie todas antes de finalizar.`);
      return;
    }

    const notaFinal = calcularNotaFinal();
    
    if (!confirm(`Finalizar avaliação com nota ${notaFinal}? Esta ação não pode ser desfeita.`)) {
      return;
    }

    try {
      setSalvando(true);
      
      const avaliacaoData = {
        nota: notaFinal,
        observacoes: observacoesGerais,
        manobras: ficha.manobras.map(m => ({
          id: m.id,
          pontuacao: m.pontuacao,
          observacoes: m.observacoes
        })),
        status_final: notaFinal >= 7 ? 'APROVADO' : 'REPROVADO'
      };

      const response = await fetch(`/api/v2/simulador/fichas/${fichaUuid}/avaliar`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(avaliacaoData)
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        navigate('/simuladores');
      } else {
        alert(`Erro ao finalizar avaliação: ${result.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('Erro ao finalizar avaliação:', error);
      alert('Erro de conexão ao finalizar avaliação');
    } finally {
      setSalvando(false);
    }
  };

  const salvarRascunho = async () => {
    if (!ficha) return;

    try {
      setSalvando(true);
      
      const rascunhoData = {
        manobras: ficha.manobras.map(m => ({
          id: m.id,
          pontuacao: m.pontuacao,
          observacoes: m.observacoes
        })),
        observacoes_gerais: observacoesGerais,
        status: 'RASCUNHO'
      };

      const response = await fetch(`/api/v2/simulador/fichas/${fichaUuid}/rascunho`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rascunhoData)
      });

      if (response.ok) {
      }
    } catch (error) {
      console.error('Erro ao salvar rascunho:', error);
    } finally {
      setSalvando(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <div className="flex items-center gap-3">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
            <span className="text-gray-600">Carregando ficha de avaliação...</span>
          </div>
        </div>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="container mx-auto py-8">
        <Card className="text-center p-8">
          <AlertTriangle className="mx-auto text-red-500 mb-4" size={48} />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Ficha não encontrada</h2>
          <p className="text-gray-600 mb-4">
            A ficha de avaliação solicitada não foi encontrada.
          </p>
          <Button onClick={() => navigate('/simuladores')}>
            Voltar ao Dashboard
          </Button>
        </Card>
      </div>
    );
  }

  const notaFinal = calcularNotaFinal();
  const statusFinal = notaFinal >= 7 ? 'APROVADO' : 'REPROVADO';
  const manobrasPendentes = ficha.manobras.filter(m => m.pontuacao === null).length;

  return (
    <div className="container mx-auto py-8">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button 
          onClick={() => navigate('/simuladores')} 
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          disabled={salvando}
        >
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <ClipboardCheck className="text-blue-600" size={24} />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Avaliar Ficha</h1>
              <p className="text-gray-600">
                {ficha.participante_nome} • {ficha.template_nome}
              </p>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="ghost" 
            onClick={salvarRascunho}
            disabled={salvando}
          >
            <Save size={16} className="mr-2" />
            Salvar Rascunho
          </Button>
          <Button 
            onClick={finalizarAvaliacao}
            disabled={salvando || manobrasPendentes > 0}
            className={statusFinal === 'APROVADO' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}
          >
            {salvando ? (
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
            ) : (
              <CheckCircle size={16} className="mr-2" />
            )}
            Finalizar Avaliação
          </Button>
        </div>
      </div>

      {/* Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-4">
          <div className="text-sm text-gray-500">Participante</div>
          <div className="font-semibold text-gray-900">{ficha.participante_nome}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Instrutor</div>
          <div className="font-semibold text-gray-900">{ficha.instrutor_nome}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Nota Atual</div>
          <div className={`text-xl font-bold ${notaFinal >= 7 ? 'text-green-600' : 'text-red-600'}`}>
            {notaFinal.toFixed(1)}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-500">Status</div>
          <div className={`font-semibold ${
            manobrasPendentes > 0 ? 'text-yellow-600' : 
            statusFinal === 'APROVADO' ? 'text-green-600' : 'text-red-600'
          }`}>
            {manobrasPendentes > 0 ? `${manobrasPendentes} Pendentes` : statusFinal}
          </div>
        </Card>
      </div>

      {/* Avaliação das Manobras */}
      <Card className="p-6 mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Avaliação das Manobras
        </h2>
        
        <div className="space-y-4">
          {ficha.manobras.map((manobra) => (
            <div key={manobra.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-gray-900">{manobra.nome}</h3>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  manobra.pontuacao === null ? 'bg-yellow-100 text-yellow-800' :
                  manobra.pontuacao >= 5 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {manobra.pontuacao === null ? 'Pendente' : manobra.status}
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600 min-w-[80px]">Pontuação:</span>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((pontos) => (
                    <button
                      key={pontos}
                      onClick={() => atualizarPontuacaoManobra(manobra.id, pontos)}
                      className={`w-8 h-8 rounded-full border-2 text-sm font-medium transition-colors ${
                        manobra.pontuacao === pontos
                          ? pontos >= 5 
                            ? 'bg-green-600 border-green-600 text-white' 
                            : 'bg-red-600 border-red-600 text-white'
                          : 'border-gray-300 text-gray-600 hover:border-blue-400 hover:text-blue-600'
                      }`}
                    >
                      {pontos}
                    </button>
                  ))}
                </div>
              </div>
              
              {manobra.pontuacao !== null && (
                <div className="mt-3 flex items-center gap-2">
                  {Array.from({ length: manobra.pontuacao }, (_, i) => (
                    <Star key={i} size={16} className="text-yellow-400 fill-current" />
                  ))}
                  <span className="text-sm text-gray-600">
                    {manobra.pontuacao}/10 pontos
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Observações Gerais */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Observações Gerais
        </h2>
        <textarea
          value={observacoesGerais}
          onChange={(e) => setObservacoesGerais(e.target.value)}
          rows={4}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Adicione comentários sobre o desempenho geral do participante..."
        />
      </Card>

      {/* Loading Overlay */}
      {salvando && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
            <span className="text-gray-700">Salvando avaliação...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default AvaliarFicha;
