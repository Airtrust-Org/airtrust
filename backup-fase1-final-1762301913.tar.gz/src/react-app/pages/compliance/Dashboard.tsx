import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Clock, Users, Filter, X } from 'lucide-react';

export default function ComplianceDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [matriz, setMatriz] = useState<any[]>([]);
  const [alertas, setAlertas] = useState<any[]>([]);
  const [filtros, setFiltros] = useState({ setor: '', funcao: '' });
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  useEffect(() => {
    carregarDashboard();
    carregarAlertas();
  }, []);

  useEffect(() => {
    carregarMatriz();
  }, [filtros]);

  const carregarDashboard = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/compliance/dashboard`);
      const data = await response.json();
      if (data.success) {
        setStats(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dashboard:', error);
    }
  };

  const carregarMatriz = async () => {
    try {
      const params = new URLSearchParams();
      if (filtros.setor) params.append('setor', filtros.setor);
      if (filtros.funcao) params.append('funcao', filtros.funcao);

      const response = await fetch(`${API_BASE_URL}/api/v2/compliance/matriz?${params}`);
      const data = await response.json();
      if (data.success) {
        setMatriz(data.funcionarios || []);
      }
    } catch (error) {
      console.error('Erro ao carregar matriz:', error);
    } finally {
      setLoading(false);
    }
  };

  const carregarAlertas = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/compliance/alertas`);
      const data = await response.json();
      if (data.success) {
        setAlertas(data.alertas || []);
      }
    } catch (error) {
      console.error('Erro ao carregar alertas:', error);
    }
  };

  const getStatusColor = (validas: number, total: number) => {
    if (total === 0) return 'bg-gray-100 text-gray-800';
    const taxa = (validas / total) * 100;
    if (taxa >= 80) return 'bg-green-100 text-green-800';
    if (taxa >= 50) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const limparFiltros = () => {
    setFiltros({ setor: '', funcao: '' });
  };

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Compliance Matrix</h1>
          <p className="text-gray-600 mt-1">Visão consolidada de certificações e vencimentos</p>
        </div>

        {/* Cards de Métricas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card card-primary rounded-xl p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total Funcionários</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats?.stats?.total_funcionarios || 0}
                </p>
                <p className="text-xs text-gray-500 mt-1">Ativos no sistema</p>
              </div>
              <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center">
                <Users className="w-7 h-7 text-gray-600" />
              </div>
            </div>
          </div>

          <div className="card card-success rounded-xl p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Certificações Válidas</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats?.stats?.total_validas || 0}
                </p>
                <p className="text-xs text-gray-500 mt-1">Em conformidade</p>
              </div>
              <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-7 h-7 text-gray-600" />
              </div>
            </div>
          </div>

          <div className="card card-warning rounded-xl p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Vencendo (30 dias)</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats?.stats?.total_vencendo || 0}
                </p>
                <p className="text-xs text-gray-500 mt-1">Requer atenção</p>
              </div>
              <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center">
                <Clock className="w-7 h-7 text-gray-600" />
              </div>
            </div>
          </div>

          <div className="card card-error rounded-xl p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Vencidas</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {stats?.stats?.total_vencidas || 0}
                </p>
                <p className="text-xs text-gray-500 mt-1">Ação urgente</p>
              </div>
              <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-7 h-7 text-gray-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtros
            </h2>
            {(filtros.setor || filtros.funcao) && (
              <button
                onClick={limparFiltros}
                className="flex items-center gap-2 px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
                Limpar Filtros
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Filtrar por Setor (ex: Operações)"
              value={filtros.setor}
              onChange={(e) => setFiltros({ ...filtros, setor: e.target.value })}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <input
              type="text"
              placeholder="Filtrar por Função ID"
              value={filtros.funcao}
              onChange={(e) => setFiltros({ ...filtros, funcao: e.target.value })}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Matriz de Compliance */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            Matriz de Compliance por Funcionário
          </h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Matrícula
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Nome
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Função
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Setor
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Total
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Válidas
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Vencendo
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Vencidas
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {matriz.map((f: any) => (
                  <tr key={f.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-sm text-gray-900">{f.matricula}</td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">{f.nome}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{f.funcao_nome || '-'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{f.setor || '-'}</td>
                    <td className="px-4 py-3 text-sm text-center font-medium">
                      {f.total_cert || 0}
                    </td>
                    <td className="px-4 py-3 text-sm text-center text-green-600 font-bold">
                      {f.validas || 0}
                    </td>
                    <td className="px-4 py-3 text-sm text-center text-yellow-600 font-bold">
                      {f.vencendo || 0}
                    </td>
                    <td className="px-4 py-3 text-sm text-center text-red-600 font-bold">
                      {f.vencidas || 0}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(
                          f.validas,
                          f.total_cert,
                        )}`}
                      >
                        {f.total_cert > 0
                          ? `${Math.round((f.validas / f.total_cert) * 100)}%`
                          : 'N/A'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {matriz.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <p>Nenhum funcionário encontrado com os filtros aplicados</p>
              </div>
            )}
          </div>
        </div>

        {/* Alertas de Vencimento */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Alertas de Vencimento
          </h2>
          <div className="space-y-3">
            {alertas.map((a: any, i: number) => (
              <div
                key={i}
                className={`p-4 rounded-lg border-l-4 ${
                  a.status_compliance === 'VENCIDO'
                    ? 'bg-red-50 border-red-600'
                    : 'bg-yellow-50 border-yellow-600'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">
                      {a.nome} ({a.matricula}) - {a.setor}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      <span className="font-medium">Certificação:</span> {a.nome_treinamento}
                      {a.codigo_treinamento && ` (${a.codigo_treinamento})`}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      <span className="font-medium">Vencimento:</span>{' '}
                      {new Date(a.data_vencimento).toLocaleDateString('pt-BR')}
                      {a.dias_restantes && (
                        <span className="ml-2">
                          ({Math.floor(a.dias_restantes)} dias{' '}
                          {a.dias_restantes < 0 ? 'atrás' : 'restantes'})
                        </span>
                      )}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      a.status_compliance === 'VENCIDO'
                        ? 'bg-red-600 text-white'
                        : 'bg-yellow-600 text-white'
                    }`}
                  >
                    {a.status_compliance}
                  </span>
                </div>
              </div>
            ))}

            {alertas.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
                <p>Nenhum alerta de vencimento no momento</p>
                <p className="text-sm mt-1">Todas as certificações estão em dia!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
