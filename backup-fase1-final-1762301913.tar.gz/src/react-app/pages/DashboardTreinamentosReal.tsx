import DashboardTreinamentosAtualizado from '@/react-app/components/treinamentos/DashboardTreinamentosAtualizado';

export default function DashboardTreinamentosReal() {
  return (
    <div className="container mx-auto px-4 py-6">
      <DashboardTreinamentosAtualizado />
    </div>
  );
}
