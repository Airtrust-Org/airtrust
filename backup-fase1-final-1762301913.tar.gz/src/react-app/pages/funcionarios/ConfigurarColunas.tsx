import { useState, useEffect } from 'react';
import { X, Eye, EyeOff, GripVertical } from 'lucide-react';

interface Coluna {
  id: string;
  label: string;
  visivel: boolean;
  ordem: number;
}

interface Props {
  onClose?: () => void;
  onSalvar: (colunas: Coluna[]) => void;
}

export default function ConfigurarColunas({ onClose, onSalvar }: Props) {
  const [colunas, setColunas] = useState<Coluna[]>([
    { id: 'nome', label: 'Nome Completo', visivel: true, ordem: 0 },
    { id: 'nome_guerra', label: 'Nome Guerra', visivel: true, ordem: 1 },
    { id: 'funcao', label: 'Função', visivel: true, ordem: 2 },
    { id: 'aeronave', label: 'Aeronave', visivel: true, ordem: 3 },
    { id: 'setor', label: 'Setor', visivel: false, ordem: 4 },
    { id: 'cpf', label: 'CPF', visivel: true, ordem: 5 },
    { id: 'data_nascimento', label: 'Data Nasc.', visivel: true, ordem: 6 },
    { id: 'codigo_anac', label: 'Código ANAC', visivel: true, ordem: 7 },
    { id: 'sispat', label: 'SISPAT', visivel: false, ordem: 8 },
    { id: 'prestserv', label: 'PrestServ', visivel: false, ordem: 9 },
    { id: 'matricula', label: 'Matrícula', visivel: true, ordem: 10 },
    { id: 'data_admissao', label: 'Data Admissão', visivel: false, ordem: 11 },
    { id: 'email', label: 'E-mail', visivel: true, ordem: 12 },
    { id: 'telefone', label: 'Telefone', visivel: true, ordem: 13 },
    { id: 'nivel_icao', label: 'Nível ICAO', visivel: false, ordem: 14 },
    { id: 'validade_icao', label: 'Validade ICAO', visivel: false, ordem: 15 },
    { id: 'cma', label: 'CMA', visivel: false, ordem: 16 },
    { id: 'validade_cma', label: 'Validade CMA', visivel: false, ordem: 17 },
    { id: 'aso', label: 'ASO', visivel: false, ordem: 18 },
    { id: 'validade_aso', label: 'Validade ASO', visivel: false, ordem: 19 },
    { id: 'status', label: 'Status', visivel: false, ordem: 20 },
  ]);

  useEffect(() => {
    const saved = localStorage.getItem('funcionarios_colunas_config');
    if (saved) {
      setColunas(JSON.parse(saved));
    }
  }, []);

  const toggleVisibilidade = (id: string) => {
    setColunas(prev =>
      prev.map(col =>
        col.id === id ? { ...col, visivel: !col.visivel } : col
      )
    );
  };

  const handleSalvar = () => {
    localStorage.setItem('funcionarios_colunas_config', JSON.stringify(colunas));
    onSalvar(colunas);
    if (onClose) onClose();
  };

  const handleResetar = () => {
    const padrao: Coluna[] = [
      { id: 'nome', label: 'Nome Completo', visivel: true, ordem: 0 },
      { id: 'nome_guerra', label: 'Nome Guerra', visivel: true, ordem: 1 },
      { id: 'funcao', label: 'Função', visivel: true, ordem: 2 },
      { id: 'aeronave', label: 'Aeronave', visivel: true, ordem: 3 },
      { id: 'setor', label: 'Setor', visivel: false, ordem: 4 },
      { id: 'cpf', label: 'CPF', visivel: true, ordem: 5 },
      { id: 'data_nascimento', label: 'Data Nasc.', visivel: true, ordem: 6 },
      { id: 'codigo_anac', label: 'Código ANAC', visivel: true, ordem: 7 },
      { id: 'sispat', label: 'SISPAT', visivel: false, ordem: 8 },
      { id: 'prestserv', label: 'PrestServ', visivel: false, ordem: 9 },
      { id: 'matricula', label: 'Matrícula', visivel: true, ordem: 10 },
      { id: 'data_admissao', label: 'Data Admissão', visivel: false, ordem: 11 },
      { id: 'email', label: 'E-mail', visivel: true, ordem: 12 },
      { id: 'telefone', label: 'Telefone', visivel: true, ordem: 13 },
      { id: 'nivel_icao', label: 'Nível ICAO', visivel: false, ordem: 14 },
      { id: 'validade_icao', label: 'Validade ICAO', visivel: false, ordem: 15 },
      { id: 'cma', label: 'CMA', visivel: false, ordem: 16 },
      { id: 'validade_cma', label: 'Validade CMA', visivel: false, ordem: 17 },
      { id: 'aso', label: 'ASO', visivel: false, ordem: 18 },
      { id: 'validade_aso', label: 'Validade ASO', visivel: false, ordem: 19 },
      { id: 'status', label: 'Status', visivel: false, ordem: 20 },
    ];
    setColunas(padrao);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-lg">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold">Configurar Colunas</h2>
          {onClose && (
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="w-6 h-6" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="p-6 space-y-3 max-h-96 overflow-y-auto">
          {colunas.map(coluna => (
            <div
              key={coluna.id}
              className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border"
            >
              <GripVertical className="w-5 h-5 text-gray-400 cursor-move" />
              
              <span className="flex-1 font-medium">{coluna.label}</span>
              
              <button
                onClick={() => toggleVisibilidade(coluna.id)}
                className={`p-2 rounded-lg transition ${
                  coluna.visivel
                    ? 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                    : 'bg-gray-200 text-gray-500 hover:bg-gray-300'
                }`}
              >
                {coluna.visivel ? (
                  <Eye className="w-5 h-5" />
                ) : (
                  <EyeOff className="w-5 h-5" />
                )}
              </button>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t bg-gray-50">
          <button
            onClick={handleResetar}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition"
          >
            Resetar
          </button>
          <button
            onClick={handleSalvar}
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
          >
            Salvar Configuração
          </button>
        </div>
      </div>
    </div>
  );
}
