import { useEffect, useState } from 'react';
import { FileText, Download, Trash2, Calendar } from 'lucide-react';

interface ListaDocumentosProps {
  funcionarioId: number;
}

export default function ListaDocumentos({ funcionarioId }: ListaDocumentosProps) {
  const [documentos, setDocumentos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    carregarDocumentos();
  }, [funcionarioId]);
  
  const carregarDocumentos = async () => {
    try {
      const response = await fetch(
        `${window.location.origin}/api/v2/funcionarios/${funcionarioId}/documentos`
      );
      if (response.ok) {
        const data = await response.json();
        setDocumentos(data.data || data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar documentos:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleDownload = async (docId: number, nomeArquivo: string) => {
    try {
      const response = await fetch(
        `${window.location.origin}/api/v2/funcionarios/documentos/${docId}/download`
      );
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nomeArquivo;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      } else {
        alert('Erro ao baixar documento');
      }
    } catch (error) {
      console.error('Erro no download:', error);
      alert('Erro ao baixar documento');
    }
  };
  
  const handleExcluir = async (docId: number) => {
    if (!confirm('Tem certeza que deseja excluir este documento?')) return;
    
    try {
      const response = await fetch(
        `${window.location.origin}/api/v2/funcionarios/documentos/${docId}`,
        { method: 'DELETE' }
      );
      
      if (response.ok) {
        alert('Documento excluído!');
        carregarDocumentos();
      } else {
        alert('Erro ao excluir documento');
      }
    } catch (error) {
      console.error('Erro ao excluir:', error);
      alert('Erro ao excluir documento');
    }
  };
  
  if (loading) {
    return <div className="text-center py-4">Carregando...</div>;
  }
  
  if (documentos.length === 0) {
    return (
      <div className="text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed">
        <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
        <p className="text-gray-600">Nenhum documento anexado</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-3">
      <h3 className="text-lg font-semibold">📁 Documentos Anexados ({documentos.length})</h3>
      
      <div className="space-y-2">
        {documentos.map(doc => (
          <div
            key={doc.id}
            className="flex items-center justify-between p-4 bg-white border rounded-lg hover:shadow-md transition"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-50 rounded-lg">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="font-medium">{doc.tipo_documento}</p>
                <p className="text-sm text-gray-500">{doc.nome_arquivo}</p>
                <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
                  <Calendar className="w-3 h-3" />
                  {new Date(doc.data_upload + 'T00:00:00').toLocaleDateString('pt-BR')}
                  <span>•</span>
                  {(doc.tamanho_bytes / 1024).toFixed(2)} KB
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => handleDownload(doc.id, doc.nome_arquivo)}
                className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                title="Baixar"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleExcluir(doc.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                title="Excluir"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
