import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, FileText, History, Zap } from 'lucide-react';
import AbaDadosPessoais from './AbaDadosPessoais';
import AbaDocumentos from './AbaDocumentos';
import AbaHistorico from './AbaHistorico';
import AbaAcoesRapidas from './AbaAcoesRapidas';

export default function PerfilFuncionario() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [funcionario, setFuncionario] = useState<any>(null);
  const [abaAtiva, setAbaAtiva] = useState('dados');
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    carregarFuncionario();
  }, [id]);
  
  const carregarFuncionario = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/funcionarios/${id}`);
      if (response.ok) {
        const data = await response.json();
        setFuncionario(data);
      }
    } catch (error) {
      console.error('Erro ao carregar funcionário:', error);
    } finally {
      setLoading(false);
    }
  };
  
  if (loading) {
    return <div className="flex items-center justify-center h-screen">Carregando...</div>;
  }
  
  if (!funcionario) {
    return <div className="flex items-center justify-center h-screen">Funcionário não encontrado</div>;
  }
  
  const abas = [
    { id: 'dados', label: 'Dados Pessoais', icone: User },
    { id: 'documentos', label: 'Documentos', icone: FileText },
    { id: 'historico', label: 'Histórico', icone: History },
    { id: 'acoes', label: 'Ações Rápidas', icone: Zap }
  ];
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <button
            onClick={() => navigate('/funcionarios')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Voltar para lista
          </button>
          
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              {/* Avatar */}
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                {funcionario.nome?.split(' ').map((n: string) => n[0]).join('').substring(0, 2)}
              </div>
              
              {/* Info Básica */}
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{funcionario.nome}</h1>
                <p className="text-gray-600">{funcionario.funcao_nome || funcionario.funcao}</p>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                  <span>📋 {funcionario.matricula}</span>
                  {funcionario.setor_nome && <span>🏢 {funcionario.setor_nome}</span>}
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="flex gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{funcionario.stats?.total_documentos || 0}</p>
                <p className="text-xs text-gray-600">Documentos</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{funcionario.stats?.total_certificacoes || 0}</p>
                <p className="text-xs text-gray-600">Certificações</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Abas */}
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-1 border-b">
            {abas.map(aba => {
              const Icone = aba.icone;
              return (
                <button
                  key={aba.id}
                  onClick={() => setAbaAtiva(aba.id)}
                  className={`flex items-center gap-2 px-6 py-3 font-medium transition ${
                    abaAtiva === aba.id
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icone className="w-5 h-5" />
                  {aba.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Conteúdo das Abas */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {abaAtiva === 'dados' && <AbaDadosPessoais funcionario={funcionario} />}
        {abaAtiva === 'documentos' && <AbaDocumentos funcionarioId={funcionario.id} />}
        {abaAtiva === 'historico' && <AbaHistorico funcionarioId={funcionario.id} />}
        {abaAtiva === 'acoes' && <AbaAcoesRapidas funcionario={funcionario} />}
      </div>
    </div>
  );
}
