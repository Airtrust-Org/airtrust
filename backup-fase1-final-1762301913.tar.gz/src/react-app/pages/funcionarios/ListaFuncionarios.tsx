import { useState, useEffect, useMemo } from 'react';
import { Plus, Upload, Download, Search, Settings, Filter, ArrowUpDown, ArrowUp, ArrowDown, X, Folder, Edit2, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import ModalFuncionario from './ModalFuncionario';
import ConfigurarColunas from './ConfigurarColunas';
import AdicionarFiltro from './AdicionarFiltro';
import { Pagination } from '../../../components/shared/Pagination';
import { formatarDataExibicao } from '../../utils/dateUtils';
import { 
  formatarCPF, 
  formatarTelefone, 
  formatarCodigoANAC, 
  formatarMatricula
} from '../../utils/formatters';

interface Coluna {
  id: string;
  label: string;
  visivel: boolean;
  ordem: number;
}

type SortDirection = 'asc' | 'desc' | null;
type SortableColumn = 'nome' | 'funcao' | 'cpf' | 'matricula' | 'email' | 'telefone' | 'data_nascimento' | 'codigo_anac' | 'anv';

interface SortConfig {
  column: SortableColumn | null;
  direction: SortDirection;
}

export function ListaFuncionarios() {
  const navigate = useNavigate();
  const [funcionarios, setFuncionarios] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [termoBusca, setTermoBusca] = useState('');
  const [modalConfigColunasAberto, setModalConfigColunasAberto] = useState(false);
  const [modalNovoAberto, setModalNovoAberto] = useState(false);
  const [modalAdicionarFiltroAberto, setModalAdicionarFiltroAberto] = useState(false);
  const [funcionarioSelecionado, setFuncionarioSelecionado] = useState<any>(null);
  const [filtrosAtivos, setFiltrosAtivos] = useState<string[]>([]);
  const [excluindo, setExcluindo] = useState<number | null>(null);
  const [sortConfig, setSortConfig] = useState<SortConfig>({
    column: null,
    direction: null
  });
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 0,
    hasNext: false,
    hasPrev: false
  });
  
  const [colunasConfig, setColunasConfig] = useState<Coluna[]>([
    { id: 'nome', label: 'Nome', visivel: true, ordem: 0 },
    { id: 'funcao', label: 'Função', visivel: true, ordem: 1 },
    { id: 'anv', label: 'Aeronave', visivel: true, ordem: 2 },
    { id: 'cpf', label: 'CPF', visivel: true, ordem: 3 },
    { id: 'data_nascimento', label: 'Data Nasc.', visivel: true, ordem: 4 },
    { id: 'codigo_anac', label: 'Código ANAC', visivel: true, ordem: 5 },
    { id: 'matricula', label: 'Matrícula', visivel: true, ordem: 6 },
    { id: 'email', label: 'E-mail', visivel: true, ordem: 7 },
    { id: 'telefone', label: 'Telefone', visivel: true, ordem: 8 },
  ]);

  useEffect(() => {
    carregarFuncionarios();
  }, [pagination.page, termoBusca]);

  const colunasVisiveis = useMemo(() => 
    colunasConfig
      .filter(col => col.visivel)
      .sort((a, b) => a.ordem - b.ordem),
    [colunasConfig]
  );
  
  const handleSort = (column: SortableColumn) => {
    let direction: SortDirection = 'asc';
    
    if (sortConfig.column === column) {
      if (sortConfig.direction === 'asc') {
        direction = 'desc';
      } else if (sortConfig.direction === 'desc') {
        direction = null;
      }
    }
    
    setSortConfig({ column: direction ? column : null, direction });
  };

  const funcionariosFiltradosEOrdenados = useMemo(() => {
    let resultado = [...funcionarios];
    
    if (termoBusca) {
      const termo = termoBusca.toLowerCase().trim();
      resultado = resultado.filter(f => {
        const nome = (f.nome || '').toLowerCase();
        const cpf = (f.cpf || '').replace(/\D/g, '');
        const matricula = (f.matricula || '').toLowerCase();
        const email = (f.email || '').toLowerCase();
        const codigoAnac = (f.codigo_anac || '').toLowerCase();
        
        return (
          nome.includes(termo) ||
          cpf.includes(termo) ||
          matricula.includes(termo) ||
          email.includes(termo) ||
          codigoAnac.includes(termo)
        );
      });
    }
    
    if (sortConfig.column && sortConfig.direction) {
      resultado.sort((a, b) => {
        const aVal = a[sortConfig.column!] || '';
        const bVal = b[sortConfig.column!] || '';
        
        let comparison = 0;
        
        if (sortConfig.column === 'data_nascimento') {
          const aDate = new Date(aVal).getTime();
          const bDate = new Date(bVal).getTime();
          comparison = aDate - bDate;
        } else {
          comparison = String(aVal).localeCompare(String(bVal), 'pt-BR', {
            numeric: true,
            sensitivity: 'base'
          });
        }
        
        return sortConfig.direction === 'asc' ? comparison : -comparison;
      });
    }
    
    return resultado;
  }, [funcionarios, termoBusca, sortConfig]);

  async function carregarFuncionarios() {
    try {
      setLoading(true);
      const url = `${window.location.origin}/api/v2/funcionarios?page=${pagination.page}&limit=${pagination.limit}&search=${termoBusca}`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        
        if (data.pagination) {
          setFuncionarios(data.data || []);
          setPagination(data.pagination);
        } else {
          setFuncionarios(data.data || data.funcionarios || data || []);
        }
      } else {
        console.error('[FUNCIONARIOS] Erro HTTP:', response.status);
        setFuncionarios([]);
      }
    } catch (error) {
      console.error('Erro ao carregar funcionários:', error);
      setFuncionarios([]);
    } finally {
      setLoading(false);
    }
  }

  const handleAdicionarFiltro = (filtroId: string) => {
    setFiltrosAtivos(prev => [...prev, filtroId]);
  };

  const handleExcluir = async (id: number, nome: string) => {
    if (excluindo === id) {
      return;
    }

    const confirmar = window.confirm(
      `Tem certeza que deseja excluir "${nome}"?\n\nEsta ação não pode ser desfeita.`
    );
    
    if (!confirmar) return;
    
    setExcluindo(id); // Marcar como em processo
    
    try {
      
      const response = await fetch(`${window.location.origin}/api/v2/funcionarios/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      
      if (response.ok) {
        
        const novaLista = funcionarios.filter(f => f.id !== id);
        setFuncionarios(novaLista);
        
        setTimeout(async () => {
          const beforeReload = novaLista.length;
          await carregarFuncionarios();
          setExcluindo(null);
        }, 2000);
      } else {
        const errorText = await response.text();
        console.error('Erro do servidor:', errorText);
        
        let errorMessage = 'Falha na operação';
        try {
          const error = JSON.parse(errorText);
          errorMessage = error.message || errorMessage;
        } catch (e) {
          errorMessage = errorText || errorMessage;
        }
        
        alert(`Erro ao excluir: ${errorMessage}`);
        setExcluindo(null);
      }
    } catch (error) {
      console.error('Erro ao excluir funcionário:', error);
      alert('Erro ao conectar com servidor');
      setExcluindo(null);
    }
  };

  const handleExportarCSV = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/funcionarios/exportar`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `funcionarios_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      } else {
        alert('Erro ao exportar CSV');
      }
    } catch (error) {
      console.error('Erro exportar:', error);
      alert('Erro ao exportar CSV');
    }
  };


  const handleSalvarFuncionario = async (dados: any) => {
    try {
      
      const url = dados.id 
        ? `${window.location.origin}/api/v2/funcionarios/${dados.id}`
        : `${window.location.origin}/api/v2/funcionarios`;
      
      const response = await fetch(url, {
        method: dados.id ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dados)
      });
      
      
      if (response.ok) {
        setModalNovoAberto(false);
        carregarFuncionarios();
      } else {
        const errorData = await response.json();
        console.error('[SAVE ERROR]', errorData);
      }
    } catch (error) {
      console.error('[SAVE EXCEPTION]', error);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-hidden">
      {/* Header com título e botões de ação */}
      <div className="flex items-center justify-between flex-shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Lista de Funcionários</h2>
          <p className="text-sm text-gray-600 mt-1">
            {funcionariosFiltradosEOrdenados.length} de {funcionarios.length} funcionários encontrados
            {termoBusca && (
              <span className="ml-2 text-blue-600">
                (filtrando por "{termoBusca}")
              </span>
            )}
          </p>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setModalConfigColunasAberto(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 bg-white rounded-lg hover:bg-gray-50 text-sm transition"
          >
            <Settings className="w-4 h-4" />
            Configurar Colunas
          </button>

          <button
            onClick={() => navigate('/funcionarios/importar')}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm transition"
          >
            <Upload className="w-4 h-4" />
            Importar
          </button>
          
          <button
            onClick={() => setModalNovoAberto(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm transition"
          >
            <Plus className="w-4 h-4" />
            Novo Funcionário
          </button>
        </div>
      </div>
      
      {/* Barra de busca */}
      <div className="bg-white p-4 rounded-lg border flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por nome, matrícula, CPF, email..."
              value={termoBusca}
              onChange={(e) => setTermoBusca(e.target.value)}
              className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {termoBusca && (
              <button
                onClick={() => setTermoBusca('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
          
          <button
            onClick={() => setModalAdicionarFiltroAberto(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 bg-white rounded-lg hover:bg-gray-50 text-sm transition whitespace-nowrap"
          >
            <Filter className="w-4 h-4" />
            Adicionar Filtro
          </button>
        </div>
      </div>
      
      {/* Tabela */}
      {loading ? (
        <div className="bg-white rounded-lg border p-8 text-center">
          <p className="text-gray-500">Carregando funcionários...</p>
        </div>
      ) : (
        <>
        <div className="flex-1 bg-white rounded-lg border overflow-auto">
          <table className="w-full min-w-max">
            <thead className="bg-gray-50 border-b sticky top-0">
              <tr>
                <th className="px-2 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider whitespace-nowrap w-32">
                  Ações
                </th>
                {colunasVisiveis.map(col => {
                  const isSortable = ['nome', 'funcao', 'cpf', 'matricula', 'email', 'telefone', 'data_nascimento', 'codigo_anac', 'anv'].includes(col.id);
                  const isActive = sortConfig.column === col.id;
                  const direction = isActive ? sortConfig.direction : null;
                  
                  return (
                    <th 
                      key={col.id} 
                      onClick={() => isSortable && handleSort(col.id as SortableColumn)}
                      className={`px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider whitespace-nowrap ${
                        isSortable ? 'cursor-pointer hover:bg-gray-100 select-none' : ''
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span>{col.label}</span>
                        {isSortable && (
                          <div className="flex flex-col">
                            {direction === null && (
                              <ArrowUpDown className="w-4 h-4 text-gray-400" />
                            )}
                            {direction === 'asc' && (
                              <ArrowUp className="w-4 h-4 text-blue-600" />
                            )}
                            {direction === 'desc' && (
                              <ArrowDown className="w-4 h-4 text-blue-600" />
                            )}
                          </div>
                        )}
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {funcionariosFiltradosEOrdenados.length === 0 ? (
                <tr>
                  <td colSpan={colunasVisiveis.length + 1} className="px-4 py-8 text-center text-gray-500">
                    {termoBusca 
                      ? `Nenhum funcionário encontrado para "${termoBusca}"` 
                      : 'Nenhum funcionário cadastrado'
                    }
                  </td>
                </tr>
              ) : (
                funcionariosFiltradosEOrdenados.map((func: any) => (
                  <tr key={func.id} className="hover:bg-gray-50">
                    <td className="px-2 py-3 text-sm">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => navigate(`/pasta-virtual/${func.id}`)}
                          className="p-1.5 text-purple-600 hover:bg-purple-50 rounded transition"
                          title="Pasta Virtual"
                        >
                          <Folder className="w-4 h-4" />
                        </button>
                        
                        <button
                          onClick={() => {
                            setFuncionarioSelecionado(func);
                            setModalNovoAberto(true);
                          }}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition"
                          title="Editar"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        
                        <button
                          onClick={() => handleExcluir(func.id, func.nome)}
                          disabled={excluindo === func.id}
                          className={`p-1.5 rounded transition ${
                            excluindo === func.id 
                              ? 'text-gray-400 cursor-not-allowed' 
                              : 'text-red-600 hover:bg-red-50'
                          }`}
                          title={excluindo === func.id ? 'Excluindo...' : 'Excluir'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    {colunasVisiveis.map(col => {
                      let valor = func[col.id] || '-';
                      
                      if (col.id === 'email' && func.email) {
                        return (
                          <td key={col.id} className="px-4 py-3 text-sm whitespace-nowrap">
                            <a
                              href={`mailto:${func.email}`}
                              className="text-blue-600 hover:text-blue-800 hover:underline"
                            >
                              {func.email}
                            </a>
                          </td>
                        );
                      }
                      
                      if (col.id === 'telefone' && func.telefone) {
                        const telefoneNumerico = func.telefone.replace(/\D/g, '');
                        const whatsappLink = `https://wa.me/55${telefoneNumerico}`;
                        return (
                          <td key={col.id} className="px-4 py-3 text-sm whitespace-nowrap">
                            <a
                              href={whatsappLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-green-600 hover:text-green-800 hover:underline flex items-center gap-1"
                            >
                              {formatarTelefone(func.telefone)}
                              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                              </svg>
                            </a>
                          </td>
                        );
                      }
                      
                      if (col.id === 'cpf' && func.cpf) {
                        valor = formatarCPF(func.cpf);
                      }
                      
                      if (col.id === 'matricula' && func.matricula) {
                        valor = formatarMatricula(func.matricula);
                      }
                      
                      if (col.id === 'codigo_anac' && func.codigo_anac) {
                        valor = formatarCodigoANAC(func.codigo_anac);
                      }
                      
                      if (col.id.includes('data_') || col.id.includes('validade_')) {
                        valor = formatarDataExibicao(func[col.id]);
                      }
                      
                      if (col.id === 'status') {
                        const statusColors: Record<string, string> = {
                          ATIVO: 'bg-green-100 text-green-800',
                          INATIVO: 'bg-gray-100 text-gray-800',
                          FERIAS: 'bg-blue-100 text-blue-800',
                          LICENCA: 'bg-yellow-100 text-yellow-800',
                        };
                        const colorClass = statusColors[valor] || 'bg-gray-100 text-gray-800';
                        
                        return (
                          <td key={col.id} className="px-4 py-3 text-sm whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${colorClass}`}>
                              {valor}
                            </span>
                          </td>
                        );
                      }
                      
                      return (
                        <td key={col.id} className="px-4 py-3 text-sm text-gray-900 whitespace-nowrap">
                          {valor}
                        </td>
                      );
                    })}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        {/* Paginação */}
        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
          hasNext={pagination.hasNext}
          hasPrev={pagination.hasPrev}
          total={pagination.total}
          limit={pagination.limit}
        />
        </>
      )}
      
      {/* Modais */}
      
      {modalNovoAberto && (
        <ModalFuncionario
          aberto={modalNovoAberto}
          funcionario={funcionarioSelecionado}
          onFechar={() => {
            setModalNovoAberto(false);
            setFuncionarioSelecionado(null);
          }}
          onSalvar={handleSalvarFuncionario}
        />
      )}
      
      {modalConfigColunasAberto && (
        <ConfigurarColunas
          onClose={() => setModalConfigColunasAberto(false)}
          onSalvar={(novaConfig: Coluna[]) => {
            setColunasConfig(novaConfig);
            setModalConfigColunasAberto(false);
          }}
        />
      )}
      
      {modalAdicionarFiltroAberto && (
        <AdicionarFiltro
          onClose={() => setModalAdicionarFiltroAberto(false)}
          filtrosAtivos={filtrosAtivos}
          onAdicionar={handleAdicionarFiltro}
        />
      )}
    </div>
  );
}
