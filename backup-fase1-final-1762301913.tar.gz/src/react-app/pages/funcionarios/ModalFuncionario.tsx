import { useState, useEffect } from 'react';
import { X, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { converterParaFormatoHTML } from '../../utils/dateUtils';

interface Props {
  aberto: boolean;
  funcionario: any;
  onFechar: () => void;
  onSalvar: (dados: any) => void;
}

export default function ModalFuncionario({ aberto, funcionario, onFechar, onSalvar }: Props) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id: null as number | null,
    nome: '',
    nome_guerra: '',
    cpf: '',
    data_nascimento: '',
    email: '',
    telefone: '',
    funcao: '',
    setor: '',
    aeronave: '',
    matricula: '',
    data_admissao: '',
    codigo_anac: '',
    nivel_icao: '',
    validade_icao: '',
    cma: '',
    validade_cma: '',
    aso: '',
    validade_aso: '',
    sispat: '',
    prestserv: '',
    status: 'ATIVO',
    is_instrutor: false,
    is_checador: false
  });
  const [loading, setLoading] = useState(false);
  
  const [aeronaves, setAeronaves] = useState<any[]>([]);
  const [funcoesList, setFuncoesList] = useState<any[]>([]);
  const [setoresList, setSetoresList] = useState<any[]>([]);
  
  useEffect(() => {
    const carregarOpcoes = async () => {
      try {
        const API = window.location.origin;
        const [aerResp, funcResp, setResp] = await Promise.all([
          fetch(`${API}/api/v2/aeronaves`),
          fetch(`${API}/api/v2/funcoes`),
          fetch(`${API}/api/v2/setores`)
        ]);

        if (aerResp.ok) {
          const a = await aerResp.json();
          setAeronaves(a.data || a || []);
        } else {
          setAeronaves([]);
        }

        if (funcResp.ok) {
          const f = await funcResp.json();
          setFuncoesList(f.data || f.funcoes || []);
        } else {
          setFuncoesList([]);
        }

        if (setResp.ok) {
          const s = await setResp.json();
          setSetoresList(s.data || s.setores || []);
        } else {
          setSetoresList([]);
        }
      } catch (error) {
        console.error('Erro ao carregar opções (aeronaves/funções/setores):', error);
        setAeronaves([]);
        setFuncoesList([]);
        setSetoresList([]);
      }
    };

    carregarOpcoes();
  }, []);
  
  useEffect(() => {
    const carregarDetalhes = async () => {
      if (!funcionario) {
        setFormData({
          id: null,
          nome: '',
          nome_guerra: '',
          cpf: '',
          data_nascimento: '',
          email: '',
          telefone: '',
          funcao: '',
          setor: '',
          aeronave: '',
          matricula: '',
          data_admissao: '',
          codigo_anac: '',
          nivel_icao: '',
          validade_icao: '',
          cma: '',
          validade_cma: '',
          aso: '',
          validade_aso: '',
          sispat: '',
          prestserv: '',
          status: 'ATIVO',
          is_instrutor: false,
          is_checador: false
        });
        return;
      }

      try {
        setLoading(true);
        const API = window.location.origin;
        const resp = await fetch(`${API}/api/v2/funcionarios/${funcionario.id}`);
        const json = await resp.json();
        const f = json?.funcionario || json?.data || funcionario;
        let icaoNivel = f.nivel_icao || '';
        let icaoVal = converterParaFormatoHTML(f.nivel_icao_data_vencimento);
        let cmaNum = f.cma_numero || '';
        let cmaVal = converterParaFormatoHTML(f.cma_data_vencimento);
        let asoNum = f.aso_numero || '';
        let asoVal = converterParaFormatoHTML(f.aso_data_vencimento);

        try {
          const qResp = await fetch(`${API}/api/v2/qualificacoes/funcionario/${funcionario.id}?incluir_renovadas=true`);
          if (qResp.ok) {
            const qJson = await qResp.json();
            const items = qJson?.qualificacoes || qJson?.data || [];
            const pickLatest = (arr: any[]) => arr
              .filter(Boolean)
              .sort((a, b) => (new Date(b.data_vencimento || '1900-01-01').getTime()) - (new Date(a.data_vencimento || '1900-01-01').getTime()))[0];
            if (!cmaVal || !cmaNum) {
              const cma = pickLatest(items.filter((i: any) => String(i.codigo || '').toUpperCase().includes('CMA')));
              if (cma) {
                if (!cmaVal) cmaVal = converterParaFormatoHTML(cma.data_vencimento);
                if (!cmaNum && cma.numero) cmaNum = String(cma.numero);
              }
            }
            if (!asoVal || !asoNum) {
              const aso = pickLatest(items.filter((i: any) => String(i.codigo || '').toUpperCase().includes('ASO')));
              if (aso) {
                if (!asoVal) asoVal = converterParaFormatoHTML(aso.data_vencimento);
                if (!asoNum && aso.numero) asoNum = String(aso.numero);
              }
            }
            if (!icaoVal || !icaoNivel) {
              const icao = pickLatest(items.filter((i: any) => String(i.codigo || '').toUpperCase().includes('ICAO')));
              if (icao) {
                if (!icaoVal) icaoVal = converterParaFormatoHTML(icao.data_vencimento);
                if (!icaoNivel) {
                  const raw = String(icao.resultado || icao.observacoes || icao.nome || '').trim();
                  const m = raw.match(/(\d)/);
                  if (m) icaoNivel = m[1];
                }
              }
            }
          }
        } catch (_) {}

        setFormData({
          id: f.id || null,
          nome: f.nome || '',
          nome_guerra: f.nome_guerra || '',
          cpf: f.cpf || '',
          data_nascimento: converterParaFormatoHTML(f.data_nascimento),
          email: f.email || '',
          telefone: f.telefone || '',
          funcao: f.funcao || '',
          setor: f.setor || '',
          aeronave: f.aeronave_principal || '',
          matricula: f.matricula || '',
          data_admissao: converterParaFormatoHTML(f.data_admissao),
          codigo_anac: f.codigo_anac || '',
          nivel_icao: icaoNivel || '',
          validade_icao: icaoVal || '',
          cma: cmaNum || '',
          validade_cma: cmaVal || '',
          aso: asoNum || '',
          validade_aso: asoVal || '',
          sispat: f.codigo_sispat || '',
          prestserv: f.codigo_prestserv || '',
          status: f.status || 'ATIVO',
          is_instrutor: f.is_instrutor === 1 || f.is_instrutor === true || false,
          is_checador: f.is_checador === 1 || f.is_checador === true || false
        });
      } catch (e) {
        setFormData((prev) => ({ ...prev }));
      } finally {
        setLoading(false);
      }
    };

    carregarDetalhes();
  }, [funcionario]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    if (name === 'matricula') {
      const numeros = value.replace(/\D/g, '');
      const matriculaLimitada = numeros.slice(0, 5);
      setFormData(prev => ({ 
        ...prev, 
        [name]: matriculaLimitada
      }));
      return;
    }
    
    setFormData(prev => ({ 
      ...prev, 
      [name]: type === 'checkbox' ? checked : value 
    }));
  };
  
  const handleSalvar = (e: React.FormEvent) => {
    e.preventDefault();
    
    const dadosParaBackend = {
      ...formData,
      cma_data_vencimento: formData.validade_cma,
      cma_numero: formData.cma,
      aso_data_vencimento: formData.validade_aso,
      nivel_icao_data_vencimento: formData.validade_icao,
      codigo_sispat: formData.sispat,
      codigo_prestserv: formData.prestserv,
      aeronave_principal: formData.aeronave,
      validade_cma: undefined,
      validade_aso: undefined,
      validade_icao: undefined,
      cma: undefined,
      aso: undefined,
      sispat: undefined,
      prestserv: undefined,
      aeronave: undefined
    };
    
    onSalvar(dadosParaBackend);
  };
  
  if (!aberto) return null;
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-bold">
            {funcionario ? 'Editar' : 'Novo'} Funcionário
          </h2>
          <button onClick={onFechar} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        {/* Body */}
        <form onSubmit={handleSalvar} className="flex flex-col flex-1 overflow-hidden">
          <div className="p-6 overflow-y-auto flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
              
              {/* COLUNA 1: DADOS PESSOAIS */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-gray-900 border-b pb-2">Dados Pessoais</h3>
                
                {/* Nome Completo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="nome"
                    value={formData.nome}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                
                {/* Nome de Guerra */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome de Guerra</label>
                  <input
                    type="text"
                    name="nome_guerra"
                    value={formData.nome_guerra}
                    onChange={handleChange}
                    placeholder="Nome de guerra"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* CPF */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CPF <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="cpf"
                    value={formData.cpf}
                    onChange={handleChange}
                    placeholder="000.000.000-00"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                
                {/* Data de Nascimento */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data de Nascimento</label>
                  <input
                    type="date"
                    name="data_nascimento"
                    value={formData.data_nascimento}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* E-mail */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* Telefone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                  <input
                    type="tel"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleChange}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              {/* COLUNA 2: DADOS PROFISSIONAIS */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg text-gray-900 border-b pb-2">Dados Profissionais</h3>
                
                {/* Função */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Função <span className="text-red-600">*</span>
                  </label>
                  <select
                    name="funcao"
                    value={formData.funcao}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="">Selecione a função</option>
                    {funcoesList
                      .filter((it) => it.deleted_at == null && (it.ativo === undefined || it.ativo === 1))
                      .sort((a: any, b: any) => String(a.nome || '').localeCompare(String(b.nome || ''), 'pt-BR'))
                      .map((func: any) => (
                        <option key={func.id} value={func.nome}>{func.nome}</option>
                      ))}
                  </select>
                </div>
                
                {/* Setor */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Setor</label>
                  <select
                    name="setor"
                    value={formData.setor}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Selecione o setor</option>
                    {setoresList
                      .filter((it) => it.deleted_at == null && (it.ativo === undefined || it.ativo === 1))
                      .sort((a: any, b: any) => String(a.nome || '').localeCompare(String(b.nome || ''), 'pt-BR'))
                      .map((set: any) => (
                        <option key={set.id} value={set.nome}>{set.nome}</option>
                      ))}
                  </select>
                </div>
                
                {/* Aeronave */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Aeronave</label>
                  <select
                    name="aeronave"
                    value={formData.aeronave}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Selecione a aeronave</option>
                    {aeronaves.map(aeronave => (
                      <option key={aeronave.id} value={aeronave.modelo || aeronave.nome}>
                        {aeronave.modelo || aeronave.nome}
                        {aeronave.prefixo && ` - ${aeronave.prefixo}`}
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Matrícula */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Matrícula <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="matricula"
                    value={formData.matricula}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      const formatted = value.padStart(5, '0').slice(0, 5);
                      setFormData({ ...formData, matricula: formatted });
                    }}
                    placeholder="00001"
                    maxLength={5}
                    pattern="[0-9]{5}"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 font-mono text-center"
                    required
                  />
                  
                  {/* Validação em tempo real */}
                  {formData.matricula && formData.matricula.length !== 5 && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <span>⚠️</span>
                      Matrícula deve ter 5 dígitos
                    </p>
                  )}
                  
                  {formData.matricula && formData.matricula.length === 5 && (
                    <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                      <span>✓</span>
                      Matrícula válida
                    </p>
                  )}
                </div>
                
                {/* Data de Admissão */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data de Admissão</label>
                  <input
                    type="date"
                    name="data_admissao"
                    value={formData.data_admissao}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                {/* Código ANAC */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Código ANAC</label>
                  <input
                    type="text"
                    name="codigo_anac"
                    value={formData.codigo_anac}
                    onChange={handleChange}
                    placeholder="Código ANAC"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              {/* SEÇÃO COMPLETA: CERTIFICAÇÕES E QUALIFICAÇÕES */}
              <div className="md:col-span-2 space-y-4">
                <div className="flex items-center justify-between border-b pb-2 mt-6">
                  <h3 className="font-semibold text-lg text-gray-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3 text-gray-500" />
                    Certificações e Qualificações
                  </h3>
                  <button
                    type="button"
                    onClick={() => navigate('/simuladores?from=qualificacoes-especiais')}
                    className="inline-flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-700"
                    title="Gerenciar no módulo de Simuladores"
                  >
                    <ShieldCheck className="w-2 h-2" />
                    Atalho Simuladores
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                  {/* ICAO - Linha 1 */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nível ICAO</label>
                    <select
                      name="nivel_icao"
                      value={formData.nivel_icao}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Selecione</option>
                      <option value="1">Nível 1</option>
                      <option value="2">Nível 2</option>
                      <option value="3">Nível 3</option>
                      <option value="4">Nível 4</option>
                      <option value="5">Nível 5</option>
                      <option value="6">Nível 6</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Validade ICAO</label>
                    <input
                      type="date"
                      name="validade_icao"
                      value={formData.validade_icao}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  {/* CMA - Linha 2 */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">CMA</label>
                    <input
                      type="text"
                      name="cma"
                      value={formData.cma}
                      onChange={handleChange}
                      placeholder="Número CMA"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Validade CMA</label>
                    <input
                      type="date"
                      name="validade_cma"
                      value={formData.validade_cma}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  {/* ASO - Linha 3 */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ASO</label>
                    <input
                      type="text"
                      name="aso"
                      value={formData.aso}
                      onChange={handleChange}
                      placeholder="Número ASO"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Validade ASO</label>
                    <input
                      type="date"
                      name="validade_aso"
                      value={formData.validade_aso}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  
                  {/* SISPAT - Linha 4 */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">SISPAT</label>
                    <select
                      name="sispat"
                      value={formData.sispat}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Selecione</option>
                      <option value="SIM">Sim</option>
                      <option value="NAO">Não</option>
                    </select>
                  </div>
                  
                  {/* PrestServ */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">PrestServ</label>
                    <select
                      name="prestserv"
                      value={formData.prestserv}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Selecione</option>
                      <option value="SIM">Sim</option>
                      <option value="NAO">Não</option>
                    </select>
                  </div>
                  
                  {/* Status - Linha 5 */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="ATIVO">Ativo</option>
                      <option value="INATIVO">Inativo</option>
                      <option value="FERIAS">Férias</option>
                      <option value="LICENCA">Licença</option>
                    </select>
                  </div>
                </div>
                
                {/* Qualificações Especiais */}
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h3 className="text-sm font-semibold text-blue-900 mb-3">✈️ Qualificações Especiais</h3>
                  <div className="space-y-3">
                    {/* Checkbox Instrutor */}
                    <div className="flex items-start">
                      <input
                        type="checkbox"
                        id="is_instrutor"
                        name="is_instrutor"
                        checked={formData.is_instrutor || false}
                        onChange={handleChange}
                        className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <label htmlFor="is_instrutor" className="ml-3 text-sm">
                        <span className="font-medium text-gray-900">É Instrutor</span>
                        <p className="text-xs text-gray-500 mt-1">
                          Marcando esta opção, o funcionário aparecerá na lista de instrutores ao agendar sessões de simulador
                        </p>
                      </label>
                    </div>

                    {/* Checkbox Checador/Examinador */}
                    <div className="flex items-start">
                      <input
                        type="checkbox"
                        id="is_checador"
                        name="is_checador"
                        checked={formData.is_checador || false}
                        onChange={handleChange}
                        className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <label htmlFor="is_checador" className="ml-3 text-sm">
                        <span className="font-medium text-gray-900">É Checador/Examinador</span>
                        <p className="text-xs text-gray-500 mt-1">
                          Marcando esta opção, o funcionário aparecerá na lista de examinadores ao agendar sessões de simulador
                        </p>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Footer com botões */}
          <div className="flex gap-3 p-6 border-t bg-gray-50">
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition"
            >
              Salvar
            </button>
            <button
              type="button"
              onClick={onFechar}
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
