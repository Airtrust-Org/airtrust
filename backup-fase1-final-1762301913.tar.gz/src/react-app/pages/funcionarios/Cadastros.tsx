import { useState, useEffect } from 'react';
import { Plus, Briefcase, Building2, Plane, Edit2, Trash2 } from 'lucide-react';
import { ModalCadastro } from '../../components/shared/ModalCadastro';

type AbaAtiva = 'funcoes' | 'setores' | 'aeronaves';

export function Cadastros() {
  const [abaAtiva, setAbaAtiva] = useState<AbaAtiva>('funcoes');
  
  const [funcoes, setFuncoes] = useState<any[]>([]);
  const [setores, setSetores] = useState<any[]>([]);
  const [aeronaves, setAeronaves] = useState<any[]>([]);
  
  const [modalFuncao, setModalFuncao] = useState<{ isOpen: boolean; data: any | null }>({ 
    isOpen: false, 
    data: null 
  });
  const [modalSetor, setModalSetor] = useState<{ isOpen: boolean; data: any | null }>({ 
    isOpen: false, 
    data: null 
  });
  const [modalAeronave, setModalAeronave] = useState<{ isOpen: boolean; data: any | null }>({ 
    isOpen: false, 
    data: null 
  });

  useEffect(() => {
    carregarDados();
  }, []);

  async function carregarDados() {
    try {
      const API_URL = window.location.origin;
      
      const [resFuncoes, resSetores, resAeronaves] = await Promise.all([
        fetch(`${API_URL}/api/v2/funcoes`),
        fetch(`${API_URL}/api/v2/setores`),
        fetch(`${API_URL}/api/v2/aeronaves`)
      ]);
      
      console.log('[CADASTROS] Respostas:', {
        funcoes: resFuncoes.status,
        setores: resSetores.status,
        aeronaves: resAeronaves.status
      });
      
      if (resFuncoes.ok) {
        const data = await resFuncoes.json();
        setFuncoes(data.data || data || []);
      } else {
        console.error('[CADASTROS] Erro funções:', resFuncoes.status);
        setFuncoes([]);
      }
      
      if (resSetores.ok) {
        const data = await resSetores.json();
        setSetores(data.data || data || []);
      } else {
        console.error('[CADASTROS] Erro setores:', resSetores.status);
        setSetores([]);
      }
      
      if (resAeronaves.ok) {
        const data = await resAeronaves.json();
        setAeronaves(data.data || data || []);
      } else {
        console.error('[CADASTROS] Erro aeronaves:', resAeronaves.status);
        setAeronaves([]);
      }
    } catch (error) {
      console.error('[CADASTROS] Erro ao carregar dados:', error);
      setFuncoes([]);
      setSetores([]);
      setAeronaves([]);
    }
  }

  async function salvarFuncao(data: any) {
    const method = data.id ? 'PUT' : 'POST';
    const url = data.id ? `${window.location.origin}/api/v2/funcoes/${data.id}` : `${window.location.origin}/api/v2/funcoes`;
    
    const response = await fetch(url, { 
      method, 
      headers: { 'Content-Type': 'application/json' }, 
      body: JSON.stringify(data) 
    });
    
    if (!response.ok) throw new Error('Erro ao salvar função');
    await carregarDados();
  }

  async function excluirFuncao(id: number) {
    if (!confirm('Deseja realmente excluir esta função?')) return;
    
    const response = await fetch(`${window.location.origin}/api/v2/funcoes/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Erro ao excluir função');
    await carregarDados();
  }

  async function salvarSetor(data: any) {
    const method = data.id ? 'PUT' : 'POST';
    const url = data.id ? `${window.location.origin}/api/v2/setores/${data.id}` : `${window.location.origin}/api/v2/setores`;
    
    const response = await fetch(url, { 
      method, 
      headers: { 'Content-Type': 'application/json' }, 
      body: JSON.stringify(data) 
    });
    
    if (!response.ok) throw new Error('Erro ao salvar setor');
    await carregarDados();
  }

  async function excluirSetor(id: number) {
    if (!confirm('Deseja realmente excluir este setor?')) return;
    
    const response = await fetch(`${window.location.origin}/api/v2/setores/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Erro ao excluir setor');
    await carregarDados();
  }

  async function salvarAeronave(data: any) {
    const method = data.id ? 'PUT' : 'POST';
    const url = data.id ? `${window.location.origin}/api/v2/aeronaves/${data.id}` : `${window.location.origin}/api/v2/aeronaves`;
    
    const response = await fetch(url, { 
      method, 
      headers: { 'Content-Type': 'application/json' }, 
      body: JSON.stringify(data) 
    });
    
    if (!response.ok) throw new Error('Erro ao salvar aeronave');
    await carregarDados();
  }

  async function excluirAeronave(id: number) {
    if (!confirm('Deseja realmente excluir esta aeronave?')) return;
    
    const response = await fetch(`${window.location.origin}/api/v2/aeronaves/${id}`, { method: 'DELETE' });
    if (!response.ok) throw new Error('Erro ao excluir aeronave');
    await carregarDados();
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex gap-2">
          <button
            onClick={() => setAbaAtiva('funcoes')}
            className={`px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 ${
              abaAtiva === 'funcoes' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            Funções
          </button>
          
          <button
            onClick={() => setAbaAtiva('setores')}
            className={`px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 ${
              abaAtiva === 'setores' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Building2 className="w-4 h-4" />
            Setores
          </button>
          
          <button
            onClick={() => setAbaAtiva('aeronaves')}
            className={`px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 ${
              abaAtiva === 'aeronaves' 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Plane className="w-4 h-4" />
            Aeronaves
          </button>
        </div>
      </div>

      {abaAtiva === 'funcoes' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold">Funções e Cargos</h3>
              <p className="text-gray-600">{funcoes.length} funções cadastradas</p>
            </div>
            <button
              onClick={() => setModalFuncao({ isOpen: true, data: null })}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Nova Função
            </button>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-2 py-3 text-left text-xs font-semibold text-gray-700 uppercase w-28">Ações</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Nome</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Descrição</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {funcoes.map((func: any) => (
                  <tr key={func.id} className="hover:bg-gray-50">
                    <td className="px-2 py-3 flex gap-2">
                      <button
                        onClick={() => setModalFuncao({ isOpen: true, data: func })}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Editar"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => excluirFuncao(func.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="px-4 py-3 font-medium">{func.nome}</td>
                    <td className="px-4 py-3 text-gray-600">{func.descricao}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        func.ativo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {func.ativo ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {abaAtiva === 'setores' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold">Setores e Departamentos</h3>
              <p className="text-gray-600">{setores.length} setores cadastrados</p>
            </div>
            <button
              onClick={() => setModalSetor({ isOpen: true, data: null })}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Novo Setor
            </button>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-2 py-3 text-left text-xs font-semibold text-gray-700 uppercase w-28">Ações</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Nome</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Sigla</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Descrição</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-700 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {setores.map((setor: any) => (
                  <tr key={setor.id} className="hover:bg-gray-50">
                    <td className="px-2 py-3 flex gap-2">
                      <button
                        onClick={() => setModalSetor({ isOpen: true, data: setor })}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Editar"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => excluirSetor(setor.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="px-4 py-3 font-medium">{setor.nome}</td>
                    <td className="px-4 py-3 font-mono text-sm">{setor.sigla}</td>
                    <td className="px-4 py-3 text-gray-600">{setor.descricao}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        setor.ativo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {setor.ativo ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {abaAtiva === 'aeronaves' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold">Aeronaves</h3>
              <p className="text-gray-600">{aeronaves.length} aeronaves cadastradas</p>
            </div>
            <button
              onClick={() => setModalAeronave({ isOpen: true, data: null })}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Nova Aeronave
            </button>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-2 py-3 text-left text-xs font-semibold text-gray-700 uppercase w-28">Ações</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Modelo</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Fabricante</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {aeronaves.map((aeronave: any) => (
                  <tr key={aeronave.id} className="hover:bg-gray-50">
                    <td className="px-2 py-3 flex gap-2">
                      <button
                        onClick={() => setModalAeronave({ isOpen: true, data: aeronave })}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Editar"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => excluirAeronave(aeronave.id)}
                        className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="px-4 py-3 font-medium">{aeronave.modelo}</td>
                    <td className="px-4 py-3">{aeronave.fabricante}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {modalFuncao.isOpen && (
        <ModalCadastro
          title={modalFuncao.data ? 'Editar Função' : 'Nova Função'}
          isOpen={modalFuncao.isOpen}
          onClose={() => setModalFuncao({ isOpen: false, data: null })}
          onSave={salvarFuncao}
          initialData={modalFuncao.data}
          fields={[
            { name: 'nome', label: 'Nome', type: 'text', required: true },
            { name: 'descricao', label: 'Descrição', type: 'text' },
            { name: 'ativo', label: 'Ativo', type: 'checkbox' }
          ]}
        />
      )}

      {modalSetor.isOpen && (
        <ModalCadastro
          title={modalSetor.data ? 'Editar Setor' : 'Novo Setor'}
          isOpen={modalSetor.isOpen}
          onClose={() => setModalSetor({ isOpen: false, data: null })}
          onSave={salvarSetor}
          initialData={modalSetor.data}
          fields={[
            { name: 'nome', label: 'Nome', type: 'text', required: true },
            { name: 'sigla', label: 'Sigla', type: 'text' },
            { name: 'descricao', label: 'Descrição', type: 'text' },
            { name: 'ativo', label: 'Ativo', type: 'checkbox' }
          ]}
        />
      )}

      {modalAeronave.isOpen && (
        <ModalCadastro
          title={modalAeronave.data ? 'Editar Aeronave' : 'Nova Aeronave'}
          isOpen={modalAeronave.isOpen}
          onClose={() => setModalAeronave({ isOpen: false, data: null })}
          onSave={salvarAeronave}
          initialData={modalAeronave.data}
          fields={[
            { name: 'modelo', label: 'Modelo', type: 'text', required: true, placeholder: 'Ex: Airbus A320, Boeing 737' },
            { name: 'fabricante', label: 'Fabricante', type: 'text', placeholder: 'Ex: Airbus, Boeing' }
          ]}
        />
      )}
    </div>
  );
}
