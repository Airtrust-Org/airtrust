import { useState } from 'react';
import { Upload, FileText, X } from 'lucide-react';

interface UploadDocumentosProps {
  funcionarioId: number;
  onUploadCompleto: () => void;
}

export default function UploadDocumentos({ funcionarioId, onUploadCompleto }: UploadDocumentosProps) {
  const [arquivo, setArquivo] = useState<File | null>(null);
  const [tipoDocumento, setTipoDocumento] = useState('');
  const [descricao, setDescricao] = useState('');
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  
  const tiposDocumentos = [
    'RG', 'CPF', 'CNH', 'CMA', 'ASO', 'ICAO', 'Contrato', 'Certificado', 'Outro'
  ];
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setArquivo(files[0]);
    }
  };
  
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setArquivo(e.target.files[0]);
    }
  };
  
  const handleUpload = async () => {
    if (!arquivo || !tipoDocumento) {
      alert('Selecione um arquivo e o tipo de documento');
      return;
    }
    
    setUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('file', arquivo);
      formData.append('tipo', tipoDocumento);
      formData.append('descricao', descricao);
      
      const response = await fetch(
        `${window.location.origin}/api/v2/funcionarios/${funcionarioId}/documentos`,
        {
          method: 'POST',
          body: formData
        }
      );
      
      if (response.ok) {
        setArquivo(null);
        setTipoDocumento('');
        setDescricao('');
        onUploadCompleto();
      } else {
        alert('Erro ao enviar documento');
      }
    } catch (error) {
      console.error('Erro no upload:', error);
      alert('Erro ao enviar documento');
    } finally {
      setUploading(false);
    }
  };
  
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">📤 Enviar Documento</h3>
      
      <div
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-lg p-8 text-center transition ${
          dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        }`}
      >
        {arquivo ? (
          <div className="flex items-center justify-center gap-3">
            <FileText className="w-8 h-8 text-blue-600" />
            <div className="text-left">
              <p className="font-medium">{arquivo.name}</p>
              <p className="text-sm text-gray-500">
                {(arquivo.size / 1024).toFixed(2)} KB
              </p>
            </div>
            <button
              onClick={() => setArquivo(null)}
              className="text-red-600 hover:text-red-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <div>
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600 mb-2">
              Arraste um arquivo aqui ou
            </p>
            <label className="cursor-pointer text-blue-600 hover:text-blue-800 font-medium">
              clique para selecionar
              <input
                type="file"
                onChange={handleFileSelect}
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              />
            </label>
          </div>
        )}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Tipo de Documento *
        </label>
        <select
          value={tipoDocumento}
          onChange={e => setTipoDocumento(e.target.value)}
          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Selecione o tipo</option>
          {tiposDocumentos.map(tipo => (
            <option key={tipo} value={tipo}>{tipo}</option>
          ))}
        </select>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Descrição (opcional)
        </label>
        <textarea
          value={descricao}
          onChange={e => setDescricao(e.target.value)}
          rows={3}
          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="Adicione uma descrição..."
        />
      </div>
      
      <button
        onClick={handleUpload}
        disabled={!arquivo || !tipoDocumento || uploading}
        className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition"
      >
        {uploading ? 'Enviando...' : 'Enviar Documento'}
      </button>
    </div>
  );
}
