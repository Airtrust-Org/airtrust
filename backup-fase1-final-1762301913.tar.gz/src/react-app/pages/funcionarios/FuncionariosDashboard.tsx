import { useState } from 'react';
import { Users, Settings } from 'lucide-react';
import { ListaFuncionarios } from './ListaFuncionarios';
import { Cadastros } from './Cadastros';
import { PageLayout } from '@/react-app/components/layout/PageLayout';

type AbaAtiva = 'lista' | 'cadastros';

export default function FuncionariosDashboard() {
  const [abaAtiva, setAbaAtiva] = useState<AbaAtiva>('lista');

  return (
    <PageLayout 
      title="Funcionários"
      subtitle="Gerencie funcionários, funções e cargos da organização"
    >
      {/* NAVEGAÇÃO ABAS */}
      <div className="bg-white rounded-lg shadow mb-6 border border-neutral-200">
        <nav className="flex border-b border-neutral-200">
          <button
            onClick={() => setAbaAtiva('lista')}
            className={`flex-1 px-6 py-4 font-medium transition flex items-center justify-center gap-2 ${
              abaAtiva === 'lista'
                ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Users className="w-5 h-5" />
            <span>Lista de Funcionários</span>
          </button>

          <button
            onClick={() => setAbaAtiva('cadastros')}
            className={`flex-1 px-6 py-4 font-medium transition flex items-center justify-center gap-2 ${
              abaAtiva === 'cadastros'
                ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span>Cadastros</span>
          </button>
        </nav>
      </div>

      {/* CONTEÚDO DAS ABAS */}
      {abaAtiva === 'lista' && <ListaFuncionarios />}
      {abaAtiva === 'cadastros' && <Cadastros />}
    </PageLayout>
  );
}
