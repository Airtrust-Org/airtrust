import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router';

interface Manobra {
  id: number;
  codigo: string;
  nome: string;
  categoria: string;
  criterios_aprovacao?: string;
  pontuacao_minima: number;
  nota_atual?: number;
  observacoes_atual?: string;
  executada: boolean;
}

interface FichaAvaliacao {
  ficha: {
    uuid: string;
    colaborador: string;
    matricula: string;
    simulador: string;
    template: string;
    data_sessao: string;
    status_workflow: string;
    funcao_na_sessao: string;
    ciclo_executado: number;
  };
  manobras: Manobra[];
  pode_avaliar: boolean;
}

const AvaliarFichaSimulador: React.FC = () => {
  const { uuid } = useParams<{ uuid: string }>();
  const navigate = useNavigate();

  const [avaliacao, setAvaliacao] = useState<FichaAvaliacao | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState<string>('');
  const [requestCount, setRequestCount] = useState(0);
  const [lastUuidProcessed, setLastUuidProcessed] = useState<string>('');
  const isProcessing = useRef(false);

  const [notas, setNotas] = useState<Record<number, string>>({});
  const [observacoes, setObservacoes] = useState<Record<number, string>>({});
  const [observacoesGerais, setObservacoesGerais] = useState('');

  const MAX_REQUESTS = 3;
  const REQUEST_TIMEOUT = 10000;

  const tentarCarregarAvaliacao = async (fichaUuid: string): Promise<any> => {
    const endpoints = [
      `/api/v2/fichas/${fichaUuid}`,
      `/api/v2/simulador/ficha/${fichaUuid}`
    ];
    
    for (const endpoint of endpoints) {
      try {
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
        }, REQUEST_TIMEOUT);
        
        const response = await fetch(endpoint, {
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: REQUEST_TIMEOUT
        } as RequestInit);
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          return data;
        } else {
        }
      } catch (error: any) {
        console.log(`❌ Falhou na avaliação: ${endpoint}`, {
          error: error.message,
          name: error.name,
          isAborted: error.name === 'AbortError',
          isTimeout: error.message?.includes('timeout')
        });
        
        if (error.name === 'AbortError') {
        }
      }
    }
    
    throw new Error('Nenhum endpoint funcionou para avaliação após múltiplas tentativas com timeout');
  };

  const carregarAvaliacao = async (fichaUuid: string) => {
    if (isProcessing.current || requestCount >= MAX_REQUESTS || fichaUuid === lastUuidProcessed) {
      console.log('🛑 Bloqueando request de avaliação:', {
        isProcessing: isProcessing.current,
        requestCount,
        maxRequests: MAX_REQUESTS,
        fichaUuid,
        lastUuidProcessed
      });
      return;
    }

    isProcessing.current = true;
    setLoading(true);
    setErro('');
    setRequestCount(prev => prev + 1);
    setLastUuidProcessed(fichaUuid);

    try {
      console.log(`🔍 Carregando avaliação: ${fichaUuid}`, {
        requestCount: requestCount + 1
      });

      const data = await tentarCarregarAvaliacao(fichaUuid);

      if (data.success && data.ficha) {
        const avaliacaoData: FichaAvaliacao = {
          ficha: {
            uuid: data.ficha.uuid || fichaUuid,
            colaborador: data.ficha.aluno_nome || data.ficha.colaborador?.nome || 'Participante',
            matricula: data.ficha.aluno_matricula || data.ficha.colaborador?.matricula || 'N/A',
            simulador: data.ficha.simulador?.nome || 'Simulador',
            template: data.ficha.template?.nome || 'Modelo',
            data_sessao: data.ficha.data_inicio || new Date().toISOString(),
            status_workflow: data.ficha.status_workflow || 'RASCUNHO',
            funcao_na_sessao: data.ficha.funcao_na_sessao || 'PIC',
            ciclo_executado: data.ficha.ciclo_executado || 1
          },
          manobras: data.ficha.manobras?.map((m: any) => ({
            id: m.id,
            codigo: m.codigo || `MAN${m.id}`,
            nome: m.nome,
            categoria: m.categoria || 'GERAL',
            criterios_aprovacao: m.criterios_aprovacao,
            pontuacao_minima: m.pontuacao_minima || 7.0,
            nota_atual: m.nota,
            observacoes_atual: m.observacoes,
            executada: m.executada || false
          })) || [],
          pode_avaliar: data.ficha.status_workflow !== 'APROVADO' && data.ficha.status_workflow !== 'REPROVADO'
        };

        setAvaliacao(avaliacaoData);

        const notasIniciais: Record<number, string> = {};
        const observacoesIniciais: Record<number, string> = {};

        avaliacaoData.manobras.forEach(manobra => {
          notasIniciais[manobra.id] = manobra.nota_atual?.toString() || '';
          observacoesIniciais[manobra.id] = manobra.observacoes_atual || '';
        });

        setNotas(notasIniciais);
        setObservacoes(observacoesIniciais);
        setObservacoesGerais(data.ficha.observacoes || '');

      } else {
        throw new Error('Dados de avaliação inválidos ou ficha não encontrada');
      }
    } catch (error: any) {
      console.error('❌ Erro ao carregar avaliação:', error);
      setErro(`Erro ao carregar avaliação: ${error.message}`);
    } finally {
      setLoading(false);
      isProcessing.current = false;
    }
  };

  useEffect(() => {
    console.log('🔄 useEffect de avaliação disparado:', {
      uuid,
      hasUuid: !!uuid,
      isValidUuid: uuid && uuid !== 'undefined' && uuid.length > 5,
      isProcessing: isProcessing.current,
      requestCount,
      pathname: window.location.pathname
    });

    if (uuid && uuid !== 'undefined' && uuid.length > 5 && !isProcessing.current && requestCount < MAX_REQUESTS) {
      carregarAvaliacao(uuid);
    } else if (!uuid || uuid === 'undefined' || uuid.length <= 5) {
      console.error('❌ UUID inválido para avaliação:', { uuid, length: uuid?.length });
      setErro('UUID da ficha inválido para avaliação');
      setLoading(false);
    }
  }, [uuid]); // ✅ DEPENDÊNCIA ESPECÍFICA - NÃO LOOP

  const handleFinalizarAvaliacao = async () => {
    if (!avaliacao || saving) return;

    setSaving(true);
    try {

      const avaliacaoCompleta = {
        status_workflow: 'AVALIADO',
        observacoes_gerais: observacoesGerais,
        manobras: avaliacao.manobras.map(manobra => ({
          id: manobra.id,
          nota: parseFloat(notas[manobra.id]) || 0,
          observacoes: observacoes[manobra.id] || '',
          executada: true
        }))
      };

      const response = await fetch(`/api/v2/simulador/ficha/${avaliacao.ficha.uuid}/avaliar`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(avaliacaoCompleta),
      });

      if (response.ok) {
        navigate(`/simuladores/ficha/${avaliacao.ficha.uuid}/visualizar`);
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Erro ao finalizar avaliação');
      }
    } catch (error: any) {
      console.error('❌ Erro ao finalizar avaliação:', error);
      setErro(`Erro ao finalizar avaliação: ${error.message}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
          <span>Carregando ficha para avaliação...</span>
          <span className="text-sm text-gray-500">({requestCount}/{MAX_REQUESTS} tentativas)</span>
        </div>
      </div>
    );
  }

  if (erro) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <h2 className="text-red-800 font-semibold">Erro ao carregar avaliação</h2>
          <p className="text-red-600 mt-1">{erro}</p>
          <div className="mt-2 text-sm text-gray-600">
            <p>UUID solicitado: {uuid}</p>
            <p>Tentativas realizadas: {requestCount}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/simuladores')}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Voltar
          </button>
          <button
            onClick={() => {
              setRequestCount(0);
              setLastUuidProcessed('');
              isProcessing.current = false;
              if (uuid) carregarAvaliacao(uuid);
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  if (!avaliacao) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
          <h2 className="text-yellow-800 font-semibold">Avaliação não encontrada</h2>
          <p className="text-yellow-600 mt-1">Não foi possível carregar os dados para avaliação.</p>
        </div>
        <button
          onClick={() => navigate('/simuladores')}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          Voltar
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Avaliar Ficha do Simulador</h1>
          <p className="text-gray-600">
            {avaliacao.ficha.colaborador} • {avaliacao.ficha.simulador} • UUID: {avaliacao.ficha.uuid}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/simuladores')}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleFinalizarAvaliacao}
            disabled={saving || !avaliacao.pode_avaliar}
            className={`px-4 py-2 rounded-md text-white ${
              saving || !avaliacao.pode_avaliar
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {saving ? (
              <>
                <div className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Finalizando...
              </>
            ) : (
              'Finalizar Avaliação'
            )}
          </button>
        </div>
      </div>

      {/* Informações da Sessão */}
      <div className="bg-white border rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Informações da Sessão</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <label className="font-medium text-gray-700">Participante:</label>
            <p>{avaliacao.ficha.colaborador}</p>
          </div>
          <div>
            <label className="font-medium text-gray-700">Matrícula:</label>
            <p>{avaliacao.ficha.matricula}</p>
          </div>
          <div>
            <label className="font-medium text-gray-700">Função:</label>
            <p>{avaliacao.ficha.funcao_na_sessao}</p>
          </div>
          <div>
            <label className="font-medium text-gray-700">Status:</label>
            <p className="font-medium">{avaliacao.ficha.status_workflow}</p>
          </div>
        </div>
      </div>

      {/* Avaliação das Manobras */}
      {avaliacao.manobras.length > 0 && (
        <div className="bg-white border rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-4">Avaliação das Manobras</h2>
          <div className="space-y-6">
            {avaliacao.manobras.map((manobra) => (
              <div key={manobra.id} className="border rounded-lg p-4 bg-gray-50">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-medium text-gray-900">{manobra.nome}</h3>
                    <p className="text-sm text-gray-600">
                      {manobra.categoria} • Nota mínima: {manobra.pontuacao_minima}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nota (0-10)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="10"
                      step="0.1"
                      value={notas[manobra.id] || ''}
                      onChange={(e) => setNotas(prev => ({
                        ...prev,
                        [manobra.id]: e.target.value
                      }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Digite a nota..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Observações
                    </label>
                    <input
                      type="text"
                      value={observacoes[manobra.id] || ''}
                      onChange={(e) => setObservacoes(prev => ({
                        ...prev,
                        [manobra.id]: e.target.value
                      }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Observações específicas da manobra..."
                    />
                  </div>
                </div>

                {manobra.criterios_aprovacao && (
                  <div className="mt-3">
                    <p className="text-sm text-gray-600">
                      <strong>Critérios:</strong> {manobra.criterios_aprovacao}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Observações Gerais */}
      <div className="bg-white border rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Observações Gerais</h2>
        <textarea
          value={observacoesGerais}
          onChange={(e) => setObservacoesGerais(e.target.value)}
          rows={4}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Digite as observações gerais sobre a performance do participante na sessão..."
        />
      </div>

      {/* Status de permissão */}
      {!avaliacao.pode_avaliar && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800">
            Esta ficha já foi finalizada e não pode mais ser avaliada.
          </p>
        </div>
      )}
    </div>
  );
};

export default AvaliarFichaSimulador;
