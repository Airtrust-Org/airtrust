/**
 * Componentes da página de Habilitações
 * Incluindo Header, Filters e Table
 */

import { memo } from 'react';
import type { Habilitacao } from '@/react-app/hooks/useHabilitacoes';
import {
  Plus,
  Upload,
  Settings,
  Download,
  Search,
  Filter,
  X,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from 'lucide-react';

// ============ TYPES ============

interface Stats {
  total: number;
  validas: number;
  vencendo: number;
  vencidas: number;
}

interface Coluna {
  id: string;
  nome: string;
  visivel: boolean;
}

interface HabilitacoesHeaderProps {
  stats: Stats;
  onNovaHabilitacao: () => void;
  onImportar: () => void;
  onConfigurarColunas: () => void;
  onExportar?: () => void;
}

interface HabilitacoesFiltersProps {
  busca: string;
  onBuscaChange: (value: string) => void;
  tipoFiltro: string;
  onTipoChange: (value: string) => void;
  statusFiltro: string;
  onStatusChange: (value: string) => void;
  incluirRenovadas: boolean;
  onIncluirRenovadasChange: (value: boolean) => void;
  onLimparFiltros: () => void;
}

interface HabilitacoesTableProps {
  habilitacoes: Habilitacao[];
  configColunas: Coluna[];
  orderBy: string;
  orderDir: 'asc' | 'desc';
  onSort: (field: string) => void;
  renderizarCelulas: (hab: Habilitacao) => React.ReactNode;
}

// ============ HEADER ============

export const HabilitacoesHeader = memo(function HabilitacoesHeader({
  stats,
  onNovaHabilitacao,
  onImportar,
  onConfigurarColunas,
  onExportar,
}: HabilitacoesHeaderProps) {
  return (
    <>
      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-600">Total</div>
          <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-600">Válidas</div>
          <div className="text-2xl font-bold text-green-600">{stats.validas}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-600">Vencendo</div>
          <div className="text-2xl font-bold text-yellow-600">{stats.vencendo}</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-sm text-gray-600">Vencidas</div>
          <div className="text-2xl font-bold text-red-600">{stats.vencidas}</div>
        </div>
      </div>

      {/* Botões de Ação */}
      <div className="flex flex-wrap gap-3 mb-6">
        <button
          onClick={onNovaHabilitacao}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nova Habilitação
        </button>

        <button
          onClick={onImportar}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Upload className="w-4 h-4" />
          Importar
        </button>

        <button
          onClick={onConfigurarColunas}
          className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
        >
          <Settings className="w-4 h-4" />
          Configurar Colunas
        </button>

        {onExportar && (
          <button
            onClick={onExportar}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
        )}
      </div>
    </>
  );
});

// ============ FILTERS ============

export const HabilitacoesFilters = memo(function HabilitacoesFilters({
  busca,
  onBuscaChange,
  tipoFiltro,
  onTipoChange,
  statusFiltro,
  onStatusChange,
  incluirRenovadas,
  onIncluirRenovadasChange,
  onLimparFiltros,
}: HabilitacoesFiltersProps) {
  return (
    <div className="bg-white rounded-lg shadow p-4 mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Filter className="w-5 h-5 text-gray-600" />
        <h3 className="text-lg font-semibold">Filtros</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Busca */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por nome, código..."
            value={busca}
            onChange={(e) => onBuscaChange(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Tipo */}
        <select
          value={tipoFiltro}
          onChange={(e) => onTipoChange(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">Todos os tipos</option>
          <option value="TREINAMENTO">Treinamento</option>
          <option value="EXAME">Exame</option>
          <option value="CHECK">Check</option>
        </select>

        {/* Status */}
        <select
          value={statusFiltro}
          onChange={(e) => onStatusChange(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="">Todos os status</option>
          <option value="VALIDA">Válida</option>
          <option value="VENCENDO">Vencendo</option>
          <option value="VENCIDA">Vencida</option>
        </select>

        {/* Incluir Renovadas */}
        <label className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
          <input
            type="checkbox"
            checked={incluirRenovadas}
            onChange={(e) => onIncluirRenovadasChange(e.target.checked)}
            className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-700">Incluir renovadas</span>
        </label>
      </div>

      {/* Limpar Filtros */}
      {(busca || tipoFiltro || statusFiltro || incluirRenovadas) && (
        <button
          onClick={onLimparFiltros}
          className="mt-4 flex items-center gap-2 px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
          Limpar filtros
        </button>
      )}
    </div>
  );
});

// ============ TABLE ============

export function HabilitacoesTable({
  habilitacoes,
  configColunas,
  orderBy,
  orderDir,
  onSort,
  renderizarCelulas,
}: HabilitacoesTableProps) {
  const getSortIcon = (field: string) => {
    if (orderBy !== field) return <ArrowUpDown className="w-4 h-4" />;
    return orderDir === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />;
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {configColunas
                .filter((col) => col.visivel)
                .map((col) => (
                  <th
                    key={col.id}
                    onClick={() => col.id !== 'acoes' && onSort(col.id)}
                    className={`px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${
                      col.id !== 'acoes' ? 'cursor-pointer hover:bg-gray-100' : ''
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      {col.nome}
                      {col.id !== 'acoes' && getSortIcon(col.id)}
                    </div>
                  </th>
                ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {habilitacoes.length === 0 ? (
              <tr>
                <td
                  colSpan={configColunas.filter((c) => c.visivel).length}
                  className="px-6 py-8 text-center text-gray-500"
                >
                  Nenhuma habilitação encontrada
                </td>
              </tr>
            ) : (
              habilitacoes.map((hab) => (
                <tr key={hab.id} className="hover:bg-gray-50">
                  {renderizarCelulas(hab)}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
