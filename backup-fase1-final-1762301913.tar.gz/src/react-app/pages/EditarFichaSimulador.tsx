import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, Save, AlertTriangle, CheckCircle, XCircle, Edit3, Eye } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

interface FichaDetalhes {
  ficha_uuid: string;
  status_workflow: string;
  funcao_na_sessao: string;
  ciclo_executado: number;
  resultado_final?: string;
  nota?: number;
  observacoes_instrutor?: string;
  aluno: {
    id: number;
    nome: string;
    matricula: string;
    funcao: string;
  };
  instrutor: {
    id: number;
    nome: string;
    matricula: string;
  };
  agendamento: {
    simulador: {
      id: number;
      nome: string;
      codigo_identificacao: string;
    };
    data_inicio: string;
    data_fim: string;
  };
  template: {
    id: number;
    nome: string;
    descricao?: string;
    numero_sessao: number;
    manobras: Array<{
      id: number;
      manobra_id_codigo: string;
      nome: string;
      categoria: string;
      criterios_aprovacao: string;
      pontuacao_minima: number;
      nota?: number;
      observacoes?: string;
      executada?: boolean;
    }>;
  };
}

const EditarFichaSimulador: React.FC = () => {
  const { uuid } = useParams<{ uuid: string }>();
  const navigate = useNavigate();

  const [ficha, setFicha] = useState<FichaDetalhes | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [erro, setErro] = useState<string>('');
  const [requestCount, setRequestCount] = useState(0);
  const [lastUuidProcessed, setLastUuidProcessed] = useState<string>('');
  const isProcessing = useRef(false);

  const [notas, setNotas] = useState<Record<number, string>>({});
  const [observacoes, setObservacoes] = useState<Record<number, string>>({});
  const [observacoesInstrutor, setObservacoesInstrutor] = useState('');
  const [conceito, setConceito] = useState<'APROVADO' | 'REPROVADO' | null>(null);

  const MAX_REQUESTS = 3;
  const REQUEST_TIMEOUT = 10000;

  const tentarCarregarFicha = async (fichaUuid: string): Promise<any> => {
    const endpoints = [
      `/api/v2/fichas/${fichaUuid}`,
      `/api/v2/simulador/ficha/${fichaUuid}`
    ];
    
    for (const endpoint of endpoints) {
      try {
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
        }, REQUEST_TIMEOUT);
        
        const response = await fetch(endpoint, {
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: REQUEST_TIMEOUT
        } as RequestInit);
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          return data;
        } else {
        }
      } catch (error: any) {
        console.log(`❌ Falhou na edição: ${endpoint}`, {
          error: error.message,
          name: error.name,
          isAborted: error.name === 'AbortError',
          isTimeout: error.message?.includes('timeout')
        });
        
        if (error.name === 'AbortError') {
        }
      }
    }
    
    throw new Error('Nenhum endpoint funcionou para edição após múltiplas tentativas com timeout');
  };

  const carregarFicha = async () => {
    if (!uuid) return;

    if (isProcessing.current || requestCount >= MAX_REQUESTS || uuid === lastUuidProcessed) {
      console.log('🛑 Bloqueando request de edição:', {
        isProcessing: isProcessing.current,
        requestCount,
        maxRequests: MAX_REQUESTS,
        uuid,
        lastUuidProcessed
      });
      return;
    }

    isProcessing.current = true;
    setLoading(true);
    setErro('');
    setRequestCount(prev => prev + 1);
    setLastUuidProcessed(uuid);

    try {
      console.log(`🔍 Carregando ficha para edição: ${uuid}`, {
        requestCount: requestCount + 1
      });

      const data = await tentarCarregarFicha(uuid);

      if (!data.success || !data.ficha) {
        throw new Error('Ficha não encontrada ou dados inválidos');
      }


      const fichaData: FichaDetalhes = {
        ficha_uuid: data.ficha.uuid || uuid,
        status_workflow: data.ficha.status_workflow || 'RASCUNHO',
        funcao_na_sessao: data.ficha.funcao_na_sessao || 'PIC',
        ciclo_executado: data.ficha.ciclo_executado || 1,
        resultado_final: data.ficha.conceito_final,
        nota: data.ficha.nota,
        observacoes_instrutor: data.ficha.observacoes,
        aluno: {
          id: 1,
          nome: data.ficha.aluno_nome || data.ficha.colaborador?.nome || 'Nome não informado',
          matricula: data.ficha.aluno_matricula || data.ficha.colaborador?.matricula || 'N/A',
          funcao: data.ficha.colaborador?.funcao || 'ATPL'
        },
        instrutor: {
          id: 2,
          nome: data.ficha.instrutor?.nome || 'Instrutor não informado',
          matricula: data.ficha.instrutor?.matricula || 'INST001'
        },
        agendamento: {
          simulador: {
            id: 1,
            nome: data.ficha.simulador?.nome || 'Simulador não informado',
            codigo_identificacao: data.ficha.simulador?.codigo || 'SIM001'
          },
          data_inicio: data.ficha.data_inicio || new Date().toISOString(),
          data_fim: data.ficha.data_fim || new Date().toISOString()
        },
        template: {
          id: 1,
          nome: data.ficha.template?.nome || 'Template não informado',
          descricao: data.ficha.template?.descricao,
          numero_sessao: data.ficha.template?.numero_sessao || 1,
          manobras: data.ficha.manobras?.map((m: any) => ({
            id: m.id,
            manobra_id_codigo: m.codigo || `MAN${m.id}`,
            nome: m.nome,
            categoria: m.categoria || 'GERAL',
            criterios_aprovacao: m.criterios_aprovacao || 'Critérios não definidos',
            pontuacao_minima: m.pontuacao_minima || 7.0,
            nota: m.nota,
            observacoes: m.observacoes,
            executada: m.executada || false
          })) || []
        }
      };

      if (!podeEditar(fichaData)) {
        alert('❌ Esta ficha não pode ser editada no status atual');
        navigate('/simuladores');
        return;
      }

      setFicha(fichaData);
      setObservacoesInstrutor(fichaData.observacoes_instrutor || '');

      const notasIniciais: Record<number, string> = {};
      const observacoesIniciais: Record<number, string> = {};

      fichaData.template?.manobras?.forEach((manobra: any) => {
        notasIniciais[manobra.id] = manobra.nota?.toString() || '';
        observacoesIniciais[manobra.id] = manobra.observacoes || '';
      });

      setNotas(notasIniciais);
      setObservacoes(observacoesIniciais);

      calcularConceito(notasIniciais);

    } catch (error: any) {
      console.error('❌ Erro ao carregar ficha para edição:', error);
      setErro(`Erro ao carregar ficha: ${error.message}`);
    } finally {
      setLoading(false);
      isProcessing.current = false;
    }
  };

  useEffect(() => {
    console.log('🔄 useEffect de edição disparado:', {
      uuid,
      hasUuid: !!uuid,
      isValidUuid: uuid && uuid !== 'undefined' && uuid.length > 5,
      isProcessing: isProcessing.current,
      requestCount,
      pathname: window.location.pathname
    });

    if (uuid && uuid !== 'undefined' && uuid.length > 5 && !isProcessing.current && requestCount < MAX_REQUESTS) {
      carregarFicha();
    } else if (!uuid || uuid === 'undefined' || uuid.length <= 5) {
      console.error('❌ UUID inválido para edição:', { uuid, length: uuid?.length });
      setErro('UUID da ficha inválido para edição');
      setLoading(false);
    }
  }, [uuid]); // ✅ DEPENDÊNCIA ESPECÍFICA - NÃO LOOP

  const podeEditar = (ficha: FichaDetalhes) => {
    const statusEditaveis = ['RASCUNHO', 'PENDENTE_ALUNO', 'EM_ANDAMENTO'];
    return statusEditaveis.includes(ficha.status_workflow);
  };

  const handleNotaChange = (manobraId: number, valor: string) => {
    const novasNotas = { ...notas, [manobraId]: valor };
    setNotas(novasNotas);
    calcularConceito(novasNotas);
  };

  const handleObservacaoChange = (manobraId: number, valor: string) => {
    setObservacoes({ ...observacoes, [manobraId]: valor });
  };

  const calcularConceito = (notasAtuais: Record<number, string>) => {
    if (!ficha?.template?.manobras) return;

    const notasPreenchidas = Object.values(notasAtuais).filter(n => n !== '' && n !== 'NR');
    const todasPreenchidas = notasPreenchidas.length === ficha.template.manobras.length;

    if (todasPreenchidas) {
      const notasNumericas = notasPreenchidas
        .filter(n => n !== 'NR')
        .map(Number)
        .filter(n => !isNaN(n));

      const temNotaBaixa = notasNumericas.some(nota => nota < 5);
      setConceito(temNotaBaixa ? 'REPROVADO' : 'APROVADO');
    } else {
      setConceito(null);
    }
  };

  const salvarAvaliacao = async () => {
    if (!ficha?.template?.manobras || !todasNotasPreenchidas()) {
      alert('❌ Todas as manobras devem ter nota definida');
      return;
    }

    setSaving(true);
    setErro('');

    try {
      const payload = {
        manobras: ficha.template.manobras.map(manobra => ({
          manobra_id: manobra.id,
          nota: notas[manobra.id] === 'NR' ? 'NR' : Number(notas[manobra.id]),
          observacoes: observacoes[manobra.id] || undefined
        })),
        observacoes_instrutor: observacoesInstrutor || undefined
      };


      const response = await fetch(`/api/v2/fichas/${uuid}/notas`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao salvar avaliação');
      }

      navigate(`/simuladores/ficha/${uuid}/visualizar`);

    } catch (error: any) {
      console.error('❌ Erro ao salvar:', error);
      setErro(error.message || 'Erro ao salvar avaliação');
    } finally {
      setSaving(false);
    }
  };

  const todasNotasPreenchidas = () => {
    if (!ficha?.template?.manobras) return false;
    return ficha.template.manobras.every(manobra => notas[manobra.id] !== '');
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'RASCUNHO': 'bg-gray-100 text-gray-800',
      'PENDENTE_ALUNO': 'bg-yellow-100 text-yellow-800',
      'PENDENTE_INSTRUTOR_FINAL': 'bg-orange-100 text-orange-800',
      'PENDENTE_CHECK': 'bg-purple-100 text-purple-800',
      'CONCLUIDA': 'bg-green-100 text-green-800',
      'REPROVADA': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getNotaColor = (nota: string, pontuacaoMinima: number) => {
    if (nota === 'NR') return 'text-gray-600';
    const notaNum = Number(nota);
    if (notaNum < pontuacaoMinima) return 'text-red-600 font-bold';
    if (notaNum >= 7) return 'text-green-600 font-semibold';
    return 'text-yellow-600 font-medium';
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
          <span>Carregando ficha para edição...</span>
          <span className="text-sm text-gray-500">({requestCount}/{MAX_REQUESTS} tentativas)</span>
        </div>
      </div>
    );
  }

  if (erro) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <h2 className="text-red-800 font-semibold flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Erro ao carregar ficha para edição
          </h2>
          <p className="text-red-600 mt-1">{erro}</p>
          <div className="mt-2 text-sm text-gray-600">
            <p>UUID solicitado: {uuid}</p>
            <p>Tentativas realizadas: {requestCount}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            onClick={() => navigate('/simuladores')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <Button
            variant="primary"
            onClick={() => {
              setRequestCount(0);
              setLastUuidProcessed('');
              isProcessing.current = false;
              carregarFicha();
            }}
          >
            Tentar novamente
          </Button>
        </div>
      </div>
    );
  }

  if (!ficha) {
    return (
      <div className="p-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
          <h2 className="text-yellow-800 font-semibold">Ficha não encontrada</h2>
          <p className="text-yellow-600 mt-1">Não foi possível carregar os dados da ficha para edição.</p>
        </div>
        <Button
          variant="secondary"
          onClick={() => navigate('/simuladores')}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div className="flex items-center space-x-4">
          <Button variant="secondary" onClick={() => navigate('/simuladores')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center">
              <Edit3 className="w-6 h-6 mr-3 text-blue-600" />
              Editar Ficha de Simulador
            </h1>
            <p className="text-gray-600 mt-1">{ficha.ficha_uuid}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(ficha.status_workflow)}`}>
            {ficha.status_workflow}
          </span>
          <Button 
            variant="secondary" 
            size="sm"
            onClick={() => navigate(`/simuladores/ficha/${uuid}/visualizar`)}
          >
            <Eye className="w-4 h-4 mr-1" />
            Visualizar
          </Button>
        </div>
      </div>

      {/* Error Display */}
      {erro && (
        <Card className="p-4 bg-red-50 border border-red-200">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <p className="text-red-800 text-sm">{erro}</p>
          </div>
        </Card>
      )}

      {/* Informações Básicas */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4 flex items-center">
          📋 Informações da Sessão
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <label className="text-sm font-medium text-gray-500 block mb-1">Aluno</label>
            <p className="text-gray-900 font-medium">{ficha.aluno.nome}</p>
            <p className="text-sm text-gray-500">{ficha.aluno.matricula}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500 block mb-1">Simulador</label>
            <p className="text-gray-900 font-medium">{ficha.agendamento.simulador.nome}</p>
            <p className="text-sm text-gray-500">{ficha.agendamento.simulador.codigo_identificacao}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500 block mb-1">Modelo</label>
            <p className="text-gray-900 font-medium">{ficha.template.nome}</p>
            <p className="text-sm text-gray-500">Sessão {ficha.template.numero_sessao}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-500 block mb-1">Instrutor</label>
            <p className="text-gray-900 font-medium">{ficha.instrutor.nome}</p>
            <p className="text-sm text-gray-500">{ficha.instrutor.matricula}</p>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-sm font-medium text-gray-500 block mb-1">Data da Sessão</label>
              <p className="text-gray-900">
                {new Date(ficha.agendamento.data_inicio).toLocaleString('pt-BR')}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500 block mb-1">Função</label>
              <p className="text-gray-900">{ficha.funcao_na_sessao}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500 block mb-1">Ciclo</label>
              <p className="text-gray-900">Ciclo {ficha.ciclo_executado}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Avaliação das Manobras */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-6 flex items-center">
          🎮 Avaliação das Manobras 
          <span className="ml-2 bg-blue-100 text-blue-800 text-sm px-2 py-1 rounded">
            {ficha.template.manobras?.length || 0} manobras
          </span>
        </h2>
        
        {ficha.template.manobras && ficha.template.manobras.length > 0 ? (
          <div className="space-y-6">
            {ficha.template.manobras.map((manobra) => (
              <div key={manobra.id} className="border border-gray-200 rounded-lg p-6 bg-gray-50">
                <div className="mb-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">
                        {manobra.manobra_id_codigo} - {manobra.nome}
                      </h3>
                      <span className="inline-block text-xs font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded mb-2">
                        {manobra.categoria}
                      </span>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-sm text-gray-500 mb-1">Nota mínima</div>
                      <div className="text-lg font-bold text-gray-900">
                        {manobra.pontuacao_minima}
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-700 mb-3 p-3 bg-blue-50 rounded border-l-4 border-blue-400">
                    <strong>Critérios:</strong> {manobra.criterios_aprovacao}
                  </p>
                  
                  {manobra.nota && (
                    <div className="text-sm text-gray-600 mb-3 p-2 bg-yellow-50 rounded">
                      📊 <strong>Nota anterior:</strong> 
                      <span className={`ml-1 font-bold ${getNotaColor(manobra.nota.toString(), manobra.pontuacao_minima)}`}>
                        {manobra.nota}
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nova Nota * <span className="text-red-500">*</span>
                    </label>
                    <select 
                      value={notas[manobra.id] || ''} 
                      onChange={(e) => handleNotaChange(manobra.id, e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                      required
                    >
                      <option value="">Selecione uma nota...</option>
                      {[1,2,3,4,5,6,7,8,9,10].map(num => (
                        <option key={num} value={num.toString()}>
                          {num} {num < manobra.pontuacao_minima ? '(Reprovado)' : ''}
                        </option>
                      ))}
                      <option value="NR">NR - Não Realizado</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Observações da Manobra
                    </label>
                    <textarea
                      value={observacoes[manobra.id] || ''}
                      onChange={(e) => handleObservacaoChange(manobra.id, e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows={3}
                      placeholder="Observações específicas desta manobra..."
                    />
                  </div>
                </div>

                {/* Preview da nota */}
                {notas[manobra.id] && (
                  <div className="mt-4 p-3 bg-white rounded border-l-4 border-blue-400">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Nota atribuída:</span>
                      <span className={`text-lg font-bold ${getNotaColor(notas[manobra.id], manobra.pontuacao_minima)}`}>
                        {notas[manobra.id]}
                        {notas[manobra.id] !== 'NR' && Number(notas[manobra.id]) < manobra.pontuacao_minima && (
                          <span className="ml-2 text-sm font-normal text-red-600">- REPROVADO</span>
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-6xl mb-4">🎮</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma manobra encontrada</h3>
            <p className="text-gray-600">Este modelo não possui manobras configuradas.</p>
          </div>
        )}

        {/* Observações Gerais do Instrutor */}
        <div className="mt-8 pt-6 border-t border-gray-300">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            💬 Observações Gerais do Instrutor
          </label>
          <textarea
            value={observacoesInstrutor}
            onChange={(e) => setObservacoesInstrutor(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={4}
            placeholder="Observações gerais sobre a performance do aluno na sessão..."
          />
        </div>

        {/* Preview do Conceito */}
        {conceito && (
          <div className={`mt-6 p-4 rounded-lg border-2 ${
            conceito === 'APROVADO' 
              ? 'bg-green-50 border-green-200' 
              : 'bg-red-50 border-red-200'
          }`}>
            <div className="flex items-center space-x-3">
              {conceito === 'APROVADO' ? (
                <CheckCircle className="w-8 h-8 text-green-500" />
              ) : (
                <XCircle className="w-8 h-8 text-red-500" />
              )}
              <div>
                <h3 className={`text-lg font-bold ${
                  conceito === 'APROVADO' ? 'text-green-700' : 'text-red-700'
                }`}>
                  Resultado Calculado: {conceito}
                </h3>
                {conceito === 'REPROVADO' && (
                  <p className="text-sm text-red-700 mt-1">
                    ⚠️ Reprovação identificada: pelo menos uma nota é menor que 5
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Progresso de preenchimento */}
        {ficha.template.manobras && ficha.template.manobras.length > 0 && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Progresso da avaliação</span>
              <span className="text-sm text-gray-600">
                {Object.values(notas).filter(n => n !== '').length} / {ficha.template.manobras.length}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ 
                  width: `${(Object.values(notas).filter(n => n !== '').length / ficha.template.manobras.length) * 100}%` 
                }}
              ></div>
            </div>
          </div>
        )}

        {/* Botões de Ação */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-300">
          <Button 
            variant="secondary" 
            onClick={() => navigate('/simuladores')} 
            disabled={saving}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          
          <div className="flex space-x-3">
            <Button 
              variant="secondary"
              onClick={() => navigate(`/simuladores/ficha/${uuid}/visualizar`)}
              disabled={saving}
            >
              <Eye className="w-4 h-4 mr-2" />
              Visualizar
            </Button>
            
            <Button 
              onClick={salvarAvaliacao}
              disabled={!todasNotasPreenchidas() || saving}
              variant="primary"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Avaliação {!todasNotasPreenchidas() && '(Preencha todas as notas)'}
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default EditarFichaSimulador;
