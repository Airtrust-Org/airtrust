import { useState, useEffect } from 'react';
import { BarChart3, CheckCircle, Grid3X3, Upload, Download, BookOpen, Target, TrendingUp, AlertCircle } from 'lucide-react';
import Button from '../components/Button';
import CatalogoManagement from '../components/treinamentos/CatalogoManagement';
import CertificacoesList from '../components/treinamentos/CertificacoesList';
import ComplianceMatrix from '../components/compliance/ComplianceMatrix';
import StatusCertificacoes from '../components/treinamentos/StatusCertificacoes';
import TreinamentosCriticos from '../components/treinamentos/TreinamentosCriticos';
import RastreabilidadeDocumental from '../components/treinamentos/RastreabilidadeDocumental';
import ImportarCertificacoesModal from '../components/shared/ImportarCertificacoes';
import ImportarCSVModal from '../components/ImportarCSVModal';
import BackupRestoreModal from '../components/shared/BackupRestoreModal';

const DashboardTreinamentos: React.FC = () => {
  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');
  const [activeTab, setActiveTab] = useState(tabParam || 'visao-geral');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isImportCertModalOpen, setIsImportCertModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [importMode, setImportMode] = useState<'catalog' | 'history'>('catalog');
  const [loading, setLoading] = useState(true);
  const [dashboardStats, setDashboardStats] = useState({
    totalCertificacoes: 0,    // ✅ NOME CORRETO DA API
    funcionariosAtivos: 0,    // ✅ NOME CORRETO DA API  
    vencendoEm30Dias: 0,
    vencidas: 0               // ✅ NOME CORRETO DA API
  });

  useEffect(() => {
    const carregarDashboard = async () => {
      setLoading(true);
      try {
        const response = await fetch('/api/v2/treinamentos/dashboard');
        const data = await response.json();

        if (data.success && data.dashboard) {
          setDashboardStats({
            totalCertificacoes: data.dashboard.estatisticas?.totalCertificacoes || 0,
            funcionariosAtivos: data.dashboard.estatisticas?.funcionariosAtivos || 0,
            vencendoEm30Dias: data.dashboard.estatisticas?.vencendoEm30Dias || 0,
            vencidas: data.dashboard.estatisticas?.vencidas || 0
          });
        }
      } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
      } finally {
        setLoading(false);
      }
    };

    carregarDashboard();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto p-8">
          <div className="text-center py-20">
            <div className="relative">
              <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 border-t-blue-600 mx-auto"></div>
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400 to-indigo-500 opacity-20 animate-pulse"></div>
            </div>
            <p className="mt-6 text-lg text-gray-600 font-medium">Carregando dashboard...</p>
            <p className="text-sm text-gray-500">Preparando módulo de treinamentos</p>
          </div>
        </div>
      </div>
    );
  }

  const tabs = [
    { 
      id: 'visao-geral', 
      label: 'Visão Geral', 
      icon: BarChart3,
      description: 'Panorama completo dos treinamentos',
      gradient: 'from-blue-500 to-indigo-600'
    },
    { 
      id: 'treinamentos', 
      label: 'Treinamentos', 
      icon: BookOpen,
      description: 'Catálogo de cursos obrigatórios',
      gradient: 'from-emerald-500 to-teal-600'
    },
    { 
      id: 'certificacoes', 
      label: 'Certificações', 
      icon: CheckCircle,
      description: 'Histórico e certificados emitidos',
      gradient: 'from-violet-500 to-purple-600'
    },
    { 
      id: 'matriz-compliance', 
      label: 'Matriz de Compliance', 
      icon: Grid3X3,
      description: 'Conformidade regulatória',
      gradient: 'from-amber-500 to-orange-600'
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'visao-geral':
        return (
          <div className="space-y-8">
            {/* Cards de Estatísticas Principais */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-2xl shadow-lg border border-blue-100 p-6 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full -translate-y-8 translate-x-8 opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-600">Total Certificações</p>
                    <p className="text-3xl font-bold text-gray-900">{dashboardStats.totalCertificacoes}</p>
                    <p className="text-xs text-blue-600 font-medium">Catálogo ativo</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg border border-emerald-100 p-6 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full -translate-y-8 translate-x-8 opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl shadow-lg">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                    <Target className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-600">Funcionários Ativos</p>
                    <p className="text-3xl font-bold text-gray-900">{dashboardStats.funcionariosAtivos}</p>
                    <p className="text-xs text-emerald-600 font-medium">Válidas atualmente</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg border border-amber-100 p-6 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full -translate-y-8 translate-x-8 opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl shadow-lg">
                      <AlertCircle className="w-6 h-6 text-white" />
                    </div>
                    <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-600">Vencendo em 30 dias</p>
                    <p className="text-3xl font-bold text-gray-900">{dashboardStats.vencendoEm30Dias}</p>
                    <p className="text-xs text-amber-600 font-medium">Requer atenção</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-lg border border-violet-100 p-6 relative overflow-hidden group hover:shadow-xl transition-all duration-300">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-violet-400 to-purple-500 rounded-full -translate-y-8 translate-x-8 opacity-10 group-hover:opacity-20 transition-opacity"></div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl shadow-lg">
                      <Grid3X3 className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-500">Vencidas</div>
                      <div className="text-sm font-bold text-red-600">{dashboardStats.vencidas}</div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-600">Certificações Vencidas</p>
                    <p className="text-3xl font-bold text-gray-900">{dashboardStats.vencidas}</p>
                    <p className="text-xs text-red-600 font-medium">Requer renovação</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Componentes da Visão Geral */}
            <StatusCertificacoes />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <TreinamentosCriticos />
              <RastreabilidadeDocumental />
            </div>
          </div>
        );
      case 'treinamentos':
        return <CatalogoManagement />;
      case 'certificacoes':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Lista de Certificações</h3>
                  <p className="text-gray-600">Histórico completo de certificações emitidas</p>
                </div>
                <div className="p-3 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl shadow-lg">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
            <CertificacoesList />
          </div>
        );
      case 'matriz-compliance':
        return <ComplianceMatrix />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto">
        {/* Header Principal Redesenhado */}
        <div className="relative bg-white shadow-xl border border-gray-100 rounded-3xl m-6 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 opacity-5"></div>
          <div className="relative p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl shadow-lg">
                    <BookOpen className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                      Gestão de Treinamentos e Certificações
                    </h1>
                    <p className="text-gray-600 mt-1 text-lg">
                      Sistema completo de gestão de treinamentos, certificações e compliance
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Botões de Ação Redesenhados */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  variant="secondary" 
                  className="bg-white hover:bg-blue-50 border-blue-200 text-blue-700 shadow-lg hover:shadow-xl transition-all duration-300 group"
                  onClick={() => {
                    setImportMode('catalog');
                    setIsImportModalOpen(true);
                  }}
                >
                  <Upload className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                  Importar Treinamentos
                </Button>
                
                <Button 
                  variant="secondary" 
                  className="bg-white hover:bg-emerald-50 border-emerald-200 text-emerald-700 shadow-lg hover:shadow-xl transition-all duration-300 group"
                  onClick={() => setIsImportCertModalOpen(true)}
                >
                  <Upload className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                  Importar Certificações
                </Button>
                
                <Button 
                  variant="secondary" 
                  className="bg-white hover:bg-violet-50 border-violet-200 text-violet-700 shadow-lg hover:shadow-xl transition-all duration-300 group"
                  onClick={() => setIsBackupModalOpen(true)}
                >
                  <Download className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                  Backup/Restore
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Redesenhada */}
        <div className="bg-white shadow-xl border border-gray-100 rounded-3xl mx-6 mb-6 overflow-hidden">
          <div className="p-2">
            <nav className="flex flex-wrap gap-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`group relative flex items-center gap-3 px-6 py-4 rounded-2xl font-medium text-sm transition-all duration-300 min-w-0 flex-1 md:flex-none ${
                      isActive
                        ? `bg-gradient-to-r ${tab.gradient} text-white shadow-lg transform scale-105`
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-gray-600'} transition-colors`} />
                    <div className="text-left">
                      <div className="font-semibold">{tab.label}</div>
                      <div className={`text-xs ${isActive ? 'text-white/80' : 'text-gray-500'} hidden sm:block`}>
                        {tab.description}
                      </div>
                    </div>
                    {isActive && (
                      <div className="absolute inset-0 rounded-2xl bg-white/10 pointer-events-none"></div>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="mx-6 mb-6">
          <div className="bg-white shadow-xl border border-gray-100 rounded-3xl overflow-hidden">
            <div className="p-8">
              {renderTabContent()}
            </div>
          </div>
        </div>
      </div>

      {/* Modais */}
      <ImportarCSVModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        mode={importMode}
        title={importMode === 'catalog' ? 'Importar Treinamentos via CSV' : 'Importar Certificações via CSV'}
        description="Importe dados usando arquivo CSV com validação avançada"
      />

      <ImportarCertificacoesModal
        isOpen={isImportCertModalOpen}
        onClose={() => setIsImportCertModalOpen(false)}
        onSuccess={() => {
          setIsImportCertModalOpen(false);
        }}
      />

      <BackupRestoreModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
      />
    </div>
  );
};

export default DashboardTreinamentos;
