import { useState, useEffect } from 'react';
import { Plus, Upload, Search, Edit2, Trash2 } from 'lucide-react';
import Button from '@/react-app/components/Button';
import { PageLayout, PageSection } from '@/react-app/components/layout/PageLayout';
import { classHelpers } from '@/react-app/styles/design-tokens';
import ImportarCSVModal from '../components/ImportarCSVModal';
import { useConfirmDelete } from '../hooks/useConfirmDelete';

export default function Manobras() {
  const [manobras, setManobras] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const { confirm, ConfirmDialog } = useConfirmDelete();

  useEffect(() => {
    fetchManobras();
  }, []);

  const fetchManobras = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/manobras`);
      const data = await response.json();
      setManobras(data.data || []);
    } catch (error) {
      console.error('Erro ao carregar manobras:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = (id: number, nome: string) => {
    confirm({
      message: 'Tem certeza que deseja excluir esta manobra?',
      itemName: nome,
      onConfirm: async () => {
        try {
          const response = await fetch(`${window.location.origin}/api/v2/manobras/${id}`, {
            method: 'DELETE',
          });

          if (response.ok) {
            fetchManobras();
          } else {
            alert('Erro ao excluir manobra');
          }
        } catch (error) {
          console.error('Erro ao excluir:', error);
          alert('Erro ao excluir manobra');
        }
      },
    });
  };

  const filteredManobras = manobras.filter(
    (m: Record<string, unknown>) =>
      String(m.nome).toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(m.codigo).toLowerCase().includes(searchTerm.toLowerCase()),
  );

  if (loading) {
    return (
      <PageLayout title="Manobras">
        <PageSection>
          <div className="p-6 text-center text-neutral-500">Carregando...</div>
        </PageSection>
      </PageLayout>
    );
  }

  return (
    <PageLayout
      title="Manobras"
      subtitle="Catálogo de manobras para treinamentos"
      action={
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => setShowImportModal(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button variant="primary" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Nova Manobra
          </Button>
        </div>
      }
    >
      <PageSection>
        <div className="p-6">
          {/* Search */}
          <div className="mb-6">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Buscar manobras..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-neutral-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-neutral-200 bg-neutral-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase w-24">
                    Ações
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase">
                    Código
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase">
                    Nome
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase">
                    Tipo
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-neutral-600 uppercase">
                    Referência QRH
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredManobras.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-neutral-500">
                      Nenhuma manobra encontrada
                    </td>
                  </tr>
                ) : (
                  filteredManobras.map((manobra) => {
                    const manobraTyped = manobra as Record<string, unknown>;
                    const id = String(manobraTyped.id);
                    return (
                      <tr
                        key={id}
                        className="border-t border-neutral-200 hover:bg-neutral-50 transition-colors"
                      >
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm" title="Editar">
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                handleExcluir(
                                  manobraTyped.id as number,
                                  manobraTyped.nome as string,
                                )
                              }
                              title="Excluir"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                        <td className="px-4 py-3 font-medium text-neutral-900">
                          {String(manobraTyped.codigo)}
                        </td>
                        <td className="px-4 py-3 text-neutral-900">{String(manobraTyped.nome)}</td>
                        <td className="px-4 py-3 text-neutral-600">{String(manobraTyped.tipo)}</td>
                        <td className="px-4 py-3 text-neutral-600">
                          {String(manobraTyped.referenciaQRH) || '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </PageSection>

      <ImportarCSVModal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        onSuccess={() => {
          fetchManobras();
          setShowImportModal(false);
        }}
        endpoint="/api/v2/manobras/import"
        templateEndpoint="/api/v2/manobras/template"
        title="Importar Manobras"
      />

      <ConfirmDialog />
    </PageLayout>
  );
}
