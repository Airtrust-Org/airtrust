import { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { TrendingUp, Users, Activity, BookOpen, BarChart3, Download } from 'lucide-react';

export default function RelatoriosDashboard() {
  const [certMes, setCertMes] = useState<any[]>([]);
  const [complianceSetor, setComplianceSetor] = useState<any[]>([]);
  const [simUso, setSimUso] = useState<any[]>([]);
  const [treinCat, setTreinCat] = useState<any[]>([]);
  const [dashExec, setDashExec] = useState<any>(null);
  const [simResumo, setSimResumo] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      const [certResp, compResp, simResp, treinResp, dashResp, simConResp] = await Promise.all([
        fetch(`${API_BASE_URL}/api/v2/relatorios/certificacoes-mes`),
        fetch(`${API_BASE_URL}/api/v2/relatorios/compliance-setor`),
        fetch(`${API_BASE_URL}/api/v2/relatorios/simuladores-uso`),
        fetch(`${API_BASE_URL}/api/v2/relatorios/treinamentos-categoria`),
        fetch(`${API_BASE_URL}/api/v2/relatorios/dashboard-executivo`),
        fetch(`${API_BASE_URL}/api/v2/relatorios/simuladores`)
      ]);

      const [certData, compData, simData, treinData, dashData, simConData] = await Promise.all([
        certResp.json(), compResp.json(), simResp.json(), treinResp.json(), dashResp.json(), simConResp.json()
      ]);

      if (certData.success) setCertMes(certData.dados || []);
      if (compData.success) setComplianceSetor(compData.dados || []);
      if (simData.success) setSimUso(simData.dados || []);
      if (treinData.success) setTreinCat(treinData.dados || []);
      if (dashData.success) setDashExec(dashData.data || null);
      if (simConData.success) setSimResumo(simConData.data || null);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const exportarCSV = () => {
    window.open(`${API_BASE_URL}/api/v2/relatorios/exportar-csv?tipo=qualificacoes`, '_blank');
  };

  const CORES = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Relatórios e Análises</h1>
            <p className="text-gray-600 mt-1">Dashboards executivos com métricas operacionais</p>
          </div>
          <button onClick={exportarCSV} className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg bg-white text-gray-700 hover:bg-gray-50">
            <Download className="w-4 h-4" /> Exportar CSV
          </button>
        </div>

        {/* Cards Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-sm text-gray-600">Cert./Mês (Média)</p>
            <p className="text-2xl font-bold text-blue-600 mt-1">
              {certMes.length > 0
                ? Math.round(certMes.reduce((a, b) => a + (b.total || 0), 0) / certMes.length)
                : 0}
            </p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-sm text-gray-600">Compliance Médio</p>
            <p className="text-2xl font-bold text-green-600 mt-1">
              {complianceSetor.length > 0
                ? Math.round(
                    complianceSetor.reduce((a, b) => a + (b.taxa_compliance || 0), 0) /
                      complianceSetor.length
                  )
                : 0}
              %
            </p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Activity className="w-6 h-6 text-purple-600" />
            </div>
            <p className="text-sm text-gray-600">Total Sessões</p>
            <p className="text-2xl font-bold text-purple-600 mt-1">
              {simUso.reduce((a, b) => a + (b.total_sessoes || 0), 0)}
            </p>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-orange-600" />
            </div>
            <p className="text-sm text-gray-600">Treinamentos</p>
            <p className="text-2xl font-bold text-orange-600 mt-1">
              {treinCat.reduce((a, b) => a + (b.total || 0), 0)}
            </p>
          </div>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Gráfico 1: Certificações por Mês */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Certificações por Mês (Últimos 12 meses)
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={certMes}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="mes" stroke="#6B7280" style={{ fontSize: '12px' }} />
                <YAxis stroke="#6B7280" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFF',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="total"
                  stroke="#3B82F6"
                  strokeWidth={3}
                  name="Certificações"
                  dot={{ fill: '#3B82F6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Gráfico 2: Compliance por Setor */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-green-600" />
              Taxa de Compliance por Setor
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={complianceSetor}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="setor" stroke="#6B7280" style={{ fontSize: '12px' }} />
                <YAxis domain={[0, 100]} stroke="#6B7280" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFF',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar dataKey="taxa_compliance" fill="#10B981" name="Compliance (%)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Gráfico 3: Simuladores Mais Usados */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-purple-600" />
              Top 5 Simuladores Mais Usados
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={simUso}
                  dataKey="total_sessoes"
                  nameKey="nome"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  label={({ nome, percent }) => `${nome}: ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {simUso.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={CORES[index % CORES.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFF',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Gráfico 4: Treinamentos por Categoria */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-orange-600" />
              Distribuição de Treinamentos por Categoria
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={treinCat} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis type="number" stroke="#6B7280" style={{ fontSize: '12px' }} />
                <YAxis
                  type="category"
                  dataKey="categoria"
                  width={150}
                  stroke="#6B7280"
                  style={{ fontSize: '12px' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFF',
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Bar dataKey="total" fill="#F59E0B" name="Quantidade" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mensagem quando não há dados */}
        {certMes.length === 0 &&
          complianceSetor.length === 0 &&
          simUso.length === 0 &&
          treinCat.length === 0 && (
            <div className="bg-white rounded-xl border border-gray-200 p-12 text-center mt-6">
              <BarChart3 className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Sem Dados Disponíveis</h3>
              <p className="text-gray-600">
                Não há dados suficientes para gerar os relatórios. Adicione certificações, sessões e
                treinamentos para visualizar as análises.
              </p>
            </div>
          )}
      </div>
    </div>
  );
}
