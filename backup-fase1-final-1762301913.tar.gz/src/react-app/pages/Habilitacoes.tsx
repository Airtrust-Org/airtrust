import React, { useState, useEffect } from 'react';
import { useHabilitacoes, type Habilitacao } from '@/react-app/hooks/useHabilitacoes';
import { useMutacoesHabilitacao } from '@/react-app/hooks/useMutacoesHabilitacao';
import { useQualificacoes, type Qualificacao } from '@/react-app/hooks/useQualificacoes';
import { useToast } from '@/react-app/hooks/useToast';
import { ModalHabilitacao } from '@/react-app/components/modals/ModalHabilitacao';
import { ModalNovaQualificacao } from '@/react-app/components/modals/ModalNovaQualificacao';
import { ModalNovaCategoria } from '@/react-app/components/modals/ModalNovaCategoria';
import { ModalUploadCertificado } from '@/react-app/components/modals/ModalUploadCertificado';

interface Categoria {
  id: number;
  nome: string;
  codigo: string;
  descricao?: string;
  cor?: string;
}
import {
  Plus,
  Edit2,
  Trash2,
  Download,
  AlertCircle,
  CheckCircle,
  Clock,
  Search,
  RotateCcw,
  FileUp,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from 'lucide-react';
import Button from '@/react-app/components/Button';
import Card, { CardContent } from '@/react-app/components/Card';

interface StatusInfo {
  status: 'VÁLIDO' | 'VENCENDO' | 'VENCIDA';
  cor: string;
  colorClass: string;
  diasTexto: string;
}

export function Habilitacoes() {
  const {
    habilitacoes,
    loading: habLoading,
    carregar: carregarHab,
    mutarHabilitacao,
  } = useHabilitacoes();
  const { registrarListener } = useMutacoesHabilitacao();
  const { qualificacoes, loading: qualLoading, carregar: carregarQual } = useQualificacoes();
  const { success, error } = useToast();
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [loadingCategorias, setLoadingCategorias] = useState(false);

  // ========== PAGINAÇÃO E STATS ==========
  const [paginaAtual, setPaginaAtual] = useState(1);
  const [totalRegistros, setTotalRegistros] = useState(0);
  const [stats, setStats] = useState({
    total: 0,
    validas: 0,
    vencendo: 0,
    vencidas: 0,
    renovadas: 0,
  });
  const [loadingStats, setLoadingStats] = useState(false);
  const limitPorPagina = 20;
  const totalPages = Math.ceil(totalRegistros / limitPorPagina);

  const [activeTab, setActiveTab] = useState<'historico' | 'qualificacoes' | 'categorias'>(
    'historico',
  );
  const [filtroTipo, setFiltroTipo] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('');
  const [filtroFuncionario, setFiltroFuncionario] = useState('');
  const [filtroRenovada, setFiltroRenovada] = useState('');
  const [sortColuna, setSortColuna] = useState<string | null>(null);
  const [sortDirecao, setSortDirecao] = useState<'asc' | 'desc'>('asc');

  const [modalAdicionarHabilitacao, setModalAdicionarHabilitacao] = useState(false);
  const [modalEditarHabilitacao, setModalEditarHabilitacao] = useState(false);
  const [editingHabilitacao, setEditingHabilitacao] = useState<Habilitacao | null>(null);
  const [modalAdicionarQualificacao, setModalAdicionarQualificacao] = useState(false);
  const [modalEditarQualificacao, setModalEditarQualificacao] = useState(false);
  const [modalAdicionarCategoria, setModalAdicionarCategoria] = useState(false);
  const [modalEditarCategoria, setModalEditarCategoria] = useState(false);
  const [modalUploadCertificado, setModalUploadCertificado] = useState(false);
  const [habilitacaoUpload, setHabilitacaoUpload] = useState<Habilitacao | null>(null);
  const [certificadosPorHabilitacao] = useState<Record<number, number>>({});

  /**
   * Carregar stats (dashboard) e primeira página da tabela em paralelo
   */
  useEffect(() => {
    const carregarDadosIniciais = async () => {
      setLoadingStats(true);
      try {
        // 1. Chamada paralela: stats + dados paginados
        const [statsRes, habRes] = await Promise.all([
          fetch('/api/v2/habilitacoes/stats'),
          fetch(`/api/v2/habilitacoes?page=1&limit=${limitPorPagina}`),
        ]);

        if (statsRes.ok) {
          const statsData = await statsRes.json();
          if (statsData.success && statsData.data) {
            setStats(statsData.data);
          }
        }

        if (habRes.ok) {
          const habData = await habRes.json();
          if (habData.success && habData.data) {
            // Usar dados da resposta paginada
            setTotalRegistros(habData.pagination?.total || 0);
            setPaginaAtual(habData.pagination?.page || 1);
            // Carregar dados paginados no hook
            if (habData.data && Array.isArray(habData.data)) {
              carregarHab(1, limitPorPagina);
            }
          }
        }
      } catch (err) {
        console.error('❌ Erro ao carregar dados iniciais:', err);
      } finally {
        setLoadingStats(false);
      }
    };

    carregarDadosIniciais();
    carregarQual();
    carregarCategorias();

    /**
     * 🔄 LISTENER DE MUTAÇÕES: Atualizar estado local ao invés de fazer full-page reload
     * Quando o modal de certificado dispara uma mutação, atualizamos apenas a habilitação afetada
     */
    const desregistrar = registrarListener((evento) => {
      console.log(
        `📡 Evento de mutação recebido:`,
        evento.tipo,
        `para habilitação #${evento.habilitacaoId}`,
      );

      if (evento.tipo === 'atualizacao' && evento.dados) {
        // Atualizar apenas a habilitação específica no estado
        mutarHabilitacao(evento.habilitacaoId, evento.dados);
      } else if (evento.tipo === 'criacao') {
        // Adicionar nova habilitação (seria raro neste contexto)
        console.log('✨ Nova habilitação criada, considere fazer refetch se necessário');
      } else if (evento.tipo === 'delecao') {
        // Remover habilitação
        console.log('🗑️ Habilitação deletada');
      }
    });

    return () => {
      desregistrar();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const carregarCategorias = async () => {
    try {
      setLoadingCategorias(true);
      const res = await fetch('/api/v2/categorias-qualificacoes');
      if (!res.ok) throw new Error('Erro ao carregar categorias');
      const data = await res.json();
      const cats = Array.isArray(data?.data) ? data.data : [];
      setCategorias(cats);
    } catch (err) {
      console.error('Erro ao carregar categorias:', err);
    } finally {
      setLoadingCategorias(false);
    }
  };

  // ========== FUNÇÃO PRINCIPAL: CALCULAR STATUS COM PRECEDÊNCIA DE RENOVADA ==========
  // REGRA: Se eh_renovada=true, SEMPRE retorna "RENOVADA" independente da data
  const calcularStatus = (dataVencimento: string, ehRenovada?: boolean): StatusInfo => {
    // ⭐ REGRA DE OURO: Se está renovada, é SEMPRE "RENOVADA"
    if (ehRenovada) {
      return {
        status: 'RENOVADA',
        cor: '#8B5CF6',
        colorClass: 'text-purple-600',
        diasTexto: 'Habilitação renovada',
      };
    }

    if (!dataVencimento) {
      return {
        status: 'VENCIDA',
        cor: '#F44336',
        colorClass: 'text-red-600',
        diasTexto: 'Sem validade',
      };
    }

    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const vencimento = new Date(dataVencimento);
    vencimento.setHours(0, 0, 0, 0);

    const diffTime = vencimento.getTime() - hoje.getTime();
    const diffDias = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDias < 0) {
      return {
        status: 'VENCIDA',
        cor: '#F44336',
        colorClass: 'text-red-600',
        diasTexto: `Vencida há ${Math.abs(diffDias)} dia${Math.abs(diffDias) !== 1 ? 's' : ''}`,
      };
    } else if (diffDias <= 30) {
      return {
        status: 'VENCENDO',
        cor: '#FF9800',
        colorClass: 'text-yellow-600',
        diasTexto: `Vence em ${diffDias} dia${diffDias !== 1 ? 's' : ''}`,
      };
    } else {
      return {
        status: 'VÁLIDO',
        cor: '#4CAF50',
        colorClass: 'text-green-600',
        diasTexto: `Válida por ${diffDias} dias`,
      };
    }
  };

  // ========== FORMATAÇÃO DE DATA ==========
  const formatarDataBR = (data: string | undefined) => {
    if (!data) return '-';
    const date = new Date(data);
    return date.toLocaleDateString('pt-BR');
  };

  // ========== FILTRO DE DADOS ==========
  const habilitacoesFiltradas = habilitacoes.filter((hab) => {
    const matchTipo =
      !filtroTipo || hab.qualificacao_codigo?.toLowerCase().includes(filtroTipo.toLowerCase());
    const matchStatus =
      !filtroStatus || calcularStatus(hab.data_vencimento, isRenovada(hab)).status === filtroStatus;
    const matchFuncionario =
      !filtroFuncionario ||
      hab.funcionario_nome?.toLowerCase().includes(filtroFuncionario.toLowerCase());
    const matchRenovada =
      !filtroRenovada || (filtroRenovada === 'sim' ? isRenovada(hab) : !isRenovada(hab));
    return matchTipo && matchStatus && matchFuncionario && matchRenovada;
  });

  // ========== ORDENAÇÃO DE DADOS ==========
  const habilitacoesOrdenadas = [...habilitacoesFiltradas].sort((a, b) => {
    if (!sortColuna) return 0;

    let valorA: any = a[sortColuna as keyof Habilitacao];
    let valorB: any = b[sortColuna as keyof Habilitacao];

    // Tratar valores null/undefined
    if (valorA == null && valorB == null) return 0;
    if (valorA == null) return sortDirecao === 'asc' ? 1 : -1;
    if (valorB == null) return sortDirecao === 'asc' ? -1 : 1;

    // Comparar strings
    if (typeof valorA === 'string' && typeof valorB === 'string') {
      const comp = valorA.localeCompare(valorB, 'pt-BR');
      return sortDirecao === 'asc' ? comp : -comp;
    }

    // Comparar números
    if (typeof valorA === 'number' && typeof valorB === 'number') {
      return sortDirecao === 'asc' ? valorA - valorB : valorB - valorA;
    }

    // Comparar datas
    if (sortColuna === 'data_vencimento' || sortColuna === 'data_conclusao') {
      const dataA = new Date(valorA).getTime();
      const dataB = new Date(valorB).getTime();
      return sortDirecao === 'asc' ? dataA - dataB : dataB - dataA;
    }

    return 0;
  });

  // ========== HANDLER DE ORDENAÇÃO ==========
  const handleSort = (coluna: string) => {
    if (sortColuna === coluna) {
      // Toggle entre asc e desc
      setSortDirecao(sortDirecao === 'asc' ? 'desc' : 'asc');
    } else {
      // Nova coluna, sempre começa com asc
      setSortColuna(coluna);
      setSortDirecao('asc');
    }
  };

  // ========== COMPONENTE DE HEADER COM SETA ==========
  const SortHeader = ({ coluna, label }: { coluna: string; label: string }) => (
    <th
      className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition"
      onClick={() => handleSort(coluna)}
    >
      <div className="flex items-center gap-2">
        {label}
        {sortColuna === coluna ? (
          sortDirecao === 'asc' ? (
            <ArrowUp className="w-4 h-4 text-blue-600" />
          ) : (
            <ArrowDown className="w-4 h-4 text-blue-600" />
          )
        ) : (
          <ArrowUpDown className="w-4 h-4 text-gray-400" />
        )}
      </div>
    </th>
  );

  // ========== FUNÇÃO HELPER: VERIFICAR SE RENOVADA ==========
  // Lógica: Uma habilitação é renovada se:
  // 1. eh_renovada = 1 (booleano true ou número 1)
  // 2. renovada_em tem uma data válida
  // 3. habilitacao_anterior_id existe e não é null
  const isRenovada = (hab: Habilitacao): boolean => {
    // Verificação 1: eh_renovada explicitamente marcado
    if (typeof hab.eh_renovada === 'number') {
      if (hab.eh_renovada === 1) return true;
    } else if (typeof hab.eh_renovada === 'boolean') {
      if (hab.eh_renovada === true) return true;
    }

    // Verificação 2: renovada_em com data válida
    if (hab.renovada_em) {
      try {
        const dataRenovacao = new Date(hab.renovada_em);
        if (!isNaN(dataRenovacao.getTime())) {
          return true;
        }
      } catch {
        // Continua para próxima verificação
      }
    }

    // Verificação 3: habilitacao_anterior_id existe (cadeia de renovações)
    if (hab.habilitacao_anterior_id && hab.habilitacao_anterior_id !== null) {
      return true;
    }

    return false;
  };

  // ========== DASHBOARD STATS (via API /stats) ==========
  // Agora os stats vêm do endpoint separado, não do array local
  const totalHab = stats.total;
  const validas = stats.validas;
  const vencendo = stats.vencendo;
  const vencidas = stats.vencidas;
  const renovadas = stats.renovadas;

  // ========== FUNÇÕES DE EDIÇÃO ==========
  const abrirEdicaoQualificacao = (id: number) => {
    const qual = qualificacoes.find((q) => q.id === id);
    if (qual) {
      setModalEditarQualificacao(true);
    }
  };

  // ========== LOADING STATE ==========
  if (habLoading || qualLoading || loadingStats) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Carregando dados...</p>
        </div>
      </div>
    );
  }

  // ========== CARD DASHBOARD GENÉRICO ==========
  const DashboardCard = ({
    titulo,
    valor,
    icone: Icone,
    corFundo,
    corBorda,
    corTexto,
  }: {
    titulo: string;
    valor: number;
    icone: React.ComponentType<{ className: string }>;
    corFundo: string;
    corBorda: string;
    corTexto: string;
  }) => {
    const shadowMap: Record<string, string> = {
      'border-blue-500': 'rgba(59, 130, 246, 0.1)',
      'border-green-500': 'rgba(34, 197, 94, 0.1)',
      'border-yellow-500': 'rgba(234, 179, 8, 0.1)',
      'border-red-500': 'rgba(239, 68, 68, 0.1)',
      'border-purple-500': 'rgba(139, 92, 246, 0.1)',
    };
    const shadowColor = shadowMap[corBorda] || 'rgba(0, 0, 0, 0.05)';
    return (
      <Card
        className={`${corFundo} border-l-4 ${corBorda}`}
        style={{ boxShadow: `0 4px 12px ${shadowColor}` }}
      >
        <CardContent className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">{titulo}</p>
            <p className={`text-3xl font-bold mt-2 ${corTexto}`}>{valor}</p>
          </div>
          <Icone className={`w-12 h-12 ${corTexto} opacity-20`} />
        </CardContent>
      </Card>
    );
  };

  // ========== COMPONENTE PRINCIPAL ==========
  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      {/* CABEÇALHO */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Habilitações</h1>
        <p className="text-gray-600">
          Gerencie qualificações, certificações e treinamentos dos funcionários
        </p>
      </div>

      {/* ========== DASHBOARD - 5 CARDS ========== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <DashboardCard
          titulo="Total"
          valor={totalHab}
          icone={CheckCircle}
          corFundo="bg-white/80"
          corBorda="border-blue-500"
          corTexto="text-blue-600"
        />
        <DashboardCard
          titulo="Válidas"
          valor={validas}
          icone={CheckCircle}
          corFundo="bg-white/80"
          corBorda="border-green-500"
          corTexto="text-green-600"
        />
        <DashboardCard
          titulo="Vencendo"
          valor={vencendo}
          icone={Clock}
          corFundo="bg-white/80"
          corBorda="border-yellow-500"
          corTexto="text-yellow-600"
        />
        <DashboardCard
          titulo="Vencidas"
          valor={vencidas}
          icone={AlertCircle}
          corFundo="bg-white/80"
          corBorda="border-red-500"
          corTexto="text-red-600"
        />
        <DashboardCard
          titulo="Renovadas"
          valor={renovadas}
          icone={RotateCcw}
          corFundo="bg-white/80"
          corBorda="border-purple-500"
          corTexto="text-purple-600"
        />
      </div>

      {/* ========== CARD COM ABAS ========== */}
      <Card>
        {/* ABAS */}
        <div className="flex border-b border-gray-200 bg-gray-50/50">
          {(['historico', 'qualificacoes', 'categorias'] as const).map((tab) => (
            <Button
              key={tab}
              variant="ghost"
              onClick={() => setActiveTab(tab)}
              className={`flex-1 px-6 py-4 font-medium transition-all border-b-2 rounded-none ${
                activeTab === tab
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab === 'historico' && 'Histórico'}
              {tab === 'qualificacoes' && 'Qualificações'}
              {tab === 'categorias' && 'Categorias'}
            </Button>
          ))}
        </div>

        {/* ========== ABA 1: HISTÓRICO ========== */}
        {activeTab === 'historico' && (
          <CardContent>
            {/* FILTROS AVANÇADOS */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Filtros Avançados</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Filtro: Tipo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Tipo
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Ex: CRM, PIC..."
                      value={filtroTipo}
                      onChange={(e) => setFiltroTipo(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Filtro: Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Status
                  </label>
                  <select
                    value={filtroStatus}
                    onChange={(e) => setFiltroStatus(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                  >
                    <option value="">Todos os Status</option>
                    <option value="VÁLIDO">Válido</option>
                    <option value="VENCENDO">Vencendo</option>
                    <option value="VENCIDA">Vencida</option>
                    <option value="RENOVADA">Renovada</option>
                  </select>
                </div>

                {/* Filtro: Funcionário */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Funcionário
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Nome do funcionário..."
                      value={filtroFuncionario}
                      onChange={(e) => setFiltroFuncionario(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Filtro: Renovada */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Renovada
                  </label>
                  <select
                    value={filtroRenovada}
                    onChange={(e) => setFiltroRenovada(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                  >
                    <option value="">Todas</option>
                    <option value="sim">✓ Renovadas</option>
                    <option value="nao">✕ Não Renovadas</option>
                  </select>
                </div>
              </div>

              {/* Botão Limpar Filtros */}
              {(filtroTipo || filtroStatus || filtroFuncionario || filtroRenovada) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setFiltroTipo('');
                    setFiltroStatus('');
                    setFiltroFuncionario('');
                    setFiltroRenovada('');
                  }}
                  className="mt-4 text-blue-600 hover:text-blue-800"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Limpar Filtros
                </Button>
              )}
            </div>

            {/* BOTÃO NOVA HABILITAÇÃO */}
            <div className="mb-6 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">
                Registros ({habilitacoesOrdenadas.length})
              </h3>
              <Button
                variant="primary"
                size="md"
                onClick={() => setModalAdicionarHabilitacao(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Habilitação
              </Button>
            </div>

            {/* TABELA */}
            {habilitacoesOrdenadas.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">Nenhuma habilitação encontrada</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Ações
                      </th>
                      <SortHeader coluna="funcionario_nome" label="Funcionário" />
                      <SortHeader coluna="categoria_nome" label="Categoria" />
                      <SortHeader coluna="qualificacao_nome" label="Qualificação" />
                      <SortHeader coluna="status" label="Status" />
                      <SortHeader coluna="data_vencimento" label="Vencimento" />
                      <SortHeader coluna="validade_meses" label="Validade" />
                      <SortHeader coluna="data_conclusao" label="Conclusão" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {habilitacoesOrdenadas.map((hab) => {
                      const statusInfo = calcularStatus(hab.data_vencimento, isRenovada(hab));
                      return (
                        <tr key={hab.id} className="hover:bg-blue-50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex gap-2">
                              {/* Download: SÓ se tiver certificado */}
                              {hab.certificado_url ? (
                                <Button variant="ghost" size="sm" title="Download Certificado">
                                  <Download className="w-4 h-4 text-blue-600" />
                                </Button>
                              ) : null}

                              {/* Upload/Gestão de Certificado: SEMPRE aparece */}
                              <Button
                                variant="ghost"
                                size="sm"
                                title={
                                  certificadosPorHabilitacao[hab.id]
                                    ? `${certificadosPorHabilitacao[hab.id]} certificado(s)`
                                    : 'Nenhum certificado'
                                }
                                onClick={() => {
                                  if (hab.id && hab.funcionario_id) {
                                    setHabilitacaoUpload(hab);
                                    setModalUploadCertificado(true);
                                  } else {
                                    alert('Habilitação inválida');
                                    error('Habilitação inválida');
                                  }
                                }}
                              >
                                <FileUp
                                  className={`w-4 h-4 ${
                                    certificadosPorHabilitacao[hab.id]
                                      ? 'text-green-600'
                                      : 'text-gray-400'
                                  }`}
                                />
                              </Button>

                              {/* Editar */}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setEditingHabilitacao(hab);
                                  setModalEditarHabilitacao(true);
                                }}
                                title="Editar"
                              >
                                <Edit2 className="w-4 h-4 text-indigo-600" />
                              </Button>

                              {/* Deletar */}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (confirm('Deletar habilitação?')) {
                                    fetch(`/api/v2/habilitacoes/${hab.id}`, {
                                      method: 'DELETE',
                                    }).then(() => {
                                      carregarHab(1, 50);
                                      success('Habilitação deletada com sucesso!');
                                    });
                                  }
                                }}
                                title="Deletar"
                              >
                                <Trash2 className="w-4 h-4 text-red-600" />
                              </Button>
                            </div>
                          </td>

                          {/* FUNCIONÁRIO */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {hab.funcionario_nome || '-'}
                            </div>
                          </td>

                          {/* CATEGORIA (Chip) */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            {(() => {
                              const cat = categorias.find((c) => c.nome === hab.categoria_nome);
                              const corBg = cat?.cor ? `${cat.cor}20` : '#e0e7ff';
                              const corText = cat?.cor || '#3b82f6';
                              return (
                                <span
                                  className="px-3 py-1 inline-flex items-center text-xs font-medium rounded-full"
                                  style={{
                                    backgroundColor: corBg,
                                    color: corText,
                                  }}
                                >
                                  {hab.categoria_nome || '-'}
                                </span>
                              );
                            })()}
                          </td>

                          {/* QUALIFICAÇÃO */}
                          <td className="px-6 py-4">
                            <div className="text-sm text-gray-900">
                              {hab.qualificacao_nome || '-'}
                            </div>
                          </td>

                          {/* STATUS (Chip colorido - SEM ÍCONES, RENOVADA É EXCLUSIVO) */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col gap-1">
                              <span
                                className={`px-3 py-1 rounded text-xs font-semibold w-fit ${statusInfo.colorClass}`}
                                style={{
                                  backgroundColor: `${statusInfo.cor}15`,
                                }}
                              >
                                {statusInfo.status}
                              </span>
                              <div className="text-xs" style={{ color: statusInfo.cor }}>
                                {statusInfo.diasTexto}
                              </div>
                            </div>
                          </td>

                          {/* VENCIMENTO */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatarDataBR(hab.data_vencimento)}
                          </td>

                          {/* VALIDADE (meses) */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {(() => {
                              // Buscar por nome ou código já que qualificacao_id é null
                              const qual = qualificacoes.find(
                                (q) =>
                                  q.nome === hab.qualificacao_nome ||
                                  q.codigo === hab.qualificacao_codigo ||
                                  q.id === hab.qualificacao_id,
                              );
                              return qual?.validade_meses ? `${qual.validade_meses} meses` : '-';
                            })()}
                          </td>

                          {/* CONCLUSÃO */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {formatarDataBR(hab.data_conclusao)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* ========== PAGINAÇÃO ========== */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="text-sm text-gray-700">
                  Mostrando {Math.max(1, (paginaAtual - 1) * limitPorPagina + 1)} até{' '}
                  {Math.min(paginaAtual * limitPorPagina, totalRegistros)} de {totalRegistros}{' '}
                  registros
                </div>

                <div className="flex items-center space-x-2">
                  {/* Primeira página */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setPaginaAtual(1);
                      carregarHab(1, limitPorPagina);
                    }}
                    disabled={paginaAtual === 1}
                    className="h-8 w-8 p-0"
                    title="Primeira página"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </Button>

                  {/* Página anterior */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const novaPagina = Math.max(1, paginaAtual - 1);
                      setPaginaAtual(novaPagina);
                      carregarHab(novaPagina, limitPorPagina);
                    }}
                    disabled={paginaAtual === 1}
                    className="h-8 w-8 p-0"
                    title="Página anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>

                  {/* Números das páginas */}
                  <div className="flex items-center space-x-1">
                    <span className="px-3 py-1 text-sm font-medium text-gray-900">
                      Página {paginaAtual} de {totalPages}
                    </span>
                  </div>

                  {/* Próxima página */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const novaPagina = Math.min(totalPages, paginaAtual + 1);
                      setPaginaAtual(novaPagina);
                      carregarHab(novaPagina, limitPorPagina);
                    }}
                    disabled={paginaAtual === totalPages}
                    className="h-8 w-8 p-0"
                    title="Próxima página"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>

                  {/* Última página */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setPaginaAtual(totalPages);
                      carregarHab(totalPages, limitPorPagina);
                    }}
                    disabled={paginaAtual === totalPages}
                    className="h-8 w-8 p-0"
                    title="Última página"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        )}

        {/* ========== ABA 2: QUALIFICAÇÕES ========== */}
        {activeTab === 'qualificacoes' && (
          <CardContent>
            <div className="mb-6 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">
                Qualificações ({qualificacoes?.length || 0})
              </h3>
              <div className="flex gap-2">
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => setModalAdicionarQualificacao(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Nova
                </Button>
              </div>
            </div>

            {!qualificacoes || qualificacoes.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">Nenhuma qualificação cadastrada</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Ações
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Categoria
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Nome Completo
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Categoria
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Validade
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {qualificacoes.map((qual: Qualificacao) => (
                      <tr key={qual.id} className="hover:bg-blue-50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => abrirEdicaoQualificacao(qual.id)}
                            >
                              <Edit2 className="w-4 h-4 text-indigo-600" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (confirm('Deletar qualificação?')) {
                                  fetch(`/api/v2/qualificacoes/${qual.id}`, {
                                    method: 'DELETE',
                                  }).then(() => carregarQual());
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-3 py-1 inline-flex items-center text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                            {qual.codigo || '-'}
                          </span>
                        </td>
                        <td className="px-6 py-4 font-medium text-gray-900">
                          {qual.codigo && qual.nome
                            ? `${qual.codigo} - ${qual.nome}`
                            : qual.nome || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {qual.categoria || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {qual.validade_meses ? `${qual.validade_meses} meses` : '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-3 py-1 inline-flex items-center text-xs font-medium rounded-full ${
                              qual.ativo
                                ? 'bg-green-100 text-green-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {qual.ativo ? '✓ Ativa' : '○ Inativa'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        )}

        {/* ========== ABA 3: CATEGORIAS ========== */}
        {activeTab === 'categorias' && (
          <CardContent>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">
                Categorias ({categorias?.length || 0})
              </h3>
              <Button variant="primary" size="sm" onClick={() => setModalAdicionarCategoria(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Nova Categoria
              </Button>
            </div>

            {loadingCategorias ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4" />
                <p className="text-gray-600">Carregando categorias...</p>
              </div>
            ) : !categorias || categorias.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 font-medium">Nenhuma categoria cadastrada</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Ações
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Categoria
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Nome
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Descrição
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                        Cor
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {categorias.map((cat) => (
                      <tr key={cat.id} className="hover:bg-blue-50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setModalEditarHabilitacao(true)}
                            >
                              <Edit2 className="w-4 h-4 text-indigo-600" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                if (confirm('Deletar categoria?')) {
                                  fetch(`/api/v2/categorias-qualificacoes/${cat.id}`, {
                                    method: 'DELETE',
                                  }).then(() => {
                                    carregarCategorias();
                                    success('Categoria deletada com sucesso!');
                                  });
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-3 py-1 inline-flex items-center text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                            {cat.codigo}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                          {cat.nome}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">{cat.descricao || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-6 h-6 rounded border border-gray-300"
                              style={{ backgroundColor: cat.cor || '#6B7280' }}
                            />
                            <span className="text-xs text-gray-500">{cat.cor || '-'}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        )}
      </Card>

      <ModalHabilitacao
        isOpen={modalAdicionarHabilitacao}
        onClose={() => setModalAdicionarHabilitacao(false)}
        onSave={() => {
          carregarHab(1, 50);
          setModalAdicionarHabilitacao(false);
          success('Habilitação adicionada com sucesso!');
        }}
      />
      <ModalUploadCertificado
        isOpen={modalUploadCertificado}
        onClose={() => setModalUploadCertificado(false)}
        habilitacaoId={habilitacaoUpload?.id}
        funcionarioId={habilitacaoUpload?.funcionario_id}
        onSave={() => {
          carregarHab(1, 50);
          success('Certificado salvo com sucesso!');
        }}
      />

      <ModalHabilitacao
        isOpen={modalEditarHabilitacao}
        onClose={() => setModalEditarHabilitacao(false)}
        habilitacao={editingHabilitacao}
        onSave={() => {
          carregarHab(1, 50);
          setModalEditarHabilitacao(false);
          success('Habilitação atualizada com sucesso!');
        }}
      />
      <ModalNovaQualificacao
        isOpen={modalAdicionarQualificacao}
        onClose={() => setModalAdicionarQualificacao(false)}
        onSave={() => {
          carregarQual();
          setModalAdicionarQualificacao(false);
        }}
      />
      <ModalNovaQualificacao
        isOpen={modalEditarQualificacao}
        onClose={() => setModalEditarQualificacao(false)}
        onSave={() => {
          carregarQual();
          setModalEditarQualificacao(false);
        }}
      />
      <ModalNovaCategoria
        isOpen={modalAdicionarCategoria}
        onClose={() => setModalAdicionarCategoria(false)}
        onSave={() => {
          carregarCategorias();
          setModalAdicionarCategoria(false);
        }}
      />
      <ModalNovaCategoria
        isOpen={modalEditarCategoria}
        onClose={() => setModalEditarCategoria(false)}
        onSave={() => {
          carregarCategorias();
          setModalEditarCategoria(false);
        }}
      />
    </div>
  );
}

export default Habilitacoes;
