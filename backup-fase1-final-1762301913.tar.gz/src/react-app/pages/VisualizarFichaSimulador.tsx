import FichaVisualizacaoAprimorada from '../components/simuladores/FichaVisualizacaoAprimorada';

export default function VisualizarFichaSimulador() {
  return <FichaVisualizacaoAprimorada />;
}
