import { HardRefreshButton } from '@/react-app/components/configuracoes/HardRefreshButton';

export default function HardRefresh() {
  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-semibold text-gray-900">Hard Refresh</h2>
        <p className="text-gray-600 mt-1">
          Limpe caches persistentes do navegador e recarregue o sistema para garantir que você está vendo a versão mais recente da aplicação.
        </p>
      </section>

      <HardRefreshButton />

      <section className="bg-white border border-gray-200 rounded-lg p-4">
        <h3 className="text-lg font-semibold text-gray-900">Quando usar o Hard Refresh?</h3>
        <ul className="mt-3 list-disc list-inside text-sm text-gray-700 space-y-1">
          <li>Após um deploy quando a interface continua mostrando componentes antigos.</li>
          <li>Quando scripts ou estilos parecem desatualizados mesmo após recarregar a página.</li>
          <li>Se o navegador insistir em usar dados em cache que causam comportamentos inesperados.</li>
        </ul>
      </section>
    </div>
  );
}
