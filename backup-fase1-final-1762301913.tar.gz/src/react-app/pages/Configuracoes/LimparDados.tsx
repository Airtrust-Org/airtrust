
import { useState, useEffect } from 'react';
import { Trash2, AlertTriangle, Shield, X } from 'lucide-react';

interface Contadores {
  funcionarios: number;
  qualificacoes: number;
  treinamentos: number;
  funcoes: number;
  aeronaves: number;
  setores: number;
  auditoria: number;
  importacoes: number;
}

interface Modulo {
  id: string;
  nome: string;
  descricao: string;
  perigo: 'BAIXO' | 'MEDIO' | 'ALTO' | 'CRITICO';
}

const MODULOS: Modulo[] = [
  {
    id: 'qualificacoes',
    nome: 'Qualificações',
    descricao: 'Remove todas as qualificações (treinamentos, exames e checks)',
    perigo: 'ALTO'
  },
  {
    id: 'importacoes',
    nome: 'Logs de Importação',
    descricao: 'Remove histórico de importações',
    perigo: 'BAIXO'
  },
  {
    id: 'treinamentos',
    nome: 'Catálogo de Treinamentos',
    descricao: 'Remove treinamentos do catálogo (não afeta qualificações)',
    perigo: 'MEDIO'
  },
  {
    id: 'funcoes',
    nome: 'Funções',
    descricao: 'Remove funções organizacionais',
    perigo: 'MEDIO'
  },
  {
    id: 'aeronaves',
    nome: 'Aeronaves',
    descricao: 'Remove aeronaves do catálogo',
    perigo: 'MEDIO'
  },
  {
    id: 'setores',
    nome: 'Setores',
    descricao: 'Remove setores organizacionais',
    perigo: 'MEDIO'
  },
  {
    id: 'auditoria',
    nome: 'Auditoria Antiga',
    descricao: 'Remove registros de auditoria com mais de 30 dias',
    perigo: 'BAIXO'
  },
  {
    id: 'funcionarios',
    nome: 'Funcionários',
    descricao: 'Remove TODOS os funcionários e suas qualificações',
    perigo: 'CRITICO'
  },
  {
    id: 'tudo',
    nome: '⚠️ LIMPAR TUDO',
    descricao: 'Remove TODOS OS DADOS do sistema (irreversível!)',
    perigo: 'CRITICO'
  }
];

export default function LimparDados() {
  const [contadores, setContadores] = useState<Contadores | null>(null);
  const [loading, setLoading] = useState(true);
  const [moduloSelecionado, setModuloSelecionado] = useState<string | null>(null);
  const [confirmacao, setConfirmacao] = useState('');
  const [entendi, setEntendi] = useState(false);
  const [processando, setProcessando] = useState(false);
  
  useEffect(() => {
    carregarContadores();
  }, []);
  
  const carregarContadores = async () => {
    try {
      const res = await fetch('/api/v2/admin/limpar-dados/contadores');
      const data = await res.json();
      if (data.success) {
        setContadores(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar contadores:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const abrirModal = (moduloId: string) => {
    setModuloSelecionado(moduloId);
    setConfirmacao('');
    setEntendi(false);
  };
  
  const fecharModal = () => {
    setModuloSelecionado(null);
    setConfirmacao('');
    setEntendi(false);
  };
  
  const confirmarLimpeza = async () => {
    if (confirmacao !== 'LIMPAR DADOS' || !entendi) {
      alert('Por favor, confirme todas as etapas');
      return;
    }
    
    setProcessando(true);
    
    try {
      const res = await fetch(`/api/v2/admin/limpar-dados/${moduloSelecionado}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          confirmacao: 'LIMPAR DADOS',
          usuario_id: 1
        })
      });
      
      const data = await res.json();
      
      if (data.success) {
        fecharModal();
        carregarContadores();
      } else {
        alert(`❌ Erro: ${data.error}`);
      }
    } catch (error) {
      console.error('Erro ao limpar dados:', error);
      alert('❌ Erro ao limpar dados');
    } finally {
      setProcessando(false);
    }
  };
  
  const getCorBadge = (perigo: string) => {
    const cores = {
      BAIXO: 'bg-yellow-100 text-yellow-800',
      MEDIO: 'bg-orange-100 text-orange-800',
      ALTO: 'bg-red-100 text-red-800',
      CRITICO: 'bg-red-600 text-white'
    };
    return cores[perigo as keyof typeof cores] || cores.BAIXO;
  };
  
  const getCorBorda = (perigo: string) => {
    const cores = {
      BAIXO: 'border-yellow-400',
      MEDIO: 'border-orange-400',
      ALTO: 'border-red-400',
      CRITICO: 'border-red-600'
    };
    return cores[perigo as keyof typeof cores] || cores.BAIXO;
  };
  
  const getContador = (moduloId: string) => {
    if (!contadores) return 0;
    return contadores[moduloId as keyof Contadores] || 0;
  };
  
  const moduloAtual = MODULOS.find(m => m.id === moduloSelecionado);
  
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
          <Shield className="h-8 w-8 text-red-600" />
          Limpeza de Dados
        </h1>
        <p className="text-gray-600 mt-2">
          ⚠️ <strong>ATENÇÃO:</strong> Esta área é restrita a administradores. 
          Todas as ações são auditadas e irreversíveis.
        </p>
      </div>
      
      {/* Alerta de Segurança */}
      <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
        <div className="flex items-start">
          <AlertTriangle className="h-6 w-6 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="text-red-800 font-bold mb-1">Zona de Perigo</h3>
            <p className="text-red-700 text-sm">
              As ações abaixo são <strong>permanentes</strong> e <strong>não podem ser desfeitas</strong>.
              Use apenas para limpar o sistema antes de importar dados corretos.
              Sempre faça backup antes de prosseguir.
            </p>
          </div>
        </div>
      </div>
      
      {/* Grid de Módulos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {MODULOS.map((modulo) => {
          const contador = getContador(modulo.id);
          
          return (
            <div
              key={modulo.id}
              className={`bg-white rounded-lg shadow border-l-4 ${getCorBorda(modulo.perigo)} p-4 hover:shadow-lg transition`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Trash2 className="h-5 w-5 text-gray-600" />
                  <h3 className="font-bold text-gray-900">{modulo.nome}</h3>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-bold ${getCorBadge(modulo.perigo)}`}>
                  {modulo.perigo}
                </span>
              </div>
              
              <p className="text-sm text-gray-600 mb-3">{modulo.descricao}</p>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">
                  {loading ? '...' : contador.toLocaleString()}
                </span>
                <button
                  onClick={() => abrirModal(modulo.id)}
                  disabled={loading || contador === 0}
                  className={`px-4 py-2 rounded font-medium transition ${
                    modulo.perigo === 'CRITICO'
                      ? 'bg-red-600 text-white hover:bg-red-700'
                      : 'bg-red-500 text-white hover:bg-red-600'
                  } disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2`}
                >
                  <Trash2 className="h-4 w-4" />
                  Limpar
                </button>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Modal de Confirmação */}
      {moduloSelecionado && moduloAtual && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-red-600 flex items-center gap-2">
                <AlertTriangle className="h-6 w-6" />
                Confirmar Limpeza
              </h2>
              <button
                onClick={fecharModal}
                disabled={processando}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded">
              <p className="text-red-800 font-bold mb-2">
                Você está prestes a remover:
              </p>
              <p className="text-red-700 text-xl font-bold">
                {getContador(moduloAtual.id).toLocaleString()} registros
              </p>
              <p className="text-red-600 text-sm mt-2">
                {moduloAtual.descricao}
              </p>
            </div>
            
            <div className="space-y-4">
              {/* Checkbox de Confirmação */}
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={entendi}
                  onChange={(e) => setEntendi(e.target.checked)}
                  className="mt-1 h-5 w-5 text-red-600"
                  disabled={processando}
                />
                <span className="text-sm text-gray-700">
                  Eu entendo que esta ação é <strong>permanente e irreversível</strong>.
                  Todos os dados serão removidos e não poderão ser recuperados.
                </span>
              </label>
              
              {/* Input de Confirmação */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Digite <strong>LIMPAR DADOS</strong> para confirmar:
                </label>
                <input
                  type="text"
                  value={confirmacao}
                  onChange={(e) => setConfirmacao(e.target.value)}
                  placeholder="LIMPAR DADOS"
                  disabled={processando}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
              </div>
              
              {/* Botões */}
              <div className="flex gap-3 pt-4">
                <button
                  onClick={fecharModal}
                  disabled={processando}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded font-medium text-gray-700 hover:bg-gray-50 transition disabled:opacity-50"
                >
                  Cancelar
                </button>
                <button
                  onClick={confirmarLimpeza}
                  disabled={confirmacao !== 'LIMPAR DADOS' || !entendi || processando}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded font-medium hover:bg-red-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {processando ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4" />
                      Confirmar Limpeza
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
