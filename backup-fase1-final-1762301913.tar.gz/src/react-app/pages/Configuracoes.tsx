
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Database, Users, Shield, ArrowLeft, Package, Bell, Upload, Edit2, Eye, Save, X } from 'lucide-react';
import { showToast } from '../utils/toast';
import { API_BASE_URL } from '../config/api';

export default function Configuracoes() {
  const [activeTab, setActiveTab] = useState<'geral' | 'backup' | 'usuarios'>('geral');
  const [backups, setBackups] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [templateHtml, setTemplateHtml] = useState<string>('');
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleUploadLogo = async () => {
    if (!logoFile) {
      showToast.error('Selecione um arquivo');
      return;
    }

    try {
      setUploading(true);
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const base64String = e.target?.result as string;
          const base64 = base64String.split(',')[1];
          
          const res = await fetch(`/api/v2/empresa-certificado-config/1/logo`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ base64, contentType: logoFile.type })
          });
          
          const data = await res.json();
          if (data.success) {
            setLogoPreview(data.data.logo_url);
            setLogoFile(null);
            showToast.success('Logo enviado com sucesso!');
          } else {
            showToast.error(data.error || 'Erro ao fazer upload');
          }
        } catch (err) {
          showToast.error('Erro ao fazer upload');
          console.error(err);
        } finally {
          setUploading(false);
        }
      };
      reader.readAsDataURL(logoFile);
    } catch (err) {
      showToast.error('Erro ao ler arquivo');
      console.error(err);
      setUploading(false);
    }
  };

  const handleSalvarTemplate = async () => {
    try {
      const res = await fetch(`/api/v2/empresa-certificado-config/1`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ template_html: templateHtml, cor_primaria: '#0066cc', cor_secundaria: '#333333' })
      });
      
      if (res.ok) {
        setShowTemplateModal(false);
        showToast.success('Template salvo com sucesso!');
      } else {
        showToast.error('Erro ao salvar template');
      }
    } catch (err) {
      showToast.error('Erro ao salvar template');
      console.error(err);
    }
  };

  const handleCreateBackup = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/backup/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });

      const data = await response.json();

      if (data.success) {
        showToast.success('Backup criado com sucesso!');
        loadBackups();
      } else {
        showToast.error(data.error || 'Erro ao criar backup');
      }
    } catch (error) {
      showToast.error('Erro ao criar backup');
    } finally {
      setLoading(false);
    }
  };

  const loadBackups = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/backup/list`);
      const data = await response.json();

      if (data.success) {
        setBackups(data.data);
      }
    } catch (error) {
      console.error('Erro ao carregar backups:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Configurações</h1>
          <p className="text-sm text-gray-600">Gerencie as configurações do sistema</p>
        </div>
      </div>

      {/* Container */}
      <div className="max-w-7xl mx-auto px-6 py-8">

        {/* Tabs */}
        <div className="bg-white rounded-lg border border-gray-200 mb-8">
          <nav className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('geral')}
              className={`px-6 py-4 font-medium text-sm transition-colors border-b-2 ${
                activeTab === 'geral'
                  ? 'border-blue-600 text-blue-600 bg-blue-50'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Settings className="w-4 h-4 inline mr-2" />
              Geral
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`px-6 py-4 font-medium text-sm transition-colors border-b-2 ${
                activeTab === 'backup'
                  ? 'border-blue-600 text-blue-600 bg-blue-50'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Database className="w-4 h-4 inline mr-2" />
              Backup
            </button>
            <button
              onClick={() => setActiveTab('usuarios')}
              className={`px-6 py-4 font-medium text-sm transition-colors border-b-2 ${
                activeTab === 'usuarios'
                  ? 'border-blue-600 text-blue-600 bg-blue-50'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Users className="w-4 h-4 inline mr-2" />
              Usuários
            </button>
          </nav>
        </div>

        {/* Conteúdo */}
        {activeTab === 'geral' && (
          <div className="space-y-6">
            {/* Informações da Empresa */}
            <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 mb-6 flex items-center gap-2">
                <span>📋</span> Informações da Empresa
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome da Empresa
                  </label>
                  <input
                    type="text"
                    className="w-full h-10 border border-gray-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 transition-colors"
                    placeholder="AirTrust"
                  />
                </div>
              </div>
            </div>

            {/* Configuração de Certificados */}
            <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 mb-8 flex items-center gap-2">
                <span>🏢</span> Configuração de Certificados
              </h2>

              {/* Logo do Certificado */}
              <div className="mb-8 pb-8 border-b border-gray-200">
                <h3 className="text-base font-semibold text-gray-900 mb-4">Logo do Certificado</h3>
                
                {logoPreview && (
                  <div className="mb-4 border border-gray-200 rounded-md p-4 bg-gray-50">
                    <img 
                      src={logoPreview} 
                      style={{maxHeight: '100px', width: '100%', objectFit: 'contain'}} 
                      alt="Logo"
                    />
                  </div>
                )}

                <div className="flex gap-3">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setLogoFile(e.target.files?.[0] || null)}
                    className="flex-1 text-sm"
                  />
                  <button
                    onClick={handleUploadLogo}
                    disabled={!logoFile || uploading}
                    className="h-10 bg-blue-600 text-white px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-medium text-sm transition-colors"
                  >
                    <Upload size={16} />
                    {uploading ? 'Enviando...' : 'Enviar Logo'}
                  </button>
                </div>
              </div>

              {/* Template HTML */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-4">Template de Certificado</h3>
                
                {templateHtml && (
                  <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md text-sm text-blue-800">
                    ✓ Template configurado ({templateHtml.length} caracteres)
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowTemplateModal(true)}
                    className="flex-1 h-10 bg-green-600 text-white px-4 rounded-md hover:bg-green-700 flex items-center justify-center gap-2 font-medium text-sm transition-colors"
                  >
                    <Edit2 size={16} />
                    {templateHtml ? 'Editar Template' : 'Criar Template'}
                  </button>
                  
                  {templateHtml && (
                    <button
                      onClick={() => setShowPreview(!showPreview)}
                      className="h-10 bg-purple-600 text-white px-4 rounded-md hover:bg-purple-700 flex items-center gap-2 font-medium text-sm transition-colors"
                    >
                      <Eye size={16} />
                      Preview
                    </button>
                  )}
                </div>

                {showPreview && (
                  <div className="mt-4 border border-gray-200 rounded-md p-4 bg-gray-50 max-h-96 overflow-auto">
                    <div dangerouslySetInnerHTML={{ __html: templateHtml }} />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* MODAL DE EDIÇÃO DE TEMPLATE */}
        {showTemplateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl w-full max-h-96 overflow-auto">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900">✏️ Editar Template</h3>
                <button 
                  onClick={() => setShowTemplateModal(false)} 
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
              
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md text-sm text-gray-700">
                <strong className="text-gray-900">Placeholders disponíveis:</strong>
                <br className="mt-2" />
                <code className="text-xs text-gray-600">
                  {`{{nome_funcionario}}`}, {`{{logo_url}}`}, {`{{nome_qualificacao}}`}, {`{{codigo_qualificacao}}`}, {`{{data_conclusao}}`}, {`{{data_atual}}`}, ...
                </code>
              </div>
              
              <textarea
                value={templateHtml}
                onChange={(e) => setTemplateHtml(e.target.value)}
                className="w-full h-64 border border-gray-200 rounded-md p-3 font-mono text-sm mb-4 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                placeholder="Cole seu HTML aqui..."
              />
              
              <div className="flex gap-3">
                <button
                  onClick={() => setShowTemplateModal(false)}
                  className="flex-1 h-10 bg-gray-200 text-gray-800 px-4 rounded-md hover:bg-gray-300 font-medium text-sm transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSalvarTemplate}
                  className="flex-1 h-10 bg-green-600 text-white px-4 rounded-md hover:bg-green-700 flex items-center justify-center gap-2 font-medium text-sm transition-colors"
                >
                  <Save size={16} />
                  Salvar Template
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'backup' && (
          <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Backup e Restore</h2>
              <button
                onClick={handleCreateBackup}
                disabled={loading}
                className="h-10 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium text-sm transition-colors"
              >
                {loading ? 'Criando...' : 'Criar Backup'}
              </button>
            </div>

            <div className="space-y-3">
              {backups.map((backup) => (
                <div key={backup.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">
                  <div>
                    <p className="font-medium text-gray-900">{backup.nome_arquivo}</p>
                    <p className="text-sm text-gray-600">{backup.created_at}</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-2 text-blue-600 hover:bg-blue-50 rounded-md text-sm font-medium transition-colors">
                      Download
                    </button>
                    <button className="px-3 py-2 text-green-600 hover:bg-green-50 rounded-md text-sm font-medium transition-colors">
                      Restaurar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'usuarios' && (
          <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Gerenciar Usuários</h2>
            <p className="text-gray-600 text-sm">Funcionalidade em desenvolvimento</p>
          </div>
        )}
      </div>
    </div>
  );
}
