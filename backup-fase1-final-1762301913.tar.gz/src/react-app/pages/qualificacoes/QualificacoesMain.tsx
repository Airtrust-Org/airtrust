import Habilitacoes from '../Habilitacoes';

const QualificacoesMain = () => {
  return <Habilitacoes />;
};

export default QualificacoesMain;
