import { useState, useEffect } from "react";
import { Bell, AlertTriangle, Clock } from "lucide-react";

interface Notificacao {
  id: number;
  funcionario_nome: string;
  funcionario_email?: string;
  tipo: string;
  categoria: string;
  data_vencimento: string;
  dias_restantes: number;
}

const Alertas = () => {
  const [notificacoes, setNotificacoes] = useState<Notificacao[]>([]);
  const [resumo, setResumo] = useState({
    vencendo_7_dias: 0,
    vencendo_30_dias: 0,
    vencidas: 0,
  });
  const [loading, setLoading] = useState(true);
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      setLoading(true);

      setNotificacoes([]);
      setResumo({ vencendo_7_dias: 0, vencendo_30_dias: 0, vencidas: 0 });
    } catch (error) {
      console.error("Erro ao carregar alertas:", error);
    } finally {
      setLoading(false);
    }
  };

  const enviarAlertas = async () => {
    if (
      !confirm(
        `Enviar alertas para ${notificacoes.length} qualificações vencendo?`,
      )
    )
      return;

    try {
      setEnviando(true);
      const API_URL = window.location.origin;
      const response = await fetch(
        `${API_URL}/api/v2/notificacoes/enviar-alertas`,
        {
          method: "POST",
        },
      );
      const data = await response.json();

      if (data.success) {
      } else {
        alert(`❌ Erro: ${data.error}`);
      }
    } catch (error) {
      alert("Erro ao enviar alertas");
      console.error(error);
    } finally {
      setEnviando(false);
    }
  };

  const getCorPrioridade = (dias: number) => {
    if (dias < 0) return "border-red-500 bg-red-50";
    if (dias <= 7) return "border-orange-500 bg-orange-50";
    if (dias <= 30) return "border-yellow-500 bg-yellow-50";
    return "border-gray-300 bg-white";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Resumo */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-red-600 font-medium">Vencidas</p>
              <p className="text-3xl font-bold text-red-700">
                {resumo.vencidas}
              </p>
            </div>
            <AlertTriangle className="w-10 h-10 text-red-500" />
          </div>
        </div>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-600 font-medium">
                Vencendo (7 dias)
              </p>
              <p className="text-3xl font-bold text-orange-700">
                {resumo.vencendo_7_dias}
              </p>
            </div>
            <Clock className="w-10 h-10 text-orange-500" />
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-yellow-600 font-medium">
                Vencendo (30 dias)
              </p>
              <p className="text-3xl font-bold text-yellow-700">
                {resumo.vencendo_30_dias}
              </p>
            </div>
            <Bell className="w-10 h-10 text-yellow-500" />
          </div>
        </div>
      </div>

      {/* Ações */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Alertas e Notificações</h2>
            <p className="text-sm text-gray-600">
              {notificacoes.length} qualificações vencendo nos próximos 30 dias
            </p>
          </div>
          <button
            onClick={enviarAlertas}
            disabled={enviando || notificacoes.length === 0}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
              enviando || notificacoes.length === 0
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700"
            } text-white`}
          >
            <Bell className="w-4 h-4" />
            {enviando ? "Enviando..." : "Processar Alertas"}
          </button>
        </div>
      </div>

      {/* Lista de Notificações */}
      <div className="space-y-3">
        {notificacoes.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
            <Bell className="w-12 h-12 mx-auto mb-3 text-gray-400" />
            <p>Nenhuma qualificação vencendo nos próximos 30 dias</p>
          </div>
        ) : (
          notificacoes.map((n) => (
            <div
              key={n.id}
              className={`bg-white rounded-lg shadow p-4 border-l-4 ${getCorPrioridade(n.dias_restantes)}`}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold text-gray-900">
                      {n.funcionario_nome}
                    </span>
                    {n.funcionario_email && (
                      <span className="text-xs text-gray-500">
                        ({n.funcionario_email})
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <span className="px-2 py-1 bg-gray-100 rounded text-xs font-medium">
                      {n.tipo}
                    </span>
                    <span>{n.categoria}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p
                    className={`text-lg font-bold ${
                      n.dias_restantes < 0
                        ? "text-red-600"
                        : n.dias_restantes <= 7
                          ? "text-orange-600"
                          : "text-yellow-600"
                    }`}
                  >
                    {n.dias_restantes < 0
                      ? `${Math.abs(n.dias_restantes)} dias vencido`
                      : `${n.dias_restantes} dias restantes`}
                  </p>
                  <p className="text-sm text-gray-500">
                    Vence:{" "}
                    {new Date(n.data_vencimento + 'T00:00:00').toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Informação */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <strong>ℹ️ Nota:</strong> O sistema está preparado para envio de
          emails. Para ativar, integre com um serviço de email (Resend,
          SendGrid, etc.) no arquivo{" "}
          <code className="bg-blue-100 px-1 rounded">
            src/worker/routes/notificacoes.ts
          </code>
        </p>
      </div>
    </div>
  );
};

export default Alertas;
