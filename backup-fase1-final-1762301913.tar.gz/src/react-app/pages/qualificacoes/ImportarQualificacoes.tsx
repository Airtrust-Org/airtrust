import { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import {
  Upload,
  Download,
  FileSpreadsheet,
  CheckCircle,
  XCircle,
  AlertCircle,
} from "lucide-react";

interface ImportarQualificacoesProps {
  onImportSuccess?: () => void;
}

export default function ImportarQualificacoes({
  onImportSuccess,
}: ImportarQualificacoesProps) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [historico, setHistorico] = useState<any[]>([]);

  useEffect(() => {
    carregarHistorico();
  }, []);

  const carregarHistorico = async () => {
    try {
      const API_URL = window.location.origin;
      const response = await fetch(
        `${API_URL}/api/v2/qualificacoes/importacoes-historico?limit=10`,
      );
      const data = await response.json();
      if (data.success) {
        setHistorico(data.importacoes);
      }
    } catch (error) {
      console.error("Erro ao carregar histórico:", error);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setResultado(null);

      try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "buffer" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        const previewData = jsonData.slice(0, 5).map((row: any) => {
          const newRow = { ...row };
          Object.keys(newRow).forEach((key) => {
            const value = newRow[key];
            if (
              typeof value === "number" &&
              (key.toLowerCase().includes("data") ||
                key.toLowerCase().includes("validade"))
            ) {
              const date = new Date((value - 25569) * 86400 * 1000);
              const day = String(date.getUTCDate()).padStart(2, "0");
              const month = String(date.getUTCMonth() + 1).padStart(2, "0");
              const year = date.getUTCFullYear();
              newRow[key] = `${day}/${month}/${year}`;
            }
          });
          return newRow;
        });

        setPreview(previewData);
        setShowPreview(true);
      } catch (error) {
        console.error("Erro ao gerar preview:", error);
      }
    }
  };

  const handleImport = async () => {
    if (!file) {
      alert("Selecione um arquivo");
      return;
    }

    setLoading(true);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const API_URL = window.location.origin;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout

      const response = await fetch(
        `${API_URL}/api/v2/qualificacoes/importar-json`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            dados: jsonData,
            arquivo_nome: file.name,
          }),
          signal: controller.signal,
        },
      );

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json();
        const errorMsg =
          errorData.error || `Erro ${response.status}: ${response.statusText}`;
        console.error("[IMPORT ERROR]", errorData);
        alert(`Erro ao importar: ${errorMsg}`);
        setLoading(false);
        return;
      }

      const data = await response.json();

      if (data.success) {
        setResultado(data.resultados);
        onImportSuccess?.();
        carregarHistorico();

        if (data.resultados.erros.length === 0) {
          setTimeout(() => {
            setFile(null);
            setResultado(null);
            setPreview([]);
            setShowPreview(false);
          }, 10000);
        }
      } else {
        alert(`Erro: ${data.error || "Erro desconhecido"}`);
        console.error("[IMPORT ERROR]", data);
      }
    } catch (error) {
      let errorMsg = "Erro ao importar planilha";

      if (error instanceof Error) {
        if (error.name === "AbortError") {
          errorMsg =
            "Timeout: A importação demorou mais de 60 segundos. Tente com menos registros.";
        } else {
          errorMsg = error.message;
        }
      }

      alert(`Erro: ${errorMsg}`);
      console.error("[IMPORT EXCEPTION]", error);
    } finally {
      setLoading(false);
    }
  };

  const downloadTemplate = () => {
    const template = [
      [
        "cpf",
        "tipo",
        "codigo",
        "categoria",
        "descricao",
        "instituicao",
        "instrutor",
        "carga_horaria",
        "numero",
        "data_emissao",
        "data_conclusao",
        "data_vencimento",
        "observacoes",
      ],
      [
        "123.456.789-00",
        "TREINAMENTO",
        "CRM-2025",
        "CRM",
        "Crew Resource Management",
        "ANAC",
        "João Silva",
        40,
        "CERT-001",
        "15/01/2025",
        "20/01/2025",
        "20/01/2026",
        "Treinamento obrigatório",
      ],
      [
        "123.456.789-00",
        "CHECK",
        "PC-A320",
        "SIMULADOR",
        "Proficiency Check A320",
        "AirTrust",
        "Maria Santos",
        4,
        "CHECK-001",
        "01/02/2025",
        "01/02/2025",
        "01/08/2025",
        "Aprovado",
      ],
      [
        "987.654.321-00",
        "EXAME",
        "ASO-2025",
        "ASO",
        "Atestado Saúde Ocupacional",
        "Clínica Médica",
        "Dr. Pedro",
        0,
        "ASO-001",
        "10/03/2025",
        "10/03/2025",
        "10/03/2026",
        "Apto para voo",
      ],
    ];

    const ws = XLSX.utils.aoa_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Qualificações");
    XLSX.writeFile(wb, "template_qualificacoes_airtrust.xlsx");
  };

  return (
    <div className="space-y-6">
      {/* Importação */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex items-center gap-3 mb-4">
          <FileSpreadsheet className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-semibold">
            Importar Qualificações (Excel)
          </h3>
        </div>

        <div className="space-y-4">
          {/* Template */}
          <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <Download className="w-5 h-5 text-blue-600" />
            <div className="flex-1">
              <p className="font-medium text-blue-900">
                Baixe o template Excel
              </p>
              <p className="text-sm text-blue-700">
                Use este arquivo para garantir o formato correto
              </p>
            </div>
            <button
              onClick={downloadTemplate}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Baixar Template
            </button>
          </div>

          {/* Upload */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Selecionar Arquivo (.xlsx ou .xls)
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center justify-center px-4 py-8 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 cursor-pointer transition">
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <div className="text-center">
                  <Upload className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600">
                    {file ? (
                      <span className="font-semibold text-blue-600">
                        {file.name}
                      </span>
                    ) : (
                      "Clique para selecionar ou arraste o arquivo"
                    )}
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Preview */}
          {showPreview && preview.length > 0 && (
            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                <h4 className="font-semibold">Preview (primeiras 5 linhas)</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm border">
                  <thead className="bg-gray-200">
                    <tr>
                      {Object.keys(preview[0]).map((key) => (
                        <th key={key} className="px-3 py-2 text-left border">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white">
                    {preview.map((row, i) => (
                      <tr key={i} className="border-t hover:bg-gray-50">
                        {Object.values(row).map((val: any, j) => (
                          <td key={j} className="px-3 py-2 border">
                            {String(val)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Total de {preview.length} linhas no preview. Arquivo completo
                será processado na importação.
              </p>
            </div>
          )}

          {/* Botão Importar */}
          <button
            onClick={handleImport}
            disabled={!file || loading}
            className={`w-full py-3 rounded-lg text-white font-semibold flex items-center justify-center gap-2 ${
              loading || !file
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-green-600 hover:bg-green-700"
            }`}
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                Importando...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Importar Qualificações
              </>
            )}
          </button>

          {/* Resultados */}
          {resultado && (
            <div className="mt-4 p-4 border rounded-lg bg-white">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Resultado da Importação
              </h4>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-100 rounded">
                  <p className="text-2xl font-bold">{resultado.total}</p>
                  <p className="text-sm text-gray-600">Total</p>
                </div>
                <div className="text-center p-3 bg-green-100 rounded">
                  <p className="text-2xl font-bold text-green-600">
                    {resultado.sucesso}
                  </p>
                  <p className="text-sm text-gray-600">Sucesso</p>
                </div>
                <div className="text-center p-3 bg-red-100 rounded">
                  <p className="text-2xl font-bold text-red-600">
                    {resultado.erros.length}
                  </p>
                  <p className="text-sm text-gray-600">Erros</p>
                </div>
              </div>

              {resultado.erros.length > 0 && (
                <div className="mt-3">
                  <p className="text-red-600 font-semibold mb-2 flex items-center gap-2">
                    <XCircle className="w-5 h-5" />
                    Detalhes dos Erros:
                  </p>
                  <div className="max-h-60 overflow-y-auto bg-red-50 p-3 rounded border border-red-200">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-red-200">
                          <th className="text-left p-2">Linha</th>
                          <th className="text-left p-2">Campo</th>
                          <th className="text-left p-2">Erro</th>
                        </tr>
                      </thead>
                      <tbody>
                        {resultado.erros.map((erro: any, i: number) => (
                          <tr key={i} className="border-b border-red-100">
                            <td className="p-2">{erro.linha}</td>
                            <td className="p-2">{erro.campo || "-"}</td>
                            <td className="p-2">{erro.erro}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Histórico de Importações */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold mb-4">Histórico de Importações</h3>
        {historico.length === 0 ? (
          <p className="text-gray-500 text-center py-8">
            Nenhuma importação realizada ainda
          </p>
        ) : (
          <div className="space-y-2">
            {historico.map((imp: any) => (
              <div
                key={imp.id}
                className="border rounded-lg p-4 flex items-center justify-between hover:bg-gray-50"
              >
                <div>
                  <p className="font-semibold">{imp.arquivo_nome}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(imp.data_importacao).toLocaleString("pt-BR")}
                  </p>
                </div>
                <div className="text-right">
                  <span
                    className={`px-3 py-1 rounded text-sm font-semibold ${
                      imp.status === "CONCLUIDA"
                        ? "bg-green-100 text-green-800"
                        : imp.status === "PARCIAL"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                    }`}
                  >
                    {imp.status}
                  </span>
                  <p className="text-sm mt-1 text-gray-600">
                    {imp.sucesso}/{imp.total} registros
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
