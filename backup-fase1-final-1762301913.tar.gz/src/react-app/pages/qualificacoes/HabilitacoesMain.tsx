import Habilitacoes from '../Habilitacoes';

const HabilitacoesMain = () => {
  return <Habilitacoes />;
};

export default HabilitacoesMain;
