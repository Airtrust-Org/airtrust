import { useState, useEffect } from "react";
import {
  Award,
  CheckCircle,
  Clock,
  XCircle,
  BarChart3,
  Upload,
} from "lucide-react";
import {
  fetchAPI,
  diasRestantes,
  formatarData,
  QualificacoesResponse,
} from "@/react-app/utils/qualificacoesUtils";
import DashboardGraficos from "./DashboardGraficos";
import DashboardCharts from "@/react-app/components/qualificacoes/DashboardCharts";
import ImportarQualificacoes from "./ImportarQualificacoes";

interface Stats {
  total: number;
  validas: number;
  vencendo: number;
  vencidas: number;
}

const Dashboard = () => {
  const [stats, setStats] = useState<Stats>({
    total: 0,
    validas: 0,
    vencendo: 0,
    vencidas: 0,
  });
  const [qualificacoes, setQualificacoes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [mostrarGraficos, setMostrarGraficos] = useState(false);
  const [mostrarImportacao, setMostrarImportacao] = useState(false);
  const [exames, setExames] = useState<any[]>([]);
  const [checks, setChecks] = useState<any[]>([]);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      setLoading(true);
      setErro(null);

      const API_URL = window.location.origin;
      const [qualsData, examesRes, checksRes] = await Promise.all([
        fetchAPI<QualificacoesResponse>("/api/v2/qualificacoes"),
        fetch(`${API_URL}/api/v2/exames`),
        fetch(`${API_URL}/api/v2/checks`),
      ]);

      const quals = qualsData.qualificacoes || [];
      setQualificacoes(quals);
      calcularStats(quals);

      const examesData = await examesRes.json();
      if (examesData.success) {
        setExames(examesData.data || []);
      }

      const checksData = await checksRes.json();
      if (checksData.success) {
        setChecks(checksData.data || []);
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      setErro("Erro ao carregar dados. Verifique se o servidor está rodando.");
    } finally {
      setLoading(false);
    }
  };

  const calcularStats = (quals: any[]) => {
    setStats({
      total: quals.length,
      validas: quals.filter((q) => diasRestantes(q.data_vencimento) > 30)
        .length,
      vencendo: quals.filter((q) => {
        const dias = diasRestantes(q.data_vencimento);
        return dias >= 0 && dias <= 30;
      }).length,
      vencidas: quals.filter((q) => diasRestantes(q.data_vencimento) < 0)
        .length,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (erro) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-red-900 mb-2">
          Erro ao Carregar Dados
        </h3>
        <p className="text-red-700 mb-4">{erro}</p>
        <button
          onClick={carregarDados}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Botões de Ação */}
      <div className="flex justify-end gap-2">
        <button
          onClick={() => setMostrarImportacao(!mostrarImportacao)}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          <Upload className="w-4 h-4" />
          {mostrarImportacao ? "Ocultar Importação" : "Importar Qualificações"}
        </button>
        <button
          onClick={() => setMostrarGraficos(!mostrarGraficos)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <BarChart3 className="w-4 h-4" />
          {mostrarGraficos ? "Ocultar Gráficos" : "Mostrar Gráficos Avançados"}
        </button>
      </div>

      {/* Importação de Excel */}
      {mostrarImportacao && (
        <div className="mb-6">
          <ImportarQualificacoes onImportSuccess={carregarDados} />
        </div>
      )}

      {/* Gráficos Avançados */}
      {mostrarGraficos && (
        <div className="space-y-6">
          <DashboardGraficos />
          <DashboardCharts exames={exames} checks={checks} />
        </div>
      )}

      {/* CARDS DE ESTATÍSTICAS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-blue-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total</p>
              <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
              <p className="text-xs text-gray-500 mt-1">Qualificações</p>
            </div>
            <Award className="w-10 h-10 text-blue-500 opacity-20" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-green-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-600 mb-1">Válidas</p>
              <p className="text-3xl font-bold text-green-600">
                {stats.validas}
              </p>
              <p className="text-xs text-gray-500 mt-1">Compliance OK</p>
            </div>
            <CheckCircle className="w-10 h-10 text-green-500 opacity-20" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-yellow-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-600 mb-1">Vencendo</p>
              <p className="text-3xl font-bold text-yellow-600">
                {stats.vencendo}
              </p>
              <p className="text-xs text-gray-500 mt-1">≤ 30 dias</p>
            </div>
            <Clock className="w-10 h-10 text-yellow-500 opacity-20" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow border-l-4 border-red-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-600 mb-1">Vencidas</p>
              <p className="text-3xl font-bold text-red-600">
                {stats.vencidas}
              </p>
              <p className="text-xs text-gray-500 mt-1">Não conforme</p>
            </div>
            <XCircle className="w-10 h-10 text-red-500 opacity-20" />
          </div>
        </div>
      </div>

      {/* QUALIFICAÇÕES RECENTES */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-bold mb-4">Qualificações Recentes</h3>
        {qualificacoes.length === 0 ? (
          <p className="text-gray-500 text-center py-8">
            Nenhuma qualificação cadastrada
          </p>
        ) : (
          <div className="space-y-3">
            {qualificacoes.slice(0, 5).map((qual) => {
              const dias = diasRestantes(qual.data_vencimento);
              const statusColor =
                dias < 0
                  ? "text-red-600"
                  : dias <= 30
                    ? "text-yellow-600"
                    : "text-green-600";

              return (
                <div
                  key={qual.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
                >
                  <div>
                    <p className="font-medium">
                      {qual.funcionario_nome || "Sem nome"}
                    </p>
                    <p className="text-sm text-gray-600">{qual.categoria}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      Validade: {formatarData(qual.data_vencimento)}
                    </p>
                    <p className={`text-xs font-semibold ${statusColor}`}>
                      {dias < 0
                        ? `Vencida há ${Math.abs(dias)} dias`
                        : dias <= 30
                          ? `Vence em ${dias} dias`
                          : "Válida"}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
