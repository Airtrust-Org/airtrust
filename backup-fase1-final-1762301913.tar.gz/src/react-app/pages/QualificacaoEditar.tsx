
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Save, X, ArrowLeft, AlertCircle } from 'lucide-react';

interface QualificacaoData {
  id: number;
  funcionario_id: number;
  funcionario_nome: string;
  tipo: 'TREINAMENTO' | 'EXAME' | 'CHECK';
  codigo: string;
  nome?: string;
  descricao?: string;
  data_conclusao?: string;
  data_vencimento?: string;
  instituicao?: string;
  instrutor?: string;
  checador?: string;
  carga_horaria?: number;
  numero?: string;
  nota?: number;
  resultado?: string;
  observacoes?: string;
  categoria?: string;
}

export default function QualificacaoEditar() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<QualificacaoData | null>(null);

  useEffect(() => {
    if (id) {
      carregarQualificacao();
    } else {
      setFormData({
        id: 0,
        funcionario_id: 0,
        funcionario_nome: '',
        tipo: 'TREINAMENTO',
        codigo: '',
        nome: '',
        descricao: '',
        data_conclusao: '',
        data_vencimento: '',
        instituicao: '',
        instrutor: '',
        checador: '',
        carga_horaria: 0,
        numero: '',
        nota: 0,
        resultado: '',
        observacoes: '',
        categoria: ''
      });
      setLoading(false);
    }
  }, [id]);

  const carregarQualificacao = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(`/api/v2/qualificacoes/${id}`);
      const data = await response.json();

      if (data.success && data.qualificacao) {
        setFormData(data.qualificacao);
      } else {
        setError('Qualificação não encontrada');
      }
    } catch (err) {
      console.error('Erro ao carregar qualificação:', err);
      setError('Erro ao carregar dados da qualificação');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    setSaving(true);
    setError(null);

    try {
      const isNew = !id;
      const url = isNew ? '/api/v2/qualificacoes' : `/api/v2/qualificacoes/${id}`;
      const method = isNew ? 'POST' : 'PUT';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (data.success) {
        navigate('/qualificacoes');
      } else {
        setError(data.error || 'Erro ao salvar qualificação');
      }
    } catch (err) {
      console.error('Erro ao salvar:', err);
      setError('Erro ao salvar qualificação');
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (field: keyof QualificacaoData, value: any) => {
    if (!formData) return;
    setFormData({ ...formData, [field]: value });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error && !formData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md">
          <div className="flex items-center gap-3 text-red-600 mb-4">
            <AlertCircle className="h-6 w-6" />
            <h2 className="text-xl font-bold">Erro</h2>
          </div>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={() => navigate('/qualificacoes')}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Voltar para Qualificações
          </button>
        </div>
      </div>
    );
  }

  if (!formData) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="mb-6">
          <button
            onClick={() => navigate('/qualificacoes')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar para Qualificações
          </button>
          <h1 className="text-3xl font-bold text-gray-900">
            {id ? 'Editar Qualificação' : 'Nova Qualificação'}
          </h1>
          {id && formData.funcionario_nome && (
            <p className="text-gray-600 mt-1">
              {formData.funcionario_nome} - {formData.tipo} - {formData.codigo}
            </p>
          )}
        </div>

        {/* Erro */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-2 text-red-800">
              <AlertCircle className="h-5 w-5" />
              <p className="font-medium">{error}</p>
            </div>
          </div>
        )}

        {/* Formulário */}
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-6 space-y-6">
          {/* Informações Básicas */}
          <div className="border-b pb-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Informações Básicas</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo *
                </label>
                <input
                  type="text"
                  value={formData.tipo}
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-600"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Código *
                </label>
                <input
                  type="text"
                  value={formData.codigo}
                  onChange={(e) => handleChange('codigo', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nome
                </label>
                <input
                  type="text"
                  value={formData.nome || ''}
                  onChange={(e) => handleChange('nome', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Descrição
                </label>
                <textarea
                  value={formData.descricao || ''}
                  onChange={(e) => handleChange('descricao', e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Datas */}
          <div className="border-b pb-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Datas</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data de Conclusão
                </label>
                <input
                  type="date"
                  value={formData.data_conclusao || formData.data_conclusao || ''}
                  onChange={(e) => {
                    handleChange('data_conclusao', e.target.value);
                    handleChange('data_conclusao', e.target.value);
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Data Vencimento
                </label>
                <input
                  type="date"
                  value={formData.data_vencimento || ''}
                  onChange={(e) => handleChange('data_vencimento', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Campos Específicos por Tipo */}
          {formData.tipo === 'TREINAMENTO' && (
            <div className="border-b pb-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Dados do Treinamento</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Instituição
                  </label>
                  <input
                    type="text"
                    value={formData.instituicao || ''}
                    onChange={(e) => handleChange('instituicao', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Instrutor
                  </label>
                  <input
                    type="text"
                    value={formData.instrutor || ''}
                    onChange={(e) => handleChange('instrutor', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Carga Horária
                  </label>
                  <input
                    type="number"
                    value={formData.carga_horaria || ''}
                    onChange={(e) => handleChange('carga_horaria', parseInt(e.target.value) || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Categoria
                  </label>
                  <input
                    type="text"
                    value={formData.categoria || ''}
                    onChange={(e) => handleChange('categoria', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {formData.tipo === 'EXAME' && (
            <div className="border-b pb-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Dados do Exame</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Instituição
                  </label>
                  <input
                    type="text"
                    value={formData.instituicao || ''}
                    onChange={(e) => handleChange('instituicao', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Número
                  </label>
                  <input
                    type="text"
                    value={formData.numero || ''}
                    onChange={(e) => handleChange('numero', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Resultado
                  </label>
                  <select
                    value={formData.resultado || ''}
                    onChange={(e) => handleChange('resultado', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Selecione...</option>
                    <option value="APTO">Apto</option>
                    <option value="INAPTO">Inapto</option>
                    <option value="APTO_COM_RESTRICAO">Apto com Restrição</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {formData.tipo === 'CHECK' && (
            <div className="border-b pb-4">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Dados do Check</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Checador
                  </label>
                  <input
                    type="text"
                    value={formData.checador || ''}
                    onChange={(e) => handleChange('checador', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nota Final
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.nota || ''}
                    onChange={(e) => handleChange('nota', parseFloat(e.target.value) || null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Resultado
                  </label>
                  <select
                    value={formData.resultado || ''}
                    onChange={(e) => handleChange('resultado', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Selecione...</option>
                    <option value="APROVADO">Aprovado</option>
                    <option value="REPROVADO">Reprovado</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Observações */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Observações
            </label>
            <textarea
              value={formData.observacoes || ''}
              onChange={(e) => handleChange('observacoes', e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Observações adicionais..."
            />
          </div>

          {/* Botões */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => navigate('/qualificacoes')}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition"
            >
              <X className="h-4 w-4" />
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4" />
              {saving ? 'Salvando...' : 'Salvar Alterações'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
