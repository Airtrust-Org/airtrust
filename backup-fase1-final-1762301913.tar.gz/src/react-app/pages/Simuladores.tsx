import { useState, useEffect } from 'react';
import { Calendar, List, Plus, Edit, Trash2, Clock, User, FileText, Eye, ClipboardCheck, Upload, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAgendamentos } from '../hooks/useAgendamentos';
import FormularioAgendamento from '../components/simuladores/FormularioAgendamento';
import FormularioManobra from '../components/simuladores/FormularioManobra';
import FormularioTemplate from '../components/simuladores/FormularioTemplate';
import FormularioCategoria from '../components/simuladores/FormularioCategoria';
import ImportarManobras from '../components/simuladores/ImportarManobras';
import BotoesAcaoFichaFinal from '../components/simuladores/BotoesAcaoFichaFinal';
import { CalendarioAgendamentos } from '../components/simuladores/CalendarioAgendamentos';
import ModalAssinaturaCanvas from '../components/simuladores/ModalAssinaturaCanvas';
import { PageLayout } from '@/react-app/components/layout/PageLayout';
import Button from '@/react-app/components/Button';

export default function Simuladores() {
  const [activeTab, setActiveTab] = useState<'agenda' | 'fichas' | 'cadastro'>('agenda');
  const [viewMode, setViewMode] = useState<'calendario' | 'lista'>('calendario');
  const [showModalAgendamento, setShowModalAgendamento] = useState(false);
  const [agendamentoSelecionado, setAgendamentoSelecionado] = useState<any>(null);
  const [modoEdicao, setModoEdicao] = useState(false);

  return (
    <PageLayout
      title="Simuladores"
      subtitle="Gerencie agendamentos e sessões de simulador"
      action={
        <Button
          variant="primary"
          onClick={() => setShowModalAgendamento(true)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Agendar Sessão de Simulador
        </Button>
      }
      noPadding={false}
    >
      {/* Tabs */}
      <div className="bg-white rounded-lg shadow mb-8 border border-neutral-200">
        <nav className="flex border-b border-neutral-200">
          <button
            onClick={() => setActiveTab('agenda')}
            className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'agenda'
                ? 'border-blue-600 text-blue-600 bg-blue-50'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Agenda / Calendário
          </button>
          <button
            onClick={() => setActiveTab('fichas')}
            className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'fichas'
                ? 'border-blue-600 text-blue-600 bg-blue-50'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            Fichas das Sessões
          </button>
          <button
            onClick={() => setActiveTab('cadastro')}
            className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'cadastro'
                ? 'border-blue-600 text-blue-600 bg-blue-50'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }`}
          >
            <User className="w-4 h-4" />
            Cadastro
          </button>
        </nav>
      </div>

      {/* Content */}
      <div className="space-y-6">
        {activeTab === 'agenda' && (
          <AgendaView 
            viewMode={viewMode} 
            setViewMode={setViewMode}
            onAbrirModalAgendamento={() => setShowModalAgendamento(true)}
            onSelecionarAgendamento={(ag: any) => {
              setAgendamentoSelecionado(ag);
              setShowModalAgendamento(true);
            }}
          />
        )}
        {activeTab === 'fichas' && <FichasView />}
        {activeTab === 'cadastro' && <CadastroView />}
      </div>

      {/* Modais */}
      {showModalAgendamento && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto relative">
            <button
              onClick={() => {
                setShowModalAgendamento(false);
                setAgendamentoSelecionado(null);
              }}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-10"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            
            {agendamentoSelecionado && !modoEdicao ? (
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Detalhes do Agendamento</h2>
                
                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Simulador</label>
                    <p className="text-lg font-semibold">{agendamentoSelecionado.simulador_nome || 'N/A'}</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <span className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${
                      agendamentoSelecionado.status === 'AGENDADO' ? 'bg-blue-100 text-blue-800' :
                      agendamentoSelecionado.status === 'CONCLUIDO' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {agendamentoSelecionado.status}
                    </span>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Data</label>
                    <p className="text-lg">{new Date(agendamentoSelecionado.data + 'T00:00:00').toLocaleDateString('pt-BR')}</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Horário</label>
                    <p className="text-lg">{agendamentoSelecionado.hora_inicio} - {agendamentoSelecionado.hora_fim}</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Instrutor</label>
                    <p className="text-lg">{agendamentoSelecionado.instrutor_nome || 'Não definido'}</p>
                  </div>
                  
                  {agendamentoSelecionado.checador_nome && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Checador</label>
                      <p className="text-lg">{agendamentoSelecionado.checador_nome}</p>
                    </div>
                  )}
                </div>
                
                {agendamentoSelecionado.participantes_nomes && agendamentoSelecionado.participantes_nomes.length > 0 && (
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-3">Participantes</label>
                    <div className="space-y-2">
                      {agendamentoSelecionado.participantes_nomes.map((nome: string, idx: number) => (
                        <div key={idx} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                          <span className="font-medium">{nome}</span>
                          <span className="text-sm text-gray-600">{agendamentoSelecionado.tipo_sessao || 'PC'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {agendamentoSelecionado.observacoes && (
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Observações</label>
                    <p className="text-gray-600">{agendamentoSelecionado.observacoes}</p>
                  </div>
                )}
                
                <div className="flex gap-3 pt-4 border-t">
                  <button
                    onClick={() => {
                      setModoEdicao(true);
                    }}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                  >
                    Editar Agendamento
                  </button>
                  <button
                    onClick={() => {
                      setShowModalAgendamento(false);
                      setAgendamentoSelecionado(null);
                      setModoEdicao(false);
                    }}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            ) : (
              <FormularioAgendamento 
                onCancelar={() => {
                  setShowModalAgendamento(false);
                  setAgendamentoSelecionado(null);
                  setModoEdicao(false);
                }}
              />
            )}
          </div>
        </div>
      )}

    </PageLayout>
  );
}

function AgendaView({ viewMode, setViewMode, onAbrirModalAgendamento, onSelecionarAgendamento }: any) {
  const { agendamentos, loading, error, refetch } = useAgendamentos();
  const [agendamentosExcluidos, setAgendamentosExcluidos] = useState<number[]>([]);
  
  const agendamentosFiltrados = agendamentos.filter((ag: any) => !agendamentosExcluidos.includes(ag.id));

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Carregando agendamentos...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
        <div className="text-red-600 mb-4">
          <Calendar className="w-16 h-16 mx-auto mb-2" />
          <p className="font-semibold">Erro ao carregar agendamentos</p>
          <p className="text-sm mt-2">{error}</p>
        </div>
        <button
          onClick={refetch}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  if (agendamentosFiltrados.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
        <Calendar className="w-16 h-16 mx-auto text-gray-400 mb-4" />
        <p className="text-gray-600 mb-4">Nenhuma sessão agendada</p>
        <button 
          onClick={onAbrirModalAgendamento}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Agendar Primeira Sessão
        </button>
      </div>
    );
  }

  const agendamentosPorData = agendamentosFiltrados.reduce((acc: any, ag: any) => {
    const data = ag.data;
    if (!acc[data]) acc[data] = [];
    acc[data].push(ag);
    return acc;
  }, {});

  return (
    <div>
      {/* Toggle View */}
      <div className="mb-6 flex items-center space-x-4">
        <button
          onClick={() => setViewMode('calendario')}
          className={`inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            viewMode === 'calendario'
              ? 'bg-white text-gray-900 border border-gray-300 shadow-sm'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <Calendar className="w-4 h-4 mr-2" />
          Calendário
        </button>
        <button
          onClick={() => setViewMode('lista')}
          className={`inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
            viewMode === 'lista'
              ? 'bg-white text-gray-900 border border-gray-300 shadow-sm'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <List className="w-4 h-4 mr-2" />
          Lista
        </button>
      </div>

      {/* Visualização */}
      {viewMode === 'calendario' ? (
        <CalendarioAgendamentos 
          agendamentos={agendamentosFiltrados}
          onAgendamentoClick={onSelecionarAgendamento}
        />
      ) : (
        <div className="space-y-6">
          {Object.entries(agendamentosPorData).map(([data, agendamentosData]: [string, any]) => (
            <div key={data}>
              {/* Data Header */}
              <h3 className="text-sm font-semibold text-gray-700 mb-3">
                {formatarDataCompleta(data)}
              </h3>

              {/* Cards Compactos */}
              <div className="space-y-3">
                {agendamentosData.map((ag: any) => (
                  <CardAgendamentoCompacto 
                    key={ag.id} 
                    agendamento={ag}
                    onExcluir={(id: number) => setAgendamentosExcluidos(prev => [...prev, id])}
                    onEditar={onAbrirModalAgendamento}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CardAgendamentoCompacto({ agendamento, onExcluir, onEditar }: { agendamento: any; onExcluir?: (id: number) => void; onEditar?: () => void }) {
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const getSimuladorNome = (id: number) => {
    const nomes: any = {
      1: 'A320-001',
      2: 'B737-001',
      3: 'B737-002',
      4: 'ATR72-001'
    };
    return agendamento.simulador_nome || nomes[id] || `Simulador ${id}`;
  };

  const getStatusColor = (status: string) => {
    const colors: any = {
      'AGENDADO': 'bg-blue-100 text-blue-800',
      'EM_ANDAMENTO': 'bg-yellow-100 text-yellow-800',
      'CONCLUIDO': 'bg-green-100 text-green-800',
      'CANCELADO': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const handleEditar = () => {
    if (onEditar) {
      onEditar();
    }
  };

  const handleExcluir = async () => {
    try {
      const response = await fetch(`/api/v2/simuladores-consolidado/agendamentos/${agendamento.id}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        if (onExcluir) {
          onExcluir(agendamento.id);
        }
      } else {
        const data = await response.json();
        alert('Erro ao excluir: ' + (data.error || response.statusText));
      }
    } catch (error) {
      alert('Erro ao excluir agendamento: ' + error);
    }
    setShowConfirmDelete(false);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 hover:shadow-md transition-shadow">
      {/* Header Compacto */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h4 className="text-base font-semibold text-gray-900 mb-1">
            {getSimuladorNome(agendamento.simulador_id)}
          </h4>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{agendamento.hora_inicio} - {agendamento.hora_fim}</span>
            </div>
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              <span>{agendamento.instrutor_nome || 'Não definido'}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(agendamento.status)}`}>
            {agendamento.status}
          </span>
          <button 
            onClick={handleEditar}
            className="p-1.5 text-gray-400 hover:text-gray-600 transition-colors"
            title="Editar"
          >
            <Edit className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setShowConfirmDelete(true)}
            className="p-1.5 text-gray-400 hover:text-red-600 transition-colors"
            title="Excluir"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Observações Compactas */}
      {agendamento.observacoes && (
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {agendamento.observacoes}
        </p>
      )}

      {/* Participantes Compactos */}
      {agendamento.participantes && agendamento.participantes.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-gray-500">Participantes:</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {agendamento.participantes_nomes?.map((nome: string, idx: number) => {
              const fichaUuid = agendamento.participantes_fichas?.[idx];
              if (!fichaUuid) return null;
              
              return (
                <CardParticipanteCompacto 
                  key={idx}
                  agendamento={agendamento}
                  participante={{ 
                    nome, 
                    id: agendamento.participantes[idx],
                    tipo_sessao: agendamento.tipo_sessao,
                    ficha_uuid: fichaUuid
                  }} 
                />
              );
            })}
          </div>
        </div>
      )}
      
      {/* MODAL DE CONFIRMAÇÃO DE EXCLUSÃO */}
      {showConfirmDelete && (
        <div className="mt-4 p-4 bg-red-50 border-2 border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0">
              <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-red-900 mb-2">
                Confirmar Exclusão de Agendamento
              </h3>
              <p className="text-sm text-red-800 mb-3">
                Tem certeza que deseja excluir este agendamento?<br/>
                <strong>Esta ação não pode ser desfeita!</strong>
              </p>
              <div className="flex gap-3">
                <button
                  onClick={handleExcluir}
                  className="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors"
                >
                  Sim, Excluir
                </button>
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="px-4 py-2 bg-white border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CardParticipanteCompacto({ participante, agendamento }: { participante: any; agendamento: any }) {
  const fichaUuid = participante.ficha_uuid;

  const sessaoData = {
    id: agendamento.id,
    ficha_uuid: fichaUuid,
    participante_id: participante.id,
    participante_nome: participante.nome,
    funcao: participante.tipo_sessao || 'PF',
    instrutor_id: agendamento.instrutor_id || 0,
    template_id: agendamento.template_id || null
  };

  return (
    <div className="rounded-lg border border-gray-200 bg-gray-50 p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <h6 className="text-sm font-medium text-gray-900">{participante.nome}</h6>
          <span className="px-1.5 py-0.5 text-xs font-medium rounded bg-yellow-100 text-yellow-800">
            {participante.tipo_sessao || 'PC'}
          </span>
        </div>
      </div>

      {/* BOTÕES DE AÇÃO COMPACTOS */}
      <BotoesAcaoFichaFinal sessao={sessaoData} />
    </div>
  );
}

function FichasView() {
  const navigate = useNavigate();
  const [fichas, setFichas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtroStatus, setFiltroStatus] = useState<string>('TODOS');
  const [showModalAssinatura, setShowModalAssinatura] = useState(false);
  const [fichaParaAssinar, setFichaParaAssinar] = useState<any>(null);
  const [tipoAssinatura, setTipoAssinatura] = useState<'INSTRUTOR' | 'ALUNO'>('INSTRUTOR');

  useEffect(() => {
    carregarFichas();
  }, []);

  const carregarFichas = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/fichas`);
      const data = await response.json();
      if (data.success) {
        setFichas(data.data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar fichas:', error);
    } finally {
      setLoading(false);
    }
  };

  const fichasFiltradas = filtroStatus === 'TODOS' 
    ? fichas 
    : fichas.filter(f => f.status === filtroStatus);

  const contadores = {
    TODOS: fichas.length,
    RASCUNHO: fichas.filter(f => f.status === 'PENDENTE' || f.status === 'RASCUNHO').length,
    EM_AVALIACAO: fichas.filter(f => f.status === 'EM_AVALIACAO').length,
    APROVADA: fichas.filter(f => f.status === 'APROVADA').length,
    REPROVADA: fichas.filter(f => f.status === 'REPROVADA').length,
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Fichas de Sessão</h2>
        <p className="text-sm text-gray-500 mt-1">Acompanhe o status das fichas de sessão</p>
      </div>

      {/* Contadores */}
      <div className="mb-6 flex items-center gap-4 flex-wrap">
        <button
          onClick={() => setFiltroStatus('TODOS')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filtroStatus === 'TODOS'
              ? 'bg-gray-900 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {contadores.TODOS} TOTAL
        </button>
        <button
          onClick={() => setFiltroStatus('PENDENTE')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filtroStatus === 'PENDENTE'
              ? 'bg-yellow-600 text-white'
              : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
          }`}
        >
          {contadores.RASCUNHO} PENDENTE
        </button>
        <button
          onClick={() => setFiltroStatus('EM_AVALIACAO')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filtroStatus === 'EM_AVALIACAO'
              ? 'bg-blue-600 text-white'
              : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
          }`}
        >
          {contadores.EM_AVALIACAO} EM AVALIAÇÃO
        </button>
        <button
          onClick={() => setFiltroStatus('APROVADA')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filtroStatus === 'APROVADA'
              ? 'bg-green-600 text-white'
              : 'bg-green-100 text-green-800 hover:bg-green-200'
          }`}
        >
          {contadores.APROVADA} APROVADA
        </button>
        <button
          onClick={() => setFiltroStatus('REPROVADA')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filtroStatus === 'REPROVADA'
              ? 'bg-red-600 text-white'
              : 'bg-red-100 text-red-800 hover:bg-red-200'
          }`}
        >
          {contadores.REPROVADA} REPROVADA
        </button>
      </div>

      {/* Lista de Fichas */}
      <div className="space-y-4">
        {fichasFiltradas.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Nenhuma ficha encontrada</p>
          </div>
        ) : (
          fichasFiltradas.map((ficha) => (
            <div key={ficha.id} className="bg-white rounded-lg border border-gray-200 p-6">
              {/* Header da Ficha */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="text-base font-semibold text-gray-900">
                      Ficha #{ficha.id}
                    </h4>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      {ficha.status || 'RASCUNHO'}
                    </span>
                  </div>
                  
                  <div className="space-y-1 text-sm text-gray-600">
                    <div>
                      <span className="font-medium">{ficha.funcionario_nome}</span>
                      {ficha.matricula && ` (${ficha.matricula})`}
                    </div>
                    <div>
                      Simulador: {ficha.simulador_nome || 'N/A'}
                    </div>
                    <div>Status: {ficha.status || 'AGENDADO'}</div>
                    <div>
                      {ficha.data_inicio && new Date(ficha.data_inicio + 'T00:00:00').toLocaleDateString('pt-BR')}
                      {ficha.hora_inicio && ` às ${ficha.hora_inicio}`}
                    </div>
                    <div>Instrutor: {ficha.instrutor_nome}</div>
                  </div>
                </div>

                {/* Botões de Ação */}
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => {
                      navigate(`/simuladores/ficha/${ficha.uuid || ficha.id}`);
                    }}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Visualizar
                  </button>
                  <button
                    onClick={() => navigate(`/simuladores/ficha/${ficha.uuid || ficha.id}/avaliar`)}
                    className="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"
                  >
                    <ClipboardCheck className="w-4 h-4 mr-2" />
                    Avaliar
                  </button>
                  <button
                    onClick={() => {
                      setFichaParaAssinar(ficha);
                      setTipoAssinatura('INSTRUTOR');
                      setShowModalAssinatura(true);
                    }}
                    className={`inline-flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      ficha.assinatura_instrutor 
                        ? 'bg-gray-300 text-gray-600 cursor-not-allowed' 
                        : 'bg-purple-600 text-white hover:bg-purple-700'
                    }`}
                    disabled={ficha.assinatura_instrutor}
                  >
                    {ficha.assinatura_instrutor ? <CheckCircle className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
                    Assinar (Instrutor)
                  </button>
                  <button
                    onClick={() => {
                      setFichaParaAssinar(ficha);
                      setTipoAssinatura('ALUNO');
                      setShowModalAssinatura(true);
                    }}
                    className={`inline-flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      ficha.assinatura_tripulante 
                        ? 'bg-gray-300 text-gray-600 cursor-not-allowed' 
                        : 'bg-orange-600 text-white hover:bg-orange-700'
                    }`}
                    disabled={ficha.assinatura_tripulante}
                  >
                    {ficha.assinatura_tripulante ? <CheckCircle className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
                    Assinar (Tripulante)
                  </button>
                  <button
                    onClick={() => window.open(`/api/v2/fichas-pdf/${ficha.id}`, '_blank')}
                    className="inline-flex items-center px-3 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Gerar PDF
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal de Assinatura */}
      {showModalAssinatura && fichaParaAssinar && (
        <ModalAssinaturaCanvas
          isOpen={showModalAssinatura}
          onClose={() => {
            setShowModalAssinatura(false);
            setFichaParaAssinar(null);
          }}
          fichaUuid={fichaParaAssinar.uuid || fichaParaAssinar.id}
          tipoAssinatura={tipoAssinatura}
          nomeUsuario="Administrador"
          onAssinaturaConcluida={() => {
            carregarFichas();
            setShowModalAssinatura(false);
            setFichaParaAssinar(null);
          }}
        />
      )}
    </div>
  );
}

function CadastroView() {
  const navigate = useNavigate();
  const [subTab, setSubTab] = useState<'simuladores' | 'manobras' | 'templates' | 'categorias' | 'tipos'>('simuladores');
  const [simuladores, setSimuladores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (subTab === 'simuladores') {
      carregarSimuladores();
    }
  }, [subTab]);

  const carregarSimuladores = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/simuladores`);
      const data = await response.json();
      if (data.success) {
        setSimuladores(data.data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar simuladores:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este simulador?')) return;
    
    try {
      const response = await fetch(`${window.location.origin}/api/v2/simuladores/${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        carregarSimuladores();
      } else {
        alert('Erro: ' + (data.error || 'Erro desconhecido'));
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao excluir simulador: ' + error);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Gestão de Simuladores</h2>
        <p className="text-sm text-gray-500 mt-1">Configure simuladores, ciclos, manobras e modelos de sessão</p>
      </div>

      {/* Sub-Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <div className="flex space-x-8">
          <button
            onClick={() => setSubTab('simuladores')}
            className={`pb-3 px-1 border-b-2 text-sm font-medium transition-colors ${
              subTab === 'simuladores'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Simuladores
          </button>
          <button
            onClick={() => setSubTab('manobras')}
            className={`pb-3 px-1 border-b-2 text-sm font-medium transition-colors ${
              subTab === 'manobras'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Manobras
          </button>
          <button
            onClick={() => setSubTab('templates')}
            className={`pb-3 px-1 border-b-2 text-sm font-medium transition-colors ${
              subTab === 'templates'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Modelos de Sessão
          </button>
          <button
            onClick={() => setSubTab('categorias')}
            className={`pb-3 px-1 border-b-2 text-sm font-medium transition-colors ${
              subTab === 'categorias'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Categorias
          </button>
          <button
            onClick={() => setSubTab('tipos')}
            className={`pb-3 px-1 border-b-2 text-sm font-medium transition-colors ${
              subTab === 'tipos'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Tipos de Sessão
          </button>
        </div>
      </div>

      {/* Conteúdo das Sub-Tabs */}
      {subTab === 'simuladores' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Simuladores</h3>
            <button
              onClick={() => navigate('/simuladores/novo')}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Simulador
            </button>
          </div>
        
        {simuladores.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Nenhum simulador cadastrado</p>
          </div>
        ) : (
          simuladores.map((sim) => (
            <div key={sim.id} className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h4 className="text-lg font-semibold text-gray-900">
                      Simulador {sim.nome}
                    </h4>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      ATIVO
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Código:</span>
                      <span className="ml-2 text-gray-900 font-medium">{sim.codigo || sim.nome}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Tipo:</span>
                      <span className="ml-2 text-gray-900 font-medium">{sim.tipo || 'FFS'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Aeronave:</span>
                      <span className="ml-2 text-gray-900 font-medium">{sim.aeronave || 'A320'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Local:</span>
                      <span className="ml-2 text-gray-900 font-medium">{sim.localizacao || 'CAE'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigate(`/simuladores/${sim.id}/editar`)}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                    title="Editar"
                  >
                    <Edit className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleExcluir(sim.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
        </div>
      )}

      {subTab === 'manobras' && <ManobrasView />}
      {subTab === 'templates' && <TemplatesView />}
      {subTab === 'categorias' && <CategoriasView />}
      {subTab === 'tipos' && <TiposSessaoView />}
    </div>
  );
}

function ManobrasView() {
  const [manobras, setManobras] = useState<any[]>([]);
  const [categorias, setCategorias] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtroCategoria, setFiltroCategoria] = useState<string>('');
  const [showFormulario, setShowFormulario] = useState(false);
  const [manobraEditando, setManobraEditando] = useState<any>(null);
  const [showImportar, setShowImportar] = useState(false);

  useEffect(() => {
    carregarDados();
  }, [filtroCategoria]);

  const carregarDados = async () => {
    try {
      setLoading(true);
      
      try {
        const resCat = await fetch(`${window.location.origin}/api/v2/simuladores-consolidado/categorias`);
        if (resCat.ok) {
          const dataCat = await resCat.json();
          if (dataCat.success) {
            setCategorias(dataCat.data || []);
          }
        } else {
          console.warn('Erro ao carregar categorias, usando fallback vazio');
          setCategorias([]);
        }
      } catch (error) {
        console.error('Erro ao carregar categorias:', error);
        setCategorias([]); // Fallback vazio
      }
      
      try {
        const url = filtroCategoria 
          ? `${window.location.origin}/api/v2/manobras?categoria=${filtroCategoria}`
          : `${window.location.origin}/api/v2/manobras`;
        const resMan = await fetch(url);
        if (resMan.ok) {
          const dataMan = await resMan.json();
          if (dataMan.success) {
            setManobras(dataMan.data || []);
          }
        } else {
          console.warn('Erro ao carregar manobras, usando fallback vazio');
          setManobras([]);
        }
      } catch (error) {
        console.error('Erro ao carregar manobras:', error);
        setManobras([]); // Fallback vazio
      }
      
    } catch (error) {
      console.error('Erro geral ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir esta manobra?')) return;
    
    try {
      const response = await fetch(`${window.location.origin}/api/v2/manobras/${id}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        carregarDados();
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao excluir manobra');
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Manobras</h3>
          <p className="text-sm text-gray-500 mt-1">Catálogo de manobras do simulador</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowImportar(true)}
            className="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar Manobras
          </button>
          <button
            onClick={() => { setManobraEditando(null); setShowFormulario(true); }}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Manobra
          </button>
        </div>
      </div>

      {/* Filtro por Categoria */}
      <div className="mb-4">
        <select
          value={filtroCategoria}
          onChange={(e) => setFiltroCategoria(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
        >
          <option value="">Todas as categorias</option>
          {categorias.map((cat) => (
            <option key={cat.id} value={cat.id}>{cat.nome}</option>
          ))}
        </select>
      </div>

      {/* Lista de Manobras */}
      <div className="space-y-4">
        {manobras.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Nenhuma manobra encontrada</p>
          </div>
        ) : (
          manobras.map((man) => (
            <div key={man.id} className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="text-base font-semibold text-gray-900">{man.codigo}</h4>
                    <span 
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium text-white"
                      style={{ backgroundColor: man.categoria_cor || '#3B82F6' }}
                    >
                      {man.categoria || 'Sem categoria'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">{man.nome}</p>
                  {man.descricao && (
                    <p className="text-xs text-gray-500 mt-1">{man.descricao}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => { setManobraEditando(man); setShowFormulario(true); }}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleExcluir(man.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Formulário */}
      {showFormulario && (
        <FormularioManobra
          manobra={manobraEditando}
          onSalvar={() => { setShowFormulario(false); carregarDados(); }}
          onCancelar={() => setShowFormulario(false)}
        />
      )}

      {/* Modal Importar */}
      {showImportar && (
        <ImportarManobras
          onSucesso={() => { setShowImportar(false); carregarDados(); }}
          onCancelar={() => setShowImportar(false)}
        />
      )}
    </div>
  );
}

function TemplatesView() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFormulario, setShowFormulario] = useState(false);
  const navigate = useNavigate();
  const [templateEditando, setTemplateEditando] = useState<any>(null);
  const [showModalManobras, setShowModalManobras] = useState(false);
  const [templateConfigurar, setTemplateConfigurar] = useState<any>(null);

  useEffect(() => {
    carregarTemplates();
  }, []);

  const carregarTemplates = async () => {
    try {
      const response = await fetch(`${window.location.origin}/api/v2/simuladores/modelos`);
      const data = await response.json();
      if (data.success) {
        setTemplates(data.data || []);
      }
    } catch (error) {
      console.error('Erro ao carregar modelos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este modelo?')) return;
    
    try {
      const response = await fetch(`/api/v2/simuladores/modelos/${id}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        carregarTemplates();
      } else {
        alert('Erro: ' + (data.error || 'Erro desconhecido'));
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao excluir modelo');
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Modelos de Sessão</h3>
          <p className="text-sm text-gray-500 mt-1">Modelos de sessões de treinamento</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/simuladores/importar-relacoes')}
            className="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar Relações
          </button>
          <button
            onClick={() => { setTemplateEditando(null); setShowFormulario(true); }}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Modelo
          </button>
        </div>
      </div>

      {/* Lista de Modelos */}
      <div className="space-y-4">
        {templates.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Nenhum modelo encontrado</p>
          </div>
        ) : (
          templates.map((tpl) => (
            <div key={tpl.id} className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="text-base font-semibold text-gray-900 mb-1">{tpl.nome}</h4>
                  <p className="text-sm text-gray-600 mb-2">{tpl.descricao || 'Sem descrição'}</p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>{Math.round((tpl.duracao_minutos || 0) / 60 * 10) / 10}h de duração</span>
                    <span>•</span>
                    <span>{tpl.total_manobras || 0} manobras</span>
                    <span>•</span>
                    <span>Tipo: {tpl.tipo}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => { setTemplateConfigurar(tpl); setShowModalManobras(true); }}
                    className="p-2 text-gray-400 hover:text-green-600 transition-colors"
                    title="Configurar Manobras"
                  >
                    <ClipboardCheck className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { setTemplateEditando(tpl); setShowFormulario(true); }}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleExcluir(tpl.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Formulário */}
      {showFormulario && (
        <FormularioTemplate
          template={templateEditando}
          onSalvar={() => { setShowFormulario(false); carregarTemplates(); }}
          onCancelar={() => setShowFormulario(false)}
        />
      )}

      {/* Modal Configurar Manobras */}
      {showModalManobras && templateConfigurar && (
        <FormularioTemplate
          template={templateConfigurar}
          onSalvar={() => { setShowModalManobras(false); carregarTemplates(); }}
          onCancelar={() => setShowModalManobras(false)}
        />
      )}
    </div>
  );
}

function CategoriasView() {
  const [categorias, setCategorias] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFormulario, setShowFormulario] = useState(false);
  const [categoriaEditando, setCategoriaEditando] = useState<any>(null);

  useEffect(() => {
    carregarCategorias();
  }, []);

  const carregarCategorias = async () => {
    try {
      const response = await fetch('/api/v2/simuladores-consolidado/categorias');
      const data = await response.json();
      if (data.success) {
        setCategorias(data.data || []);
      }
    } catch (error) {
      console.error('Erro:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExcluir = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir esta categoria?')) return;
    
    try {
      const response = await fetch(`/api/v2/simuladores-consolidado/categorias/${id}`, {
        method: 'DELETE'
      });
      const data = await response.json();
      
      if (data.success) {
        alert('Categoria excluída!');
        carregarCategorias();
      } else {
        alert('Erro: ' + data.error);
      }
    } catch (error) {
      console.error('Erro:', error);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Categorias de Manobras</h3>
          <p className="text-sm text-gray-500 mt-1">Organize manobras por categorias</p>
        </div>
        <button
          onClick={() => { setCategoriaEditando(null); setShowFormulario(true); }}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Categoria
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categorias.map((cat) => (
          <div key={cat.id} className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div
                  className="w-4 h-4 rounded"
                  style={{ backgroundColor: cat.cor }}
                />
                <div>
                  <h4 className="text-sm font-semibold text-gray-900">{cat.nome}</h4>
                  <p className="text-xs text-gray-500">{cat.codigo}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => { setCategoriaEditando(cat); setShowFormulario(true); }}
                  className="p-1 text-gray-400 hover:text-blue-600"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleExcluir(cat.id)}
                  className="p-1 text-gray-400 hover:text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            {cat.descricao && (
              <p className="text-xs text-gray-600">{cat.descricao}</p>
            )}
          </div>
        ))}
      </div>

      {showFormulario && (
        <FormularioCategoria
          categoria={categoriaEditando}
          onSalvar={() => { setShowFormulario(false); carregarCategorias(); }}
          onCancelar={() => setShowFormulario(false)}
        />
      )}
    </div>
  );
}

function TiposSessaoView() {
  return (
    <div>
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Tipos de Sessão</h3>
        <p className="text-sm text-gray-500 mt-1">Gerencie os tipos de sessão disponíveis</p>
      </div>
      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
        <p className="text-gray-600">Tipos de sessão: INICIAL, RECORRENTE, CHECK</p>
        <p className="text-sm text-gray-500 mt-2">Funcionalidade em desenvolvimento</p>
      </div>
    </div>
  );
}

function formatarDataCompleta(dataISO: string): string {
  const data = new Date(dataISO + 'T00:00:00');
  const diasSemana = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  
  const diaSemana = diasSemana[data.getDay()];
  const dia = data.getDate();
  const mes = meses[data.getMonth()];
  const ano = data.getFullYear();
  
  return `${diaSemana}, ${dia} de ${mes} de ${ano}`;
}
