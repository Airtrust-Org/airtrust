import React from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Sessao {
  id: number;
  data: string;
  hora_inicio: string;
  hora_fim?: string;
  simulador_nome: string;
  instrutor_nome?: string;
  status: string;
}

export const AgendaMensal: React.FC = () => {
  const navigate = useNavigate();
  const [mesAtual, setMesAtual] = React.useState(new Date());
  const [sessoes, setSessoes] = React.useState<Sessao[]>([]);
  const [loading, setLoading] = React.useState(true);
  
  React.useEffect(() => {
    carregarSessoesMes();
  }, [mesAtual]);
  
  const carregarSessoesMes = async () => {
    setLoading(true);
    try {
      const inicio = new Date(mesAtual.getFullYear(), mesAtual.getMonth(), 1);
      const fim = new Date(mesAtual.getFullYear(), mesAtual.getMonth() + 1, 0);
      
      const response = await fetch(
        `/api/v2/sessoes?inicio=${inicio.toISOString().split('T')[0]}&fim=${fim.toISOString().split('T')[0]}`,
        { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }}
      );
      
      const data = await response.json();
      setSessoes(data.sessoes || []);
    } catch (error) {
      console.error('Erro:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const getDiasDoMes = () => {
    const ano = mesAtual.getFullYear();
    const mes = mesAtual.getMonth();
    const primeiroDia = new Date(ano, mes, 1).getDay();
    const ultimoDia = new Date(ano, mes + 1, 0).getDate();
    
    const dias = [];
    
    for (let i = 0; i < primeiroDia; i++) {
      dias.push(null);
    }
    
    for (let dia = 1; dia <= ultimoDia; dia++) {
      dias.push(dia);
    }
    
    return dias;
  };
  
  const getSessoesDoDia = (dia: number) => {
    return sessoes.filter(s => {
      const dataSessao = new Date(s.data);
      return dataSessao.getDate() === dia &&
             dataSessao.getMonth() === mesAtual.getMonth() &&
             dataSessao.getFullYear() === mesAtual.getFullYear();
    });
  };
  
  const mesAnterior = () => {
    setMesAtual(new Date(mesAtual.getFullYear(), mesAtual.getMonth() - 1, 1));
  };
  
  const mesSeguinte = () => {
    setMesAtual(new Date(mesAtual.getFullYear(), mesAtual.getMonth() + 1, 1));
  };
  
  const mesNome = mesAtual.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Calendar size={28} />
          Agenda de Simuladores
        </h1>
        <button
          onClick={() => navigate('/simuladores')}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Voltar
        </button>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={mesAnterior}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronLeft size={24} />
          </button>
          
          <h2 className="text-xl font-bold capitalize">{mesNome}</h2>
          
          <button
            onClick={mesSeguinte}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronRight size={24} />
          </button>
        </div>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <div className="grid grid-cols-7 gap-2">
            {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(dia => (
              <div key={dia} className="font-bold text-center p-3 bg-gray-100 rounded-lg">
                {dia}
              </div>
            ))}
            
            {getDiasDoMes().map((dia, idx) => {
              const sessoesDia = dia ? getSessoesDoDia(dia) : [];
              const isHoje = dia && 
                dia === new Date().getDate() &&
                mesAtual.getMonth() === new Date().getMonth() &&
                mesAtual.getFullYear() === new Date().getFullYear();
              
              return (
                <div
                  key={idx}
                  className={`border-2 rounded-lg p-2 min-h-[120px] ${
                    dia 
                      ? isHoje 
                        ? 'bg-blue-50 border-blue-300' 
                        : 'bg-white'
                      : 'bg-gray-50'
                  }`}
                >
                  {dia && (
                    <>
                      <div className={`font-bold mb-2 ${isHoje ? 'text-blue-600' : ''}`}>
                        {dia}
                      </div>
                      <div className="space-y-1">
                        {sessoesDia.map(sessao => (
                          <div
                            key={sessao.id}
                            onClick={() => navigate(`/simuladores/sessoes/${sessao.id}`)}
                            className="text-xs bg-blue-100 hover:bg-blue-200 p-2 rounded cursor-pointer transition-colors"
                          >
                            <div className="font-bold truncate">{sessao.hora_inicio}</div>
                            <div className="truncate text-gray-600">{sessao.simulador_nome}</div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}
        
        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-gray-600">
            {sessoes.length} sessão(ões) agendada(s) neste mês
          </div>
          <div className="flex gap-2">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-50 border-2 border-blue-300 rounded"></div>
              <span className="text-sm">Hoje</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-blue-100 rounded"></div>
              <span className="text-sm">Sessão agendada</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgendaMensal;
