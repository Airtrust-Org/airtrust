import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import ReordenarManobras from '../../components/modelos/ReordenarManobras';

interface Modelo {
  id: number;
  codigo: string;
  nome: string;
  descricao: string;
  duracao_minutos: number;
  tipo: string;
}

export default function EditarModeloSessao() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [modelo, setModelo] = useState<Modelo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      carregarModelo();
    }
  }, [id]);

  const carregarModelo = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const res = await fetch(
        `${window.location.origin}/api/v2/simuladores/modelos/${id}`
      );
      const data = await res.json();
      
      if (data.success) {
        setModelo(data.data);
      } else {
        setError(data.error || 'Erro ao carregar modelo');
      }
    } catch (err) {
      setError('Erro ao carregar modelo');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Carregando modelo...</p>
        </div>
      </div>
    );
  }

  if (error || !modelo) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h2 className="text-xl font-semibold text-red-800 mb-2">
              Erro ao carregar modelo
            </h2>
            <p className="text-red-700 mb-4">{error}</p>
            <button
              onClick={() => navigate('/simuladores')}
              className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <button
            onClick={() => navigate('/simuladores')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar para Simuladores
          </button>
          
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Editar Modelo de Sessão
            </h1>
            <p className="text-gray-600 mt-1">
              {modelo.codigo} - {modelo.nome}
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Informações do Modelo */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Informações do Modelo
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700">Código</label>
              <p className="mt-1 text-gray-900">{modelo.codigo}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Tipo</label>
              <p className="mt-1 text-gray-900">{modelo.tipo || 'N/A'}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Duração</label>
              <p className="mt-1 text-gray-900">{modelo.duracao_minutos} minutos</p>
            </div>
          </div>
          
          {modelo.descricao && (
            <div className="mt-4">
              <label className="text-sm font-medium text-gray-700">Descrição</label>
              <p className="mt-1 text-gray-600">{modelo.descricao}</p>
            </div>
          )}
        </div>

        {/* Componente de Reordenamento */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <ReordenarManobras
            modeloId={Number(id)}
            modeloNome={`${modelo.codigo} - ${modelo.nome}`}
          />
        </div>
      </div>
    </div>
  );
}
