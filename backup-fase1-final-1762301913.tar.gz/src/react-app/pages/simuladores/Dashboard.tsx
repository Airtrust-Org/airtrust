import { useState, useEffect } from 'react';
import { Monitor, Clock, TrendingUp, Calendar } from 'lucide-react';

export default function SimuladoresDashboard() {
  const [stats, setStats] = useState({
    total_simuladores: 0,
    sessoes_mes: 0,
    taxa_utilizacao: 0,
    horas_voadas: 0
  });
  const [proximasSessoes, setProximasSessoes] = useState([]);
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      const [simResp, sessoesResp] = await Promise.all([
        fetch(`${API_BASE_URL}/api/v2/simuladores`),
        fetch(`${API_BASE_URL}/api/v2/simuladores/sessoes?limit=5&status=agendada`)
      ]);

      const simData = await simResp.json();
      const sessoesData = await sessoesResp.json();

      setStats({
        total_simuladores: simData.total || 0,
        sessoes_mes: 45, // Mock
        taxa_utilizacao: 82,
        horas_voadas: 120
      });

      setProximasSessoes(sessoesData.sessoes || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-7xl mx-auto px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Simuladores</h1>
          <p className="text-gray-600 mt-1">Visão geral do sistema de simuladores</p>
        </div>

        {/* Cards Métricas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Total Simuladores</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stats.total_simuladores}</p>
                <p className="text-xs text-gray-500 mt-1">Operacionais</p>
              </div>
              <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center">
                <Monitor className="w-7 h-7 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Sessões Mês Atual</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stats.sessoes_mes}</p>
                <p className="text-xs text-gray-500 mt-1">Outubro 2025</p>
              </div>
              <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-7 h-7 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Taxa Utilização</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stats.taxa_utilizacao}%</p>
                <p className="text-xs text-gray-500 mt-1">Média mensal</p>
              </div>
              <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-7 h-7 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 font-medium">Horas Voadas</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{stats.horas_voadas}h</p>
                <p className="text-xs text-gray-500 mt-1">Este mês</p>
              </div>
              <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center">
                <Clock className="w-7 h-7 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Próximas Sessões */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Próximas 5 Sessões Agendadas</h2>
          
          {proximasSessoes.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>Nenhuma sessão agendada</p>
            </div>
          ) : (
            <div className="space-y-4">
              {proximasSessoes.map((sessao: any) => (
                <div
                  key={sessao.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Monitor className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{sessao.simulador_nome}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(sessao.data + 'T00:00:00').toLocaleDateString('pt-BR')} • {sessao.hora_inicio} - {sessao.hora_fim}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">Instrutor: {sessao.instrutor_nome}</p>
                    <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 mt-1">
                      {sessao.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
