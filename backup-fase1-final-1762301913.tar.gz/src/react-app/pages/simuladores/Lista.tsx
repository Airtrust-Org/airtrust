import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Calendar, Edit, Trash2, Search } from 'lucide-react';

export default function SimuladoresLista() {
  const navigate = useNavigate();
  const [simuladores, setSimuladores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('todos');

  const API_BASE_URL = window.location.origin;

  useEffect(() => {
    carregarSimuladores();
  }, []);

  const handleExcluir = async (id: number) => {
    const simulador = simuladores.find((s: any) => s.id === id);
    if (!confirm(`Tem certeza que deseja excluir o simulador "${simulador?.nome}"?`)) {
      return;
    }

    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/simuladores/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        carregarSimuladores();
      } else {
        alert('Erro ao excluir simulador');
      }
    } catch (error) {
      console.error('Erro ao excluir:', error);
      alert('Erro ao excluir simulador');
    }
  };

  const carregarSimuladores = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/simuladores`);
      const data = await response.json();
      setSimuladores(data.simuladores || []);
    } catch (error) {
      console.error('Erro ao carregar simuladores:', error);
    } finally {
      setLoading(false);
    }
  };

  const simuladoresFiltrados = simuladores.filter((sim: any) => {
    const matchSearch = sim.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       sim.modelo?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = filtroStatus === 'todos' || sim.status === filtroStatus;
    return matchSearch && matchStatus;
  });

  const getStatusBadge = (status: string) => {
    const badges = {
      operacional: 'bg-green-100 text-green-800',
      manutencao: 'bg-yellow-100 text-yellow-800',
      inativo: 'bg-gray-100 text-gray-800'
    };
    return badges[status as keyof typeof badges] || badges.inativo;
  };

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-7xl mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Simuladores</h1>
            <p className="text-gray-600 mt-1">Gerenciar simuladores e equipamentos</p>
          </div>
          <button 
            onClick={() => navigate('/simuladores/novo')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Novo Simulador
          </button>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Buscar por nome ou modelo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <select
              value={filtroStatus}
              onChange={(e) => setFiltroStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="todos">Todos os Status</option>
              <option value="operacional">Operacional</option>
              <option value="manutencao">Manutenção</option>
              <option value="inativo">Inativo</option>
            </select>

            <button
              onClick={() => { setSearchTerm(''); setFiltroStatus('todos'); }}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Limpar Filtros
            </button>
          </div>
        </div>

        {/* Tabela */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-2 py-3 text-left text-xs font-semibold text-gray-700 uppercase w-32">Ações</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Nome</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Modelo/Tipo</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Fabricante</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Localização</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Capacidade</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {simuladoresFiltrados.map((sim: any) => (
                    <tr key={sim.id} className="hover:bg-gray-50">
                      <td className="px-2 py-3">
                        <div className="flex items-center gap-1">
                          <button
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Ver Agenda"
                          >
                            <Calendar className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => navigate(`/simuladores/${sim.id}/agendar`)}
                            className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                            title="Novo Agendamento"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => navigate(`/simuladores/${sim.id}/editar`)}
                            className="p-1.5 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                            title="Editar"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleExcluir(sim.id)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{sim.nome}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {sim.modelo} • {sim.tipo}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{sim.fabricante || '-'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{sim.localizacao || '-'}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{sim.capacidade} alunos</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(sim.status)}`}>
                          {sim.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {simuladoresFiltrados.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <p>Nenhum simulador encontrado</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
