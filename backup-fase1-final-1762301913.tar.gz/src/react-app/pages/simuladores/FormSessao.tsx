import { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function FormSessao({ isOpen, onClose, onSuccess }: Props) {
  const [simuladores, setSimuladores] = useState([]);
  const [instrutores, setInstrutores] = useState([]);
  const [alunos, setAlunos] = useState([]);
  const [manobras, setManobras] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    simulador_id: '',
    data: '',
    hora_inicio: '',
    hora_fim: '',
    instrutor_id: '',
    aluno_ids: [] as string[],
    aeronave_simulada: '',
    manobras_planejadas: [] as string[],
    objetivos: ''
  });

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  useEffect(() => {
    if (isOpen) {
      carregarDados();
    }
  }, [isOpen]);

  const carregarDados = async () => {
    try {
      const [simResp, funcResp, manResp] = await Promise.all([
        fetch(`${API_BASE_URL}/api/v2/simuladores`),
        fetch(`${API_BASE_URL}/api/v2/funcionarios`),
        fetch(`${API_BASE_URL}/api/v2/simuladores/manobras`)
      ]);

      const simData = await simResp.json();
      const funcData = await funcResp.json();
      const manData = await manResp.json();

      setSimuladores(simData.simuladores || []);
      setInstrutores(funcData.data?.filter((f: any) => f.is_instrutor) || []);
      setAlunos(funcData.data || []);
      setManobras(manData.manobras || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/simuladores/sessoes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (data.success) {
        onSuccess?.();
        onClose();
      } else {
        alert(`Erro: ${data.error}`);
      }
    } catch (error) {
      console.error('Erro ao agendar sessão:', error);
      alert('Erro ao agendar sessão');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Agendar Nova Sessão</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Simulador */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Simulador *
              </label>
              <select
                required
                value={formData.simulador_id}
                onChange={(e) => setFormData({ ...formData, simulador_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Selecione...</option>
                {simuladores.map((sim: any) => (
                  <option key={sim.id} value={sim.id}>
                    {sim.nome} - {sim.modelo}
                  </option>
                ))}
              </select>
            </div>

            {/* Data */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data *
              </label>
              <input
                type="date"
                required
                value={formData.data}
                onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Hora Início */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hora Início *
              </label>
              <input
                type="time"
                required
                value={formData.hora_inicio}
                onChange={(e) => setFormData({ ...formData, hora_inicio: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Hora Fim */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hora Fim *
              </label>
              <input
                type="time"
                required
                value={formData.hora_fim}
                onChange={(e) => setFormData({ ...formData, hora_fim: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Instrutor */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Instrutor *
              </label>
              <select
                required
                value={formData.instrutor_id}
                onChange={(e) => setFormData({ ...formData, instrutor_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Selecione...</option>
                {instrutores.map((inst: any) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.nome} - {inst.matricula}
                  </option>
                ))}
              </select>
            </div>

            {/* Aeronave Simulada */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Aeronave Simulada
              </label>
              <input
                type="text"
                value={formData.aeronave_simulada}
                onChange={(e) => setFormData({ ...formData, aeronave_simulada: e.target.value })}
                placeholder="Ex: EC135, Bell 407"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          {/* Alunos */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Alunos
            </label>
            <select
              multiple
              value={formData.aluno_ids}
              onChange={(e) => {
                const selected = Array.from(e.target.selectedOptions, option => option.value);
                setFormData({ ...formData, aluno_ids: selected });
              }}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-32"
            >
              {alunos.map((aluno: any) => (
                <option key={aluno.id} value={aluno.id}>
                  {aluno.nome} - {aluno.matricula}
                </option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1">Segure Ctrl/Cmd para selecionar múltiplos</p>
          </div>

          {/* Manobras Planejadas */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Manobras Planejadas
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-48 overflow-y-auto p-4 border border-gray-300 rounded-lg">
              {manobras.map((man: any) => (
                <label key={man.id} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.manobras_planejadas.includes(man.id.toString())}
                    onChange={(e) => {
                      const id = man.id.toString();
                      setFormData({
                        ...formData,
                        manobras_planejadas: e.target.checked
                          ? [...formData.manobras_planejadas, id]
                          : formData.manobras_planejadas.filter(m => m !== id)
                      });
                    }}
                    className="w-4 h-4 text-blue-600 rounded"
                  />
                  <span className="text-sm text-gray-700">{man.nome}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Objetivos */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Objetivos da Sessão
            </label>
            <textarea
              value={formData.objetivos}
              onChange={(e) => setFormData({ ...formData, objetivos: e.target.value })}
              rows={4}
              placeholder="Descreva os objetivos desta sessão de treinamento..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50">
          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-100 transition-colors disabled:opacity-50"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Agendando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Agendar Sessão
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
