import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export default function AprovarSessao() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [sessao, setSessao] = useState<any>(null);
  const [manobras, setManobras] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processando, setProcessando] = useState(false);
  const [motivo, setMotivo] = useState('');
  const [observacoes, setObservacoes] = useState('');

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  useEffect(() => {
    carregarDados();
  }, [id]);

  const carregarDados = async () => {
    try {
      const [sessaoResp, manobrasResp] = await Promise.all([
        fetch(`${API_BASE_URL}/api/v2/simuladores/sessoes/${id}`),
        fetch(`${API_BASE_URL}/api/v2/simuladores/sessoes/${id}/manobras`)
      ]);

      const sessaoData = await sessaoResp.json();
      const manobrasData = await manobrasResp.json();

      if (sessaoData.success) {
        setSessao(sessaoData.sessao);
      }

      if (manobrasData.success) {
        setManobras(manobrasData.manobras || []);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const aprovar = async () => {
    if (!confirm('Confirma a aprovação desta sessão?')) return;

    setProcessando(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/v2/simuladores/sessoes/${id}/aprovar`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ observacoes })
        }
      );

      const data = await response.json();
      if (data.success) {
        navigate(`/simuladores/sessoes/${id}`);
      } else {
        alert(`Erro: ${data.error}`);
      }
    } catch (error) {
      console.error('Erro ao aprovar:', error);
      alert('Erro ao aprovar sessão');
    } finally {
      setProcessando(false);
    }
  };

  const reprovar = async () => {
    if (!motivo.trim()) {
      alert('Por favor, informe o motivo da reprovação');
      return;
    }

    if (!confirm('Confirma a reprovação desta sessão?')) return;

    setProcessando(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/v2/simuladores/sessoes/${id}/reprovar`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ motivo, observacoes })
        }
      );

      const data = await response.json();
      if (data.success) {
        alert('❌ Sessão reprovada');
        navigate(`/simuladores/sessoes/${id}`);
      } else {
        alert(`Erro: ${data.error}`);
      }
    } catch (error) {
      console.error('Erro ao reprovar:', error);
      alert('Erro ao reprovar sessão');
    } finally {
      setProcessando(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const executadas = manobras.filter(m => m.executada).length;
  const satisfatorias = manobras.filter(m => m.avaliacao === 'satisfatorio').length;
  const percentualSatisfatorio = executadas > 0 ? (satisfatorias / executadas) * 100 : 0;
  const podeAprovar = percentualSatisfatorio >= 80;

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-4xl mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Avaliação Final da Sessão</h1>
          <p className="text-gray-600">{sessao?.simulador_nome} • {new Date(sessao?.data).toLocaleDateString('pt-BR')}</p>
        </div>

        {/* Resumo */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Resumo da Sessão</h2>
          
          <div className="grid grid-cols-3 gap-6 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Total Manobras</p>
              <p className="text-3xl font-bold text-blue-600">{manobras.length}</p>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Executadas</p>
              <p className="text-3xl font-bold text-purple-600">{executadas}</p>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Satisfatórias</p>
              <p className="text-3xl font-bold text-green-600">{satisfatorias}</p>
            </div>
          </div>

          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Taxa de Aproveitamento</span>
              <span className="text-2xl font-bold text-gray-900">{percentualSatisfatorio.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all ${
                  percentualSatisfatorio >= 80 ? 'bg-green-600' : 'bg-red-600'
                }`}
                style={{ width: `${percentualSatisfatorio}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-2">Mínimo necessário: 80%</p>
          </div>
        </div>

        {/* Alerta */}
        {!podeAprovar && (
          <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-4 mb-6 flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-yellow-900">Atenção!</p>
              <p className="text-sm text-yellow-800 mt-1">
                A taxa de aproveitamento está abaixo de 80%. Recomenda-se reprovar a sessão ou revisar as avaliações.
              </p>
            </div>
          </div>
        )}

        {/* Manobras Detalhadas */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Manobras Avaliadas</h2>
          
          <div className="space-y-3">
            {manobras.filter(m => m.executada).map((manobra: any) => (
              <div
                key={manobra.manobra_id}
                className={`p-3 rounded-lg border-l-4 ${
                  manobra.avaliacao === 'satisfatorio'
                    ? 'bg-green-50 border-green-500'
                    : 'bg-red-50 border-red-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-900">{manobra.nome}</p>
                    {manobra.observacoes && (
                      <p className="text-sm text-gray-600 mt-1">{manobra.observacoes}</p>
                    )}
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    manobra.avaliacao === 'satisfatorio'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {manobra.avaliacao}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Formulário Aprovação/Reprovação */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Decisão Final</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Observações Gerais
              </label>
              <textarea
                value={observacoes}
                onChange={(e) => setObservacoes(e.target.value)}
                rows={3}
                placeholder="Comentários sobre o desempenho geral do aluno..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Motivo da Reprovação (se aplicável)
              </label>
              <textarea
                value={motivo}
                onChange={(e) => setMotivo(e.target.value)}
                rows={3}
                placeholder="Descreva os motivos caso vá reprovar..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              />
            </div>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={reprovar}
            disabled={processando}
            className="flex items-center gap-2 px-8 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <XCircle className="w-5 h-5" />
            {processando ? 'Processando...' : 'Reprovar Sessão'}
          </button>

          <button
            onClick={aprovar}
            disabled={processando || !podeAprovar}
            className="flex items-center gap-2 px-8 py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <CheckCircle className="w-5 h-5" />
            {processando ? 'Processando...' : 'Aprovar Sessão'}
          </button>
        </div>

        {!podeAprovar && (
          <p className="text-center text-sm text-gray-500 mt-4">
            * Aprovação desabilitada: taxa de aproveitamento abaixo de 80%
          </p>
        )}
      </div>
    </div>
  );
}
