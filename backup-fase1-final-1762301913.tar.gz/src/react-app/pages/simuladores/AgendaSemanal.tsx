import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';

export default function AgendaSemanal() {
  const [simuladorSelecionado, setSimuladorSelecionado] = useState('');
  const [simuladores, setSimuladores] = useState([]);
  const [semanaAtual, setSemanaAtual] = useState(new Date());
  const [sessoes, setSessoes] = useState<any[]>([]);

  const API_BASE_URL = import.meta.env.VITE_API_URL || window.location.origin;

  const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const horarios = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);

  useEffect(() => {
    carregarSimuladores();
  }, []);

  useEffect(() => {
    if (simuladorSelecionado) {
      carregarSessoes();
    }
  }, [simuladorSelecionado, semanaAtual]);

  const carregarSimuladores = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/simuladores`);
      const data = await response.json();
      setSimuladores(data.simuladores || []);
      if (data.simuladores?.length > 0) {
        setSimuladorSelecionado(data.simuladores[0].id);
      }
    } catch (error) {
      console.error('Erro ao carregar simuladores:', error);
    }
  };

  const carregarSessoes = async () => {
    try {
      const primeiroDia = getInicioSemana(semanaAtual);
      const ultimoDia = new Date(primeiroDia);
      ultimoDia.setDate(ultimoDia.getDate() + 6);

      const response = await fetch(
        `${API_BASE_URL}/api/v2/simuladores/sessoes?simulador_id=${simuladorSelecionado}`
      );
      const data = await response.json();
      
      const sessoesSemana = (data.sessoes || []).filter((s: any) => {
        const dataSessao = new Date(s.data);
        return dataSessao >= primeiroDia && dataSessao <= ultimoDia;
      });
      
      setSessoes(sessoesSemana);
    } catch (error) {
      console.error('Erro ao carregar sessões:', error);
    }
  };

  const getInicioSemana = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const getDiasSemana = () => {
    const inicio = getInicioSemana(semanaAtual);
    return Array.from({ length: 7 }, (_, i) => {
      const dia = new Date(inicio);
      dia.setDate(inicio.getDate() + i);
      return dia;
    });
  };

  const getSessoesDia = (dia: Date, hora: string) => {
    return sessoes.filter((s: any) => {
      const dataSessao = new Date(s.data);
      return (
        dataSessao.toDateString() === dia.toDateString() &&
        s.hora_inicio <= hora &&
        s.hora_fim > hora
      );
    });
  };

  const getCorStatus = (status: string) => {
    const cores = {
      agendada: 'bg-blue-100 border-blue-300 text-blue-800',
      em_progresso: 'bg-yellow-100 border-yellow-300 text-yellow-800',
      concluida: 'bg-green-100 border-green-300 text-green-800',
      cancelada: 'bg-red-100 border-red-300 text-red-800'
    };
    return cores[status as keyof typeof cores] || cores.agendada;
  };

  const navegarSemana = (direcao: number) => {
    const nova = new Date(semanaAtual);
    nova.setDate(nova.getDate() + (direcao * 7));
    setSemanaAtual(nova);
  };

  const irParaHoje = () => {
    setSemanaAtual(new Date());
  };

  const dias = getDiasSemana();

  return (
    <div className="flex-1 bg-gray-50">
      <div className="max-w-full mx-auto px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Agenda Semanal</h1>
          <p className="text-gray-600 mt-1">Visualização de sessões agendadas</p>
        </div>

        {/* Controles */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            {/* Select Simulador */}
            <select
              value={simuladorSelecionado}
              onChange={(e) => setSimuladorSelecionado(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {simuladores.map((sim: any) => (
                <option key={sim.id} value={sim.id}>
                  {sim.nome} - {sim.modelo}
                </option>
              ))}
            </select>

            {/* Navegação Semana */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => navegarSemana(-1)}
                className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <button
                onClick={irParaHoje}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Hoje
              </button>
              
              <button
                onClick={() => navegarSemana(1)}
                className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Período */}
            <div className="text-sm font-medium text-gray-700">
              {dias[0].toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })} - {dias[6].toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
            </div>
          </div>
        </div>

        {/* Calendário */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <div className="min-w-[1200px]">
              {/* Header Dias */}
              <div className="grid grid-cols-8 border-b border-gray-200 bg-gray-50">
                <div className="p-4 text-sm font-semibold text-gray-700">Horário</div>
                {dias.map((dia, idx) => (
                  <div key={idx} className="p-4 text-center border-l border-gray-200">
                    <div className="text-sm font-semibold text-gray-700">{diasSemana[dia.getDay()]}</div>
                    <div className={`text-lg font-bold mt-1 ${
                      dia.toDateString() === new Date().toDateString()
                        ? 'text-blue-600'
                        : 'text-gray-900'
                    }`}>
                      {dia.getDate()}
                    </div>
                  </div>
                ))}
              </div>

              {/* Grid Horários */}
              <div className="divide-y divide-gray-200">
                {horarios.map((hora) => (
                  <div key={hora} className="grid grid-cols-8 hover:bg-gray-50">
                    <div className="p-2 text-xs text-gray-600 font-medium border-r border-gray-200">
                      {hora}
                    </div>
                    {dias.map((dia, idx) => {
                      const sessoesCelula = getSessoesDia(dia, hora);
                      return (
                        <div
                          key={idx}
                          className="p-1 border-l border-gray-200 min-h-[60px] relative group"
                        >
                          {sessoesCelula.map((sessao: any) => (
                            <div
                              key={sessao.id}
                              className={`p-2 rounded border-l-4 text-xs mb-1 cursor-pointer hover:shadow-md transition-shadow ${getCorStatus(sessao.status)}`}
                              title={`${sessao.hora_inicio} - ${sessao.hora_fim}\nInstrutor: ${sessao.instrutor_nome}`}
                            >
                              <div className="font-semibold truncate">{sessao.hora_inicio}</div>
                              <div className="truncate">{sessao.instrutor_nome}</div>
                            </div>
                          ))}
                          
                          {/* Botão + ao hover */}
                          {sessoesCelula.length === 0 && (
                            <button className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700">
                                <Plus className="w-5 h-5" />
                              </div>
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Legenda */}
        <div className="mt-4 flex items-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-100 border-2 border-blue-300 rounded"></div>
            <span className="text-gray-700">Agendada</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-100 border-2 border-yellow-300 rounded"></div>
            <span className="text-gray-700">Em Progresso</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-100 border-2 border-green-300 rounded"></div>
            <span className="text-gray-700">Concluída</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-100 border-2 border-red-300 rounded"></div>
            <span className="text-gray-700">Cancelada</span>
          </div>
        </div>
      </div>
    </div>
  );
}
