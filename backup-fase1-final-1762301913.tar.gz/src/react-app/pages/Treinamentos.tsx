import { useState, useEffect } from 'react';
import { Plus, Upload, Search } from 'lucide-react';
import { PageLayout, PageSection } from '@/react-app/components/layout/PageLayout';
import { classHelpers } from '@/react-app/styles/design-tokens';
import Button from '@/react-app/components/Button';
import ImportarCSVModal from '../components/ImportarCSVModal';
import { API_BASE_URL } from '../config/api';

interface Treinamento {
  id: string;
  codigo: string;
  nome: string;
  categoria: string;
  periodicidade: string;
}

export default function Treinamentos() {
  const [treinamentos, setTreinamentos] = useState<Treinamento[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showImportModal, setShowImportModal] = useState(false);
  const [showNovoModal, setShowNovoModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [treinamentoEdit, setTreinamentoEdit] = useState<Treinamento | null>(null);
  const [novoTreinamento, setNovoTreinamento] = useState({
    codigo: '',
    nome: '',
    categoria: '',
    periodicidade: '',
  });

  useEffect(() => {
    fetchTreinamentos();
  }, []);

  const fetchTreinamentos = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/treinamentos`);
      const result = await response.json();
      if (result.success) {
        setTreinamentos(result.data);
      }
    } catch (error) {
      console.error('Erro ao buscar treinamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredTreinamentos = treinamentos.filter(
    (t) =>
      t.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.nome.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const handleDeleteTreinamento = async (id: string, nome: string) => {
    if (confirm(`Deseja realmente excluir o treinamento "${nome}"?`)) {
      try {
        const response = await fetch(`${API_BASE_URL}/api/v2/treinamentos/${id}`, {
          method: 'DELETE',
        });
        const result = await response.json();
        if (result.success) {
          fetchTreinamentos();
        } else {
          alert('Erro ao excluir: ' + (result.error || 'Erro desconhecido'));
        }
      } catch (error) {
        alert('Erro ao excluir: ' + (error as Error).message);
      }
    }
  };

  const handleSaveEdit = async () => {
    if (!treinamentoEdit) return;
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/treinamentos/${treinamentoEdit.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(treinamentoEdit),
      });
      const result = await response.json();
      if (result.success) {
        setShowEditModal(false);
        setTreinamentoEdit(null);
        fetchTreinamentos();
      } else {
        alert('Erro ao atualizar: ' + (result.error || 'Erro desconhecido'));
      }
    } catch (error) {
      alert('Erro ao atualizar: ' + (error as Error).message);
    }
  };

  const handleCreateNew = async () => {
    if (
      !novoTreinamento.codigo ||
      !novoTreinamento.nome ||
      !novoTreinamento.categoria ||
      !novoTreinamento.periodicidade
    ) {
      alert('Preencha todos os campos');
      return;
    }
    try {
      const response = await fetch(`${API_BASE_URL}/api/v2/treinamentos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(novoTreinamento),
      });
      const result = await response.json();
      if (result.success) {
        setShowNovoModal(false);
        setNovoTreinamento({ codigo: '', nome: '', categoria: '', periodicidade: '' });
        fetchTreinamentos();
      } else {
        alert('Erro ao criar: ' + (result.error || 'Erro desconhecido'));
      }
    } catch (error) {
      alert('Erro ao criar: ' + (error as Error).message);
    }
  };

  if (loading) {
    return (
      <PageLayout title="Treinamentos">
        <PageSection>
          <div className={`${classHelpers.centerContent} py-12`}>Carregando...</div>
        </PageSection>
      </PageLayout>
    );
  }

  return (
    <PageLayout
      title="Treinamentos"
      subtitle="Gerencie o catálogo de treinamentos"
      action={
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setShowImportModal(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button variant="primary" onClick={() => setShowNovoModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Novo Treinamento
          </Button>
        </div>
      }
    >
      <PageSection>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div className="flex-1 max-w-md w-full">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Buscar treinamentos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200">
            <thead className="bg-neutral-50">
              <tr>
                <th className="px-2 py-3 text-left text-xs font-medium text-neutral-600 uppercase w-32">
                  Ações
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-600 uppercase">
                  Código
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-600 uppercase">
                  Nome
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-600 uppercase">
                  Categoria
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-neutral-600 uppercase">
                  Periodicidade
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {filteredTreinamentos.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-4 text-center text-neutral-500">
                    Nenhum treinamento encontrado
                  </td>
                </tr>
              ) : (
                filteredTreinamentos.map((treinamento) => (
                  <tr key={treinamento.id} className="hover:bg-neutral-50">
                    <td className="px-2 py-3 whitespace-nowrap text-sm text-neutral-600">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setTreinamentoEdit(treinamento);
                            setShowEditModal(true);
                          }}
                        >
                          Editar
                        </Button>
                        <span className="text-neutral-300">|</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteTreinamento(treinamento.id, treinamento.nome)}
                        >
                          Excluir
                        </Button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-900">
                      {treinamento.codigo}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-900">
                      {treinamento.nome}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                      {treinamento.categoria}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                      {treinamento.periodicidade}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </PageSection>

      <ImportarCSVModal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        onSuccess={() => {
          fetchTreinamentos();
          setShowImportModal(false);
        }}
        endpoint="/api/v2/treinamentos/import"
        templateEndpoint="/api/v2/treinamentos/template"
        title="Importar Treinamentos"
      />

      {/* Modal Editar Treinamento */}
      {showEditModal && treinamentoEdit && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md border border-neutral-200 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-neutral-900">Editar Treinamento</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Código</label>
                <input
                  type="text"
                  value={treinamentoEdit.codigo}
                  onChange={(e) =>
                    setTreinamentoEdit({ ...treinamentoEdit, codigo: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Nome</label>
                <input
                  type="text"
                  value={treinamentoEdit.nome}
                  onChange={(e) => setTreinamentoEdit({ ...treinamentoEdit, nome: e.target.value })}
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Categoria</label>
                <select
                  value={treinamentoEdit.categoria}
                  onChange={(e) =>
                    setTreinamentoEdit({ ...treinamentoEdit, categoria: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione...</option>
                  <option value="OPERACIONAL">Operacional</option>
                  <option value="SEGURANCA">Segurança</option>
                  <option value="TECNICO">Técnico</option>
                  <option value="REGULATORIO">Regulatório</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">
                  Periodicidade
                </label>
                <select
                  value={treinamentoEdit.periodicidade}
                  onChange={(e) =>
                    setTreinamentoEdit({ ...treinamentoEdit, periodicidade: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione...</option>
                  <option value="ANUAL">Anual</option>
                  <option value="SEMESTRAL">Semestral</option>
                  <option value="TRIMESTRAL">Trimestral</option>
                  <option value="MENSAL">Mensal</option>
                  <option value="UNICO">Único</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setTreinamentoEdit(null);
                }}
                className="px-4 py-2 text-neutral-700 bg-neutral-100 rounded-lg hover:bg-neutral-200"
              >
                Cancelar
              </button>
              <Button variant="primary" onClick={handleSaveEdit}>
                Salvar Alterações
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Novo Treinamento */}
      {showNovoModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md border border-neutral-200 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-neutral-900">Novo Treinamento</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Código</label>
                <input
                  type="text"
                  value={novoTreinamento.codigo}
                  onChange={(e) =>
                    setNovoTreinamento({ ...novoTreinamento, codigo: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Ex: TRN-001"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Nome</label>
                <input
                  type="text"
                  value={novoTreinamento.nome}
                  onChange={(e) => setNovoTreinamento({ ...novoTreinamento, nome: e.target.value })}
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Ex: CRM - Crew Resource Management"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Categoria</label>
                <select
                  value={novoTreinamento.categoria}
                  onChange={(e) =>
                    setNovoTreinamento({ ...novoTreinamento, categoria: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione...</option>
                  <option value="OPERACIONAL">Operacional</option>
                  <option value="SEGURANCA">Segurança</option>
                  <option value="TECNICO">Técnico</option>
                  <option value="REGULATORIO">Regulatório</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">
                  Periodicidade
                </label>
                <select
                  value={novoTreinamento.periodicidade}
                  onChange={(e) =>
                    setNovoTreinamento({ ...novoTreinamento, periodicidade: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Selecione...</option>
                  <option value="ANUAL">Anual</option>
                  <option value="SEMESTRAL">Semestral</option>
                  <option value="TRIMESTRAL">Trimestral</option>
                  <option value="MENSAL">Mensal</option>
                  <option value="UNICO">Único</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => {
                  setShowNovoModal(false);
                  setNovoTreinamento({ codigo: '', nome: '', categoria: '', periodicidade: '' });
                }}
                className="px-4 py-2 text-neutral-700 bg-neutral-100 rounded-lg hover:bg-neutral-200"
              >
                Cancelar
              </button>
              <Button
                variant="primary"
                disabled={
                  !novoTreinamento.codigo ||
                  !novoTreinamento.nome ||
                  !novoTreinamento.categoria ||
                  !novoTreinamento.periodicidade
                }
                onClick={handleCreateNew}
              >
                Criar Treinamento
              </Button>
            </div>
          </div>
        </div>
      )}
    </PageLayout>
  );
}
