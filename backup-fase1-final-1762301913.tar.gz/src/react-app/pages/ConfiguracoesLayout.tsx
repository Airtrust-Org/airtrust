import { Routes, Route, Navigate } from 'react-router';
import { lazy } from 'react';
import MasterDetailLayout from '../components/layouts/MasterDetailLayout';
import AeronavesCRUD from './Aeronaves';

const ConfiguracoesFuncoes = lazy(() => import('./ConfiguracoesFuncoes'));
const ConfiguracaoEmpresa = lazy(() => import('./ConfiguracaoEmpresa'));
const ConfiguracaoCertificado = lazy(() => import('./ConfiguracaoCertificado'));
const LimparDados = lazy(() => import('./Configuracoes/LimparDados'));
const HardRefresh = lazy(() => import('./Configuracoes/HardRefresh'));

const UserManagement = () => (
  <div className="text-center py-12">
    <h2 className="text-xl font-semibold text-gray-900 mb-4">Usuários e Permissões</h2>
    <p className="text-gray-600">Esta funcionalidade estará disponível em breve.</p>
  </div>
);

const AuditLogs = () => (
  <div className="text-center py-12">
    <h2 className="text-xl font-semibold text-gray-900 mb-4">Logs de Auditoria</h2>
    <p className="text-gray-600">Esta funcionalidade estará disponível em breve.</p>
  </div>
);

export default function ConfiguracoesLayout() {
  return (
    <div className="ml-64">
      <MasterDetailLayout>
        <Routes>
          <Route path="/" element={<Navigate to="/configuracoes/funcoes" replace />} />
          <Route path="/funcoes" element={<ConfiguracoesFuncoes />} />
          <Route path="/empresa" element={<ConfiguracaoEmpresa />} />
          <Route path="/certificado" element={<ConfiguracaoCertificado />} />
          <Route path="/aeronaves" element={<AeronavesCRUD />} />
          <Route path="/limpar-dados" element={<LimparDados />} />
          <Route path="/hard-refresh" element={<HardRefresh />} />
          <Route path="/usuarios" element={<UserManagement />} />
          <Route path="/auditoria" element={<AuditLogs />} />
        </Routes>
      </MasterDetailLayout>
    </div>
  );
}
