import { useState, useEffect } from 'react';
import { Plus, Plane, Edit2, Trash2 } from 'lucide-react';

import Button from '@/react-app/components/Button';
import Card, { CardHeader, CardContent } from '@/react-app/components/Card';
import { BaseModal as Modal } from '@/react-app/components/modals/BaseModal';
import Badge from '@/react-app/components/Badge';

interface Aeronave {
  id: number;
  codigo: string;
  nome: string;
  fabricante?: string;
  created_at: string;
  updated_at: string;
}

interface AeronaveFormData {
  codigo: string;
  nome: string;
  fabricante?: string;
}

export default function Aeronaves() {
  const [aeronaves, setAeronaves] = useState<Aeronave[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingAeronave, setEditingAeronave] = useState<Aeronave | null>(null);
  const [formData, setFormData] = useState<AeronaveFormData>({
    codigo: '',
    nome: '',
    fabricante: ''
  });

  const fetchAeronaves = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/v2/aeronaves');
      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Erro ao buscar aeronaves');
      }

      setAeronaves(result.data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
      console.error('Erro ao buscar aeronaves:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAeronaves();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const url = editingAeronave ? `/api/v2/aeronaves/${editingAeronave.id}` : '/api/v2/aeronaves';
      const method = editingAeronave ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Erro ao salvar aeronave');
      }

      setIsCreateModalOpen(false);
      setIsEditModalOpen(false);
      setEditingAeronave(null);
      setFormData({ codigo: '', nome: '', fabricante: '' });
      fetchAeronaves();
    } catch (err) {
      console.error('Erro ao salvar aeronave:', err);
    }
  };

  const handleEdit = (aeronave: Aeronave) => {
    setEditingAeronave(aeronave);
    setFormData({
      codigo: aeronave.codigo,
      nome: aeronave.nome,
      fabricante: aeronave.fabricante || ''
    });
    setIsEditModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir esta aeronave?')) {
      return;
    }

    try {
      const response = await fetch(`/api/v2/aeronaves/${id}`, {
        method: 'DELETE'
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Erro ao excluir aeronave');
      }

      fetchAeronaves();
    } catch (err) {
      console.error('Erro ao excluir aeronave:', err);
      alert('Erro ao excluir aeronave');
    }
  };

  const openCreateModal = () => {
    setFormData({ codigo: '', nome: '', fabricante: '' });
    setEditingAeronave(null);
    setIsCreateModalOpen(true);
  };

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">Erro ao carregar aeronaves: {error}</p>
        <Button 
          variant="primary" 
          onClick={fetchAeronaves}
          className="mt-4"
        >
          Tentar Novamente
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Catálogo de Aeronaves
          </h1>
          <p className="text-neutral-600 mt-2">
            Gerenciamento centralizado de aeronaves da frota
          </p>
        </div>
        <Button variant="primary" onClick={openCreateModal}>
          <Plus className="w-4 h-4 mr-2" />
          Nova Aeronave
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Plane className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-neutral-600">Total de Aeronaves</p>
                <p className="text-2xl font-semibold text-neutral-900">
                  {loading ? '-' : aeronaves.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Plane className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-neutral-600">Fabricantes</p>
                <p className="text-2xl font-semibold text-neutral-900">
                  {loading ? '-' : new Set(aeronaves.map(a => a.fabricante).filter(Boolean)).size}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Plane className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-neutral-600">Modelos Únicos</p>
                <p className="text-2xl font-semibold text-neutral-900">
                  {loading ? '-' : new Set(aeronaves.map(a => a.codigo)).size}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Aeronaves */}
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold text-neutral-900">
            Aeronaves Cadastradas
          </h3>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-neutral-200 rounded"></div>
              ))}
            </div>
          ) : aeronaves.length === 0 ? (
            <div className="text-center py-8">
              <Plane className="h-12 w-12 text-neutral-400 mx-auto mb-4" />
              <p className="text-neutral-500 text-lg font-medium mb-2">Nenhuma aeronave cadastrada</p>
              <p className="text-sm text-neutral-400 mb-4">
                Clique em "Nova Aeronave" para adicionar a primeira aeronave ao catálogo
              </p>
              <Button variant="primary" onClick={openCreateModal}>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Primeira Aeronave
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-neutral-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Código
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Nome
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Fabricante
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {aeronaves.map((aeronave) => (
                    <tr key={aeronave.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Badge variant="neutral" size="sm">
                            {aeronave.codigo}
                          </Badge>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-neutral-900">
                          {aeronave.nome}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-neutral-500">
                          {aeronave.fabricante || '-'}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(aeronave)}
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(aeronave.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Criação */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Nova Aeronave"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Código *
            </label>
            <input
              type="text"
              required
              value={formData.codigo}
              onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: A320, B738"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Nome *
            </label>
            <input
              type="text"
              required
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Airbus A320"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Fabricante
            </label>
            <input
              type="text"
              value={formData.fabricante}
              onChange={(e) => setFormData({ ...formData, fabricante: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: Airbus"
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setIsCreateModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary">
              Criar Aeronave
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal de Edição */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Editar Aeronave"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Código *
            </label>
            <input
              type="text"
              required
              value={formData.codigo}
              onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Nome *
            </label>
            <input
              type="text"
              required
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Fabricante
            </label>
            <input
              type="text"
              value={formData.fabricante}
              onChange={(e) => setFormData({ ...formData, fabricante: e.target.value })}
              className="w-full px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setIsEditModalOpen(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" variant="primary">
              Salvar Alterações
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
