import { useState } from 'react';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router';
import FormularioAgendamento from '../components/simuladores/FormularioAgendamento';
import Card from '../components/Card';

const Agendamento: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [sucesso, setSucesso] = useState(false);
  
  const handleSubmit = async (dados: any) => {
    try {
      setLoading(true);
      
      
      const payload = {
        dados_gerais: {
          simulador_id: parseInt(dados.simulador_id),
          instrutor_id: parseInt(dados.instrutor_id),
          template_id: dados.template_id ? parseInt(dados.template_id) : null,
          data_inicio: dados.data_inicio,
          data_fim: dados.data_fim,
          observacoes: dados.observacoes || ''
        },
        participantes: [] // Será preenchido posteriormente
      };
      
      const response = await fetch('/api/v2/agendamentos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      const result = await response.json();
      
      if (response.ok && result.success) {
        setSucesso(true);
        
        setTimeout(() => {
          navigate('/simuladores');
        }, 2000);
      } else {
        console.error('❌ Erro no agendamento:', result);
        alert(`Erro ao agendar sessão: ${result.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('❌ Erro na requisição:', error);
      alert('Erro de conexão ao agendar sessão');
    } finally {
      setLoading(false);
    }
  };

  if (sucesso) {
    return (
      <div className="container mx-auto py-8">
        <Card className="max-w-md mx-auto text-center p-8">
          <div className="flex flex-col items-center gap-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="text-green-600" size={32} />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">Sessão Agendada!</h2>
            <p className="text-gray-600">
              Sua sessão foi agendada com sucesso. Redirecionando para o dashboard...
            </p>
            <div className="animate-spin rounded-full h-6 w-6 border-2 border-green-600 border-t-transparent"></div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <button 
          onClick={() => navigate('/simuladores')} 
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          disabled={loading}
        >
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Agendar Sessão</h1>
          <p className="text-gray-600 mt-1">
            Configure uma nova sessão de treinamento em simulador
          </p>
        </div>
      </div>

      {loading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-2 border-blue-600 border-t-transparent"></div>
            <span className="text-gray-700">Agendando sessão...</span>
          </div>
        </div>
      )}

      <FormularioAgendamento 
        onCancelar={() => navigate('/simuladores')}
      />
    </div>
  );
};

export default Agendamento;
