import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, FileText, User, Calendar, Award, Download, Folder, File, RefreshCw, AlertTriangle, Clock, Activity } from 'lucide-react';
import Button from '@/react-app/components/Button';
import Card, { CardHeader, CardContent } from '@/react-app/components/Card';
import Badge from '@/react-app/components/Badge';
import AddCertificacaoModal from '@/react-app/components/funcionarios/AddCertificacaoModal';
import AbaCertificados from '@/react-app/components/funcionarios/AbaCertificados';
import PastaVirtualCompleta from '@/react-app/components/funcionarios/PastaVirtualCompleta';
import { PageLayout } from '@/react-app/components/layout/PageLayout';

interface Funcionario {
  id: number;
  nome: string;
  matricula: string;
  funcao: string;
  email: string;
  telefone?: string;
  status: string;
  aeronave_principal?: string;
}

interface ArquivoPasta {
  id: number;
  nome: string;
  tipo: string;
  categoria: string;
  codigo: string;
  dataUpload: string;
  tamanho: string;
  status: string;
  data_vencimento?: string;
  diasParaVencimento?: number | string;
}

interface PastaVirtualData {
  success: boolean;
  arquivos: ArquivoPasta[];
}

interface CatalogoTreinamento {
  id: number;
  codigo: string;
  nome: string;
  descricao?: string;
  categoria: string;
  periodicidade_meses?: number;
  ativo: boolean;
}

export default function PastaVirtual() {
  const { funcionarioId } = useParams<{ funcionarioId: string }>();
  const navigate = useNavigate();
  
  const [funcionario, setFuncionario] = useState<Funcionario | null>(null);
  const [catalogoTreinamentos, setCatalogoTreinamentos] = useState<CatalogoTreinamento[]>([]);
  const [pastaVirtualData, setPastaVirtualData] = useState<PastaVirtualData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingSync, setLoadingSync] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [abaAtiva, setAbaAtiva] = useState<'documentos' | 'certificados'>('documentos');

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);


      const funcionarioResponse = await fetch(`/api/v2/funcionarios/${funcionarioId}`);
      const funcionarioData = await funcionarioResponse.json();
      
      
      const dadosFuncionario = funcionarioData.funcionario || funcionarioData.data;
      
      if (!funcionarioData.success || !dadosFuncionario) {
        console.error('❌ Dados inválidos:', { success: funcionarioData.success, hasFuncionario: !!dadosFuncionario });
        throw new Error(funcionarioData.error || 'Funcionário não encontrado');
      }
      
      setFuncionario(dadosFuncionario);

      setPastaVirtualData({ success: true, arquivos: [] });

      setCatalogoTreinamentos([]);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro ao carregar dados';
      setError(errorMessage);
      console.error('❌ Erro ao buscar dados da pasta virtual:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddSuccess = () => {
    setIsAddModalOpen(false);
    fetchData(); // Re-fetch para atualizar a lista
  };

  const sincronizarFuncionario = async () => {
    try {
      setLoadingSync(true);
      setError(null);


      const result = await fetch(`/api/v2/pasta-virtual/${funcionarioId}`, {
        method: 'GET'
      });
      const data = await result.json();

      if (data.success) {
        setPastaVirtualData(data);
      } else {
        throw new Error(data.error || 'Erro na sincronização');
      }

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro na sincronização';
      setError(errorMessage);
      console.error('❌ Erro na sincronização:', err);
    } finally {
      setLoadingSync(false);
    }
  };

  const downloadArquivo = (arquivo: ArquivoPasta) => {
    
    const url = `/api/v2/pasta-virtual/download/${arquivo.id}`;
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `${arquivo.nome}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'sincronizado': return 'success';
      case 'pendente': return 'warning'; 
      case 'erro': return 'danger';
      case 'vencido': return 'danger';
      case 'vencendo': return 'warning';
      default: return 'neutral';
    }
  };

  const getStatusText = (arquivo: ArquivoPasta) => {
    if (arquivo.diasParaVencimento === 'vencido') return 'VENCIDO';
    if (typeof arquivo.diasParaVencimento === 'number' && arquivo.diasParaVencimento <= 30) return 'VENCENDO';
    if (arquivo.status === 'sincronizado') return 'VÁLIDO';
    return arquivo.status?.toUpperCase() || 'DESCONHECIDO';
  };

  useEffect(() => {
    if (funcionarioId) {
      fetchData();
    }
  }, [funcionarioId]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4 w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <p className="text-red-600 mb-4 text-lg font-medium">Erro: {error}</p>
        <div className="space-x-3">
          <Button variant="secondary" onClick={fetchData}>
            Tentar Novamente
          </Button>
          <Button variant="primary" onClick={() => navigate('/funcionarios')}>
            Voltar para Funcionários
          </Button>
        </div>
      </div>
    );
  }

  if (!funcionario) {
    return (
      <div className="text-center py-12">
        <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 mb-4">Funcionário não encontrado</p>
        <Button variant="primary" onClick={() => navigate('/funcionarios')}>
          Voltar para Funcionários
        </Button>
      </div>
    );
  }

  const arquivos = pastaVirtualData?.arquivos || [];
  const totalArquivos = arquivos.length;
  const arquivosVencidos = arquivos.filter(a => a.diasParaVencimento === 'vencido').length;
  const arquivosVencendo = arquivos.filter(a => typeof a.diasParaVencimento === 'number' && a.diasParaVencimento <= 30).length;
  const espacoTotal = arquivos.length * 2.5; // MB estimado

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/funcionarios')}
            className="p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Pasta Virtual
            </h1>
            <p className="text-gray-600 mt-1">
              Sistema de Gestão Documental Integrado
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="secondary" 
            onClick={sincronizarFuncionario}
            disabled={loadingSync}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loadingSync ? 'animate-spin' : ''}`} />
            {loadingSync ? 'Sincronizando...' : 'Sincronizar'}
          </Button>
          <Button variant="primary" onClick={() => setIsAddModalOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Adicionar
          </Button>
        </div>
      </div>

      {/* Cabeçalho do Funcionário */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-xl">
              {funcionario.nome.split(' ').map(n => n[0]).join('').substring(0, 2)}
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-900">{funcionario.nome}</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
                <div className="flex items-center text-sm text-gray-600">
                  <User className="w-4 h-4 mr-2" />
                  Matrícula: {funcionario.matricula}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Award className="w-4 h-4 mr-2" />
                  Função: {funcionario.funcao}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <FileText className="w-4 h-4 mr-2" />
                  Aeronave: {funcionario.aeronave_principal || 'N/A'}
                </div>
                <div>
                  <Badge variant={funcionario.status === 'ATIVO' ? 'success' : 'danger'}>
                    {funcionario.status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-xl font-bold text-gray-900">{totalArquivos}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <Award className="w-5 h-5 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-600">Certificações</p>
                <p className="text-xl font-bold text-gray-900">{totalArquivos}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-600">Vencendo</p>
                <p className="text-xl font-bold text-gray-900">{arquivosVencendo}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-600">Vencidos</p>
                <p className="text-xl font-bold text-gray-900">{arquivosVencidos}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Activity className="w-5 h-5 text-purple-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-600">Espaço</p>
                <p className="text-xl font-bold text-gray-900">{espacoTotal.toFixed(1)}MB</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Navegação de Abas */}
      <div className="bg-white rounded-lg shadow border border-gray-200">
        <nav className="flex border-b">
          <button
            onClick={() => setAbaAtiva('documentos')}
            className={`flex-1 px-6 py-4 font-medium transition flex items-center justify-center gap-2 ${
              abaAtiva === 'documentos'
                ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <Folder className="w-5 h-5" />
            <span>Documentos</span>
          </button>

          <button
            onClick={() => setAbaAtiva('certificados')}
            className={`flex-1 px-6 py-4 font-medium transition flex items-center justify-center gap-2 ${
              abaAtiva === 'certificados'
                ? 'border-b-2 border-blue-600 text-blue-600 bg-blue-50'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span>Certificados</span>
          </button>
        </nav>
      </div>

      {/* Conteúdo da Aba Documentos */}
      {abaAtiva === 'documentos' && (
        <PastaVirtualCompleta funcionarioId={parseInt(funcionarioId!)} />
      )}

      {/* Conteúdo Antigo (Comentado) */}
      {false && abaAtiva === 'documentos' && (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Folder className="w-5 h-5 mr-2 text-blue-600" />
              Documentos da Pasta Virtual
            </h3>
            <p className="text-sm text-gray-500">
              Última atualização: {new Date().toLocaleString('pt-BR')}
            </p>
          </div>
        </CardHeader>
        <CardContent>
          {totalArquivos === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-xl font-medium mb-2">Pasta Virtual Vazia</p>
              <p className="text-gray-400 mb-6">
                Nenhum documento encontrado. Clique em "Sincronizar" para carregar documentos ou "Adicionar" para inserir manualmente.
              </p>
              <div className="space-x-3">
                <Button variant="primary" onClick={sincronizarFuncionario} disabled={loadingSync}>
                  <RefreshCw className={`w-4 h-4 mr-2 ${loadingSync ? 'animate-spin' : ''}`} />
                  Sincronizar
                </Button>
                <Button variant="secondary" onClick={() => setIsAddModalOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Manual
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {arquivos.map((arquivo) => (
                <div key={arquivo.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors hover:shadow-md">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <File className="w-5 h-5 text-blue-600" />
                        <h5 className="font-medium text-gray-900 text-lg">
                          {arquivo.nome}
                        </h5>
                        <Badge 
                          variant={getStatusBadgeVariant(getStatusText(arquivo))}
                          size="sm"
                        >
                          {getStatusText(arquivo)}
                        </Badge>
                        {arquivo.codigo && (
                          <Badge variant="neutral" size="sm">
                            {arquivo.codigo}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 mb-2">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          <span>Upload: {new Date(arquivo.dataUpload).toLocaleDateString('pt-BR')}</span>
                        </div>
                        {arquivo.data_vencimento && (
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-2" />
                            <span>Vence: {new Date(arquivo.data_vencimento).toLocaleDateString('pt-BR')}</span>
                          </div>
                        )}
                        <div className="flex items-center">
                          <Activity className="w-4 h-4 mr-2" />
                          <span>Tipo: {arquivo.tipo}</span>
                        </div>
                        {arquivo.categoria && (
                          <div className="flex items-center">
                            <Award className="w-4 h-4 mr-2" />
                            <span>Categoria: {arquivo.categoria}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>📁 {arquivo.nome}.pdf</span>
                        <span>💾 {arquivo.tamanho}</span>
                        <span>🔗 ID: {arquivo.id}</span>
                      </div>
                    </div>
                    
                    <div className="ml-4">
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => downloadArquivo(arquivo)}
                        className="flex items-center space-x-2 hover:bg-blue-700 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      )}

      {/* Conteúdo da Aba Certificados */}
      {abaAtiva === 'certificados' && (
        <AbaCertificados funcionarioId={parseInt(funcionarioId!)} />
      )}

      {/* Modal de Adicionar Certificação */}
      <AddCertificacaoModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSuccess={handleAddSuccess}
        funcionarioId={parseInt(funcionarioId!)}
        catalogoTreinamentos={catalogoTreinamentos}
      />
    </div>
  );
}
