import { funcionariosService } from '../../services/funcionarios.service';
import api from '../../services/api';

jest.mock('../../services/api');

const mockApi = api as jest.Mocked<typeof api>;

describe('funcionariosService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    funcionariosService.limparCache();
  });

  describe('listar', () => {
    it('deve listar funcionários sem filtros', async () => {
      const mockFuncionarios = [
        {
          id: '1',
          nome: 'João Silva',
          cpf: '123.456.789-00',
          email: 'joao@email.com',
          matricula: '001',
          cargo: 'Piloto',
          setor: 'Operações',
          ativo: true,
          data_admissao: '2023-01-15',
          created_at: '2023-01-15T10:00:00Z',
          updated_at: '2023-01-15T10:00:00Z'
        }
      ];

      mockApi.get.mockResolvedValue(mockFuncionarios);

      const result = await funcionariosService.listar();

      expect(mockApi.get).toHaveBeenCalledWith('/funcionarios');
      expect(result).toEqual(mockFuncionarios);
    });

    it('deve listar funcionários com filtros e paginação', async () => {
      const mockFuncionarios = [];
      const filtros = { search: 'João', cargo: 'Piloto' };
      const paginacao = { page: 2, limit: 20 };

      mockApi.get.mockResolvedValue(mockFuncionarios);

      const result = await funcionariosService.listar(filtros, paginacao);

      expect(mockApi.get).toHaveBeenCalledWith('/funcionarios?page=2&limit=20&search=João&cargo=Piloto');
      expect(result).toEqual(mockFuncionarios);
    });

    it('deve usar cache quando disponível e válido', async () => {
      const mockFuncionarios = [
        {
          id: '1',
          nome: 'João Silva',
          cpf: '123.456.789-00',
          email: 'joao@email.com',
          matricula: '001',
          cargo: 'Piloto',
          setor: 'Operações',
          ativo: true,
          data_admissao: '2023-01-15',
          created_at: '2023-01-15T10:00:00Z',
          updated_at: '2023-01-15T10:00:00Z'
        }
      ];

      mockApi.get.mockResolvedValue(mockFuncionarios);

      await funcionariosService.listar();
      expect(mockApi.get).toHaveBeenCalledTimes(1);

      const result = await funcionariosService.listar();
      expect(mockApi.get).toHaveBeenCalledTimes(1); // Não deve chamar API novamente
      expect(result).toEqual(mockFuncionarios);
    });
  });

  describe('buscarPorId', () => {
    it('deve buscar funcionário por ID', async () => {
      const mockFuncionario = {
        id: '1',
        nome: 'João Silva',
        cpf: '123.456.789-00',
        email: 'joao@email.com',
        matricula: '001',
        cargo: 'Piloto',
        setor: 'Operações',
        ativo: true,
        data_admissao: '2023-01-15',
        created_at: '2023-01-15T10:00:00Z',
        updated_at: '2023-01-15T10:00:00Z'
      };

      mockApi.get.mockResolvedValue(mockFuncionario);

      const result = await funcionariosService.buscarPorId('1');

      expect(mockApi.get).toHaveBeenCalledWith('/funcionarios/1');
      expect(result).toEqual(mockFuncionario);
    });
  });

  describe('criar', () => {
    it('deve criar funcionário e limpar cache', async () => {
      const funcionarioCreate = {
        nome: 'Maria Santos',
        cpf: '987.654.321-00',
        email: 'maria@email.com',
        matricula: '002',
        cargo: 'Comissária',
        setor: 'Operações',
        ativo: true,
        data_admissao: '2023-02-01'
      };

      const funcionarioCriado = {
        id: '2',
        ...funcionarioCreate,
        created_at: '2023-02-01T10:00:00Z',
        updated_at: '2023-02-01T10:00:00Z'
      };

      mockApi.post.mockResolvedValue(funcionarioCriado);

      const result = await funcionariosService.criar(funcionarioCreate);

      expect(mockApi.post).toHaveBeenCalledWith('/funcionarios', funcionarioCreate);
      expect(result).toEqual(funcionarioCriado);
    });
  });

  describe('atualizar', () => {
    it('deve atualizar funcionário e limpar cache', async () => {
      const funcionarioUpdate = { nome: 'João Silva Atualizado' };
      const funcionarioAtualizado = {
        id: '1',
        nome: 'João Silva Atualizado',
        cpf: '123.456.789-00',
        email: 'joao@email.com',
        matricula: '001',
        cargo: 'Piloto',
        setor: 'Operações',
        ativo: true,
        data_admissao: '2023-01-15',
        created_at: '2023-01-15T10:00:00Z',
        updated_at: '2023-01-16T10:00:00Z'
      };

      mockApi.put.mockResolvedValue(funcionarioAtualizado);

      const result = await funcionariosService.atualizar('1', funcionarioUpdate);

      expect(mockApi.put).toHaveBeenCalledWith('/funcionarios/1', funcionarioUpdate);
      expect(result).toEqual(funcionarioAtualizado);
    });
  });

  describe('excluir', () => {
    it('deve excluir funcionário e limpar cache', async () => {
      mockApi.delete.mockResolvedValue(undefined);

      await funcionariosService.excluir('1');

      expect(mockApi.delete).toHaveBeenCalledWith('/funcionarios/1');
    });
  });

  describe('importar', () => {
    it('deve importar funcionários via arquivo', async () => {
      const mockFile = new File([''], 'funcionarios.csv', { type: 'text/csv' });
      const importResult = { sucesso: 10, erros: [] };

      mockApi.post.mockResolvedValue(importResult);

      const result = await funcionariosService.importar(mockFile);

      expect(mockApi.post).toHaveBeenCalledWith('/funcionarios/import', expect.any(FormData), {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      expect(result).toEqual(importResult);
    });
  });

  describe('exportar', () => {
    it('deve exportar funcionários', async () => {
      const mockBlob = new Blob(['csv data'], { type: 'text/csv' });
      mockApi.get.mockResolvedValue(mockBlob);

      const result = await funcionariosService.exportar();

      expect(mockApi.get).toHaveBeenCalledWith('/funcionarios/export', {
        responseType: 'blob'
      });
      expect(result).toEqual(mockBlob);
    });
  });

  describe('limparCache', () => {
    it('deve limpar cache interno', () => {
      funcionariosService.listar();

      funcionariosService.limparCache();

      expect(true).toBe(true); // Placeholder - em implementação real verificar se cache foi limpo
    });
  });
});
