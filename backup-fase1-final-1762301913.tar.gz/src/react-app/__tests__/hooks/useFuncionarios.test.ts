import { renderHook, act } from '@testing-library/react';
import { useFuncionarios } from '../hooks/useFuncionarios';
import { funcionariosService } from '../services/funcionarios.service';

jest.mock('../services/funcionarios.service');

const mockFuncionariosService = funcionariosService as jest.Mocked<typeof funcionariosService>;

describe('useFuncionarios', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('deve carregar funcionários com sucesso', async () => {
    const mockFuncionarios = [
      {
        id: '1',
        nome: 'João Silva',
        cpf: '123.456.789-00',
        email: 'joao@email.com',
        matricula: '001',
        cargo: 'Piloto',
        setor: 'Operações',
        ativo: true,
        data_admissao: '2023-01-15',
        created_at: '2023-01-15T10:00:00Z',
        updated_at: '2023-01-15T10:00:00Z'
      }
    ];

    mockFuncionariosService.listar.mockResolvedValue(mockFuncionarios);

    const { result } = renderHook(() => useFuncionarios());

    expect(result.current.loading).toBe(true);
    expect(result.current.funcionarios).toEqual([]);
    expect(result.current.error).toBe(null);

    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 0));
    });

    expect(result.current.loading).toBe(false);
    expect(result.current.funcionarios).toEqual(mockFuncionarios);
    expect(result.current.error).toBe(null);
  });

  it('deve lidar com erro ao carregar funcionários', async () => {
    const mockError = new Error('Erro de conexão');
    mockFuncionariosService.listar.mockRejectedValue(mockError);

    const { result } = renderHook(() => useFuncionarios());

    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 0));
    });

    expect(result.current.loading).toBe(false);
    expect(result.current.funcionarios).toEqual([]);
    expect(result.current.error).toBe('Erro de conexão');
  });

  it('deve criar funcionário com sucesso', async () => {
    const novoFuncionario = {
      id: '2',
      nome: 'Maria Santos',
      cpf: '987.654.321-00',
      email: 'maria@email.com',
      matricula: '002',
      cargo: 'Comissária',
      setor: 'Operações',
      ativo: true,
      data_admissao: '2023-02-01',
      created_at: '2023-02-01T10:00:00Z',
      updated_at: '2023-02-01T10:00:00Z'
    };

    const funcionarioCreate = {
      nome: 'Maria Santos',
      cpf: '987.654.321-00',
      email: 'maria@email.com',
      matricula: '002',
      cargo: 'Comissária',
      setor: 'Operações',
      ativo: true,
      data_admissao: '2023-02-01'
    };

    mockFuncionariosService.criar.mockResolvedValue(novoFuncionario);

    const { result } = renderHook(() => useFuncionarios());

    await act(async () => {
      await result.current.criar(funcionarioCreate);
    });

    expect(mockFuncionariosService.criar).toHaveBeenCalledWith(funcionarioCreate);
    expect(result.current.loading).toBe(false);
  });

  it('deve atualizar funcionário com sucesso', async () => {
    const funcionarioAtualizado = {
      id: '1',
      nome: 'João Silva Atualizado',
      cpf: '123.456.789-00',
      email: 'joao@email.com',
      matricula: '001',
      cargo: 'Piloto',
      setor: 'Operações',
      ativo: true,
      data_admissao: '2023-01-15',
      created_at: '2023-01-15T10:00:00Z',
      updated_at: '2023-01-16T10:00:00Z'
    };

    const funcionarioUpdate = {
      nome: 'João Silva Atualizado'
    };

    mockFuncionariosService.atualizar.mockResolvedValue(funcionarioAtualizado);

    const { result } = renderHook(() => useFuncionarios());

    await act(async () => {
      await result.current.atualizar('1', funcionarioUpdate);
    });

    expect(mockFuncionariosService.atualizar).toHaveBeenCalledWith('1', funcionarioUpdate);
    expect(result.current.loading).toBe(false);
  });

  it('deve excluir funcionário com sucesso', async () => {
    mockFuncionariosService.excluir.mockResolvedValue();

    const { result } = renderHook(() => useFuncionarios());

    await act(async () => {
      await result.current.excluir('1');
    });

    expect(mockFuncionariosService.excluir).toHaveBeenCalledWith('1');
    expect(result.current.loading).toBe(false);
  });

  it('deve lidar com paginação', async () => {
    const mockFuncionarios = Array.from({ length: 25 }, (_, i) => ({
      id: `${i + 1}`,
      nome: `Funcionário ${i + 1}`,
      cpf: `${i + 1}`.padStart(3, '0') + '.456.789-00',
      email: `funcionario${i + 1}@email.com`,
      matricula: `${i + 1}`.padStart(3, '0'),
      cargo: 'Funcionário',
      setor: 'Operações',
      ativo: true,
      data_admissao: '2023-01-15',
      created_at: '2023-01-15T10:00:00Z',
      updated_at: '2023-01-15T10:00:00Z'
    }));

    mockFuncionariosService.listar.mockResolvedValue(mockFuncionarios.slice(0, 10));

    const { result } = renderHook(() => useFuncionarios());

    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 0));
    });

    expect(result.current.pagination.total).toBe(10);
    expect(result.current.pagination.pages).toBe(1);
    expect(result.current.pagination.page).toBe(1);
    expect(result.current.pagination.limit).toBe(10);
  });
});
