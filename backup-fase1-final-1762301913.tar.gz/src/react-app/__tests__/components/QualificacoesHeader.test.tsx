/**
 * Testes do componente QualificacoesHeader
 */

import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import QualificacoesHeader from '../../react-app/pages/qualificacoes/components/QualificacoesHeader';

describe('QualificacoesHeader', () => {
  const mockStats = {
    total: 100,
    validas: 70,
    vencendo: 20,
    vencidas: 10,
  };

  const mockHandlers = {
    onNovaQualificacao: vi.fn(),
    onImportar: vi.fn(),
    onConfigurarColunas: vi.fn(),
    onExportar: vi.fn(),
  };

  it('deve renderizar o header corretamente', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    expect(screen.getByText('Qualificações')).toBeInTheDocument();
  });

  it('deve exibir estatísticas corretas', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    expect(screen.getByText('100')).toBeInTheDocument(); // Total
    expect(screen.getByText('70')).toBeInTheDocument(); // Válidas
    expect(screen.getByText('20')).toBeInTheDocument(); // Vencendo
    expect(screen.getByText('10')).toBeInTheDocument(); // Vencidas
  });

  it('deve chamar onNovaQualificacao ao clicar no botão', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    const novoButton = screen.getByText('Nova Qualificação');
    fireEvent.click(novoButton);

    expect(mockHandlers.onNovaQualificacao).toHaveBeenCalledTimes(1);
  });

  it('deve chamar onImportar ao clicar no botão', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    const importarButton = screen.getByText('Importar');
    fireEvent.click(importarButton);

    expect(mockHandlers.onImportar).toHaveBeenCalledTimes(1);
  });

  it('deve chamar onConfigurarColunas ao clicar no botão', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    const configurarButton = screen.getByText('Configurar Colunas');
    fireEvent.click(configurarButton);

    expect(mockHandlers.onConfigurarColunas).toHaveBeenCalledTimes(1);
  });

  it('deve exibir botão de exportar se fornecido', () => {
    render(<QualificacoesHeader stats={mockStats} {...mockHandlers} />);

    const exportarButton = screen.getByText('Exportar');
    expect(exportarButton).toBeInTheDocument();

    fireEvent.click(exportarButton);
    expect(mockHandlers.onExportar).toHaveBeenCalledTimes(1);
  });

  it('não deve exibir botão de exportar se não fornecido', () => {
    const handlersWithoutExport = { ...mockHandlers, onExportar: undefined };
    render(<QualificacoesHeader stats={mockStats} {...handlersWithoutExport} />);

    expect(screen.queryByText('Exportar')).not.toBeInTheDocument();
  });

  it('deve exibir estatísticas zeradas corretamente', () => {
    const emptyStats = {
      total: 0,
      validas: 0,
      vencendo: 0,
      vencidas: 0,
    };

    render(<QualificacoesHeader stats={emptyStats} {...mockHandlers} />);

    const zeros = screen.getAllByText('0');
    expect(zeros.length).toBeGreaterThanOrEqual(4);
  });
});
