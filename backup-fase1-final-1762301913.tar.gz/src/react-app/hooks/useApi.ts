import { useState, useEffect } from 'react';
import { API_BASE_URL } from '@/react-app/config/api';

export function useApi<T>(url: string) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
      
      const token = localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const response = await fetch(fullUrl, { headers });
      
      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.error || `Erro ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      
      if (result.success !== undefined) {
        if (result.success) {
          setData(result.data);
        } else {
          throw new Error(result.error || 'Erro desconhecido');
        }
      } else if (Array.isArray(result)) {
        setData(result as T);
      } else if (typeof result === 'object') {
        setData(result as T);
      } else {
        throw new Error('Formato de resposta inválido');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [url]);

  return { data, loading, error, refetch: fetchData };
}

export function useApiMutation<T>() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = async (url: string, options: RequestInit): Promise<T> => {
    try {
      setLoading(true);
      setError(null);
      
      const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
      
      const token = localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(options.headers as Record<string, string>),
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const response = await fetch(fullUrl, {
        ...options,
        headers,
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Erro na requisição');
      }
      
      if (!result.success) {
        throw new Error(result.error || 'Erro desconhecido');
      }
      
      return result.data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return { mutate, loading, error };
}
