import { useState, useEffect, useCallback, useRef } from 'react';

const apiCache = new Map<string, { data: any; timestamp: number; ttl: number }>();
const CACHE_TTL = 30000; // 30 segundos

interface UseOptimizedApiOptions {
  immediate?: boolean;
  cacheTtl?: number;
  retryAttempts?: number;
}

export function useOptimizedApi<T>(url: string, options: UseOptimizedApiOptions = {}) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(options.immediate !== false);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);

  const fetchData = useCallback(async (retryCount = 0) => {
    const cacheKey = url;
    const cached = apiCache.get(cacheKey);
    const ttl = options.cacheTtl || CACHE_TTL;
    
    if (cached && Date.now() - cached.timestamp < ttl) {
      setData(cached.data);
      setLoading(false);
      return;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();

    try {
      setLoading(true);
      setError(null);

      const response = await fetch(url, {
        signal: abortControllerRef.current.signal,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `HTTP error! status: ${response.status}`);
      }

      if (!mountedRef.current) return;

      const finalData = result.success ? result.data : result;

      apiCache.set(cacheKey, {
        data: finalData,
        timestamp: Date.now(),
        ttl
      });

      setData(finalData);
      setLoading(false);
    } catch (err: any) {
      if (!mountedRef.current) return;
      
      if (err.name === 'AbortError') {
        return; // Requisição cancelada, não é erro
      }

      const maxRetries = options.retryAttempts || 2;
      if (retryCount < maxRetries) {
        setTimeout(() => {
          if (mountedRef.current) {
            fetchData(retryCount + 1);
          }
        }, Math.pow(2, retryCount) * 1000);
        return;
      }

      setError(err.message);
      setLoading(false);
    }
  }, [url, options.cacheTtl, options.retryAttempts]);

  const refetch = useCallback(() => {
    apiCache.delete(url);
    fetchData();
  }, [fetchData, url]);

  useEffect(() => {
    mountedRef.current = true;
    
    if (options.immediate !== false) {
      fetchData();
    }

    return () => {
      mountedRef.current = false;
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [fetchData, options.immediate]);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return { data, loading, error, refetch };
}

export function usePreloadCriticalData() {
  useEffect(() => {
    const preloadUrls = [
      '/api/v2/funcoes',
      '/api/v2/system/health',
      '/api/v2/system/info'
    ];

    preloadUrls.forEach(url => {
      fetch(url)
        .then(response => response.json())
        .then(result => {
          const finalData = result.success ? result.data : result;
          apiCache.set(url, {
            data: finalData,
            timestamp: Date.now(),
            ttl: 60000 // 1 minuto para dados pré-carregados
          });
        })
        .catch(() => {
        });
    });
  }, []);
}

export default useOptimizedApi;
