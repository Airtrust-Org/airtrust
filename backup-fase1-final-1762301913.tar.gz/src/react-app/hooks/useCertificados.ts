import { useEffect, useState } from 'react';

export interface Certificado {
  id: number;
  qualificacao_id: number;
  arquivo_nome: string;
  arquivo_url: string;
  tipo: 'UPLOAD' | 'GERADO' | 'RENOVADO';
  status: 'ATIVO' | 'VENCIDO' | 'REJEITADO' | 'SUBSTITUIDO';
  data_documento?: string;
  validade_ate?: string;
  created_at: string;
  updated_at: string;
}

export interface UseCertificadosReturn {
  certificados: Certificado[];
  loading: boolean;
  error: string | null;
  gerar: () => Promise<{ id: number; url: string; filename: string } | null>;
  download: (id: number) => Promise<void>;
  carregar: () => Promise<void>;
  refetch: () => Promise<void>;
}

/**
 * Hook para gerenciar certificados de uma qualificação
 * @param qualificacao_id ID da qualificação
 * @returns Objeto com certificados, operações e estado
 */
export function useCertificados(qualificacao_id: number | null): UseCertificadosReturn {
  const [certificados, setCertificados] = useState<Certificado[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Carrega certificados da API
   */
  const carregar = async () => {
    if (!qualificacao_id) {
      setCertificados([]);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`/api/v2/certificados/qualificacao/${qualificacao_id}`);

      if (!response.ok) {
        throw new Error(`Erro ao carregar certificados: ${response.statusText}`);
      }

      const data = await response.json();
      setCertificados(data.data || data || []);
    } catch (err) {
      const mensagem = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(mensagem);
      console.error('Erro ao carregar certificados:', err);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Gera novo certificado PDF
   */
  const gerar = async () => {
    if (!qualificacao_id) {
      setError('ID de qualificação não informado');
      return null;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`/api/v2/certificados/gerar/${qualificacao_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao gerar certificado');
      }

      const resultado = await response.json();

      // Recarregar lista de certificados
      await carregar();

      return resultado;
    } catch (err) {
      const mensagem = err instanceof Error ? err.message : 'Erro ao gerar certificado';
      setError(mensagem);
      console.error('Erro ao gerar certificado:', err);
      return null;
    } finally {
      setLoading(false);
    }
  };

  /**
   * Faz download de um certificado
   */
  const download = async (id: number) => {
    try {
      const cert = certificados.find((c) => c.id === id);
      if (!cert?.arquivo_url) {
        setError('URL do arquivo não disponível');
        return;
      }

      // Usar endpoint de download com validação
      const response = await fetch(`/api/v2/certificados/${id}/download`);

      if (!response.ok) {
        throw new Error(`Erro ao baixar certificado: ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${cert.arquivo_nome || `certificado-${id}.pdf`}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      const mensagem = err instanceof Error ? err.message : 'Erro ao baixar certificado';
      setError(mensagem);
      console.error('Erro ao baixar certificado:', err);
    }
  };

  /**
   * Carrega certificados ao mudar qualificacao_id
   */
  useEffect(() => {
    if (qualificacao_id) {
      carregar();
    }
  }, [qualificacao_id]);

  return {
    certificados,
    loading,
    error,
    gerar,
    download,
    carregar,
    refetch: carregar,
  };
}

/**
 * Hook para estatísticas de certificados (global)
 */
export interface EstatisticasCertificados {
  total: number;
  ativos: number;
  vencidos: number;
  substituidos: number;
}

export function useEstatisticasCertificados() {
  const [stats, setStats] = useState<EstatisticasCertificados>({
    total: 0,
    ativos: 0,
    vencidos: 0,
    substituidos: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('/api/v2/certificados/stats');

      if (!response.ok) {
        throw new Error(`Erro ao carregar estatísticas: ${response.statusText}`);
      }

      const data = await response.json();
      setStats({
        total: data.total || 0,
        ativos: data.ativos || 0,
        vencidos: data.vencidos || 0,
        substituidos: data.substituidos || 0,
      });
    } catch (err) {
      const mensagem = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(mensagem);
      console.error('Erro ao carregar estatísticas:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  return { stats, loading, error, refetch: carregar };
}
