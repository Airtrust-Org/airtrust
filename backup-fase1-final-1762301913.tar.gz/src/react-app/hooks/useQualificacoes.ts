import { useState, useEffect, useCallback } from 'react';

export interface Qualificacao {
  id: number;
  nome: string;
  codigo: string;
  categoria: string;
  validade_meses: number;
  ativo: boolean;
  created_at?: string;
  updated_at?: string;
}

const API_BASE = '/api/v2';

function getToken(): string {
  try {
    return (
      localStorage.getItem('auth_token') ||
      localStorage.getItem('token') ||
      sessionStorage.getItem('auth_token') ||
      'test'
    );
  } catch {
    return 'test';
  }
}

export const useQualificacoes = () => {
  const [qualificacoes, setQualificacoes] = useState<Qualificacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const carregar = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE}/qualificacoes?limit=100`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${getToken()}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Erro HTTP ${response.status}`);
      }

      const json = await response.json();
      
      if (json.success && Array.isArray(json.data)) {
        setQualificacoes(json.data);
      } else {
        throw new Error('Resposta inválida da API');
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar qualificações');
      console.error('❌ Erro ao carregar qualificações:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    carregar();
  }, [carregar]);

  return {
    qualificacoes,
    loading,
    error,
    carregar,
  };
};
