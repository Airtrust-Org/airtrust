import { useState, useEffect, useCallback } from 'react';
import { funcionariosService } from '@/services';
import { Funcionario, FuncionarioCreate, FuncionarioUpdate, FiltrosFuncionarios, PaginacaoParams } from '@/types';

export const useFuncionarios = () => {
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, pages: 0 });
  const [filtros, setFiltros] = useState<FiltrosFuncionarios>({});

  const carregar = useCallback(async (page = 1, limit = 10, filtros?: FiltrosFuncionarios) => {
    setLoading(true);
    setError(null);
    try {
      const paginacao: PaginacaoParams = { page, limit };
      const data = await funcionariosService.listar(filtros, paginacao);

      setFuncionarios(data);
      setPagination(prev => ({ ...prev, page, limit, total: data.length, pages: Math.ceil(data.length / limit) }));
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar funcionários');
    } finally {
      setLoading(false);
    }
  }, []);

  const criar = async (data: FuncionarioCreate) => {
    setLoading(true);
    try {
      const novo = await funcionariosService.criar(data);
      setFuncionarios(prev => [...prev, novo]);
      return novo;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const atualizar = async (id: string, data: FuncionarioUpdate) => {
    setLoading(true);
    try {
      const atualizado = await funcionariosService.atualizar(id, data);
      setFuncionarios(prev => prev.map(f => f.id === id ? atualizado : f));
      return atualizado;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const excluir = async (id: string) => {
    setLoading(true);
    try {
      await funcionariosService.excluir(id);
      setFuncionarios(prev => prev.filter(f => f.id !== id));
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (page: number) => {
    carregar(page, pagination.limit, filtros);
  };

  const handleFiltrosChange = (novosFiltros: FiltrosFuncionarios) => {
    setFiltros(novosFiltros);
    carregar(1, pagination.limit, novosFiltros);
  };

  useEffect(() => {
    carregar();
  }, [carregar]);

  return {
    funcionarios,
    loading,
    error,
    pagination,
    filtros,
    carregar,
    criar,
    atualizar,
    excluir,
    handlePageChange,
    handleFiltrosChange
  };
};
