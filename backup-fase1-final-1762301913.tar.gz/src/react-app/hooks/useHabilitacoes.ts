/**
 * 🎯 useHabilitacoes.ts - Hook para Habilitações
 * ✅ COMPLETA com todas as funcionalidades necessárias
 * Interface compatível com Habilitacoes.tsx original
 */

import { useState, useCallback, useEffect } from 'react';

export interface Habilitacao {
  id: number;
  funcionario_id: number;
  qualificacao_id: number;
  data_conclusao: string;
  data_vencimento: string;
  resultado: string;
  observacoes?: string;
  certificado_url?: string;
  nota_final?: number;
  status: string;
  eh_renovada: boolean;
  renovada_em?: string | null;
  habilitacao_anterior_id?: number | null;
  funcionario_nome?: string;
  funcionario_matricula?: string;
  qualificacao_nome?: string;
  qualificacao_codigo?: string;
  categoria_nome?: string;
  validade_meses?: number;
  carga_horaria?: number;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
  dias_para_vencimento?: number;
}

interface ListResponse {
  success: boolean;
  data: Habilitacao[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  timestamp?: string;
}

interface StatsResponse {
  success: boolean;
  data: {
    total: number;
    validas: number;
    vencendo: number;
    vencidas: number;
    renovadas: number;
  };
  timestamp?: string;
}

const API_BASE = '/api/v2';

function getToken(): string {
  try {
    return (
      localStorage.getItem('auth_token') ||
      localStorage.getItem('token') ||
      sessionStorage.getItem('auth_token') ||
      'test' // Token padrão para testes
    );
  } catch {
    return 'test';
  }
}

/**
 * Hook principal para listar e gerenciar habilitações
 * Interface compatível com a página original
 */
export function useHabilitacoes() {
  const [habilitacoes, setHabilitacoes] = useState<Habilitacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState({ page: 1, limit: 10000, total: 0, pages: 0 });

  const carregar = useCallback(
    async (
      page: number = 1,
      limit: number = 10000,
      filters?: {
        status?: string;
        funcionario_id?: number;
        qualificacao_id?: number;
        search?: string;
      },
    ) => {
      try {
        setLoading(true);
        setError(null);

        const params = new URLSearchParams();
        params.append('page', String(page));
        params.append('limit', String(limit));
        if (filters?.status) params.append('status', filters.status);
        if (filters?.funcionario_id)
          params.append('funcionario_id', String(filters.funcionario_id));
        if (filters?.qualificacao_id)
          params.append('qualificacao_id', String(filters.qualificacao_id));
        if (filters?.search) params.append('search', filters.search);

        const response = await fetch(`${API_BASE}/habilitacoes?${params.toString()}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          throw new Error(`Erro HTTP ${response.status}: ${response.statusText}`);
        }

        const json = (await response.json()) as ListResponse;

        console.log('📡 Resposta da API:', json);
        console.log('📊 Dados recebidos:', json.data?.length, 'registros');
        if (json.data && json.data.length > 0) {
          console.log('🔍 Primeiro registro:', json.data[0]);
        }

        if (!json.success) {
          throw new Error(
            json.data?.length === 0 ? 'Nenhuma habilitação encontrada' : 'Erro ao carregar',
          );
        }

        setHabilitacoes(json.data || []);
        console.log('✅ Estado atualizado com', json.data?.length || 0, 'habilitações');
        if (json.pagination) {
          setPagination(json.pagination);
          console.log('📄 Paginação:', json.pagination);
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(message);
        console.error('❌ Erro ao carregar habilitações:', err);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  /**
   * 🔄 MUTAÇÃO LOCAL: Atualizar uma habilitação específica no estado
   * Sem fazer requisição ao servidor - apenas atualiza o React state
   * Útil para: upload de certificados, edições rápidas, etc.
   */
  const mutarHabilitacao = useCallback(
    (habilitacaoId: number, atualizacoes: Partial<Habilitacao>) => {
      setHabilitacoes((prev) =>
        prev.map((hab) => (hab.id === habilitacaoId ? { ...hab, ...atualizacoes } : hab)),
      );
      console.log(`✏️ Habilitação #${habilitacaoId} atualizada localmente`);
    },
    [],
  );

  /**
   * 🔄 MUTAÇÃO LOCAL: Adicionar uma nova habilitação ao estado
   */
  const adicionarHabilitacao = useCallback((novaHab: Habilitacao) => {
    setHabilitacoes((prev) => [novaHab, ...prev]);
    console.log(`✨ Nova habilitação #${novaHab.id} adicionada ao estado`);
  }, []);

  /**
   * 🔄 MUTAÇÃO LOCAL: Remover uma habilitação do estado
   */
  const removerHabilitacao = useCallback((habilitacaoId: number) => {
    setHabilitacoes((prev) => prev.filter((hab) => hab.id !== habilitacaoId));
    console.log(`🗑️ Habilitação #${habilitacaoId} removida do estado`);
  }, []);

  // Carregar na montagem
  useEffect(() => {
    carregar(1, 10000);
  }, [carregar]);

  return {
    habilitacoes,
    loading,
    error,
    pagination,
    carregar,
    mutarHabilitacao,
    adicionarHabilitacao,
    removerHabilitacao,
  };
}

/**
 * Hook para obter estatísticas
 */
export function useHabilitacoesStats() {
  const [stats, setStats] = useState<{
    total: number;
    validas: number;
    vencendo: number;
    vencidas: number;
    renovadas: number;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetch_stats = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(`${API_BASE}/habilitacoes/stats`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) throw new Error('Erro ao carregar stats');

        const json = (await response.json()) as StatsResponse;
        if (json.success && json.data) {
          setStats(json.data);
        }
      } catch (err) {
        console.error('❌ Erro ao carregar stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetch_stats();
  }, []);

  return { stats, loading, error };
}

/**
 * Hook para obter qualificações disponíveis
 */
export function useQualificacoesDisponiveis() {
  const [qualificacoes, setQualificacoes] = useState<
    Array<{ id: number; nome: string; total: number }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(`${API_BASE}/habilitacoes/qualificacoes`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) throw new Error('Erro ao carregar qualificações');

        const json = (await response.json()) as {
          success: boolean;
          data: Array<{ id: number; nome: string; total: number }>;
        };
        if (json.success && Array.isArray(json.data)) {
          setQualificacoes(json.data);
        }
      } catch (err) {
        console.error('❌ Erro ao carregar qualificações:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return { qualificacoes, loading, error };
}

/**
 * Hook para obter funcionários com habilitações
 */
export function useFuncionariosDisponiveis() {
  const [funcionarios, setFuncionarios] = useState<
    Array<{ id: number; nome: string; total: number }>
  >([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(`${API_BASE}/habilitacoes/funcionarios`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) throw new Error('Erro ao carregar funcionários');

        const json = (await response.json()) as {
          success: boolean;
          data: Array<{ id: number; nome: string; total: number }>;
        };
        if (json.success && Array.isArray(json.data)) {
          setFuncionarios(json.data);
        }
      } catch (err) {
        console.error('❌ Erro ao carregar funcionários:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return { funcionarios, loading, error };
}

/**
 * Hook para criar habilitação
 */
export function useCreateHabilitacao() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const criar = useCallback(
    async (
      dados: Omit<Habilitacao, 'id' | 'created_at' | 'updated_at'>,
    ): Promise<Habilitacao | null> => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(`${API_BASE}/habilitacoes`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(dados),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Erro HTTP ${response.status}`);
        }

        const json = (await response.json()) as { success: boolean; data: Habilitacao };
        if (json.success && json.data) {
          return json.data;
        }
        throw new Error('Resposta inválida');
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(message);
        console.error('❌ Erro ao criar habilitação:', err);
        return null;
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  return { criar, loading, error };
}

/**
 * Hook para atualizar habilitação
 */
export function useUpdateHabilitacao() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const atualizar = useCallback(
    async (id: number, dados: Partial<Habilitacao>): Promise<boolean> => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(`${API_BASE}/habilitacoes/${id}`, {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${getToken()}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(dados),
        });

        if (!response.ok) {
          throw new Error(`Erro ao atualizar: ${response.statusText}`);
        }

        const json = (await response.json()) as { success: boolean };
        return json.success;
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(message);
        console.error('❌ Erro ao atualizar habilitação:', err);
        return false;
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  return { atualizar, loading, error };
}

/**
 * Hook para deletar habilitação
 */
export function useDeleteHabilitacao() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const deletar = useCallback(async (id: number): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(`${API_BASE}/habilitacoes/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${getToken()}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Erro ao deletar: ${response.statusText}`);
      }

      const json = (await response.json()) as { success: boolean };
      return json.success;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(message);
      console.error('❌ Erro ao deletar habilitação:', err);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  return { deletar, loading, error };
}

/**
 * Hook para obter histórico de renovações
 */
export function useHistoricoRenovacoes(funcionarioId: number, qualificacaoId: number) {
  const [historico, setHistorico] = useState<Habilitacao[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(
          `${API_BASE}/habilitacoes/${funcionarioId}/${qualificacaoId}/renovacoes`,
          {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${getToken()}`,
              'Content-Type': 'application/json',
            },
          },
        );

        if (!response.ok) throw new Error('Erro ao carregar histórico');

        const json = (await response.json()) as { success: boolean; data: Habilitacao[] };
        if (json.success && Array.isArray(json.data)) {
          setHistorico(json.data);
        }
      } catch (err) {
        console.error('❌ Erro ao carregar histórico:', err);
      } finally {
        setLoading(false);
      }
    };

    if (funcionarioId && qualificacaoId) {
      fetchData();
    }
  }, [funcionarioId, qualificacaoId]);

  return { historico, loading, error };
}
