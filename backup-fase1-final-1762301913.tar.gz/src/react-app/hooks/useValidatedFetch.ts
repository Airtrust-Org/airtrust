/**
 * @file useValidatedFetch.ts
 * @description Hook para fazer fetch com validação Zod automática
 * @module Hooks/UseValidatedFetch
 */

import { z } from 'zod';

/**
 * Hook para fazer fetch com validação Zod
 * 
 * @param schema - Schema Zod para validar a response
 * @returns Função de fetch tipada
 * 
 * @example
 * ```typescript
 * const fetchQualificacoes = useValidatedFetch(
 *   z.array(QualificacaoSchema)
 * );
 * 
 * const data = await fetchQualificacoes('/api/v2/qualificacoes');
 * // data é tipado como Qualificacao[]
 * ```
 */
export function useValidatedFetch<T>(schema: z.ZodSchema<T>) {
  return async (url: string, options?: RequestInit): Promise<T> => {
    try {
      const response = await fetch(url, options);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Validar com Zod
      const validation = schema.safeParse(data);
      
      if (!validation.success) {
        console.error('❌ Validation error:', validation.error);
        console.error('📄 Invalid data:', data);
        throw new Error('Resposta inválida do servidor');
      }
      
      return validation.data;
    } catch (error) {
      console.error('❌ Fetch error:', error);
      throw error;
    }
  };
}

/**
 * Versão simplificada sem validação (para casos onde não há schema)
 */
export async function safeFetch<T = any>(
  url: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(url, options);
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || `HTTP ${response.status}`);
  }
  
  return response.json();
}

/**
 * Hook para validar dados antes de enviar
 * 
 * @param schema - Schema Zod para validar
 * @returns Função de validação
 */
export function useValidateData<T>(schema: z.ZodSchema<T>) {
  return (data: unknown): { valid: true; data: T } | { valid: false; errors: string[] } => {
    const result = schema.safeParse(data);
    
    if (!result.success) {
      return {
        valid: false,
        errors: result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`),
      };
    }
    
    return {
      valid: true,
      data: result.data,
    };
  };
}
