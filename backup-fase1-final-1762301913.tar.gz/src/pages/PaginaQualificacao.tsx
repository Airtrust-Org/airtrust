import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { GerenciadorCertificados } from '../components/GerenciadorCertificados';
import { PastaVirtualIntegrada } from '../components/PastaVirtualIntegrada';

interface Qualificacao {
  id: number;
  funcionario_id: number;
  nome: string;
  codigo: string;
  carga_horaria: number;
  conteudo_programatico: string;
  data_conclusao: string;
  data_vencimento: string;
  status: string;
}

export function PaginaQualificacao() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [qualificacao, setQualificacao] = useState<Qualificacao | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const carregar = async () => {
      if (!id) {
        setError('ID da qualificação não fornecido');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // Tenta primeiro a nova API
        let res = await fetch(`/api/v2/qualificacoes/${id}`);

        // Se não encontrar, tenta a rota antiga
        if (!res.ok) {
          res = await fetch(`/api/qualificacoes/${id}`);
        }

        if (res.ok) {
          const data = await res.json();
          setQualificacao(data);
        } else {
          setError('Qualificação não encontrada');
        }
      } catch (err) {
        console.error('Erro:', err);
        setError('Erro ao carregar qualificação');
      } finally {
        setLoading(false);
      }
    };

    carregar();
  }, [id]);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      VALIDA: 'bg-green-100 text-green-800',
      VENCIDA: 'bg-red-100 text-red-800',
      PENDENTE: 'bg-yellow-100 text-yellow-800',
      CANCELADA: 'bg-gray-100 text-gray-800',
    };
    return colors[status] || 'bg-blue-100 text-blue-800';
  };

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center py-10">
          <div className="inline-block animate-spin">⏳</div>
          <p className="mt-2 text-gray-600">Carregando qualificação...</p>
        </div>
      </div>
    );
  }

  if (error || !qualificacao) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <p className="text-red-800 font-medium">❌ {error || 'Qualificação não encontrada'}</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 text-blue-600 hover:text-blue-800 font-medium"
          >
            ← Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <button
          onClick={() => navigate(-1)}
          className="text-blue-600 hover:text-blue-800 font-medium mb-4 inline-flex items-center gap-1"
        >
          ← Voltar
        </button>

        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{qualificacao.nome}</h1>
            <p className="text-gray-600 mt-2">
              Código: <span className="font-mono font-semibold">{qualificacao.codigo}</span>
            </p>
          </div>
          <div
            className={`px-4 py-2 rounded-lg font-medium ${getStatusColor(qualificacao.status)}`}
          >
            {qualificacao.status}
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-xs text-gray-600 font-medium">Carga Horária</p>
            <p className="text-xl font-bold text-gray-900 mt-1">{qualificacao.carga_horaria}h</p>
          </div>
          <div className="bg-green-50 rounded-lg p-4">
            <p className="text-xs text-gray-600 font-medium">Conclusão</p>
            <p className="text-lg font-bold text-gray-900 mt-1">
              {qualificacao.data_conclusao
                ? new Date(qualificacao.data_conclusao).toLocaleDateString('pt-BR')
                : '—'}
            </p>
          </div>
          <div className="bg-orange-50 rounded-lg p-4">
            <p className="text-xs text-gray-600 font-medium">Vencimento</p>
            <p className="text-lg font-bold text-gray-900 mt-1">
              {qualificacao.data_vencimento
                ? new Date(qualificacao.data_vencimento).toLocaleDateString('pt-BR')
                : '—'}
            </p>
          </div>
          <div className="bg-purple-50 rounded-lg p-4">
            <p className="text-xs text-gray-600 font-medium">ID</p>
            <p className="text-lg font-bold text-gray-900 mt-1 font-mono">#{qualificacao.id}</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Certificados - Spanning 2 columns */}
        <div className="lg:col-span-2">
          <GerenciadorCertificados
            qualificacao_id={qualificacao.id}
            qualificacao_nome={qualificacao.nome}
          />
        </div>

        {/* Pasta Virtual - Sidebar */}
        <div>
          <PastaVirtualIntegrada
            qualificacao_id={qualificacao.id}
            funcionario_id={qualificacao.funcionario_id}
          />
        </div>
      </div>

      {/* Conteúdo Programático */}
      {qualificacao.conteudo_programatico && (
        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">📚 Conteúdo Programático</h3>
          <div className="bg-gray-50 rounded-lg p-4 max-h-80 overflow-y-auto">
            <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
              {qualificacao.conteudo_programatico}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}

export default PaginaQualificacao;
