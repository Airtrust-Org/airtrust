import React from 'react';
import { Edit, Trash2 } from 'lucide-react';
import { Funcionario } from '@/types';
import { Button, Badge } from '@/components/shared';
import { formatCPF, formatDate } from '@/utils';

interface FuncionariosListProps {
  funcionarios: Funcionario[];
  loading: boolean;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export const FuncionariosList: React.FC<FuncionariosListProps> = ({
  funcionarios,
  loading,
  onEdit,
  onDelete
}) => {
  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (funcionarios.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Nenhum funcionário encontrado</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Nome
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              CPF
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Matrícula
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Cargo
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Setor
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Admissão
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Ações
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {funcionarios.map((funcionario) => (
            <tr key={funcionario.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-gray-900">{funcionario.nome}</div>
                <div className="text-sm text-gray-500">{funcionario.email}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatCPF(funcionario.cpf)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {funcionario.matricula}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {funcionario.cargo}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {funcionario.setor}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <Badge variant={funcionario.ativo ? 'success' : 'error'}>
                  {funcionario.ativo ? 'Ativo' : 'Inativo'}
                </Badge>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatDate(funcionario.data_admissao)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onEdit(funcionario.id)}
                    icon={<Edit className="h-4 w-4" />}
                  >
                    Editar
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => onDelete(funcionario.id)}
                    icon={<Trash2 className="h-4 w-4" />}
                  >
                    Excluir
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
