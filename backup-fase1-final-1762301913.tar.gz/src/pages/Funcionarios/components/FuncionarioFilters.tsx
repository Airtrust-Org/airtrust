import React from 'react';
import { Search, Filter } from 'lucide-react';
import { FiltrosFuncionarios, CARGOS, SETORES } from '@/config/constants';

interface FuncionarioFiltersProps {
  filtros: FiltrosFuncionarios;
  onChange: (filtros: FiltrosFuncionarios) => void;
}

export const FuncionarioFilters: React.FC<FuncionarioFiltersProps> = ({
  filtros,
  onChange
}) => {
  const handleSearchChange = (value: string) => {
    onChange({ ...filtros, search: value });
  };

  const handleCargoChange = (value: string) => {
    onChange({ ...filtros, cargo: value || undefined });
  };

  const handleSetorChange = (value: string) => {
    onChange({ ...filtros, setor: value || undefined });
  };

  const handleAtivoChange = (value: string) => {
    onChange({
      ...filtros,
      ativo: value === '' ? undefined : value === 'true'
    });
  };

  return (
    <div className="flex flex-wrap gap-4">
      {/* Busca */}
      <div className="flex-1 min-w-[300px]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Buscar por nome, matrícula ou email..."
            value={filtros.search || ''}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Filtro por Cargo */}
      <div className="w-48">
        <select
          value={filtros.cargo || ''}
          onChange={(e) => handleCargoChange(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Todos os cargos</option>
          {CARGOS.map(cargo => (
            <option key={cargo.value} value={cargo.value}>
              {cargo.label}
            </option>
          ))}
        </select>
      </div>

      {/* Filtro por Setor */}
      <div className="w-48">
        <select
          value={filtros.setor || ''}
          onChange={(e) => handleSetorChange(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Todos os setores</option>
          {SETORES.map(setor => (
            <option key={setor.value} value={setor.value}>
              {setor.label}
            </option>
          ))}
        </select>
      </div>

      {/* Filtro por Status */}
      <div className="w-32">
        <select
          value={filtros.ativo === undefined ? '' : filtros.ativo.toString()}
          onChange={(e) => handleAtivoChange(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Todos</option>
          <option value="true">Ativos</option>
          <option value="false">Inativos</option>
        </select>
      </div>
    </div>
  );
};
