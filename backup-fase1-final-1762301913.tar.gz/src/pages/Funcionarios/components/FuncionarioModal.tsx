import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Funcionario, FuncionarioCreate } from '@/types';
import { Button, Card } from '@/components/shared';
import { CARGOS, SETORES } from '@/config/constants';

interface FuncionarioModalProps {
  funcionarioId?: string | null;
  onSave: (data: FuncionarioCreate) => Promise<void>;
  onClose: () => void;
}

export const FuncionarioModal: React.FC<FuncionarioModalProps> = ({
  funcionarioId,
  onSave,
  onClose
}) => {
  const [formData, setFormData] = useState<FuncionarioCreate>({
    nome: '',
    cpf: '',
    email: '',
    matricula: '',
    cargo: '',
    setor: '',
    ativo: true,
    data_admissao: new Date().toISOString().split('T')[0]
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (funcionarioId) {
    }
  }, [funcionarioId]);

  const handleInputChange = (field: keyof FuncionarioCreate, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));

    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.nome.trim()) newErrors.nome = 'Nome é obrigatório';
    if (!formData.cpf.trim()) newErrors.cpf = 'CPF é obrigatório';
    if (!formData.email.trim()) newErrors.email = 'Email é obrigatório';
    if (!formData.matricula.trim()) newErrors.matricula = 'Matrícula é obrigatória';
    if (!formData.cargo) newErrors.cargo = 'Cargo é obrigatório';
    if (!formData.setor) newErrors.setor = 'Setor é obrigatório';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);
    try {
      await onSave(formData);
    } catch (error) {
      console.error('Erro ao salvar funcionário:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            {funcionarioId ? 'Editar Funcionário' : 'Novo Funcionário'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nome */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nome Completo *
            </label>
            <input
              type="text"
              value={formData.nome}
              onChange={(e) => handleInputChange('nome', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.nome ? 'border-red-300' : 'border-gray-300'
              }`}
              placeholder="Digite o nome completo"
            />
            {errors.nome && (
              <p className="mt-1 text-sm text-red-600">{errors.nome}</p>
            )}
          </div>

          {/* CPF e Email */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CPF *
              </label>
              <input
                type="text"
                value={formData.cpf}
                onChange={(e) => handleInputChange('cpf', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.cpf ? 'border-red-300' : 'border-gray-300'
                }`}
                placeholder="000.000.000-00"
              />
              {errors.cpf && (
                <p className="mt-1 text-sm text-red-600">{errors.cpf}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.email ? 'border-red-300' : 'border-gray-300'
                }`}
                placeholder="email@exemplo.com"
              />
              {errors.email && (
                <p className="mt-1 text-sm text-red-600">{errors.email}</p>
              )}
            </div>
          </div>

          {/* Matrícula */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Matrícula *
            </label>
            <input
              type="text"
              value={formData.matricula}
              onChange={(e) => handleInputChange('matricula', e.target.value)}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.matricula ? 'border-red-300' : 'border-gray-300'
              }`}
              placeholder="Digite a matrícula"
            />
            {errors.matricula && (
              <p className="mt-1 text-sm text-red-600">{errors.matricula}</p>
            )}
          </div>

          {/* Cargo e Setor */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cargo *
              </label>
              <select
                value={formData.cargo}
                onChange={(e) => handleInputChange('cargo', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.cargo ? 'border-red-300' : 'border-gray-300'
                }`}
              >
                <option value="">Selecione o cargo</option>
                {CARGOS.map(cargo => (
                  <option key={cargo.value} value={cargo.value}>
                    {cargo.label}
                  </option>
                ))}
              </select>
              {errors.cargo && (
                <p className="mt-1 text-sm text-red-600">{errors.cargo}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Setor *
              </label>
              <select
                value={formData.setor}
                onChange={(e) => handleInputChange('setor', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  errors.setor ? 'border-red-300' : 'border-gray-300'
                }`}
              >
                <option value="">Selecione o setor</option>
                {SETORES.map(setor => (
                  <option key={setor.value} value={setor.value}>
                    {setor.label}
                  </option>
                ))}
              </select>
              {errors.setor && (
                <p className="mt-1 text-sm text-red-600">{errors.setor}</p>
              )}
            </div>
          </div>

          {/* Data de Admissão e Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data de Admissão
              </label>
              <input
                type="date"
                value={formData.data_admissao}
                onChange={(e) => handleInputChange('data_admissao', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.ativo}
                  onChange={(e) => handleInputChange('ativo', e.target.checked)}
                  className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <span className="text-sm font-medium text-gray-700">
                  Funcionário Ativo
                </span>
              </label>
            </div>
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-3 pt-6">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              loading={loading}
            >
              {funcionarioId ? 'Atualizar' : 'Criar'} Funcionário
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};
