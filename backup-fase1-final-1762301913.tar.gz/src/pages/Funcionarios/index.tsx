import { useState, useMemo } from 'react';
import { Plus, Search, Filter } from 'lucide-react';
import { useFuncionarios } from '@/hooks';
import { FuncionariosList, FuncionarioModal, FuncionarioFilters } from './components';
import { Button, Card, LoadingSpinner, ErrorMessage } from '@/components/shared';
import { FiltrosFuncionarios } from '@/types';

export default function Funcionarios() {
  const { funcionarios, loading, error, criar, atualizar, excluir } = useFuncionarios();
  const [showModal, setShowModal] = useState(false);
  const [editingFuncionario, setEditingFuncionario] = useState<string | null>(null);
  const [filtros, setFiltros] = useState<FiltrosFuncionarios>({});

  const funcionariosFiltrados = useMemo(
    () => aplicarFiltros(funcionarios, filtros),
    [funcionarios, filtros]
  );

  const handleCreate = async (data: any) => {
    try {
      await criar(data);
      setShowModal(false);
    } catch (error) {
      console.error('Erro ao criar funcionário:', error);
    }
  };

  const handleEdit = (id: string) => {
    setEditingFuncionario(id);
    setShowModal(true);
  };

  const handleUpdate = async (data: any) => {
    if (!editingFuncionario) return;

    try {
      await atualizar(editingFuncionario, data);
      setShowModal(false);
      setEditingFuncionario(null);
    } catch (error) {
      console.error('Erro ao atualizar funcionário:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deseja realmente excluir este funcionário?')) return;

    try {
      await excluir(id);
    } catch (error) {
      console.error('Erro ao excluir funcionário:', error);
    }
  };

  if (loading && funcionarios.length === 0) {
    return (
      <div className="p-6">
        <LoadingSpinner text="Carregando funcionários..." />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Funcionários</h1>
            <p className="text-gray-600 mt-1">
              Gerencie os funcionários da empresa
            </p>
          </div>

          <Button
            onClick={() => setShowModal(true)}
            icon={<Plus className="h-4 w-4" />}
          >
            Novo Funcionário
          </Button>
        </div>
      </Card>

      {/* Filtros */}
      <Card className="p-6">
        <FuncionarioFilters
          filtros={filtros}
          onChange={setFiltros}
        />
      </Card>

      {/* Lista de Funcionários */}
      <Card className="p-6">
        {error && (
          <ErrorMessage
            message={error}
            onClose={() => window.location.reload()}
            className="mb-6"
          />
        )}

        <FuncionariosList
          funcionarios={funcionariosFiltrados}
          loading={loading}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </Card>

      {/* Modal */}
      {showModal && (
        <FuncionarioModal
          funcionarioId={editingFuncionario}
          onSave={editingFuncionario ? handleUpdate : handleCreate}
          onClose={() => {
            setShowModal(false);
            setEditingFuncionario(null);
          }}
        />
      )}
    </div>
  );
}

function aplicarFiltros(funcionarios: any[], filtros: FiltrosFuncionarios) {
  return funcionarios.filter(funcionario => {
    if (filtros.search) {
      const searchLower = filtros.search.toLowerCase();
      const matchesSearch =
        funcionario.nome.toLowerCase().includes(searchLower) ||
        funcionario.matricula.toLowerCase().includes(searchLower) ||
        funcionario.email.toLowerCase().includes(searchLower);

      if (!matchesSearch) return false;
    }

    if (filtros.cargo && funcionario.cargo !== filtros.cargo) {
      return false;
    }

    if (filtros.setor && funcionario.setor !== filtros.setor) {
      return false;
    }

    if (filtros.ativo !== undefined && funcionario.ativo !== filtros.ativo) {
      return false;
    }

    return true;
  });
}
