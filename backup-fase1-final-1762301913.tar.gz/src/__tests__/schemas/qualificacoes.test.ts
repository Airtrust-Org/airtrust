/**
 * Testes dos Schemas Zod de Qualificações
 */

import { describe, it, expect } from 'vitest';
import {
  QualificacaoSchema,
  CriarQualificacaoSchema,
  AtualizarQualificacaoSchema,
  TipoQualificacaoEnum,
  StatusQualificacaoEnum,
  validarQualificacao,
  validarAtualizacaoQualificacao,
} from '../../schemas/qualificacoes.schema';

describe('Schemas - Qualificações', () => {
  describe('CriarQualificacaoSchema', () => {
    it('deve validar dados válidos de treinamento', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
        data_conclusao: '2025-11-01',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });

    it('deve validar dados válidos de exame', () => {
      const dados = {
        funcionario_id: 2,
        tipo: 'EXAME' as const,
        codigo: 'EXM-001',
        data_conclusao: '2025-11-01',
        data_vencimento: '2026-11-01',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });

    it('deve validar dados válidos de check', () => {
      const dados = {
        funcionario_id: 3,
        tipo: 'CHECK' as const,
        codigo: 'CHK-001',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });

    it('deve rejeitar tipo inválido', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'INVALIDO',
        codigo: 'TRN-001',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error.errors[0].path).toContain('tipo');
      }
    });

    it('deve rejeitar funcionario_id negativo', () => {
      const dados = {
        funcionario_id: -1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(false);
    });

    it('deve rejeitar funcionario_id não número', () => {
      const dados = {
        funcionario_id: 'abc',
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(false);
    });

    it('deve rejeitar código vazio', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: '',
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(false);
    });

    it('deve rejeitar data inválida', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
        data_conclusao: '01/11/2025', // Formato errado
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(false);
    });

    it('deve aceitar campos opcionais', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
        nome: 'Treinamento de Segurança',
        descricao: 'Descrição do treinamento',
        instituicao: 'ANAC',
        instrutor: 'João Silva',
        carga_horaria: 40,
      };
      const result = CriarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });
  });

  describe('AtualizarQualificacaoSchema', () => {
    it('deve permitir atualização parcial', () => {
      const dados = {
        nome: 'Novo Nome',
      };
      const result = AtualizarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });

    it('deve permitir atualizar múltiplos campos', () => {
      const dados = {
        nome: 'Novo Nome',
        data_conclusao: '2025-11-01',
        data_vencimento: '2026-11-01',
      };
      const result = AtualizarQualificacaoSchema.safeParse(dados);
      expect(result.success).toBe(true);
    });

    it('não deve permitir atualizar funcionario_id', () => {
      const dados = {
        funcionario_id: 999,
        nome: 'Novo Nome',
      };
      const result = AtualizarQualificacaoSchema.safeParse(dados);
      // funcionario_id deve ser ignorado
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).not.toHaveProperty('funcionario_id');
      }
    });
  });

  describe('QualificacaoSchema (Response)', () => {
    it('deve validar entidade completa', () => {
      const entidade = {
        id: 1,
        funcionario_id: 1,
        funcionario_nome: 'João Silva',
        funcionario_matricula: '12345',
        tipo: 'EXAME' as const,
        codigo: 'EXM-001',
        status: 'VALIDA' as const,
        data_conclusao: '2025-11-01',
        data_vencimento: '2026-11-01',
        validade_meses: 12,
        dias_para_vencimento: 365,
        is_renovada: false,
        instituicao: null,
        instrutor: null,
        checador: null,
        carga_horaria: null,
        numero: null,
        resultado: null,
        observacoes: null,
        certificado_url: null,
        created_at: new Date().toISOString(),
        deleted_at: null,
      };
      const result = QualificacaoSchema.safeParse(entidade);
      expect(result.success).toBe(true);
    });

    it('deve aceitar campos opcionais como null', () => {
      const entidade = {
        id: 1,
        funcionario_id: 1,
        funcionario_nome: 'João Silva',
        funcionario_matricula: '12345',
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
        status: 'VENCIDA' as const,
        data_conclusao: null,
        data_vencimento: null,
        validade_meses: 12,
        dias_para_vencimento: null,
        is_renovada: false,
        instituicao: null,
        instrutor: null,
        checador: null,
        carga_horaria: null,
        numero: null,
        resultado: null,
        observacoes: null,
        certificado_url: null,
        created_at: new Date().toISOString(),
        deleted_at: null,
      };
      const result = QualificacaoSchema.safeParse(entidade);
      expect(result.success).toBe(true);
    });
  });

  describe('Enums', () => {
    it('TipoQualificacaoEnum deve aceitar valores válidos', () => {
      expect(TipoQualificacaoEnum.safeParse('TREINAMENTO').success).toBe(true);
      expect(TipoQualificacaoEnum.safeParse('EXAME').success).toBe(true);
      expect(TipoQualificacaoEnum.safeParse('CHECK').success).toBe(true);
    });

    it('TipoQualificacaoEnum deve rejeitar valores inválidos', () => {
      expect(TipoQualificacaoEnum.safeParse('INVALIDO').success).toBe(false);
      expect(TipoQualificacaoEnum.safeParse('treinamento').success).toBe(false);
    });

    it('StatusQualificacaoEnum deve aceitar valores válidos', () => {
      expect(StatusQualificacaoEnum.safeParse('VALIDA').success).toBe(true);
      expect(StatusQualificacaoEnum.safeParse('VENCENDO').success).toBe(true);
      expect(StatusQualificacaoEnum.safeParse('VENCIDA').success).toBe(true);
      expect(StatusQualificacaoEnum.safeParse('RENOVADA').success).toBe(true);
    });
  });

  describe('Helpers de Validação', () => {
    it('validarQualificacao deve retornar success true para dados válidos', () => {
      const dados = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
      };
      const result = validarQualificacao(dados);
      expect(result.success).toBe(true);
    });

    it('validarQualificacao deve retornar success false para dados inválidos', () => {
      const dados = {
        funcionario_id: 'abc',
        tipo: 'INVALIDO',
      };
      const result = validarQualificacao(dados);
      expect(result.success).toBe(false);
    });

    it('validarAtualizacaoQualificacao deve aceitar atualização parcial', () => {
      const dados = {
        nome: 'Novo Nome',
      };
      const result = validarAtualizacaoQualificacao(dados);
      expect(result.success).toBe(true);
    });
  });
});
