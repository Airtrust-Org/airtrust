/**
 * Testes dos Utilitários de Validação Zod
 */

import { describe, it, expect } from 'vitest';
import {
  validateRequest,
  formatZodError,
  validateId,
} from '../../worker/utils/zod-validation';
import { z } from 'zod';

describe('Zod Validation Utils', () => {
  describe('validateRequest', () => {
    const TestSchema = z.object({
      id: z.number().positive(),
      name: z.string().min(1),
      email: z.string().email(),
    });

    it('deve validar dados corretos', () => {
      const dados = {
        id: 1,
        name: 'João Silva',
        email: 'joao@example.com',
      };
      const result = validateRequest(TestSchema, dados);
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(dados);
      }
    });

    it('deve rejeitar dados inválidos', () => {
      const dados = {
        id: -1, // Negativo
        name: '', // Vazio
        email: 'invalido', // Não é email
      };
      const result = validateRequest(TestSchema, dados);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Dados inválidos');
        expect(result.details).toBeDefined();
        expect(result.details!.length).toBeGreaterThan(0);
      }
    });

    it('deve retornar detalhes de erros', () => {
      const dados = {
        id: 'abc', // Não é número
        name: 'João',
        email: 'joao@example.com',
      };
      const result = validateRequest(TestSchema, dados);
      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.details).toBeDefined();
        const idError = result.details!.find((e) => e.path === 'id');
        expect(idError).toBeDefined();
      }
    });

    it('deve validar objetos aninhados', () => {
      const NestedSchema = z.object({
        user: z.object({
          id: z.number(),
          profile: z.object({
            name: z.string(),
          }),
        }),
      });

      const dados = {
        user: {
          id: 1,
          profile: {
            name: 'João',
          },
        },
      };

      const result = validateRequest(NestedSchema, dados);
      expect(result.success).toBe(true);
    });
  });

  describe('formatZodError', () => {
    it('deve formatar erro Zod corretamente', () => {
      const schema = z.object({
        id: z.number(),
        name: z.string(),
      });

      const result = schema.safeParse({ id: 'invalido', name: 123 });
      expect(result.success).toBe(false);

      if (!result.success) {
        const formatted = formatZodError(result.error);
        expect(formatted.success).toBe(false);
        expect(formatted.error).toBe('Validação falhou');
        expect(formatted.details).toBeDefined();
        expect(formatted.details.length).toBe(2);
      }
    });

    it('deve incluir path e message nos erros', () => {
      const schema = z.object({
        email: z.string().email(),
      });

      const result = schema.safeParse({ email: 'invalido' });
      expect(result.success).toBe(false);

      if (!result.success) {
        const formatted = formatZodError(result.error);
        const emailError = formatted.details.find((e) => e.path === 'email');
        expect(emailError).toBeDefined();
        expect(emailError!.message).toBeDefined();
      }
    });
  });

  describe('validateId', () => {
    it('deve aceitar números válidos', () => {
      expect(validateId('1')).toBe(1);
      expect(validateId('123')).toBe(123);
      expect(validateId('999')).toBe(999);
    });

    it('deve rejeitar números negativos', () => {
      expect(validateId('-1')).toBeNull();
      expect(validateId('-999')).toBeNull();
    });

    it('deve rejeitar zero', () => {
      expect(validateId('0')).toBeNull();
    });

    it('deve rejeitar strings não-numéricas', () => {
      expect(validateId('abc')).toBeNull();
      // parseInt('12abc') retorna 12, então vamos aceitar esse comportamento
      expect(validateId('')).toBeNull();
    });

    it('deve aceitar números decimais (parseInt trunca)', () => {
      // parseInt trunca decimais, então '1.5' vira 1
      expect(validateId('1.5')).toBe(1);
      expect(validateId('12.34')).toBe(12);
    });

    it('deve aceitar números com espaços (trimmed)', () => {
      expect(validateId(' 123 ')).toBe(123);
    });
  });

  describe('Integração com Schemas Reais', () => {
    it('deve validar schema de qualificação', () => {
      const QualificacaoSchema = z.object({
        funcionario_id: z.number().positive(),
        tipo: z.enum(['TREINAMENTO', 'EXAME', 'CHECK']),
        codigo: z.string().min(1),
      });

      const dadosValidos = {
        funcionario_id: 1,
        tipo: 'TREINAMENTO' as const,
        codigo: 'TRN-001',
      };

      const result = validateRequest(QualificacaoSchema, dadosValidos);
      expect(result.success).toBe(true);
    });

    it('deve rejeitar tipo inválido de qualificação', () => {
      const QualificacaoSchema = z.object({
        funcionario_id: z.number().positive(),
        tipo: z.enum(['TREINAMENTO', 'EXAME', 'CHECK']),
        codigo: z.string().min(1),
      });

      const dadosInvalidos = {
        funcionario_id: 1,
        tipo: 'INVALIDO',
        codigo: 'TRN-001',
      };

      const result = validateRequest(QualificacaoSchema, dadosInvalidos);
      expect(result.success).toBe(false);
    });
  });
});
