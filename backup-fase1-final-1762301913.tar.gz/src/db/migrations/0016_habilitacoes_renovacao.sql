-- Migration: 0016_habilitacoes_renovacao.sql
-- Adicionar colunas de rastreamento de renovações

ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS habilitacao_anterior_id INTEGER;
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS eh_renovada BOOLEAN DEFAULT FALSE;
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS renovada_em TIMESTAMP;

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_habilitacoes_anterior ON habilitacoes(habilitacao_anterior_id);
CREATE INDEX IF NOT EXISTS idx_habilitacoes_renovada ON habilitacoes(eh_renovada);
