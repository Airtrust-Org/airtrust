import axios from 'axios';

const BASE_URL = `${window.location.origin}/api/v2`;

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    console.error('Erro na API:', error);
    throw error;
  }
);

export default api;
