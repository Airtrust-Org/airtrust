import api from './api';
import { Funcionario, FuncionarioCreate, FuncionarioUpdate, ImportResult, FiltrosFuncionarios, PaginacaoParams } from '@/types';

export const funcionariosService = {
  listar: async (filtros?: FiltrosFuncionarios, paginacao?: PaginacaoParams): Promise<Funcionario[]> => {
    const params = new URLSearchParams();

    if (filtros?.search) params.append('search', filtros.search);
    if (filtros?.cargo) params.append('cargo', filtros.cargo);
    if (filtros?.setor) params.append('setor', filtros.setor);
    if (filtros?.ativo !== undefined) params.append('ativo', filtros.ativo.toString());
    if (paginacao?.page) params.append('page', paginacao.page.toString());
    if (paginacao?.limit) params.append('limit', paginacao.limit.toString());

    const response = await api.get(`/funcionarios?${params}`);
    return response.funcionarios || response.data || [];
  },

  buscarPorId: async (id: string | number): Promise<Funcionario> => {
    const response = await api.get(`/funcionarios/${id}`);
    return response.funcionario || response.data;
  },

  criar: async (data: FuncionarioCreate): Promise<Funcionario> => {
    const response = await api.post('/funcionarios', data);
    return response.funcionario || response.data;
  },

  atualizar: async (id: string | number, data: FuncionarioUpdate): Promise<Funcionario> => {
    const response = await api.put(`/funcionarios/${id}`, data);
    return response.funcionario || response.data;
  },

  excluir: async (id: string | number): Promise<void> => {
    return api.delete(`/funcionarios/${id}`);
  },

  importar: async (file: File): Promise<ImportResult> => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/funcionarios/import', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },

  exportar: async (): Promise<Blob> => {
    return api.get('/funcionarios/export', { responseType: 'blob' });
  }
};
