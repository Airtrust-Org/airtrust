/**
 * Logger Estruturado
 * Substitui console.log por logs com níveis e contexto
 */

export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR',
  SUCCESS = 'SUCCESS'
}

interface LogContext {
  [key: string]: any;
}

class StructuredLogger {
  private formatLog(level: LogLevel, message: string, context?: LogContext): string {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      message,
      ...(context && { context })
    };
    return JSON.stringify(logEntry);
  }

  debug(message: string, context?: LogContext) {
  }

  info(message: string, context?: LogContext) {
  }

  warn(message: string, context?: LogContext) {
    console.warn(this.formatLog(LogLevel.WARN, message, context));
  }

  error(message: string, error?: Error | any, context?: LogContext) {
    const errorContext = {
      ...context,
      error: {
        message: error?.message,
        stack: error?.stack,
        name: error?.name
      }
    };
    console.error(this.formatLog(LogLevel.ERROR, message, errorContext));
  }

  success(message: string, context?: LogContext) {
  }
}

export const Logger = new StructuredLogger();
