export interface ExpirationAlert {
  type: 'CMA' | 'ASO' | 'CERTIFICACAO' | 'NIVEL_ICAO';
  funcionario: {
    id: number;
    matricula: string;
    nome: string;
    email: string | null;
  };
  details: {
    categoria?: string;
    numero?: string;
    vencimento: string;
  };
  daysUntilExpiration: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
}

export async function getExpiringItems(db: any): Promise<ExpirationAlert[]> {
  const alerts: ExpirationAlert[] = [];
  
  const today = new Date();
  const thirtyDays = new Date(today);
  thirtyDays.setDate(today.getDate() + 30);
  
  const todayStr = today.toISOString().split('T')[0];
  const thirtyDaysStr = thirtyDays.toISOString().split('T')[0];
  
  const certifications = await db
    .prepare(`
      SELECT 
        f.id, f.matricula, f.nome, f.email,
        q.categoria, q.data_vencimento
      FROM qualificacoes q
      JOIN funcionarios f ON q.funcionario_id = f.id
      WHERE q.deleted_at IS NULL
        AND f.deleted_at IS NULL
        AND q.data_vencimento <= ?
        AND q.data_vencimento >= ?
    `)
    .bind(thirtyDaysStr, todayStr)
    .all();
  
  for (const cert of certifications.results) {
    const daysUntil = getDaysDifference(today, new Date(cert.data_vencimento as string));
    alerts.push({
      type: 'CERTIFICACAO',
      funcionario: {
        id: cert.id as number,
        matricula: cert.matricula as string,
        nome: cert.nome as string,
        email: cert.email as string | null,
      },
      details: {
        categoria: cert.categoria as string,
        vencimento: cert.data_vencimento as string,
      },
      daysUntilExpiration: daysUntil,
      urgency: getUrgency(daysUntil),
    });
  }
  
  const cmas = await db
    .prepare(`
      SELECT 
        id, matricula, nome, email,
        cma_numero, cma_data_vencimento
      FROM funcionarios
      WHERE deleted_at IS NULL
        AND cma_data_vencimento IS NOT NULL
        AND cma_data_vencimento <= ?
        AND cma_data_vencimento >= ?
    `)
    .bind(thirtyDaysStr, todayStr)
    .all();
  
  for (const cma of cmas.results) {
    const daysUntil = getDaysDifference(today, new Date(cma.cma_data_vencimento as string));
    alerts.push({
      type: 'CMA',
      funcionario: {
        id: cma.id as number,
        matricula: cma.matricula as string,
        nome: cma.nome as string,
        email: cma.email as string | null,
      },
      details: {
        numero: cma.cma_numero as string,
        vencimento: cma.cma_data_vencimento as string,
      },
      daysUntilExpiration: daysUntil,
      urgency: getUrgency(daysUntil),
    });
  }
  
  const asos = await db
    .prepare(`
      SELECT 
        id, matricula, nome, email,
        aso_data_vencimento
      FROM funcionarios
      WHERE deleted_at IS NULL
        AND aso_data_vencimento IS NOT NULL
        AND aso_data_vencimento <= ?
        AND aso_data_vencimento >= ?
    `)
    .bind(thirtyDaysStr, todayStr)
    .all();
  
  for (const aso of asos.results) {
    const daysUntil = getDaysDifference(today, new Date(aso.aso_data_vencimento as string));
    alerts.push({
      type: 'ASO',
      funcionario: {
        id: aso.id as number,
        matricula: aso.matricula as string,
        nome: aso.nome as string,
        email: aso.email as string | null,
      },
      details: {
        vencimento: aso.aso_data_vencimento as string,
      },
      daysUntilExpiration: daysUntil,
      urgency: getUrgency(daysUntil),
    });
  }
  
  const icaos = await db
    .prepare(`
      SELECT 
        id, matricula, nome, email,
        nivel_icao, nivel_icao_data_vencimento
      FROM funcionarios
      WHERE deleted_at IS NULL
        AND nivel_icao_data_vencimento IS NOT NULL
        AND nivel_icao_data_vencimento <= ?
        AND nivel_icao_data_vencimento >= ?
    `)
    .bind(thirtyDaysStr, todayStr)
    .all();
  
  for (const icao of icaos.results) {
    const daysUntil = getDaysDifference(today, new Date(icao.nivel_icao_data_vencimento as string));
    alerts.push({
      type: 'NIVEL_ICAO',
      funcionario: {
        id: icao.id as number,
        matricula: icao.matricula as string,
        nome: icao.nome as string,
        email: icao.email as string | null,
      },
      details: {
        categoria: icao.nivel_icao as string,
        vencimento: icao.nivel_icao_data_vencimento as string,
      },
      daysUntilExpiration: daysUntil,
      urgency: getUrgency(daysUntil),
    });
  }
  
  return alerts.sort((a, b) => a.daysUntilExpiration - b.daysUntilExpiration);
}

function getDaysDifference(from: Date, to: Date): number {
  const diff = to.getTime() - from.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function getUrgency(days: number): 'low' | 'medium' | 'high' | 'critical' {
  if (days <= 0) return 'critical';
  if (days <= 7) return 'high';
  if (days <= 15) return 'medium';
  return 'low';
}
