/**
 * Biblioteca completa de formatação - AirTrust
 * Backend: limpa e padroniza dados para armazenamento
 */

function apenasNumeros(valor: any): string {
  if (!valor) return '';
  return String(valor).replace(/\D/g, '');
}

/**
 * CPF: 12345678901 → armazena sem formatação
 * Exibição: 123.456.789-01
 */
export function limparCPF(cpf: any): string {
  const numeros = apenasNumeros(cpf);
  return numeros.length === 11 ? numeros : '';
}

export function formatarCPF(cpf: any): string {
  const numeros = apenasNumeros(cpf);
  if (numeros.length !== 11) return numeros;
  return numeros.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

/**
 * Telefone: 11984468788 → armazena sem formatação
 * Exibição: (11) 98446-8788
 */
export function limparTelefone(telefone: any): string {
  return apenasNumeros(telefone);
}

export function formatarTelefone(telefone: any): string {
  const numeros = apenasNumeros(telefone);
  if (!numeros) return '';
  
  if (numeros.length === 11) {
    return numeros.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  }
  
  if (numeros.length === 10) {
    return numeros.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  }
  
  return numeros;
}

/**
 * Código ANAC: 951681 → armazena com 7 dígitos
 * Exibição: 95168-1
 */
export function formatarCodigoANAC(codigo: any): string {
  const numeros = apenasNumeros(codigo);
  if (!numeros) return '';
  
  if (numeros.length === 7) {
    return numeros.replace(/(\d{6})(\d{1})/, '$1-$2');
  }
  
  if (numeros.length === 6) {
    return numeros.substring(0, 5) + '-' + numeros[5];
  }
  
  return numeros.padStart(7, '0');
}

export function limparCodigoANAC(codigo: any): string {
  return apenasNumeros(codigo).padStart(7, '0').substring(0, 7);
}

/**
 * Matrícula: 00300 → sempre 5 dígitos
 */
export function formatarMatricula(matricula: any): string {
  const numeros = apenasNumeros(matricula);
  if (!numeros) return '';
  return numeros.padStart(5, '0').substring(0, 5);
}

/**
 * Sispat: 47700622 → sempre 8 dígitos
 */
export function formatarSispat(sispat: any): string {
  const numeros = apenasNumeros(sispat);
  if (!numeros) return '';
  return numeros.padStart(8, '0').substring(0, 8);
}

/**
 * Código SISPAT: 47700622 → sempre 8 dígitos
 */
export function formatarCodigoSISPAT(codigo: any): string {
  const numeros = apenasNumeros(codigo);
  if (!numeros) return '';
  return numeros.padStart(8, '0').substring(0, 8);
}

/**
 * Código PrestServ: 4600669316 → sempre 10 dígitos
 */
export function formatarCodigoPrestServ(codigo: any): string {
  const numeros = apenasNumeros(codigo);
  if (!numeros) return '';
  return numeros.padStart(10, '0').substring(0, 10);
}

/**
 * Prestserv: 4600669316 → sempre 10 dígitos
 */
export function formatarPrestserv(prestserv: any): string {
  const numeros = apenasNumeros(prestserv);
  if (!numeros) return '';
  return numeros.padStart(10, '0').substring(0, 10);
}

/**
 * Nome: formata nome próprio com primeira letra maiúscula
 * Exemplo: "JOÃO DA SILVA" → "João da Silva"
 */
export function formatarNome(nome: any): string {
  if (!nome) return '';
  const limpo = String(nome).trim();
  return limpo
    .toLowerCase()
    .split(' ')
    .map(palavra => {
      if (palavra.length <= 2) return palavra.toLowerCase(); // de, da, do, e, etc.
      return palavra.charAt(0).toUpperCase() + palavra.slice(1);
    })
    .join(' ');
}

/**
 * Converter data serial do Excel para formato DD/MM/YYYY
 * Excel armazena datas como números (dias desde 01/01/1900)
 */
export function converterDataExcel(serial: any): string {
  if (!serial) return '';
  
  if (typeof serial === 'string' && serial.includes('/')) {
    return serial;
  }
  
  if (typeof serial === 'number') {
    const excelEpoch = new Date(1899, 11, 30); // 30/12/1899
    const dias = Math.floor(serial);
    const dataJS = new Date(excelEpoch.getTime() + dias * 24 * 60 * 60 * 1000);
    
    const dia = String(dataJS.getDate()).padStart(2, '0');
    const mes = String(dataJS.getMonth() + 1).padStart(2, '0');
    const ano = dataJS.getFullYear();
    
    return `${dia}/${mes}/${ano}`;
  }
  
  return String(serial).trim();
}

/**
 * Data: converte DD/MM/AAAA para AAAA-MM-DD (formato ISO)
 */
export function formatarDataParaISO(data: any): string | null {
  if (!data) return null;
  
  if (String(data).match(/^\d{4}-\d{2}-\d{2}$/)) {
    return String(data);
  }
  
  const match = String(data).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (match) {
    const [, dia, mes, ano] = match;
    return `${ano}-${mes}-${dia}`;
  }
  
  return null;
}

/**
 * Aplica formatação completa a todos os campos de funcionário
 */
export function formatarDadosFuncionario(dados: any): any {
  return {
    ...dados,
    cpf: dados.cpf ? limparCPF(dados.cpf) : null,
    telefone: dados.telefone ? limparTelefone(dados.telefone) : null,
    codigo_anac: dados.codigo_anac ? limparCodigoANAC(dados.codigo_anac) : null,
    codigo_canac: dados.codigo_canac ? limparCodigoANAC(dados.codigo_canac) : null,
    matricula: dados.matricula ? formatarMatricula(dados.matricula) : null,
    sispat: dados.sispat ? formatarSispat(dados.sispat) : null,
    codigo_sispat: dados.codigo_sispat ? formatarCodigoSISPAT(dados.codigo_sispat) : null,
    prestserv: dados.prestserv ? formatarPrestserv(dados.prestserv) : null,
    codigo_prestserv: dados.codigo_prestserv ? formatarCodigoPrestServ(dados.codigo_prestserv) : null,
    data_nasc: dados.data_nasc ? formatarDataParaISO(dados.data_nasc) : null,
    data_nascimento: dados.data_nascimento ? formatarDataParaISO(dados.data_nascimento) : null,
    data_admissao: dados.data_admissao ? formatarDataParaISO(dados.data_admissao) : null,
    validade_icao: dados.validade_icao ? formatarDataParaISO(dados.validade_icao) : null,
    nivel_icao_datavencimento: dados.nivel_icao_datavencimento ? formatarDataParaISO(dados.nivel_icao_datavencimento) : null,
    validade_cma: dados.validade_cma ? formatarDataParaISO(dados.validade_cma) : null,
    cma_datavencimento: dados.cma_datavencimento ? formatarDataParaISO(dados.cma_datavencimento) : null,
    validade_aso: dados.validade_aso ? formatarDataParaISO(dados.validade_aso) : null,
    aso_datavencimento: dados.aso_datavencimento ? formatarDataParaISO(dados.aso_datavencimento) : null
  };
}
