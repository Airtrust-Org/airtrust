/**
 * Sanitização de Nomes de Arquivo
 * Remove caracteres especiais, acentos, espaços
 * Garante compatibilidade com R2 e sistemas de arquivo
 */

export function sanitizeFileName(fileName: string): string {
  if (!fileName) return 'arquivo_sem_nome';

  return (
    fileName
      // Remover acentos
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      // Remover caracteres especiais, manter apenas alphanumericos, ponto, hífen, underscore
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      // Remover underscores múltiplos
      .replace(/_+/g, '_')
      // Remover underscore no início e fim
      .replace(/^_|_$/g, '')
      // Limitar comprimento a 255 caracteres
      .substring(0, 255)
      // Remover múltiplos pontos consecutivos
      .replace(/\.{2,}/g, '.')
      // Garantir que não comece com ponto
      .replace(/^\.+/, '')
  );
}

/**
 * Gerar nome de arquivo padronizado para certificado
 * Nomenclatura: CERT-{matricula}-{codigo_qualificacao}-{data}.pdf
 * Exemplo: CERT-001234-CMA-20251102.pdf
 */
export function gerarNomeCertificadoPadrao(
  matricula: string,
  codigoQualificacao: string,
  dataConclusao?: string | Date
): string {
  const sanitizedMatricula = sanitizeFileName(matricula).replace(/[^a-zA-Z0-9]/g, '');
  const sanitizedCodigo = sanitizeFileName(codigoQualificacao).replace(/[^a-zA-Z0-9]/g, '');
  
  let data = new Date().toISOString().split('T')[0].replace(/-/g, '');
  
  if (dataConclusao) {
    const d = new Date(dataConclusao);
    data = d.toISOString().split('T')[0].replace(/-/g, '');
  }

  return `CERT-${sanitizedMatricula}-${sanitizedCodigo}-${data}.pdf`;
}

/**
 * Validar se nome de arquivo é seguro
 * Retorna true se seguro para armazenar
 */
export function isFileNameSafe(fileName: string): boolean {
  if (!fileName || fileName.length === 0) return false;
  if (fileName.length > 255) return false;
  
  // Não permitir path traversal
  if (fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
    return false;
  }
  
  // Não permitir caracteres de controle
  if (/[\x00-\x1f\x7f]/.test(fileName)) {
    return false;
  }

  return true;
}
