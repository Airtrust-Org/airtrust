
export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  AUDIT = 4
}

export interface LogContext {
  userId?: string;
  ip?: string;
  userAgent?: string;
  path?: string;
  method?: string;
  duration?: number;
  [key: string]: any;
}

export class Logger {
  private static level: LogLevel = LogLevel.INFO;
  private static isProduction = false;

  static setLevel(level: LogLevel): void {
    this.level = level;
  }

  static setProduction(isProduction: boolean): void {
    this.isProduction = isProduction;
  }

  private static shouldLog(level: LogLevel): boolean {
    return level >= this.level;
  }

  private static formatMessage(level: string, message: string, context?: LogContext): string {
    const timestamp = new Date().toISOString();
    const contextStr = context ? ` | ${JSON.stringify(context)}` : '';
    return `[${level}] ${timestamp} - ${message}${contextStr}`;
  }

  static debug(message: string, context?: LogContext): void {
    if (!this.shouldLog(LogLevel.DEBUG)) return;
    
    if (this.isProduction) {
      return;
    }
    
    console.debug(this.formatMessage('DEBUG', message, context));
  }

  static info(message: string, context?: LogContext): void {
    if (!this.shouldLog(LogLevel.INFO)) return;
    
    if (this.isProduction) {
      console.log(JSON.stringify({
        level: 'info',
        timestamp: new Date().toISOString(),
        message,
        ...context
      }));
    } else {
    }
  }

  static warn(message: string, context?: LogContext): void {
    if (!this.shouldLog(LogLevel.WARN)) return;
    
    if (this.isProduction) {
      console.warn(JSON.stringify({
        level: 'warn',
        timestamp: new Date().toISOString(),
        message,
        ...context
      }));
    } else {
      console.warn(this.formatMessage('WARN', message, context));
    }
  }

  static error(message: string, error?: Error | any, context?: LogContext): void {
    if (!this.shouldLog(LogLevel.ERROR)) return;
    
    const errorInfo = error instanceof Error ? {
      name: error.name,
      message: error.message,
      stack: error.stack
    } : error;

    if (this.isProduction) {
      console.error(JSON.stringify({
        level: 'error',
        timestamp: new Date().toISOString(),
        message,
        error: errorInfo,
        ...context
      }));
    } else {
      console.error(this.formatMessage('ERROR', message, { ...context, error: errorInfo }));
      
      if (error instanceof Error && error.stack) {
        console.error(`[ERROR] Stack: ${error.stack}`);
      }
    }
  }

  static audit(action: string, userId: string, context?: LogContext): void {
    const auditData = {
      level: 'audit',
      timestamp: new Date().toISOString(),
      action,
      userId,
      ...context
    };

    if (this.isProduction) {
    } else {
    }
  }

  static endpoint(method: string, path: string, status: number, duration: number, context?: LogContext): void {
    this.info(`${method} ${path} ${status} ${duration}ms`, {
      method,
      path,
      status,
      duration,
      ...context
    });
  }

  static performance(operation: string, startTime: number, context?: LogContext): void {
    const duration = Date.now() - startTime;
    this.info(`Performance: ${operation} completed in ${duration}ms`, {
      operation,
      duration,
      ...context
    });
  }

  static validation(field: string, value: any, isValid: boolean, errors?: string[]): void {
    const status = isValid ? 'VALID' : 'INVALID';
    const message = `Validation ${status}: ${field}`;
    
    if (isValid) {
      this.debug(message, { field, value });
    } else {
      this.warn(message, { field, value, errors });
    }
  }
}

export const requestLogger = (req: any, startTime: number) => {
  return (status: number) => {
    const duration = Date.now() - startTime;
    Logger.endpoint(req.method, req.url, status, duration);
  };
};

export const createAuditLogger = (userId: string, ip?: string, userAgent?: string) => {
  return {
    userId,
    ip: ip || 'unknown',
    userAgent: userAgent || 'unknown',
    timestamp: new Date().toISOString(),
    
    logAction: (action: string, resource: string, context?: LogContext) => {
      Logger.audit(`${action} ${resource}`, userId, {
        ip,
        userAgent,
        ...context
      });
    }
  };
};

const environment = (globalThis as any)?.ENVIRONMENT || 'development';
Logger.setProduction(environment === 'production');
Logger.setLevel(environment === 'production' ? LogLevel.INFO : LogLevel.DEBUG);
