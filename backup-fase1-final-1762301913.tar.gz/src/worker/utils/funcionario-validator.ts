/**
 * Validador Unificado de Funcionários
 * Elimina duplicação de código entre CREATE, UPDATE e IMPORT
 * AirTrust v2 - Outubro 2025
 */

import { Validators } from './validators';
import { validarFuncao } from './funcoes-validator';
import { FuncionarioDados } from '../repositories/funcionario-repository';

export interface ErroValidacao {
  campo: string;
  mensagem: string;
}

export interface ResultadoValidacao {
  valido: boolean;
  erros: ErroValidacao[];
  dadosNormalizados?: FuncionarioDados;
}

export type ModoValidacao = 'create' | 'update' | 'import';

/**
 * Valida dados de funcionário com todas as regras de negócio
 */
export function validarDadosFuncionario(
  dados: any,
  modo: ModoValidacao = 'create'
): ResultadoValidacao {
  const erros: ErroValidacao[] = [];


  if (!dados.nome?.trim()) {
    erros.push({ campo: 'nome', mensagem: 'Nome é obrigatório' });
  } else if (dados.nome.trim().length < 3) {
    erros.push({ campo: 'nome', mensagem: 'Nome deve ter no mínimo 3 caracteres' });
  }

  if (modo !== 'update') {
    if (!dados.email) {
      erros.push({ campo: 'email', mensagem: 'Email é obrigatório' });
    } else if (!Validators.validateEmail(dados.email)) {
      erros.push({ campo: 'email', mensagem: 'Email inválido' });
    }
  } else if (dados.email && !Validators.validateEmail(dados.email)) {
    erros.push({ campo: 'email', mensagem: 'Email inválido' });
  }

  if (!dados.funcao) {
    if (modo !== 'update') {
      erros.push({ campo: 'funcao', mensagem: 'Função é obrigatória' });
    }
  } else {
    const funcaoValidada = validarFuncao(dados.funcao);
    
    if (!funcaoValidada.valida) {
      erros.push({ campo: 'funcao', mensagem: funcaoValidada.erro || 'Função inválida' });
    } else {
      if (funcaoValidada.exigeAnac && !dados.codigo_anac) {
        erros.push({
          campo: 'codigo_anac',
          mensagem: `Código ANAC obrigatório para função ${funcaoValidada.normalizada} (Safety Critical)`
        });
      }

      if (dados.codigo_anac) {
        const codigoLimpo = String(dados.codigo_anac).replace(/\D/g, '');
        if (codigoLimpo.length < 6 || codigoLimpo.length > 7) {
          erros.push({
            campo: 'codigo_anac',
            mensagem: 'Código ANAC deve ter 6 ou 7 dígitos'
          });
        }
      }
    }
  }


  if (dados.cpf && !Validators.validateCPF(dados.cpf)) {
    erros.push({ campo: 'cpf', mensagem: 'CPF inválido' });
  }

  if (dados.telefone && !Validators.validatePhone(dados.telefone)) {
    erros.push({ campo: 'telefone', mensagem: 'Telefone inválido (formato: (XX) XXXXX-XXXX)' });
  }

  if (dados.data_nascimento || dados.data_nasc) {
    const dataNasc = dados.data_nascimento || dados.data_nasc;
    
    if (!Validators.validateDate(dataNasc)) {
      erros.push({ campo: 'data_nascimento', mensagem: 'Data de nascimento inválida (formato: YYYY-MM-DD)' });
    } else if (!Validators.validateDataNascimento(dataNasc)) {
      erros.push({ campo: 'data_nascimento', mensagem: 'Funcionário deve ter pelo menos 18 anos' });
    }
  }

  if (dados.data_admissao) {
    if (!Validators.validateDate(dados.data_admissao)) {
      erros.push({ campo: 'data_admissao', mensagem: 'Data de admissão inválida (formato: YYYY-MM-DD)' });
    } else if (!Validators.validateNotFutureDate(dados.data_admissao)) {
      erros.push({ campo: 'data_admissao', mensagem: 'Data de admissão não pode ser futura' });
    }
  }

  if (dados.cma_data_vencimento || dados.cma_datavencimento) {
    const dataVenc = dados.cma_data_vencimento || dados.cma_datavencimento;
    if (!Validators.validateDate(dataVenc)) {
      erros.push({ campo: 'cma_data_vencimento', mensagem: 'Data de vencimento do CMA inválida' });
    }
  }

  if (dados.aso_data_vencimento || dados.aso_datavencimento) {
    const dataVenc = dados.aso_data_vencimento || dados.aso_datavencimento;
    if (!Validators.validateDate(dataVenc)) {
      erros.push({ campo: 'aso_data_vencimento', mensagem: 'Data de vencimento do ASO inválida' });
    }
  }

  if (dados.nivel_icao_data_vencimento || dados.nivel_icao_datavencimento) {
    const dataVenc = dados.nivel_icao_data_vencimento || dados.nivel_icao_datavencimento;
    if (!Validators.validateDate(dataVenc)) {
      erros.push({ campo: 'nivel_icao_data_vencimento', mensagem: 'Data de vencimento do Nível ICAO inválida' });
    }
  }

  if (modo === 'import' || modo === 'create') {
    if (dados.contato_emergencia_nome && !dados.contato_emergencia_telefone) {
      erros.push({
        campo: 'contato_emergencia_telefone',
        mensagem: 'Telefone de emergência obrigatório quando nome de contato é fornecido'
      });
    }

    if (dados.contato_emergencia_telefone) {
      if (!Validators.validatePhone(dados.contato_emergencia_telefone)) {
        erros.push({
          campo: 'contato_emergencia_telefone',
          mensagem: 'Telefone de emergência inválido'
        });
      }

      if (dados.telefone && dados.telefone === dados.contato_emergencia_telefone) {
        erros.push({
          campo: 'contato_emergencia_telefone',
          mensagem: 'Telefone de emergência deve ser diferente do telefone pessoal'
        });
      }
    }
  }


  const dadosNormalizados: FuncionarioDados = {
    nome: dados.nome?.trim(),
    matricula: dados.matricula?.trim() || undefined,
    cpf: dados.cpf?.replace(/\D/g, '') || undefined,
    codigo_anac: dados.codigo_anac?.replace(/\D/g, '') || undefined,
    funcao: dados.funcao?.toUpperCase().trim(),
    base: dados.base?.trim() || undefined,
    contrato: dados.contrato?.trim() || undefined,
    telefone: dados.telefone?.replace(/\D/g, '') || undefined,
    email: dados.email?.toLowerCase().trim() || undefined,
    status: dados.status?.toUpperCase() || 'ATIVO',
    cma_numero: dados.cma_numero || dados.cma || undefined,
    cma_datavencimento: dados.cma_datavencimento || dados.cma_data_vencimento || undefined,
    cma_status: dados.cma_status || undefined,
    aso_datavencimento: dados.aso_datavencimento || dados.aso_data_vencimento || undefined,
    nivel_icao: dados.nivel_icao || undefined,
    nivel_icao_datavencimento: dados.nivel_icao_datavencimento || dados.nivel_icao_data_vencimento || undefined,
    nivel_icao_status: dados.nivel_icao_status || undefined,
    is_instrutor: dados.is_instrutor ? 1 : 0,
    is_checador: dados.is_checador ? 1 : 0,
    aeronave_principal: dados.aeronave_principal || dados.aeronave || undefined,
    avatar: dados.avatar || undefined,
    anv: dados.anv || undefined,
    data_nascimento: dados.data_nascimento || dados.data_nasc || undefined,
    licenca_aeronautica: dados.licenca_aeronautica || undefined,
    codigo_canac: dados.codigo_canac || undefined,
    codigo_sispat: dados.codigo_sispat || undefined,
    codigo_prestserv: dados.codigo_prestserv || undefined,
    data_admissao: dados.data_admissao || undefined,
    contato_emergencia_nome: dados.contato_emergencia_nome || undefined,
    contato_emergencia_parentesco: dados.contato_emergencia_parentesco || undefined,
    contato_emergencia_telefone: dados.contato_emergencia_telefone?.replace(/\D/g, '') || undefined
  };

  return {
    valido: erros.length === 0,
    erros,
    dadosNormalizados: erros.length === 0 ? dadosNormalizados : undefined
  };
}

/**
 * Validação rápida apenas de campos obrigatórios
 */
export function validarCamposObrigatorios(dados: any): { valido: boolean; erro?: string } {
  if (!dados.nome?.trim()) {
    return { valido: false, erro: 'Nome é obrigatório' };
  }

  if (!dados.email?.trim()) {
    return { valido: false, erro: 'Email é obrigatório' };
  }

  if (!dados.funcao?.trim()) {
    return { valido: false, erro: 'Função é obrigatória' };
  }

  return { valido: true };
}
