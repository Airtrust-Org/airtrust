/**
 * SQL Sanitization utilities para proteção contra SQL injection
 * Especialmente para LIKE queries onde caracteres especiais podem ser explorados
 */

/**
 * Sanitizar string para uso seguro em LIKE queries
 * Remove caracteres especiais que podem ser usados em SQL injection
 *
 * @param value - String a ser sanitizada
 * @returns String sanitizada segura para LIKE
 */
export function sanitizeLike(value: string): string {
  if (!value) return '';
  
  return value
    .replace(/\\/g, '\\\\')  // Escape backslash PRIMEIRO (importante!)
    .replace(/%/g, '\\%')    // Escape percent (wildcard)
    .replace(/_/g, '\\_');   // Escape underscore (wildcard)
}

/**
 * Sanitizar string genérica para queries
 * Para prepared statements, isso é principalmente validação
 * Prepared statements já protegem contra SQL injection, mas adicionamos validação extra
 *
 * @param value - String a ser sanitizada
 * @returns String sanitizada
 */
export function sanitizeQuery(value: string): string {
  if (!value) return '';
  return value.trim();
}

/**
 * Validar se string contém padrões suspeitos de SQL injection
 * Detecta palavras-chave perigosas
 *
 * @param value - String a validar
 * @returns true se contém padrões suspeitos
 */
export function containsSuspiciousSQLPatterns(value: string): boolean {
  const suspiciousPatterns = [
    /drop\s+table/i,
    /delete\s+from/i,
    /insert\s+into.*values/i,
    /update\s+.*set/i,
    /union\s+select/i,
    /or\s+1\s*=\s*1/i,
    /;\s*delete/i,
    /;\s*drop/i,
    /--\s*$/i,
    /\/\*.*\*\//i,
  ];

  return suspiciousPatterns.some(pattern => pattern.test(value));
}

/**
 * Testes unitários para validação
 * Estes são exemplos de testes que deveriam passar
 */
export const sqlSanitizeTests = [
  {
    input: "O'Brien",
    expected: "O'Brien",
    desc: 'Single quote (não afeta LIKE)',
  },
  {
    input: '50%',
    expected: '50\\%',
    desc: 'Percent wildcard escaping',
  },
  {
    input: 'test_value',
    expected: 'test\\_value',
    desc: 'Underscore wildcard escaping',
  },
  {
    input: 'a\\b',
    expected: 'a\\\\b',
    desc: 'Backslash escaping',
  },
  {
    input: '',
    expected: '',
    desc: 'Empty string',
  },
  {
    input: 'normal string',
    expected: 'normal string',
    desc: 'Normal string (no special chars)',
  },
  {
    input: 'test%_\\combo',
    expected: 'test\\%\\_\\\\combo',
    desc: 'Combined special characters',
  },
];

/**
 * Executar testes de sanitização
 * Função helper para validação durante desenvolvimento
 */
export function runSanitizeTests(): {
  passed: number;
  failed: number;
  errors: string[];
} {
  const results = { passed: 0, failed: 0, errors: [] as string[] };

  for (const test of sqlSanitizeTests) {
    const actual = sanitizeLike(test.input);
    if (actual === test.expected) {
      results.passed++;
    } else {
      results.failed++;
      results.errors.push(
        `Test "${test.desc}" failed: expected "${test.expected}", got "${actual}"`
      );
    }
  }

  return results;
}
