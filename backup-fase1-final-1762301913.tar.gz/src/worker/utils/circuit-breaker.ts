/**
 * Circuit Breaker Pattern
 * Previne cascata de falhas em dependências externas
 * Estados: Closed -> Open -> Half-Open -> Closed
 */

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerConfig {
  failureThreshold: number; // Falhas consecutivas para abrir
  successThreshold: number; // Sucessos consecutivos para fechar (half-open -> closed)
  timeout: number; // Tempo em ms antes de tentar half-open
  halfOpenRequests: number; // Quantas requisições permitir em half-open
}

export interface CircuitBreakerState {
  state: CircuitState;
  failures: number;
  successes: number;
  lastFailureTime?: number;
  nextAttempt?: number;
}

/**
 * Circuit Breaker genérico
 */
export class CircuitBreaker {
  private state: CircuitBreakerState;
  private config: CircuitBreakerConfig;
  private halfOpenAttempts: number = 0;

  constructor(config: Partial<CircuitBreakerConfig> = {}) {
    this.config = {
      failureThreshold: config.failureThreshold || 5,
      successThreshold: config.successThreshold || 3,
      timeout: config.timeout || 60000, // 1 min
      halfOpenRequests: config.halfOpenRequests || 2,
    };

    this.state = {
      state: 'CLOSED',
      failures: 0,
      successes: 0,
    };
  }

  /**
   * Executar função protegida pelo circuit breaker
   */
  async execute<R>(fn: () => Promise<R>, fallback?: () => Promise<R> | R): Promise<R> {
    // Se aberto, verificar se pode tentar half-open
    if (this.state.state === 'OPEN') {
      if (!this.state.nextAttempt || Date.now() < this.state.nextAttempt) {
        throw new Error('Circuit breaker is OPEN');
      }

      // Transicionar para half-open
      this.state.state = 'HALF_OPEN';
      this.halfOpenAttempts = 0;
      this.state.successes = 0;
    }

    // Em half-open, limitar requisições
    if (this.state.state === 'HALF_OPEN' && this.halfOpenAttempts >= this.config.halfOpenRequests) {
      throw new Error('Circuit breaker exceeded half-open request limit');
    }

    if (this.state.state === 'HALF_OPEN') {
      this.halfOpenAttempts++;
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();

      // Se tem fallback, usar
      if (fallback) {
        return await Promise.resolve(fallback());
      }

      throw error;
    }
  }

  /**
   * Registrar sucesso
   */
  private onSuccess(): void {
    this.state.failures = 0;

    if (this.state.state === 'HALF_OPEN') {
      this.state.successes++;

      if (this.state.successes >= this.config.successThreshold) {
        // Fechar circuit
        this.state.state = 'CLOSED';
        this.state.successes = 0;
      }
    }
  }

  /**
   * Registrar falha
   */
  private onFailure(): void {
    this.state.failures++;
    this.state.lastFailureTime = Date.now();

    if (this.state.state === 'HALF_OPEN') {
      // Falha em half-open volta para OPEN
      this.state.state = 'OPEN';
      this.state.nextAttempt = Date.now() + this.config.timeout;
      this.halfOpenAttempts = 0;
    } else if (this.state.failures >= this.config.failureThreshold) {
      // Fechar circuit após threshold
      this.state.state = 'OPEN';
      this.state.nextAttempt = Date.now() + this.config.timeout;
    }
  }

  /**
   * Obter estado atual
   */
  getState(): CircuitBreakerState {
    return { ...this.state };
  }

  /**
   * Reset manual
   */
  reset(): void {
    this.state = {
      state: 'CLOSED',
      failures: 0,
      successes: 0,
    };
    this.halfOpenAttempts = 0;
  }

  /**
   * Check se está saudável
   */
  isHealthy(): boolean {
    return this.state.state === 'CLOSED';
  }
}

/**
 * Gerenciador de múltiplos circuit breakers
 */
export class CircuitBreakerManager {
  private breakers: Map<string, CircuitBreaker> = new Map();

  /**
   * Obter ou criar circuit breaker
   */
  getBreaker(name: string, config?: Partial<CircuitBreakerConfig>): CircuitBreaker {
    if (!this.breakers.has(name)) {
      this.breakers.set(name, new CircuitBreaker(config));
    }

    return this.breakers.get(name) as CircuitBreaker;
  }

  /**
   * Executar com circuit breaker
   */
  async execute<T>(
    name: string,
    fn: () => Promise<T>,
    fallback?: () => Promise<T> | T,
    config?: Partial<CircuitBreakerConfig>
  ): Promise<T> {
    const breaker = this.getBreaker(name, config);
    return breaker.execute(fn, fallback);
  }

  /**
   * Obter status de todos os breakers
   */
  getAllStatus(): Record<string, CircuitBreakerState> {
    const status: Record<string, CircuitBreakerState> = {};

    for (const [name, breaker] of this.breakers.entries()) {
      status[name] = breaker.getState();
    }

    return status;
  }

  /**
   * Health check geral
   */
  isSystemHealthy(): boolean {
    for (const breaker of this.breakers.values()) {
      if (!breaker.isHealthy()) {
        return false;
      }
    }

    return true;
  }

  /**
   * Reset de todos os breakers
   */
  resetAll(): void {
    for (const breaker of this.breakers.values()) {
      breaker.reset();
    }
  }
}

/**
 * Testes de circuit breaker
 */
export const circuitBreakerTests = [
  {
    name: 'Should start in CLOSED state',
    test: () => {
      const breaker = new CircuitBreaker();
      return breaker.getState().state === 'CLOSED';
    },
  },
  {
    name: 'Should allow requests when CLOSED',
    test: async () => {
      const breaker = new CircuitBreaker();
      const result = await breaker.execute(async () => 'success');
      return result === 'success';
    },
  },
  {
    name: 'Should open after threshold failures',
    test: async () => {
      const breaker = new CircuitBreaker({ failureThreshold: 2 });

      // Falhar 2 vezes
      for (let i = 0; i < 2; i++) {
        try {
          await breaker.execute(async () => {
            throw new Error('fail');
          });
        } catch {
          // ignored
        }
      }

      return breaker.getState().state === 'OPEN';
    },
  },
  {
    name: 'Should reject requests when OPEN',
    test: async () => {
      const breaker = new CircuitBreaker({ failureThreshold: 1, timeout: 1 });

      // Falhar uma vez
      try {
        await breaker.execute(async () => {
          throw new Error('fail');
        });
      } catch {
        // ignored
      }

      // Circuit should be open
      try {
        await breaker.execute(async () => 'success');
        return false; // Deveria ter lançado erro
      } catch (error) {
        return (error as Error).message.includes('OPEN');
      }
    },
  },
  {
    name: 'Should transition to HALF_OPEN after timeout',
    test: async () => {
      const breaker = new CircuitBreaker({ failureThreshold: 1, timeout: 100 });

      // Abrir circuit
      try {
        await breaker.execute(async () => {
          throw new Error('fail');
        });
      } catch {
        // ignored
      }

      // Esperar timeout
      await new Promise((resolve) => setTimeout(resolve, 150));

      // Tentar executar novamente (deve ir para half-open)
      try {
        await breaker.execute(async () => 'success');
        return breaker.getState().state === 'CLOSED'; // Se sucesso, volta para CLOSED
      } catch {
        return false;
      }
    },
  },
  {
    name: 'Should use fallback when open',
    test: async () => {
      const breaker = new CircuitBreaker({ failureThreshold: 1 });

      // Abrir
      try {
        await breaker.execute(async () => {
          throw new Error('fail');
        });
      } catch {
        // ignored
      }

      // Usar fallback
      const result = await breaker.execute(
        async () => 'primary',
        async () => 'fallback'
      );

      return result === 'fallback';
    },
  },
  {
    name: 'Should close after successful half-open requests',
    test: async () => {
      const breaker = new CircuitBreaker({
        failureThreshold: 1,
        successThreshold: 1,
        timeout: 100,
      });

      // Abrir
      try {
        await breaker.execute(async () => {
          throw new Error('fail');
        });
      } catch {
        // ignored
      }

      // Esperar e tentar
      await new Promise((resolve) => setTimeout(resolve, 150));

      await breaker.execute(async () => 'success');

      return breaker.getState().state === 'CLOSED';
    },
  },
];
