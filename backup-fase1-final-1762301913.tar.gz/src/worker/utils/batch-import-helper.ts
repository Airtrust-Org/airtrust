/**
 * ⚡ BATCH IMPORT HELPER
 * Utilitário para importações otimizadas que evita "Too many API requests"
 * 
 * PROBLEMA: Fazer 1 query por linha causa timeout em arquivos grandes
 * SOLUÇÃO: Processar em batches de 50 registros
 */

import type { CloudflareD1Database } from '../../types/cloudflare';

export interface BatchImportOptions {
  batchSize?: number; // Padrão: 50
  onProgress?: (imported: number, total: number) => void;
  onError?: (error: any, item: any, index: number) => void;
}

export interface BatchImportResult {
  success: boolean;
  total: number;
  imported: number;
  errors: Array<{
    index: number;
    item: any;
    error: string;
  }>;
  duration: number;
}

/**
 * Executa importação em batch
 * 
 * @example
 * const result = await batchImport(db, dados, async (item, db) => {
 *   await db.prepare(`INSERT INTO tabela VALUES (?)`).bind(item.valor).run();
 * });
 */
export async function batchImport<T>(
  db: CloudflareD1Database,
  items: T[],
  insertFn: (item: T, db: CloudflareD1Database) => Promise<void>,
  options: BatchImportOptions = {}
): Promise<BatchImportResult> {
  const startTime = Date.now();
  const batchSize = options.batchSize || 50;
  
  const result: BatchImportResult = {
    success: true,
    total: items.length,
    imported: 0,
    errors: [],
    duration: 0
  };

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    
    for (let j = 0; j < batch.length; j++) {
      const item = batch[j];
      const globalIndex = i + j;
      
      try {
        await insertFn(item, db);
        result.imported++;
        
        if (options.onProgress) {
          options.onProgress(result.imported, result.total);
        }
      } catch (error: any) {
        result.errors.push({
          index: globalIndex,
          item,
          error: error.message || String(error)
        });
        
        if (options.onError) {
          options.onError(error, item, globalIndex);
        }
      }
    }
    
    if (i + batchSize < items.length) {
      await new Promise(resolve => setTimeout(resolve, 10));
    }
  }

  result.duration = Date.now() - startTime;
  result.success = result.errors.length === 0;
  
  return result;
}

/**
 * Busca todos os registros de uma tabela e cria um mapa
 * Útil para evitar N queries ao buscar relacionamentos
 * 
 * @example
 * const funcionariosMap = await fetchAllAsMap(
 *   db,
 *   'SELECT id, cpf FROM funcionarios',
 *   (row) => row.cpf // key
 * );
 */
export async function fetchAllAsMap<T>(
  db: CloudflareD1Database,
  query: string,
  keyFn: (row: T) => string | number,
  bindings: any[] = []
): Promise<Map<string | number, T>> {
  const result = await db.prepare(query).bind(...bindings).all();
  const map = new Map<string | number, T>();
  
  result.results.forEach((row: any) => {
    const key = keyFn(row as T);
    map.set(key, row as T);
  });
  
  return map;
}

/**
 * Valida dados antes de importar
 */
export function validateImportData(
  data: any[],
  requiredFields: string[]
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!Array.isArray(data) || data.length === 0) {
    errors.push('Dados inválidos ou vazios');
    return { valid: false, errors };
  }
  
  const firstRow = data[0];
  const missingFields = requiredFields.filter(field => !(field in firstRow));
  
  if (missingFields.length > 0) {
    errors.push(`Campos obrigatórios faltando: ${missingFields.join(', ')}`);
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Registra importação no log
 */
export async function logImport(
  db: CloudflareD1Database,
  tipo: string,
  arquivo: string,
  result: BatchImportResult
): Promise<void> {
  try {
    await db.prepare(`
      INSERT INTO importacoes_log (
        tipo, arquivo_nome, total_registros, 
        sucesso, erros, detalhes
      ) VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      tipo,
      arquivo,
      result.total,
      result.imported,
      result.errors.length,
      JSON.stringify({
        duration: result.duration,
        errors: result.errors.slice(0, 100) // Limitar a 100 erros
      })
    ).run();
  } catch (error) {
    console.error('[LOG] Erro ao registrar importação:', error);
  }
}
