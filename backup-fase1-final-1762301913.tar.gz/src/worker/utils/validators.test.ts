import { describe, it, expect } from 'vitest';
import { Validators } from './validators';

describe('Validators', () => {
  describe('validateCPF', () => {
    it('deve aceitar CPF válido', () => {
      expect(Validators.validateCPF('12345678909')).toBe(true);
      expect(Validators.validateCPF('11144477735')).toBe(true);
    });

    it('deve rejeitar CPF inválido', () => {
      expect(Validators.validateCPF('11111111111')).toBe(false);
      expect(Validators.validateCPF('00000000000')).toBe(false);
      expect(Validators.validateCPF('12345678900')).toBe(false);
    });

    it('deve rejeitar CPF com menos de 11 dígitos', () => {
      expect(Validators.validateCPF('123456789')).toBe(false);
    });

    it('deve rejeitar CPF com mais de 11 dígitos', () => {
      expect(Validators.validateCPF('123456789012')).toBe(false);
    });

    it('deve aceitar CPF com formatação', () => {
      expect(Validators.validateCPF('123.456.789-09')).toBe(true);
    });

    it('deve rejeitar CPF vazio', () => {
      expect(Validators.validateCPF('')).toBe(false);
    });
  });

  describe('formatCPF', () => {
    it('deve formatar CPF corretamente', () => {
      expect(Validators.formatCPF('12345678909')).toBe('123.456.789-09');
    });

    it('deve manter formatação existente', () => {
      expect(Validators.formatCPF('123.456.789-09')).toBe('123.456.789-09');
    });

    it('deve retornar vazio para CPF vazio', () => {
      expect(Validators.formatCPF('')).toBe('');
    });

    it('deve retornar sem formatação se não tiver 11 dígitos', () => {
      expect(Validators.formatCPF('123456789')).toBe('123456789');
    });
  });

  describe('validateEmail', () => {
    it('deve aceitar email válido', () => {
      expect(Validators.validateEmail('teste@example.com')).toBe(true);
      expect(Validators.validateEmail('user.name@domain.co.uk')).toBe(true);
    });

    it('deve rejeitar email inválido', () => {
      expect(Validators.validateEmail('invalid')).toBe(false);
      expect(Validators.validateEmail('@example.com')).toBe(false);
      expect(Validators.validateEmail('user@')).toBe(false);
      expect(Validators.validateEmail('')).toBe(false);
    });
  });

  describe('validatePhone', () => {
    it('deve aceitar telefone com 10 dígitos', () => {
      expect(Validators.validatePhone('1134567890')).toBe(true);
    });

    it('deve aceitar telefone com 11 dígitos', () => {
      expect(Validators.validatePhone('11987654321')).toBe(true);
    });

    it('deve aceitar telefone formatado', () => {
      expect(Validators.validatePhone('(11) 98765-4321')).toBe(true);
      expect(Validators.validatePhone('(11) 3456-7890')).toBe(true);
    });

    it('deve rejeitar telefone com número incorreto de dígitos', () => {
      expect(Validators.validatePhone('123')).toBe(false);
      expect(Validators.validatePhone('123456789012')).toBe(false);
      expect(Validators.validatePhone('')).toBe(false);
    });
  });

  describe('formatPhone', () => {
    it('deve formatar telefone com 11 dígitos', () => {
      expect(Validators.formatPhone('11987654321')).toBe('(11) 98765-4321');
    });

    it('deve formatar telefone com 10 dígitos', () => {
      expect(Validators.formatPhone('1134567890')).toBe('(11) 3456-7890');
    });

    it('deve retornar vazio para telefone vazio', () => {
      expect(Validators.formatPhone('')).toBe('');
    });

    it('deve retornar sem formatação se não tiver 10 ou 11 dígitos', () => {
      expect(Validators.formatPhone('123')).toBe('123');
    });
  });

  describe('validateMatricula', () => {
    it('deve aceitar matrícula válida', () => {
      expect(Validators.validateMatricula('ABC123')).toBe(true);
      expect(Validators.validateMatricula('FUNC001')).toBe(true);
    });

    it('deve rejeitar matrícula muito curta', () => {
      expect(Validators.validateMatricula('AB')).toBe(false);
    });

    it('deve rejeitar matrícula muito longa', () => {
      expect(Validators.validateMatricula('A'.repeat(21))).toBe(false);
    });

    it('deve rejeitar matrícula com caracteres especiais', () => {
      expect(Validators.validateMatricula('ABC-123')).toBe(false);
      expect(Validators.validateMatricula('ABC 123')).toBe(false);
    });

    it('deve rejeitar matrícula vazia', () => {
      expect(Validators.validateMatricula('')).toBe(false);
    });
  });

  describe('validateNome', () => {
    it('deve aceitar nome válido', () => {
      expect(Validators.validateNome('João Silva')).toBe(true);
      expect(Validators.validateNome('Maria José')).toBe(true);
    });

    it('deve rejeitar nome muito curto', () => {
      expect(Validators.validateNome('Jo')).toBe(false);
    });

    it('deve rejeitar nome com números', () => {
      expect(Validators.validateNome('João123')).toBe(false);
    });

    it('deve rejeitar nome vazio', () => {
      expect(Validators.validateNome('')).toBe(false);
    });

    it('deve aceitar nome com acentos', () => {
      expect(Validators.validateNome('José María')).toBe(true);
    });
  });

  describe('validateDate', () => {
    it('deve aceitar data válida no formato ISO', () => {
      expect(Validators.validateDate('2025-01-19')).toBe(true);
      expect(Validators.validateDate('2024-12-31')).toBe(true);
    });

    it('deve rejeitar data em formato incorreto', () => {
      expect(Validators.validateDate('19/01/2025')).toBe(false);
      expect(Validators.validateDate('2025-1-19')).toBe(false);
      expect(Validators.validateDate('invalid')).toBe(false);
    });

    it('deve rejeitar data inválida', () => {
      expect(Validators.validateDate('2025-13-01')).toBe(false);
    });

    it('deve rejeitar data vazia', () => {
      expect(Validators.validateDate('')).toBe(false);
    });
  });

  describe('validatePassword', () => {
    it('deve aceitar senha forte', () => {
      const result = Validators.validatePassword('Senha123!');
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('deve rejeitar senha curta', () => {
      const result = Validators.validatePassword('Sen1!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha deve ter no mínimo 8 caracteres');
    });

    it('deve rejeitar senha sem maiúscula', () => {
      const result = Validators.validatePassword('senha123!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha deve conter pelo menos uma letra maiúscula');
    });

    it('deve rejeitar senha sem minúscula', () => {
      const result = Validators.validatePassword('SENHA123!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha deve conter pelo menos uma letra minúscula');
    });

    it('deve rejeitar senha sem número', () => {
      const result = Validators.validatePassword('SenhaForte!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha deve conter pelo menos um número');
    });

    it('deve rejeitar senha sem caractere especial', () => {
      const result = Validators.validatePassword('Senha123');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha deve conter pelo menos um caractere especial');
    });

    it('deve rejeitar senha vazia', () => {
      const result = Validators.validatePassword('');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Senha é obrigatória');
    });
  });

  describe('sanitizeString', () => {
    it('deve remover tags HTML', () => {
      expect(Validators.sanitizeString('<script>alert("xss")</script>')).toBe('scriptalert("xss")/script');
    });

    it('deve remover javascript:', () => {
      expect(Validators.sanitizeString('javascript:alert("xss")')).toBe('alert("xss")');
    });

    it('deve remover event handlers', () => {
      expect(Validators.sanitizeString('onclick=alert("xss")')).toBe('alert("xss")');
    });

    it('deve remover espaços extras', () => {
      expect(Validators.sanitizeString('  texto  ')).toBe('texto');
    });

    it('deve retornar vazio para string vazia', () => {
      expect(Validators.sanitizeString('')).toBe('');
    });
  });

  describe('sanitizeInput', () => {
    it('deve sanitizar string', () => {
      expect(Validators.sanitizeInput('<script>test</script>')).toBe('scripttest/script');
    });

    it('deve sanitizar array de strings', () => {
      const result = Validators.sanitizeInput(['<script>test</script>', 'normal']);
      expect(result).toEqual(['scripttest/script', 'normal']);
    });

    it('deve sanitizar objeto', () => {
      const result = Validators.sanitizeInput({
        name: '<script>test</script>',
        email: 'test@example.com'
      });
      expect(result.name).toBe('scripttest/script');
      expect(result.email).toBe('test@example.com');
    });

    it('deve retornar números sem alteração', () => {
      expect(Validators.sanitizeInput(123)).toBe(123);
    });

    it('deve retornar null sem alteração', () => {
      expect(Validators.sanitizeInput(null)).toBe(null);
    });
  });
});
