// @ts-nocheck
/**
 * 🎯 TEMPLATE PADRÃO PARA CRUDs - AIRTRUST
 * 
 * Use este template para garantir validações corretas e evitar bugs comuns.
 * 
 * BUGS PREVENIDOS:
 * ✅ BUG #1: Campos obrigatórios não validados
 * ✅ BUG #2: UPDATE verifica duplicata sem excluir próprio ID
 * ✅ BUG #3: UPDATE com poucos campos
 * ✅ BUG #4: Mensagens de erro genéricas
 * ✅ BUG #5: Catch sem tratamento específico
 * 
 * @author Sistema AirTrust
 * @version 2.0
 */

import { Hono } from 'hono';
import type { Env } from '../types';

const app = new Hono<{ Bindings: Env }>();

// ═══════════════════════════════════════════════════════════
// 📝 CONFIGURAÇÃO DO MÓDULO
// ═══════════════════════════════════════════════════════════

const CONFIG = {
  tabela: 'nome_tabela',
  entidade: 'Nome da Entidade',
  camposObrigatorios: ['nome', 'codigo'], // Ajustar por módulo
  campoUnico: 'codigo', // Campo que não pode duplicar
};

// ═══════════════════════════════════════════════════════════
// ✅ GET / - Listar todos os registros
// ═══════════════════════════════════════════════════════════

app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT * FROM ${CONFIG.tabela}
      WHERE deleted_at IS NULL
      ORDER BY created_at DESC
    `).all();
    
    return c.json({
      success: true,
      data: results || []
    });
    
  } catch (error) {
    console.error(`❌ [${CONFIG.entidade}] Erro ao listar:`, error);
    return c.json({
      success: false,
      error: `Erro ao listar ${CONFIG.entidade.toLowerCase()}s`
    }, 500);
  }
});

// ═══════════════════════════════════════════════════════════
// ✅ GET /:id - Buscar registro por ID
// ═══════════════════════════════════════════════════════════

app.get('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    const registro = await db.prepare(`
      SELECT * FROM ${CONFIG.tabela}
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!registro) {
      return c.json({
        success: false,
        error: `${CONFIG.entidade} não encontrado(a)`
      }, 404);
    }
    
    return c.json({
      success: true,
      data: registro
    });
    
  } catch (error) {
    console.error(`❌ [${CONFIG.entidade}] Erro ao buscar:`, error);
    return c.json({
      success: false,
      error: `Erro ao buscar ${CONFIG.entidade.toLowerCase()}`
    }, 500);
  }
});

// ═══════════════════════════════════════════════════════════
// ✅ POST / - Criar novo registro
// ═══════════════════════════════════════════════════════════

app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();
    // TODO: const user = c.get('user'); // Auth disabled in dev
    
    
    // ✅ PADRÃO #1: VALIDAR CAMPOS OBRIGATÓRIOS
    for (const campo of CONFIG.camposObrigatorios) {
      if (!body[campo] || String(body[campo]).trim() === '') {
        return c.json({
          success: false,
          error: `Campo '${campo}' é obrigatório`
        }, 400);
      }
    }
    
    // ✅ PADRÃO #2: VALIDAR DUPLICATAS (se aplicável)
    if (CONFIG.campoUnico && body[CONFIG.campoUnico]) {
      const existe = await db.prepare(`
        SELECT id FROM ${CONFIG.tabela}
        WHERE ${CONFIG.campoUnico} = ? AND deleted_at IS NULL
      `).bind(body[CONFIG.campoUnico]).first();
      
      if (existe) {
        return c.json({
          success: false,
          error: `${CONFIG.campoUnico} '${body[CONFIG.campoUnico]}' já cadastrado`
        }, 409);
      }
    }
    
    // ✅ Inserir registro
    const result = await db.prepare(`
      INSERT INTO ${CONFIG.tabela} (
        campo1,
        campo2,
        campo3,
        created_at
      ) VALUES (?, ?, ?, datetime('now'))
    `).bind(
      body.campo1,
      body.campo2,
      body.campo3
    ).run();
    
    const novoId = result.meta.last_row_id;
    
    
    // ✅ Auditoria
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        entity_type,
        entity_id,
        action,
        username,
        details,
        created_at
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      CONFIG.tabela,
      novoId,
      'CREATE',
      user?.username || 'system',
      JSON.stringify(body)
    ).run();
    
    return c.json({
      success: true,
      data: { id: novoId },
      message: `${CONFIG.entidade} criado(a) com sucesso`
    }, 201);
    
  } catch (error) {
    console.error(`❌ [${CONFIG.entidade}] Erro ao criar:`, error);
    
    // ✅ PADRÃO #3: TRATAMENTO ESPECÍFICO DE ERROS
    let mensagemErro = `Erro ao criar ${CONFIG.entidade.toLowerCase()}`;
    
    if (error.message.includes('UNIQUE constraint')) {
      mensagemErro = 'Registro já existe no sistema';
    } else if (error.message.includes('NOT NULL constraint')) {
      mensagemErro = 'Campos obrigatórios não preenchidos';
    } else if (error.message.includes('FOREIGN KEY constraint')) {
      mensagemErro = 'Referência inválida a outro registro';
    }
    
    return c.json({
      success: false,
      error: mensagemErro,
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    }, 500);
  }
});

// ═══════════════════════════════════════════════════════════
// ✅ PUT /:id - Atualizar registro
// ═══════════════════════════════════════════════════════════

app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    const body = await c.req.json();
    // TODO: const user = c.get('user'); // Auth disabled in dev
    
    
    // ✅ Verificar se registro existe
    const registroAtual = await db.prepare(`
      SELECT * FROM ${CONFIG.tabela}
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!registroAtual) {
      return c.json({
        success: false,
        error: `${CONFIG.entidade} não encontrado(a)`
      }, 404);
    }
    
    // ✅ PADRÃO #4: VALIDAR DUPLICATA APENAS SE CAMPO MUDOU E EXCLUINDO PRÓPRIO ID
    if (CONFIG.campoUnico && body[CONFIG.campoUnico] && body[CONFIG.campoUnico] !== registroAtual[CONFIG.campoUnico]) {
      const existe = await db.prepare(`
        SELECT id FROM ${CONFIG.tabela}
        WHERE ${CONFIG.campoUnico} = ?
          AND id != ?              -- ✅ CRÍTICO: Excluir próprio registro
          AND deleted_at IS NULL
      `).bind(body[CONFIG.campoUnico], id).first();
      
      if (existe) {
        return c.json({
          success: false,
          error: `${CONFIG.campoUnico} '${body[CONFIG.campoUnico]}' já cadastrado para outro registro`
        }, 409);
      }
    }
    
    // ✅ PADRÃO #5: UPDATE COM TODOS OS CAMPOS IMPORTANTES
    await db.prepare(`
      UPDATE ${CONFIG.tabela}
      SET campo1 = ?,
          campo2 = ?,
          campo3 = ?,
          campo4 = ?,
          campo5 = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      body.campo1 !== undefined ? body.campo1 : registroAtual.campo1,
      body.campo2 !== undefined ? body.campo2 : registroAtual.campo2,
      body.campo3 !== undefined ? body.campo3 : registroAtual.campo3,
      body.campo4 !== undefined ? body.campo4 : registroAtual.campo4,
      body.campo5 !== undefined ? body.campo5 : registroAtual.campo5,
      id
    ).run();
    
    
    // ✅ Auditoria
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        entity_type,
        entity_id,
        action,
        username,
        details,
        created_at
      ) VALUES (?, ?, ?, ?, ?, datetime('now'))
    `).bind(
      CONFIG.tabela,
      id,
      'UPDATE',
      user?.username || 'system',
      JSON.stringify(body)
    ).run();
    
    return c.json({
      success: true,
      message: `${CONFIG.entidade} atualizado(a) com sucesso`
    });
    
  } catch (error) {
    console.error(`❌ [${CONFIG.entidade}] Erro ao atualizar:`, error);
    
    // ✅ PADRÃO #3: TRATAMENTO ESPECÍFICO DE ERROS
    let mensagemErro = `Erro ao atualizar ${CONFIG.entidade.toLowerCase()}`;
    
    if (error.message.includes('UNIQUE constraint')) {
      mensagemErro = 'Valor já existe para outro registro';
    } else if (error.message.includes('NOT NULL constraint')) {
      mensagemErro = 'Campos obrigatórios não podem ser vazios';
    }
    
    return c.json({
      success: false,
      error: mensagemErro,
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    }, 500);
  }
});

// ═══════════════════════════════════════════════════════════
// ✅ DELETE /:id - Excluir registro (soft delete)
// ═══════════════════════════════════════════════════════════

app.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    // TODO: const user = c.get('user'); // Auth disabled in dev
    
    
    // ✅ Verificar se existe
    const registro = await db.prepare(`
      SELECT id FROM ${CONFIG.tabela}
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!registro) {
      return c.json({
        success: false,
        error: `${CONFIG.entidade} não encontrado(a)`
      }, 404);
    }
    
    // ✅ Soft delete
    await db.prepare(`
      UPDATE ${CONFIG.tabela}
      SET deleted_at = datetime('now')
      WHERE id = ?
    `).bind(id).run();
    
    
    // ✅ Auditoria
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        entity_type,
        entity_id,
        action,
        username,
        created_at
      ) VALUES (?, ?, ?, ?, datetime('now'))
    `).bind(
      CONFIG.tabela,
      id,
      'DELETE',
      user?.username || 'system'
    ).run();
    
    return c.json({
      success: true,
      message: `${CONFIG.entidade} excluído(a) com sucesso`
    });
    
  } catch (error) {
    console.error(`❌ [${CONFIG.entidade}] Erro ao excluir:`, error);
    return c.json({
      success: false,
      error: `Erro ao excluir ${CONFIG.entidade.toLowerCase()}`
    }, 500);
  }
});

export default app;

// ═══════════════════════════════════════════════════════════
// 📚 INSTRUÇÕES DE USO
// ═══════════════════════════════════════════════════════════

/**
 * COMO USAR ESTE TEMPLATE:
 * 
 * 1. Copie este arquivo para seu novo CRUD
 * 2. Ajuste a CONFIG no topo do arquivo
 * 3. Substitua 'campo1', 'campo2', etc. pelos campos reais
 * 4. Ajuste as queries SQL conforme necessário
 * 5. Teste todas as operações (GET, POST, PUT, DELETE)
 * 
 * CHECKLIST DE VALIDAÇÃO:
 * ✅ Campos obrigatórios validados no POST
 * ✅ Duplicatas verificadas no POST
 * ✅ UPDATE exclui próprio ID na verificação
 * ✅ UPDATE atualiza TODOS os campos importantes
 * ✅ Mensagens de erro específicas
 * ✅ Tratamento de erros específico (UNIQUE, NOT NULL, etc.)
 * ✅ Auditoria em todas as operações
 * ✅ Soft delete implementado
 * ✅ Logs informativos
 * 
 * BUGS PREVENIDOS:
 * ✅ BUG #1: POST sem validação
 * ✅ BUG #2: UPDATE sem excluir próprio ID
 * ✅ BUG #3: UPDATE com poucos campos
 * ✅ BUG #4: Mensagens genéricas
 * ✅ BUG #5: Catch sem tratamento
 */
