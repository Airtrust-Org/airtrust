/**
 * Cache para endpoints de Qualificações
 * Melhora performance e reduz carga no banco
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

const cache = new Map<string, CacheEntry<any>>();

/**
 * Configurações de cache
 */
export const CACHE_CONFIG = {
  LIST: 5 * 60 * 1000, // 5 minutos para listagens
  DETAIL: 10 * 60 * 1000, // 10 minutos para detalhes
  STATS: 2 * 60 * 1000, // 2 minutos para estatísticas
  MAX_SIZE: 1000, // Máximo de entradas
};

/**
 * Gera chave de cache
 */
export function generateCacheKey(prefix: string, params: Record<string, any>): string {
  const sortedParams = Object.keys(params)
    .sort()
    .map(key => `${key}=${params[key]}`)
    .join('&');
  return `${prefix}:${sortedParams}`;
}

/**
 * Buscar do cache
 */
export function getFromCache<T>(key: string): T | null {
  const entry = cache.get(key);
  
  if (!entry) {
    return null;
  }
  
  const now = Date.now();
  
  // Verificar se expirou
  if (now - entry.timestamp > entry.ttl) {
    cache.delete(key);
    return null;
  }
  
  return entry.data as T;
}

/**
 * Salvar no cache
 */
export function setCache<T>(key: string, data: T, ttl: number = CACHE_CONFIG.LIST): void {
  // Limpar cache se estiver muito grande
  if (cache.size >= CACHE_CONFIG.MAX_SIZE) {
    const now = Date.now();
    let cleaned = 0;
    
    // Remover entradas expiradas
    for (const [k, v] of cache.entries()) {
      if (now - v.timestamp > v.ttl) {
        cache.delete(k);
        cleaned++;
      }
      if (cleaned >= 100) break; // Limpar no máximo 100 por vez
    }
    
    // Se ainda estiver cheio, remover as mais antigas
    if (cache.size >= CACHE_CONFIG.MAX_SIZE) {
      const entries = Array.from(cache.entries());
      entries.sort((a, b) => a[1].timestamp - b[1].timestamp);
      
      for (let i = 0; i < 100 && i < entries.length; i++) {
        cache.delete(entries[i][0]);
      }
    }
  }
  
  cache.set(key, {
    data,
    timestamp: Date.now(),
    ttl,
  });
}

/**
 * Invalidar cache por padrão
 */
export function invalidateCache(pattern: string): number {
  let count = 0;
  
  for (const key of cache.keys()) {
    if (key.startsWith(pattern)) {
      cache.delete(key);
      count++;
    }
  }
  
  return count;
}

/**
 * Limpar todo o cache
 */
export function clearCache(): void {
  cache.clear();
}

/**
 * Estatísticas do cache
 */
export function getCacheStats() {
  const now = Date.now();
  let valid = 0;
  let expired = 0;
  
  for (const entry of cache.values()) {
    if (now - entry.timestamp > entry.ttl) {
      expired++;
    } else {
      valid++;
    }
  }
  
  return {
    total: cache.size,
    valid,
    expired,
    maxSize: CACHE_CONFIG.MAX_SIZE,
    hitRate: 0, // Pode ser implementado com contadores
  };
}

/**
 * Middleware de cache para Hono
 */
export function cacheMiddleware(ttl: number = CACHE_CONFIG.LIST) {
  return async (c: any, next: () => Promise<void>) => {
    const method = c.req.method;
    
    // Apenas cachear GET
    if (method !== 'GET') {
      await next();
      return;
    }
    
    const url = new URL(c.req.url);
    const cacheKey = `cache:${url.pathname}${url.search}`;
    
    // Tentar buscar do cache
    const cached = getFromCache(cacheKey);
    if (cached) {
      c.header('X-Cache', 'HIT');
      return c.json(cached);
    }
    
    // Executar handler
    await next();
    
    // Cachear response se for 200
    if (c.res.status === 200) {
      try {
        const responseData = await c.res.clone().json();
        setCache(cacheKey, responseData, ttl);
        c.header('X-Cache', 'MISS');
      } catch (e) {
        // Não é JSON, não cachear
      }
    }
  };
}
