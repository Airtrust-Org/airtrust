/**
 * src/worker/utils/softDeleteHelper.ts
 * Utilidades para gerenciar soft deletes com auditoria
 */

import type { D1Database } from '../types';
import { AuditLogger } from './auditLogger';

export class SoftDeleteHelper {
  private auditLogger: AuditLogger;

  constructor(private db: D1Database) {
    this.auditLogger = new AuditLogger(db);
  }

  /**
   * Fazer soft delete com auditoria
   */
  async deleteWithAudit(
    tabela: string,
    id: number,
    userId: number,
    dadosAntes?: any
  ): Promise<any> {
    try {
      const resultado = await this.db
        .prepare(
          `
          UPDATE ${tabela} 
          SET deleted_at = CURRENT_TIMESTAMP 
          WHERE id = ? AND deleted_at IS NULL
          RETURNING *
        `
        )
        .bind(id)
        .first();

      if (resultado) {
        await this.auditLogger.log(
          userId,
          'DELETE',
          tabela,
          id,
          dadosAntes || resultado,
          null
        );
      }

      return resultado;
    } catch (error) {
      console.error(`❌ Erro ao fazer soft delete em ${tabela}:`, error);
      throw error;
    }
  }

  /**
   * Restaurar soft deleted record
   */
  async restore(
    tabela: string,
    id: number,
    userId: number
  ): Promise<any> {
    try {
      const resultado = await this.db
        .prepare(
          `
          UPDATE ${tabela} 
          SET deleted_at = NULL 
          WHERE id = ? AND deleted_at IS NOT NULL
          RETURNING *
        `
        )
        .bind(id)
        .first();

      if (resultado) {
        await this.auditLogger.log(
          userId,
          'UPDATE',
          tabela,
          id,
          { deleted_at: new Date().toISOString() },
          { deleted_at: null }
        );
      }

      return resultado;
    } catch (error) {
      console.error(`❌ Erro ao restaurar em ${tabela}:`, error);
      throw error;
    }
  }

  /**
   * Query padrão com filtro soft delete
   */
  buildQuery(
    tabela: string,
    baseQuery: string = '*',
    whereClause: string = ''
  ): string {
    const where = `${tabela}.deleted_at IS NULL`;
    const combined = whereClause ? `${where} AND ${whereClause}` : where;
    return `SELECT ${baseQuery} FROM ${tabela} WHERE ${combined}`;
  }

  /**
   * Contar registros ativos (não deletados)
   */
  async countActive(tabela: string): Promise<number> {
    try {
      const resultado = await this.db
        .prepare(`SELECT COUNT(*) as count FROM ${tabela} WHERE deleted_at IS NULL`)
        .first() as any;

      return resultado?.count || 0;
    } catch (error) {
      console.error(`❌ Erro ao contar ativos em ${tabela}:`, error);
      return 0;
    }
  }

  /**
   * Contar registros deletados
   */
  async countDeleted(tabela: string): Promise<number> {
    try {
      const resultado = await this.db
        .prepare(`SELECT COUNT(*) as count FROM ${tabela} WHERE deleted_at IS NOT NULL`)
        .first() as any;

      return resultado?.count || 0;
    } catch (error) {
      console.error(`❌ Erro ao contar deletados em ${tabela}:`, error);
      return 0;
    }
  }

  /**
   * Listar todos os deletados de uma tabela (admin only)
   */
  async listarDeletados(
    tabela: string,
    limit: number = 100,
    offset: number = 0
  ): Promise<any[]> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT * FROM ${tabela}
          WHERE deleted_at IS NOT NULL
          ORDER BY deleted_at DESC
          LIMIT ? OFFSET ?
        `
        )
        .bind(limit, offset)
        .all();

      return resultado.results || [];
    } catch (error) {
      console.error(`❌ Erro ao listar deletados em ${tabela}:`, error);
      return [];
    }
  }

  /**
   * Purgar (deletar permanentemente) registros deletados há mais de N dias
   */
  async purgeOldDeletes(tabela: string, diasRetencao: number = 30): Promise<number> {
    try {
      await this.db
        .prepare(
          `
          DELETE FROM ${tabela}
          WHERE deleted_at IS NOT NULL
          AND deleted_at < datetime('now', '-${diasRetencao} days')
        `
        )
        .run();

      return 0; // D1 não retorna count de deletes permanentemente
    } catch (error) {
      console.error(`❌ Erro ao fazer purge em ${tabela}:`, error);
      return 0;
    }
  }

  /**
   * Obter estatísticas de soft delete
   */
  async obterEstatisticas(tabela: string): Promise<{
    total: number;
    ativos: number;
    deletados: number;
    percentualDeletado: number;
  }> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT
            COUNT(*) as total,
            SUM(CASE WHEN deleted_at IS NULL THEN 1 ELSE 0 END) as ativos,
            SUM(CASE WHEN deleted_at IS NOT NULL THEN 1 ELSE 0 END) as deletados
          FROM ${tabela}
        `
        )
        .first() as any;

      const total = resultado?.total || 0;
      const ativos = resultado?.ativos || 0;
      const deletados = resultado?.deletados || 0;
      const percentualDeletado = total > 0 ? (deletados / total) * 100 : 0;

      return {
        total,
        ativos,
        deletados,
        percentualDeletado: Math.round(percentualDeletado * 100) / 100,
      };
    } catch (error) {
      console.error(`❌ Erro ao obter estatísticas de ${tabela}:`, error);
      return { total: 0, ativos: 0, deletados: 0, percentualDeletado: 0 };
    }
  }
}
