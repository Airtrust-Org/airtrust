import { AppError } from './AppError';
import type { Env } from '../types/index';

export class R2Service {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private bucket: any;

  constructor(env: Env) {
    this.bucket = env.R2_BUCKET;
  }

  async uploadPdf(
    key: string,
    buffer: Buffer,
    metadata?: Record<string, string>
  ): Promise<string> {
    try {
      if (!this.bucket) {
        throw new AppError('R2 Bucket não configurado', 500, 'R2_NOT_CONFIGURED');
      }

      await this.bucket.put(key, buffer, {
        httpMetadata: {
          contentType: 'application/pdf',
        },
        customMetadata: metadata || {},
      });

      // Retornar URL pública
      const r2Domain = 'https://r2.example.com';
      return `${r2Domain}/${key}`;
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError('Erro ao salvar em R2', 500, 'R2_ERROR');
    }
  }

  async uploadImage(
    key: string,
    buffer: Buffer,
    contentType: string = 'image/png',
    metadata?: Record<string, string>
  ): Promise<string> {
    try {
      if (!this.bucket) {
        throw new AppError('R2 Bucket não configurado', 500, 'R2_NOT_CONFIGURED');
      }

      await this.bucket.put(key, buffer, {
        httpMetadata: {
          contentType,
        },
        customMetadata: metadata || {},
      });

      const r2Domain = 'https://r2.example.com';
      return `${r2Domain}/${key}`;
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError('Erro ao fazer upload de imagem', 500, 'R2_UPLOAD_ERROR');
    }
  }

  async downloadPdf(key: string): Promise<Buffer> {
    try {
      if (!this.bucket) {
        throw new AppError('R2 Bucket não configurado', 500, 'R2_NOT_CONFIGURED');
      }

      const obj = await this.bucket.get(key);
      if (!obj) {
        throw new AppError('PDF não encontrado', 404, 'PDF_NOT_FOUND');
      }

      const buffer = await obj.arrayBuffer();
      return Buffer.from(buffer);
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError('Erro ao baixar arquivo', 404, 'R2_DOWNLOAD_ERROR');
    }
  }

  getPublicUrl(key: string): string {
    const r2Domain = 'https://r2.example.com';
    return `${r2Domain}/${key}`;
  }

  async deleteFile(key: string): Promise<void> {
    try {
      if (!this.bucket) {
        throw new AppError('R2 Bucket não configurado', 500, 'R2_NOT_CONFIGURED');
      }

      await this.bucket.delete(key);
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError('Erro ao deletar arquivo', 500, 'R2_DELETE_ERROR');
    }
  }

  async fileExists(key: string): Promise<boolean> {
    try {
      if (!this.bucket) return false;

      const obj = await this.bucket.head(key);
      return !!obj;
    } catch {
      return false;
    }
  }
}
