/**
 * Utilitários para Cloudflare R2
 * Sistema de gerenciamento de certificados PDF
 */

import { R2Bucket, R2ObjectBody } from '@cloudflare/workers-types';

export interface UploadResult {
  key: string;
  url: string;
  size: number;
  hash: string;
}

/**
 * Sanitizar nome de arquivo
 * Remove acentos, caracteres especiais e normaliza
 */
export function sanitizeFilename(filename: string): string {
  return filename
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^a-z0-9.-]/g, '-')    // Remove caracteres especiais
    .replace(/-+/g, '-')              // Remove hífens duplicados
    .replace(/^-|-$/g, '');           // Remove hífens nas pontas
}

/**
 * Gerar nome do arquivo no padrão: YYYY-MM-DD-CODIGO-NOME.pdf
 * @param data Data no formato YYYY-MM-DD
 * @param codigo Código da qualificação (ex: F1, OPC)
 * @param nome Nome da qualificação
 */
export function generateFilename(
  data: string,
  codigo: string,
  nome: string
): string {
  const [ano, mes, dia] = data.split('-');
  const nomeSanitizado = sanitizeFilename(nome);
  return `${ano}-${mes}-${dia}-${codigo}-${nomeSanitizado}.pdf`;
}

/**
 * Gerar chave do R2 (caminho completo no bucket)
 * Formato: funcionarios/MATRICULA-NOME/YYYY-MM-DD-CODIGO-NOME.pdf
 */
export function generateR2Key(
  funcionarioMatricula: string,
  funcionarioNome: string,
  filename: string
): string {
  const nomeSanitizado = sanitizeFilename(funcionarioNome);
  return `funcionarios/${funcionarioMatricula}-${nomeSanitizado}/${filename}`;
}

/**
 * Upload de arquivo para R2
 */
export async function uploadToR2(
  bucket: R2Bucket,
  key: string,
  file: ArrayBuffer,
  metadata: Record<string, string> = {}
): Promise<UploadResult> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', file);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  await bucket.put(key, file, {
    httpMetadata: {
      contentType: 'application/pdf'
    },
    customMetadata: {
      ...metadata,
      uploadedAt: new Date().toISOString(),
      hash
    }
  });
  
  return {
    key,
    url: `/api/certificados/file/${encodeURIComponent(key)}`,
    size: file.byteLength,
    hash
  };
}

/**
 * Download de arquivo do R2
 */
export async function downloadFromR2(
  bucket: R2Bucket,
  key: string
): Promise<R2ObjectBody | null> {
  return await bucket.get(key);
}

/**
 * Excluir arquivo do R2
 */
export async function deleteFromR2(
  bucket: R2Bucket,
  key: string
): Promise<void> {
  await bucket.delete(key);
}

/**
 * Verificar se arquivo existe no R2
 */
export async function fileExistsInR2(
  bucket: R2Bucket,
  key: string
): Promise<boolean> {
  const object = await bucket.head(key);
  return object !== null;
}

/**
 * Listar arquivos de um funcionário
 */
export async function listFuncionarioCertificados(
  bucket: R2Bucket,
  funcionarioMatricula: string,
  funcionarioNome: string
): Promise<string[]> {
  const nomeSanitizado = sanitizeFilename(funcionarioNome);
  const prefix = `funcionarios/${funcionarioMatricula}-${nomeSanitizado}/`;
  
  const listed = await bucket.list({ prefix });
  return listed.objects.map(obj => obj.key);
}

/**
 * Obter metadados de um arquivo
 */
export async function getFileMetadata(
  bucket: R2Bucket,
  key: string
): Promise<Record<string, string> | null> {
  const object = await bucket.head(key);
  if (!object) return null;
  
  return {
    size: object.size.toString(),
    uploaded: object.uploaded.toISOString(),
    ...object.customMetadata
  };
}
