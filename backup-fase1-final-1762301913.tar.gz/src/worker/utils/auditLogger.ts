/**
 * src/worker/utils/auditLogger.ts
 * Serviço centralizado para logging de auditoria
 */

import type { D1Database } from '../types';

export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'READ';

export interface AuditLogEntry {
  userId: number;
  acao: AuditAction;
  tabela: string;
  registroId: number;
  dadosAntes?: Record<string, any> | null;
  dadosDepois?: Record<string, any> | null;
  ipAddress?: string;
  userAgent?: string;
}

export class AuditLogger {
  constructor(private db: D1Database) {}

  /**
   * Registrar uma ação individual
   */
  async log(
    userId: number,
    acao: AuditAction,
    tabela: string,
    registroId: number,
    dadosAntes?: any,
    dadosDepois?: any,
    ipAddress: string = 'unknown',
    userAgent: string = 'unknown'
  ): Promise<{ id: number }> {
    try {
      const resultado = await this.db
        .prepare(
          `
          INSERT INTO auditoria_detalhada 
          (usuario_id, acao, tabela, registro_id, dados_antes, dados_depois, ip_address, user_agent)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `
        )
        .bind(
          userId,
          acao,
          tabela,
          registroId,
          dadosAntes ? JSON.stringify(dadosAntes) : null,
          dadosDepois ? JSON.stringify(dadosDepois) : null,
          ipAddress,
          userAgent
        )
        .run();

      return { id: resultado.meta.last_row_id };
    } catch (error) {
      console.error('❌ Erro ao registrar auditoria:', error);
      // Não lançar erro para não quebrar a requisição
      return { id: 0 };
    }
  }

  /**
   * Registrar múltiplas ações em lote
   */
  async logBatch(userId: number, operations: AuditLogEntry[]): Promise<void> {
    for (const op of operations) {
      await this.log(
        userId,
        op.acao,
        op.tabela,
        op.registroId,
        op.dadosAntes,
        op.dadosDepois,
        op.ipAddress,
        op.userAgent
      );
    }
  }

  /**
   * Obter histórico de auditoria para um registro
   */
  async obterHistorico(
    tabela: string,
    registroId: number,
    limit: number = 50
  ): Promise<any[]> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT * FROM auditoria_detalhada
          WHERE tabela = ? AND registro_id = ?
          ORDER BY timestamp DESC
          LIMIT ?
        `
        )
        .bind(tabela, registroId, limit)
        .all();

      return resultado.results || [];
    } catch (error) {
      console.error('❌ Erro ao obter histórico:', error);
      return [];
    }
  }

  /**
   * Obter auditoria por usuário
   */
  async obterPorUsuario(
    userId: number,
    limit: number = 100
  ): Promise<any[]> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT * FROM auditoria_detalhada
          WHERE usuario_id = ?
          ORDER BY timestamp DESC
          LIMIT ?
        `
        )
        .bind(userId, limit)
        .all();

      return resultado.results || [];
    } catch (error) {
      console.error('❌ Erro ao obter auditoria do usuário:', error);
      return [];
    }
  }

  /**
   * Obter resumo de alterações
   */
  async obterResumo(horasRetrocesso: number = 24): Promise<{
    creates: number;
    updates: number;
    deletes: number;
    reads: number;
  }> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT 
            COUNT(CASE WHEN acao = 'CREATE' THEN 1 END) as creates,
            COUNT(CASE WHEN acao = 'UPDATE' THEN 1 END) as updates,
            COUNT(CASE WHEN acao = 'DELETE' THEN 1 END) as deletes,
            COUNT(CASE WHEN acao = 'READ' THEN 1 END) as reads
          FROM auditoria_detalhada
          WHERE timestamp > datetime('now', '-${horasRetrocesso} hours')
        `
        )
        .all();

      const row = resultado.results?.[0] as any;
      return {
        creates: row?.creates || 0,
        updates: row?.updates || 0,
        deletes: row?.deletes || 0,
        reads: row?.reads || 0,
      };
    } catch (error) {
      console.error('❌ Erro ao obter resumo:', error);
      return { creates: 0, updates: 0, deletes: 0, reads: 0 };
    }
  }
}
