export interface CacheOptions {
  ttl?: number;
  key: string;
}

export async function getCached<T>(
  env: any,
  options: CacheOptions,
  fetcher: () => Promise<T>
): Promise<T> {
  const { key, ttl = 300 } = options;

  try {
    const cached = await env.CACHE.get(key);
    if (cached) {
      console.log(`Cache hit: ${key}`);
      return JSON.parse(cached);
    }
  } catch (e) {
    console.error('Cache get error:', e);
  }

  const data = await fetcher();

  try {
    await env.CACHE.put(key, JSON.stringify(data), {
      expirationTtl: ttl,
    });
    console.log(`Cache set: ${key}`);
  } catch (e) {
    console.error('Cache put error:', e);
  }

  return data;
}

export async function invalidateCache(env: any, key: string) {
  try {
    await env.CACHE.delete(key);
    console.log(`Cache invalidated: ${key}`);
  } catch (e) {
    console.error('Cache delete error:', e);
  }
}
