/**
 * Parser CSV robusto para AirTrust
 * Trata vírgulas em aspas, UTF-8 BOM, e encoding
 */

/**
 * Remove UTF-8 BOM se presente
 */
export function removeBOM(content: string): string {
  if (content.charCodeAt(0) === 0xFEFF) {
    return content.slice(1);
  }
  return content;
}

/**
 * Parse uma linha CSV respeitando aspas
 */
export function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        current += '"';
        i++; // Pular próxima aspa
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  
  return result;
}

/**
 * Detecta encoding do conteúdo
 */
export function detectEncoding(content: string): string {
  if (content.charCodeAt(0) === 0xFEFF) {
    return 'UTF-8';
  }
  
  const utf8Regex = /[\u00C0-\u00FF]/;
  if (utf8Regex.test(content)) {
    return 'UTF-8';
  }
  
  return 'UTF-8'; // Default
}

/**
 * Parse arquivo CSV completo
 */
export function parseCSVFile(content: string): any[] {
  content = removeBOM(content);
  
  const lines = content.split(/\r?\n/).filter(line => line.trim());
  
  if (lines.length < 2) {
    return [];
  }
  
  const headers = parseCSVLine(lines[0]);
  
  const result: any[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    const obj: any = {};
    
    headers.forEach((header, index) => {
      obj[header] = values[index] || null;
    });
    
    result.push(obj);
  }
  
  return result;
}
