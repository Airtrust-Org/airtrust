
export const validateAgendamento = (dados: any) => {
  const errors = [];
  
  if (!dados.dados_gerais) {
    errors.push('dados_gerais obrigatório');
  } else {
    const dg = dados.dados_gerais;
    
    if (!dg.simulador_id) {
      errors.push('simulador_id obrigatório em dados_gerais');
    }
    
    if (!dg.instrutor_id) {
      errors.push('instrutor_id obrigatório em dados_gerais');
    }
    
    if (!dg.data_inicio) {
      errors.push('data_inicio obrigatória em dados_gerais');
    }
    
    if (dg.data_inicio && !/^\d{4}-\d{2}-\d{2}$/.test(dg.data_inicio)) {
      errors.push('data_inicio deve estar no formato YYYY-MM-DD');
    }
    
    if (dg.hora_inicio && !/^\d{2}:\d{2}$/.test(dg.hora_inicio)) {
      errors.push('hora_inicio deve estar no formato HH:MM');
    }
  }
  
  if (!dados.participantes || !Array.isArray(dados.participantes)) {
    errors.push('participantes deve ser um array');
  } else if (dados.participantes.length === 0) {
    errors.push('pelo menos 1 participante obrigatório');
  } else {
    dados.participantes.forEach((p: any, index: number) => {
      if (!p.colaborador_id && !p.id) {
        errors.push(`participante[${index}]: colaborador_id ou id obrigatório`);
      }
      
      if (p.funcao_na_sessao && !['PIC', 'SIC', 'DUAL'].includes(p.funcao_na_sessao)) {
        errors.push(`participante[${index}]: funcao_na_sessao deve ser PIC, SIC ou DUAL`);
      }
    });
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateFichaStatus = (status: string) => {
  const statusValidos = [
    'RASCUNHO',
    'PENDENTE_ALUNO', 
    'PENDENTE_INSTRUTOR_FINAL',
    'PENDENTE_CHECK',
    'CONCLUIDA',
    'REPROVADA'
  ];
  
  return {
    isValid: statusValidos.includes(status),
    errors: statusValidos.includes(status) ? [] : [`Status deve ser um de: ${statusValidos.join(', ')}`]
  };
};

export const validateSimuladorData = (dados: any) => {
  const errors = [];
  
  if (!dados.nome) {
    errors.push('nome obrigatório');
  }
  
  if (!dados.codigo_identificacao) {
    errors.push('codigo_identificacao obrigatório');
  }
  
  if (!dados.tipo_simulador) {
    errors.push('tipo_simulador obrigatório');
  }
  
  if (!dados.aeronave_base) {
    errors.push('aeronave_base obrigatória');
  }
  
  const tiposValidos = ['FNPT-I', 'FNPT-II', 'FFS'];
  if (dados.tipo_simulador && !tiposValidos.includes(dados.tipo_simulador)) {
    errors.push(`tipo_simulador deve ser um de: ${tiposValidos.join(', ')}`);
  }
  
  const statusValidos = ['ATIVO', 'MANUTENCAO', 'INATIVO'];
  if (dados.status && !statusValidos.includes(dados.status)) {
    errors.push(`status deve ser um de: ${statusValidos.join(', ')}`);
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateManobraData = (dados: any) => {
  const errors = [];
  
  if (!dados.manobra_id_codigo) {
    errors.push('manobra_id_codigo obrigatório');
  }
  
  if (!dados.nome_manobra) {
    errors.push('nome_manobra obrigatório');
  }
  
  if (!dados.categoria) {
    errors.push('categoria obrigatória');
  }
  
  if (dados.pontuacao_minima !== undefined) {
    const pontuacao = Number(dados.pontuacao_minima);
    if (isNaN(pontuacao) || pontuacao < 1 || pontuacao > 10) {
      errors.push('pontuacao_minima deve ser um número entre 1 e 10');
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateNumericId = (id: any, fieldName: string) => {
  const numId = Number(id);
  if (isNaN(numId) || numId <= 0) {
    return {
      isValid: false,
      errors: [`${fieldName} deve ser um número inteiro positivo`]
    };
  }
  return {
    isValid: true,
    errors: []
  };
};

export const validateDateBR = (date: string, fieldName: string) => {
  if (!date) {
    return {
      isValid: false,
      errors: [`${fieldName} é obrigatório`]
    };
  }
  
  const formatoISO = /^\d{4}-\d{2}-\d{2}$/;
  const formatoBR = /^\d{2}\/\d{2}\/\d{4}$/;
  
  if (!formatoISO.test(date) && !formatoBR.test(date)) {
    return {
      isValid: false,
      errors: [`${fieldName} deve estar no formato DD/MM/YYYY ou YYYY-MM-DD`]
    };
  }
  
  return {
    isValid: true,
    errors: []
  };
};
