
import { sign, verify } from 'hono/jwt';

const JWT_SECRET = 'airtrust-secret-key-change-in-production-2024';
const JWT_EXPIRES_IN = 60 * 60 * 24; // 24 horas
const REFRESH_EXPIRES_IN = 60 * 60 * 24 * 7; // 7 dias

export interface JWTPayload extends Record<string, unknown> {
  userId: number;
  email: string;
  role: 'admin' | 'gestor' | 'funcionario';
  iat?: number;
  exp?: number;
}

export const jwtUtils = {
  generateAccessToken: async (payload: Omit<JWTPayload, 'iat' | 'exp'>) => {
    const now = Math.floor(Date.now() / 1000);
    return await sign(
      {
        ...payload,
        iat: now,
        exp: now + JWT_EXPIRES_IN
      },
      JWT_SECRET
    );
  },

  generateRefreshToken: async (payload: Omit<JWTPayload, 'iat' | 'exp'>) => {
    const now = Math.floor(Date.now() / 1000);
    return await sign(
      {
        ...payload,
        iat: now,
        exp: now + REFRESH_EXPIRES_IN
      },
      JWT_SECRET
    );
  },

  verifyToken: async (token: string): Promise<JWTPayload | null> => {
    try {
      const decoded = await verify(token, JWT_SECRET);
      return decoded as unknown as JWTPayload;
    } catch (error) {
      return null;
    }
  },

  extractToken: (authHeader: string | undefined): string | null => {
    if (!authHeader) return null;
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') return null;
    return parts[1];
  }
};
