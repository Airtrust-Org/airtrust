/**
 * Sistema de Métricas e Monitoring
 * Coleta métricas de performance e uso da aplicação
 */

export interface Metric {
  name: string;
  value: number;
  timestamp: number;
  tags?: Record<string, string>;
}

export interface PerformanceMetric {
  endpoint: string;
  method: string;
  duration: number;
  status: number;
  timestamp: number;
}

class MetricsCollector {
  private metrics: Metric[] = [];
  private performanceMetrics: PerformanceMetric[] = [];
  private readonly MAX_METRICS = 1000;

  /**
   * Registrar métrica customizada
   */
  record(name: string, value: number, tags?: Record<string, string>): void {
    this.metrics.push({
      name,
      value,
      timestamp: Date.now(),
      tags,
    });

    // Limpar métricas antigas
    if (this.metrics.length > this.MAX_METRICS) {
      this.metrics = this.metrics.slice(-this.MAX_METRICS);
    }
  }

  /**
   * Registrar métrica de performance de API
   */
  recordPerformance(metric: PerformanceMetric): void {
    this.performanceMetrics.push(metric);

    // Limpar métricas antigas
    if (this.performanceMetrics.length > this.MAX_METRICS) {
      this.performanceMetrics = this.performanceMetrics.slice(-this.MAX_METRICS);
    }
  }

  /**
   * Obter estatísticas de performance
   */
  getPerformanceStats(endpoint?: string): {
    count: number;
    avgDuration: number;
    minDuration: number;
    maxDuration: number;
    p50: number;
    p95: number;
    p99: number;
    errorRate: number;
  } {
    let metrics = this.performanceMetrics;

    if (endpoint) {
      metrics = metrics.filter((m) => m.endpoint === endpoint);
    }

    if (metrics.length === 0) {
      return {
        count: 0,
        avgDuration: 0,
        minDuration: 0,
        maxDuration: 0,
        p50: 0,
        p95: 0,
        p99: 0,
        errorRate: 0,
      };
    }

    const durations = metrics.map((m) => m.duration).sort((a, b) => a - b);
    const errors = metrics.filter((m) => m.status >= 400).length;

    return {
      count: metrics.length,
      avgDuration: durations.reduce((a, b) => a + b, 0) / durations.length,
      minDuration: durations[0],
      maxDuration: durations[durations.length - 1],
      p50: durations[Math.floor(durations.length * 0.5)],
      p95: durations[Math.floor(durations.length * 0.95)],
      p99: durations[Math.floor(durations.length * 0.99)],
      errorRate: (errors / metrics.length) * 100,
    };
  }

  /**
   * Obter todas as métricas
   */
  getAllMetrics(): Metric[] {
    return [...this.metrics];
  }

  /**
   * Limpar métricas
   */
  clear(): void {
    this.metrics = [];
    this.performanceMetrics = [];
  }

  /**
   * Exportar métricas para Cloudflare Analytics
   */
  async exportToAnalytics(env: any): Promise<void> {
    // Implementar integração com Cloudflare Analytics
    // ou outro serviço de métricas
    console.log('Exporting metrics to analytics...');
  }
}

// Singleton
export const metrics = new MetricsCollector();

/**
 * Middleware para coletar métricas de performance
 */
export function metricsMiddleware() {
  return async (c: any, next: () => Promise<void>) => {
    const start = Date.now();
    const method = c.req.method;
    const url = new URL(c.req.url);
    const endpoint = url.pathname;

    try {
      await next();

      const duration = Date.now() - start;
      const status = c.res.status;

      metrics.recordPerformance({
        endpoint,
        method,
        duration,
        status,
        timestamp: start,
      });

      // Adicionar header de performance
      c.header('X-Response-Time', `${duration}ms`);

      // Log de performance lenta
      if (duration > 1000) {
        console.warn(`Slow request: ${method} ${endpoint} took ${duration}ms`);
      }
    } catch (error) {
      const duration = Date.now() - start;

      metrics.recordPerformance({
        endpoint,
        method,
        duration,
        status: 500,
        timestamp: start,
      });

      throw error;
    }
  };
}

/**
 * Contador de eventos
 */
export class Counter {
  private count = 0;

  increment(value: number = 1): void {
    this.count += value;
  }

  decrement(value: number = 1): void {
    this.count -= value;
  }

  get value(): number {
    return this.count;
  }

  reset(): void {
    this.count = 0;
  }
}

/**
 * Contadores globais
 */
export const counters = {
  qualificacoes: {
    created: new Counter(),
    updated: new Counter(),
    deleted: new Counter(),
    fetched: new Counter(),
  },
  cache: {
    hits: new Counter(),
    misses: new Counter(),
  },
  rateLimit: {
    blocked: new Counter(),
  },
};
