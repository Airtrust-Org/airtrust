/**
 * Funções de sanitização de input para segurança
 */

export const sanitizeInput = (input: string): string => {
  if (!input) return input;
  
  return input
    .replace(/<script[^>]*>.*?<\/script>/gi, '') // Remove scripts
    .replace(/<[^>]+>/g, '') // Remove HTML tags
    .replace(/javascript:/gi, '') // Remove javascript:
    .replace(/on\w+\s*=/gi, '') // Remove event handlers (onclick, onerror, etc)
    .replace(/alert\(/gi, '') // Remove alert calls
    .trim();
};

export const sanitizeHtml = (html: string): string => {
  if (!html) return html;
  
  return html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
};
