/**
 * Utilitários de Normalização para Importação CSV
 * Preserva acentos, apóstrofo curvo e caracteres especiais
 */

const EXCECOES_TITLE_CASE = new Set([
  'de', 'da', 'do', 'das', 'dos', 'e', 'em', 'para', 'com', 'sem'
]);

/**
 * Normaliza nome para Title Case preservando caracteres especiais
 * Exemplos: "JOÃO DA SILVA" → "João da Silva"
 *          "sant'anna" → "Sant'Anna"
 *          "KÜHR" → "Kühr"
 */
export function normalizarNome(nome: string): string {
  if (!nome) return '';
  
  nome = nome.trim().replace(/\s+/g, ' ');
  
  nome = nome.replace(/['']/g, "'");
  
  const palavras = nome.toLowerCase().split(' ');
  const normalizadas = palavras.map((palavra, index) => {
    if (index === 0) {
      return palavra.charAt(0).toUpperCase() + palavra.slice(1);
    }
    
    if (EXCECOES_TITLE_CASE.has(palavra)) {
      return palavra;
    }
    
    if (palavra.includes("'")) {
      return palavra.split("'").map(parte => 
        parte.charAt(0).toUpperCase() + parte.slice(1)
      ).join("'");
    }
    
    return palavra.charAt(0).toUpperCase() + palavra.slice(1);
  });
  
  return normalizadas.join(' ');
}

/**
 * Normaliza CPF: aceita com/sem máscara, valida formato
 * Entrada: "123.456.789-00" ou "12345678900"
 * Saída: "12345678900" (apenas dígitos)
 */
export function normalizarCPF(cpf: string, validarDV: boolean = false): { 
  valido: boolean; 
  cpf: string; 
  erro?: string 
} {
  if (!cpf) return { valido: true, cpf: '' };
  
  const apenasDigitos = cpf.replace(/\D/g, '');
  
  if (apenasDigitos === '00000000000') {
    return { 
      valido: false, 
      cpf: apenasDigitos, 
      erro: 'CPF placeholder (000.000.000-00) não permitido' 
    };
  }
  
  if (apenasDigitos.length !== 11) {
    return { 
      valido: false, 
      cpf: apenasDigitos, 
      erro: `CPF deve ter 11 dígitos (recebido: ${apenasDigitos.length})` 
    };
  }
  
  if (validarDV) {
    if (!validarDigitoVerificadorCPF(apenasDigitos)) {
      return { 
        valido: false, 
        cpf: apenasDigitos, 
        erro: 'CPF com dígito verificador inválido' 
      };
    }
  }
  
  return { valido: true, cpf: apenasDigitos };
}

/**
 * Valida dígito verificador do CPF
 */
function validarDigitoVerificadorCPF(cpf: string): boolean {
  if (cpf.length !== 11) return false;
  
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  
  let soma = 0;
  for (let i = 0; i < 9; i++) {
    soma += parseInt(cpf.charAt(i)) * (10 - i);
  }
  let resto = (soma * 10) % 11;
  if (resto === 10) resto = 0;
  if (resto !== parseInt(cpf.charAt(9))) return false;
  
  soma = 0;
  for (let i = 0; i < 10; i++) {
    soma += parseInt(cpf.charAt(i)) * (11 - i);
  }
  resto = (soma * 10) % 11;
  if (resto === 10) resto = 0;
  if (resto !== parseInt(cpf.charAt(10))) return false;
  
  return true;
}

/**
 * Normaliza código ANAC: 6-7 dígitos
 */
export function normalizarCodigoANAC(codigo: string): { 
  valido: boolean; 
  codigo: string; 
  erro?: string 
} {
  if (!codigo) return { valido: true, codigo: '' };
  
  const apenasDigitos = codigo.replace(/\D/g, '');
  
  if (apenasDigitos.length < 6 || apenasDigitos.length > 7) {
    return { 
      valido: false, 
      codigo: apenasDigitos, 
      erro: `Código ANAC deve ter 6 ou 7 dígitos (recebido: ${apenasDigitos.length})` 
    };
  }
  
  return { valido: true, codigo: apenasDigitos };
}

/**
 * Normaliza função aeronáutica
 */
const FUNCOES_VALIDAS = ['PC', 'SIC', 'CMS', 'MMA', 'CMTE', 'COPILOTO', 'ADM', 'ADMIN', 'ADMINISTRATIVO'];
const FUNCOES_AERONAUTICAS = ['PC', 'SIC', 'CMS', 'MMA', 'CMTE', 'COPILOTO'];
const MAPEAMENTO_FUNCOES: Record<string, string> = {
  'PIC': 'PC',
  'CMTE': 'PC',
  'COMANDANTE': 'PC',
  'COPILOTO': 'SIC',
  'ADMIN': 'ADM',
  'ADMINISTRATIVO': 'ADM'
};

export function normalizarFuncao(funcao: string): { 
  valido: boolean; 
  funcao: string; 
  erro?: string;
  requerANAC: boolean;
} {
  if (!funcao) {
    return { valido: false, funcao: '', erro: 'Função obrigatória', requerANAC: false };
  }
  
  const funcaoUpper = funcao.trim().toUpperCase();
  
  const funcaoMapeada = MAPEAMENTO_FUNCOES[funcaoUpper] || funcaoUpper;
  
  if (!FUNCOES_VALIDAS.includes(funcaoMapeada)) {
    return { 
      valido: false, 
      funcao: funcaoMapeada, 
      erro: `Função inválida. Válidas: ${FUNCOES_VALIDAS.join(', ')}`,
      requerANAC: false
    };
  }
  
  return { 
    valido: true, 
    funcao: funcaoMapeada,
    erro: undefined,
    requerANAC: FUNCOES_AERONAUTICAS.includes(funcaoMapeada)
  };
}

/**
 * Normaliza telefone: (DD) 9XXXX-XXXX
 */
export function normalizarTelefone(telefone: string): { 
  valido: boolean; 
  telefone: string; 
  erro?: string 
} {
  if (!telefone) return { valido: true, telefone: '' };
  
  const apenasDigitos = telefone.replace(/\D/g, '');
  
  if (apenasDigitos.length < 10 || apenasDigitos.length > 11) {
    return { 
      valido: false, 
      telefone: apenasDigitos, 
      erro: `Telefone deve ter 10 ou 11 dígitos (recebido: ${apenasDigitos.length})` 
    };
  }
  
  return { valido: true, telefone: apenasDigitos };
}

/**
 * Normaliza email
 */
export function normalizarEmail(email: string): { 
  valido: boolean; 
  email: string; 
  erro?: string 
} {
  if (!email) return { valido: false, email: '', erro: 'Email obrigatório' };
  
  const emailLower = email.trim().toLowerCase();
  
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!regex.test(emailLower)) {
    return { 
      valido: false, 
      email: emailLower, 
      erro: 'Email com formato inválido' 
    };
  }
  
  return { valido: true, email: emailLower };
}

/**
 * Normaliza matrícula
 */
export function normalizarMatricula(matricula: string): string {
  if (!matricula) return '';
  
  return matricula.trim().replace(/\.0+$/, '');
}

/**
 * Normaliza aeronave
 */
const AERONAVES_VALIDAS = ['AW139', 'AW169', 'SK76', 'H135', 'H145', 'EC135', 'EC145', 'AS350', 'AS355'];

export function normalizarAeronave(aeronave: string): { 
  valido: boolean; 
  aeronave: string; 
  erro?: string 
} {
  if (!aeronave) return { valido: true, aeronave: '' };
  
  const aeronaveUpper = aeronave.trim().toUpperCase();
  
  if (!AERONAVES_VALIDAS.includes(aeronaveUpper)) {
    return { 
      valido: false, 
      aeronave: aeronaveUpper, 
      erro: `Aeronave inválida. Válidas: ${AERONAVES_VALIDAS.join(', ')}` 
    };
  }
  
  return { valido: true, aeronave: aeronaveUpper };
}

/**
 * Normaliza booleano (is_instrutor, is_checador)
 */
export function normalizarBooleano(valor: string): number {
  if (!valor) return 0;
  
  const valorLower = valor.toString().toLowerCase().trim();
  
  if (['1', 'true', 'sim', 's', 'yes', 'y'].includes(valorLower)) {
    return 1;
  }
  
  return 0;
}

/**
 * Detecta e remove caracteres perigosos (XSS)
 */
export function sanitizarTexto(texto: string): { 
  seguro: boolean; 
  texto: string; 
  erro?: string 
} {
  if (!texto) return { seguro: true, texto: '' };
  
  const padroesPeriogosos = [
    /<script/i,
    /javascript:/i,
    /onerror=/i,
    /onclick=/i,
    /<iframe/i,
    /<embed/i,
    /<object/i
  ];
  
  for (const padrao of padroesPeriogosos) {
    if (padrao.test(texto)) {
      return { 
        seguro: false, 
        texto: '', 
        erro: 'Conteúdo HTML/JavaScript não permitido' 
      };
    }
  }
  
  const textoLimpo = texto
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero-width
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, ''); // Controle
  
  return { seguro: true, texto: textoLimpo };
}

/**
 * Valida cabeçalho do CSV
 */
export const CABECALHO_ESPERADO = [
  'nome', 'matricula', 'cpf', 'codigo_anac', 'funcao', 'base', 'contrato',
  'telefone', 'email', 'status', 'cma_numero', 'cma_data_vencimento',
  'cma_status', 'aso_data_vencimento', 'nivel_icao', 'nivel_icao_data_vencimento',
  'nivel_icao_status', 'is_instrutor', 'is_checador', 'aeronave_principal'
];

export function validarCabecalho(cabecalho: string[]): { 
  valido: boolean; 
  faltantes: string[]; 
  extras: string[]; 
  erro?: string 
} {
  const cabecalhoNormalizado = cabecalho.map(c => c.trim().toLowerCase());
  
  const faltantes = CABECALHO_ESPERADO.filter(c => !cabecalhoNormalizado.includes(c));
  const extras = cabecalhoNormalizado.filter(c => !CABECALHO_ESPERADO.includes(c));
  
  if (faltantes.length > 0 || extras.length > 0) {
    return {
      valido: false,
      faltantes,
      extras,
      erro: `Cabeçalho incorreto. Faltantes: [${faltantes.join(', ')}]. Extras: [${extras.join(', ')}]`
    };
  }
  
  return { valido: true, faltantes: [], extras: [] };
}
