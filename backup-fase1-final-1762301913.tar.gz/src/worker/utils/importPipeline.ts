/**
 * Pipeline Unificado de Importação de Funcionários
 * Suporta: CSV, XLSX, Google Sheets, Colar/Colar
 */

import { 
  normalizarNome, 
  normalizarCPF, 
  normalizarCodigoANAC,
  normalizarFuncao,
  normalizarTelefone,
  normalizarEmail,
  normalizarMatricula,
  normalizarAeronave,
  normalizarBooleano,
  sanitizarTexto,
  CABECALHO_ESPERADO
} from './csvNormalizers';

export interface ImportConfig {
  modo: 'csv' | 'xlsx' | 'sheets' | 'paste';
  politicaDuplicidade: 'parcial' | 'all-or-nothing';
  validarCPF: boolean;
  limiteErroPercent: number; // ex: 3 = 3%
  maxLinhas: number;
  maxTamanhoMB: number;
}

export interface MapeamentoColunas {
  [colunaArquivo: string]: string; // ex: "Mat." -> "matricula"
}

export interface LinhaProcessada {
  linha: number;
  dados: any;
  valida: boolean;
  erros: string[];
  warnings: string[];
}

export interface ResultadoImportacao {
  uploadId: string;
  recebidos: number;
  validos: number;
  inseridos: number;
  atualizados: number;
  rejeitados: number;
  erros: LinhaProcessada[];
  duracao: number;
}

/**
 * CAMADA 0: Detectar encoding
 */
export function detectarEncoding(conteudo: string): string {
  if (conteudo.charCodeAt(0) === 0xFEFF) {
    return 'UTF-8-BOM';
  }
  
  try {
    const encoder = new TextEncoder();
    const decoder = new TextDecoder('utf-8', { fatal: true });
    const encoded = encoder.encode(conteudo);
    decoder.decode(encoded);
    return 'UTF-8';
  } catch {
    return 'UNKNOWN';
  }
}

/**
 * CAMADA 1: Sanitização
 */
export function sanitizarConteudo(conteudo: string): {
  seguro: boolean;
  conteudo: string;
  erros: string[];
  warnings: string[];
} {
  const erros: string[] = [];
  const warnings: string[] = [];
  
  const encoding = detectarEncoding(conteudo);
  if (encoding === 'UNKNOWN') {
    erros.push('Encoding não suportado. Use UTF-8');
    return { seguro: false, conteudo: '', erros, warnings };
  }
  
  let limpo = conteudo.replace(/^\uFEFF/, '');
  
  limpo = limpo.replace(/\r\n/g, '\n');
  
  const padroesPeriogosos = [
    { regex: /<script[\s\S]*?>/gi, nome: '<script>' },
    { regex: /javascript:/gi, nome: 'javascript:' },
    { regex: /onerror\s*=/gi, nome: 'onerror=' },
    { regex: /onclick\s*=/gi, nome: 'onclick=' },
    { regex: /<iframe/gi, nome: '<iframe>' },
  ];
  
  for (const padrao of padroesPeriogosos) {
    if (padrao.regex.test(limpo)) {
      erros.push(`Conteúdo perigoso detectado: ${padrao.nome}`);
      return { seguro: false, conteudo: '', erros, warnings };
    }
  }
  
  const caracteresControle = limpo.match(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g);
  if (caracteresControle && caracteresControle.length > 0) {
    warnings.push(`${caracteresControle.length} caracteres de controle removidos`);
    limpo = limpo.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
  }
  
  const zeroWidth = limpo.match(/[\u200B-\u200D\uFEFF]/g);
  if (zeroWidth && zeroWidth.length > 0) {
    warnings.push(`${zeroWidth.length} caracteres invisíveis removidos`);
    limpo = limpo.replace(/[\u200B-\u200D\uFEFF]/g, '');
  }
  
  return { seguro: true, conteudo: limpo, erros, warnings };
}

/**
 * CAMADA 2: Mapeamento automático de colunas
 */
export function mapearColunas(cabecalhoArquivo: string[]): {
  mapeamento: MapeamentoColunas;
  confianca: number; // 0-100%
  sugestoes: { [key: string]: string[] };
} {
  const mapeamento: MapeamentoColunas = {};
  const sugestoes: { [key: string]: string[] } = {};
  let matches = 0;
  
  const sinonimos: { [key: string]: string[] } = {
    'nome': ['nome', 'name', 'funcionario', 'colaborador', 'guerra'],
    'matricula': ['matricula', 'mat', 'mat.', 'matricula', 'registro', 'id'],
    'cpf': ['cpf', 'documento', 'doc'],
    'codigo_anac': ['codigo_anac', 'anac', 'codigo anac', 'cod_anac', 'canac'],
    'funcao': ['funcao', 'função', 'cargo', 'role', 'position'],
    'base': ['base', 'local', 'localidade', 'cidade'],
    'contrato': ['contrato', 'tipo_contrato', 'vinculo'],
    'telefone': ['telefone', 'tel', 'fone', 'celular', 'phone'],
    'email': ['email', 'e-mail', 'mail', 'correio'],
    'status': ['status', 'situacao', 'situação', 'ativo'],
    'is_instrutor': ['is_instrutor', 'instrutor', 'instr', 'inst'],
    'is_checador': ['is_checador', 'checador', 'check', 'chk'],
  };
  
  for (const colArquivo of cabecalhoArquivo) {
    const colNormalizada = colArquivo.toLowerCase().trim();
    let encontrado = false;
    
    for (const [colInterna, aliases] of Object.entries(sinonimos)) {
      for (const alias of aliases) {
        if (colNormalizada === alias || colNormalizada.includes(alias)) {
          mapeamento[colArquivo] = colInterna;
          matches++;
          encontrado = true;
          break;
        }
      }
      if (encontrado) break;
    }
    
    if (!encontrado) {
      sugestoes[colArquivo] = [];
      for (const [colInterna, aliases] of Object.entries(sinonimos)) {
        const similarity = calcularSimilaridade(colNormalizada, aliases[0]);
        if (similarity > 0.5) {
          sugestoes[colArquivo].push(colInterna);
        }
      }
    }
  }
  
  const confianca = Math.round((matches / CABECALHO_ESPERADO.length) * 100);
  
  return { mapeamento, confianca, sugestoes };
}

/**
 * Calcular similaridade entre strings (Levenshtein simplificado)
 */
function calcularSimilaridade(a: string, b: string): number {
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1.0;
  
  let matches = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] === b[i]) matches++;
  }
  
  return matches / maxLen;
}

/**
 * CAMADA 3: Normalizar linha
 */
export function normalizarLinha(
  dados: any,
  numeroLinha: number,
  config: ImportConfig
): LinhaProcessada {
  const erros: string[] = [];
  const warnings: string[] = [];
  const dadosNormalizados: any = {};
  
  if (dados.nome) {
    const sanitNome = sanitizarTexto(dados.nome);
    if (!sanitNome.seguro) {
      erros.push(`nome: ${sanitNome.erro}`);
    } else {
      dadosNormalizados.nome = normalizarNome(sanitNome.texto);
      if (!dadosNormalizados.nome) {
        erros.push('nome: obrigatório');
      }
    }
  } else {
    erros.push('nome: obrigatório');
  }
  
  if (dados.cpf) {
    const cpfResult = normalizarCPF(dados.cpf, config.validarCPF);
    if (!cpfResult.valido) {
      erros.push(`cpf: ${cpfResult.erro}`);
    } else {
      dadosNormalizados.cpf = cpfResult.cpf;
    }
  }
  
  if (dados.funcao) {
    const funcaoResult = normalizarFuncao(dados.funcao);
    if (!funcaoResult.valido) {
      erros.push(`funcao: ${funcaoResult.erro}`);
    } else {
      dadosNormalizados.funcao = funcaoResult.funcao;
      
      if (funcaoResult.requerANAC) {
        if (!dados.codigo_anac) {
          erros.push(`codigo_anac: obrigatório para função ${dadosNormalizados.funcao}`);
        } else {
          const anacResult = normalizarCodigoANAC(dados.codigo_anac);
          if (!anacResult.valido) {
            erros.push(`codigo_anac: ${anacResult.erro}`);
          } else {
            dadosNormalizados.codigo_anac = anacResult.codigo;
          }
        }
      } else {
        if (dados.codigo_anac) {
          const anacResult = normalizarCodigoANAC(dados.codigo_anac);
          if (anacResult.valido) {
            dadosNormalizados.codigo_anac = anacResult.codigo;
          }
        }
      }
    }
  } else {
    erros.push('funcao: obrigatória');
  }
  
  if (dados.email) {
    const emailResult = normalizarEmail(dados.email);
    if (!emailResult.valido) {
      erros.push(`email: ${emailResult.erro}`);
    } else {
      dadosNormalizados.email = emailResult.email;
    }
  } else {
    erros.push('email: obrigatório');
  }
  
  if (dados.telefone) {
    const telResult = normalizarTelefone(dados.telefone);
    if (!telResult.valido) {
      warnings.push(`telefone: ${telResult.erro}`);
    } else {
      dadosNormalizados.telefone = telResult.telefone;
    }
  }
  
  dadosNormalizados.matricula = normalizarMatricula(dados.matricula || '');
  
  dadosNormalizados.base = dados.base?.trim() || 'SBRJ';
  dadosNormalizados.contrato = dados.contrato?.trim() || 'CLT';
  dadosNormalizados.status = dados.status?.trim() || 'ATIVO';
  
  dadosNormalizados.is_instrutor = normalizarBooleano(dados.is_instrutor || '0');
  dadosNormalizados.is_checador = normalizarBooleano(dados.is_checador || '0');
  
  if (dados.aeronave_principal) {
    const aeronaveResult = normalizarAeronave(dados.aeronave_principal);
    if (!aeronaveResult.valido) {
      warnings.push(`aeronave_principal: ${aeronaveResult.erro}`);
    } else {
      dadosNormalizados.aeronave_principal = aeronaveResult.aeronave;
    }
  }
  
  dadosNormalizados.cma_numero = dados.cma_numero?.trim() || null;
  dadosNormalizados.cma_data_vencimento = dados.cma_data_vencimento?.trim() || null;
  dadosNormalizados.cma_status = dados.cma_status?.trim() || null;
  dadosNormalizados.aso_data_vencimento = dados.aso_data_vencimento?.trim() || null;
  dadosNormalizados.nivel_icao = dados.nivel_icao?.trim() || null;
  dadosNormalizados.nivel_icao_data_vencimento = dados.nivel_icao_data_vencimento?.trim() || null;
  dadosNormalizados.nivel_icao_status = dados.nivel_icao_status?.trim() || null;
  
  return {
    linha: numeroLinha,
    dados: dadosNormalizados,
    valida: erros.length === 0,
    erros,
    warnings
  };
}

/**
 * CAMADA 4: Validar duplicados
 */
export async function validarDuplicados(
  linhas: LinhaProcessada[],
  db: any
): Promise<{ linha: number; campo: string; valor: string; conflito: string }[]> {
  const duplicados: any[] = [];
  
  const cpfsVistos = new Map<string, number>();
  const emailsVistos = new Map<string, number>();
  const matriculasVistas = new Map<string, number>();
  
  for (const linha of linhas) {
    if (!linha.valida) continue;
    
    const { cpf, email, matricula } = linha.dados;
    
    if (cpf) {
      if (cpfsVistos.has(cpf)) {
        duplicados.push({
          linha: linha.linha,
          campo: 'cpf',
          valor: cpf,
          conflito: `Duplicado na linha ${cpfsVistos.get(cpf)}`
        });
      } else {
        cpfsVistos.set(cpf, linha.linha);
      }
    }
    
    if (email) {
      if (emailsVistos.has(email)) {
        duplicados.push({
          linha: linha.linha,
          campo: 'email',
          valor: email,
          conflito: `Duplicado na linha ${emailsVistos.get(email)}`
        });
      } else {
        emailsVistos.set(email, linha.linha);
      }
    }
    
    if (matricula) {
      if (matriculasVistas.has(matricula)) {
        duplicados.push({
          linha: linha.linha,
          campo: 'matricula',
          valor: matricula,
          conflito: `Duplicado na linha ${matriculasVistas.get(matricula)}`
        });
      } else {
        matriculasVistas.set(matricula, linha.linha);
      }
    }
  }
  
  const cpfsUnicos = Array.from(cpfsVistos.keys()).filter(Boolean);
  const emailsUnicos = Array.from(emailsVistos.keys()).filter(Boolean);
  const matriculasUnicas = Array.from(matriculasVistas.keys()).filter(Boolean);
  
  if (cpfsUnicos.length > 0) {
    const placeholders = cpfsUnicos.map(() => '?').join(',');
    const result = await db.prepare(`
      SELECT cpf FROM funcionarios 
      WHERE cpf IN (${placeholders}) AND deleted_at IS NULL
    `).bind(...cpfsUnicos).all();
    
    for (const row of result.results || []) {
      const linhaOriginal = cpfsVistos.get(row.cpf);
      duplicados.push({
        linha: linhaOriginal!,
        campo: 'cpf',
        valor: row.cpf,
        conflito: 'Já existe no banco de dados'
      });
    }
  }
  
  if (emailsUnicos.length > 0) {
    const placeholders = emailsUnicos.map(() => '?').join(',');
    const result = await db.prepare(`
      SELECT email FROM funcionarios 
      WHERE email IN (${placeholders}) AND deleted_at IS NULL
    `).bind(...emailsUnicos).all();
    
    for (const row of result.results || []) {
      const linhaOriginal = emailsVistos.get(row.email);
      duplicados.push({
        linha: linhaOriginal!,
        campo: 'email',
        valor: row.email,
        conflito: 'Já existe no banco de dados'
      });
    }
  }
  
  return duplicados;
}

/**
 * Gerar CSV de erros
 */
export function gerarCSVErros(linhas: LinhaProcessada[]): string {
  const linhasComErro = linhas.filter(l => !l.valida || l.warnings.length > 0);
  
  if (linhasComErro.length === 0) {
    return 'linha,tipo,campo,mensagem\n';
  }
  
  const csvLinhas = ['linha,tipo,campo,mensagem'];
  
  for (const linha of linhasComErro) {
    for (const erro of linha.erros) {
      const [campo, mensagem] = erro.split(': ');
      csvLinhas.push(`${linha.linha},ERRO,${campo},"${mensagem}"`);
    }
    
    for (const warning of linha.warnings) {
      const [campo, mensagem] = warning.split(': ');
      csvLinhas.push(`${linha.linha},AVISO,${campo},"${mensagem}"`);
    }
  }
  
  return csvLinhas.join('\n');
}
