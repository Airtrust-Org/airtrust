/**
 * 🔍 AUDITORIA COMPLETA DE DATAS NO SISTEMA AIRTRUST
 * 
 * Script para identificar e corrigir todos os campos de data
 * que não estão no formato brasileiro padrão dd/mm/aaaa
 */

import { DatesBrasil } from '../../shared/utils/datesBrasil';

export interface ProblemaData {
  modulo: string;
  endpoint: string;
  campo: string;
  valor: any;
  formato: FormatoData;
  status: 'PRECISA_CORREÇÃO' | 'OK' | 'ERRO';
  correcaoSugerida?: string;
}

export type FormatoData = 'BRASILEIRO' | 'ISO' | 'DATE_OBJECT' | 'TIMESTAMP' | 'AMBÍGUO' | 'INVÁLIDO';

/**
 * Executa auditoria completa em todos os módulos
 */
export const executarAuditoriaCompleta = async (): Promise<{
  problemas: ProblemaData[];
  estatisticas: {
    totalCampos: number;
    camposCorretos: number;
    camposProblematicos: number;
    modulosAfetados: string[];
    tiposProblemas: Record<FormatoData, number>;
  };
}> => {
  
  const modulosParaAuditar = [
    {
      nome: 'Simulador',
      endpoints: [
        '/api/v2/simulador/fichas',
        '/api/v2/simulador/agendamentos',
        '/api/v2/simulador/sessoes',
        '/api/v2/simuladores'
      ]
    },
    {
      nome: 'Qualificações',
      endpoints: [
        '/api/v2/qualificacoes?page=1&limit=20',
        '/api/v2/qualificacoes/historico/1',
        '/api/v2/certificados-download/listar'
      ]
    },
    {
      nome: 'Treinamentos',
      endpoints: [
        '/api/v2/treinamentos/listar',
        '/api/v2/compliance/status'
      ]
    },
    {
      nome: 'Colaboradores',
      endpoints: [
        '/api/v2/funcionarios',
        '/api/v2/funcionarios/1'
      ]
    },
    {
      nome: 'Sistema',
      endpoints: [
        '/api/v2/system/health',
        '/api/v2/auditoria'
      ]
    }
  ];
  
  const problemas: ProblemaData[] = [];
  let totalCampos = 0;
  
  for (const modulo of modulosParaAuditar) {
    
    for (const endpoint of modulo.endpoints) {
      try {
        
        const dadosSimulados = simularDadosModulo(modulo.nome);
        const datasEncontradas = encontrarCamposDatas(dadosSimulados, endpoint);
        
        totalCampos += datasEncontradas.length;
        
        if (datasEncontradas.length > 0) {
          
          datasEncontradas.forEach(campo => {
            const formatoDetectado = detectarFormatoData(campo.valor);
            const problemaData: ProblemaData = {
              modulo: modulo.nome,
              endpoint: endpoint,
              campo: campo.caminho,
              valor: campo.valor,
              formato: formatoDetectado,
              status: formatoDetectado === 'BRASILEIRO' ? 'OK' : 'PRECISA_CORREÇÃO'
            };
            
            if (problemaData.status === 'PRECISA_CORREÇÃO') {
              problemaData.correcaoSugerida = sugerirCorrecao(campo.valor, formatoDetectado);
            }
            
            problemas.push(problemaData);
          });
        } else {
        }
        
      } catch (error) {
        
        problemas.push({
          modulo: modulo.nome,
          endpoint: endpoint,
          campo: 'ENDPOINT',
          valor: error,
          formato: 'INVÁLIDO',
          status: 'ERRO'
        });
      }
    }
    
    console.log(''); // Linha em branco para separar módulos
  }
  
  const camposCorretos = problemas.filter(p => p.status === 'OK').length;
  const camposProblematicos = problemas.filter(p => p.status === 'PRECISA_CORREÇÃO').length;
  const modulosAfetados = [...new Set(problemas.map(p => p.modulo))];
  
  const tiposProblemas: Record<FormatoData, number> = {
    BRASILEIRO: 0,
    ISO: 0,
    DATE_OBJECT: 0,
    TIMESTAMP: 0,
    AMBÍGUO: 0,
    INVÁLIDO: 0
  };
  
  problemas.forEach(p => {
    tiposProblemas[p.formato]++;
  });
  
  const estatisticas = {
    totalCampos,
    camposCorretos,
    camposProblematicos,
    modulosAfetados,
    tiposProblemas
  };
  
  
  Object.entries(tiposProblemas).forEach(([tipo, quantidade]) => {
    if (quantidade > 0) {
      const icone = tipo === 'BRASILEIRO' ? '✅' : '❌';
    }
  });
  
  const problemasReais = problemas.filter(p => p.status === 'PRECISA_CORREÇÃO');
  
  if (problemasReais.length === 0) {
  } else {
    problemasReais.forEach((problema, index) => {
    });
  }
  
  return { problemas, estatisticas };
};

/**
 * Encontra recursivamente campos de data em um objeto
 */
function encontrarCamposDatas(obj: any, caminho: string = ''): Array<{caminho: string, valor: any}> {
  const campos: Array<{caminho: string, valor: any}> = [];
  
  if (!obj || typeof obj !== 'object') return campos;
  
  if (Array.isArray(obj)) {
    obj.forEach((item, index) => {
      campos.push(...encontrarCamposDatas(item, `${caminho}[${index}]`));
    });
    return campos;
  }
  
  for (const [key, value] of Object.entries(obj)) {
    const novoCaminho = caminho ? `${caminho}.${key}` : key;
    
    if (ehCampoData(key) && (typeof value === 'string' || value instanceof Date || typeof value === 'number')) {
      campos.push({ caminho: novoCaminho, valor: value });
    } else if (typeof value === 'object' && value !== null) {
      campos.push(...encontrarCamposDatas(value, novoCaminho));
    }
  }
  
  return campos;
}

/**
 * Detecta o formato de uma data
 */
function detectarFormatoData(valor: any): FormatoData {
  if (valor instanceof Date) return 'DATE_OBJECT';
  if (typeof valor === 'number') return 'TIMESTAMP';
  if (typeof valor !== 'string') return 'INVÁLIDO';
  
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(valor)) {
    return DatesBrasil.validarFormatoBrasil(valor) ? 'BRASILEIRO' : 'INVÁLIDO';
  }
  
  if (/^\d{4}-\d{2}-\d{2}/.test(valor)) return 'ISO';
  
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(valor)) return 'AMBÍGUO';
  
  return 'INVÁLIDO';
}

/**
 * Verifica se um campo é reconhecido como data
 */
function ehCampoData(nomeField: string): boolean {
  const campo = nomeField.toLowerCase();
  
  const padroes = [
    /data/i,
    /date/i,
    /_at$/i,
    /nascimento/i,
    /validade/i,
    /vencimento/i,
    /conclusao/i,
    /certificacao/i,
    /assinatura/i,
    /timestamp/i,
    /created/i,
    /updated/i,
    /deleted/i,
    /inicio/i,
    /fim/i,
    /checkin/i,
    /checkout/i
  ];
  
  return padroes.some(padrao => padrao.test(campo));
}

/**
 * Sugere correção para um valor de data
 */
function sugerirCorrecao(valor: any, formato: FormatoData): string {
  try {
    switch (formato) {
      case 'ISO':
        return DatesBrasil.converterParaBrasil(valor);
      
      case 'DATE_OBJECT':
        return DatesBrasil.isoParaBrasil(valor);
      
      case 'TIMESTAMP':
        const date = new Date(typeof valor === 'number' ? valor : parseInt(valor));
        return DatesBrasil.isoParaBrasil(date);
      
      case 'AMBÍGUO':
        if (DatesBrasil.validarFormatoBrasil(valor)) {
          return valor; // Já está correto
        }
        const [mes, dia, ano] = valor.split('/');
        return `${dia.padStart(2, '0')}/${mes.padStart(2, '0')}/${ano}`;
      
      default:
        return 'CORREÇÃO_MANUAL_NECESSÁRIA';
    }
  } catch (error) {
    return 'ERRO_AO_SUGERIR_CORREÇÃO';
  }
}

/**
 * Simula dados de um módulo para auditoria (em produção, faria fetch real)
 */
function simularDadosModulo(nomeModulo: string): any {
  const dadosSimulados: Record<string, any> = {
    'Simulador': {
      fichas: [
        {
          id: 1,
          ficha_uuid: 'FICHA-001',
          created_at: '2025-09-20T10:30:00.000Z', // ISO - PROBLEMA
          data_sessao: '20/09/2025', // Brasileiro - OK
          assinatura_aluno_timestamp: '2025-09-20 14:30:00', // ISO - PROBLEMA
          colaborador: {
            data_nascimento: '15/05/1990' // Brasileiro - OK
          }
        }
      ]
    },
    'Qualificações': {
      qualificacoes: [
        {
          id: 1,
          data_conclusao: '2025-09-15', // ISO - PROBLEMA
          data_vencimento: '15/09/2027', // Brasileiro - OK
          funcionario: {
            cma_data_vencimento: '30/12/2025' // Brasileiro - OK
          }
        }
      ]
    },
    'Treinamentos': {
      treinamentos: [
        {
          id: 1,
          data_inicio: new Date('2025-09-01'), // Date Object - PROBLEMA
          data_fim: '01/12/2025' // Brasileiro - OK
        }
      ]
    },
    'Colaboradores': {
      funcionarios: [
        {
          id: 1,
          data_nascimento: '1990-05-15', // ISO - PROBLEMA
          data_admissao: '01/01/2020', // Brasileiro - OK
          updated_at: 1726851600000 // Timestamp - PROBLEMA
        }
      ]
    },
    'Sistema': {
      health: {
        timestamp: '2025-09-20T23:39:13Z', // ISO - PROBLEMA
        ultima_verificacao: '20/09/2025 23:39' // Brasileiro - OK
      }
    }
  };
  
  return dadosSimulados[nomeModulo] || {};
}

/**
 * Gera relatório de correções aplicadas
 */
export const gerarRelatorioCorrecoes = (problemas: ProblemaData[]): string => {
  const problemasParaCorrigir = problemas.filter(p => p.status === 'PRECISA_CORREÇÃO');
  
  let relatorio = `# 🇧🇷 RELATÓRIO DE PADRONIZAÇÃO DE DATAS - AIRTRUST\n\n`;
  relatorio += `**Data da auditoria:** ${DatesBrasil.hoje()}\n`;
  relatorio += `**Total de problemas:** ${problemasParaCorrigir.length}\n\n`;
  
  relatorio += `## 📋 CORREÇÕES NECESSÁRIAS\n\n`;
  
  const problemasPorModulo = problemasParaCorrigir.reduce((acc, problema) => {
    if (!acc[problema.modulo]) acc[problema.modulo] = [];
    acc[problema.modulo].push(problema);
    return acc;
  }, {} as Record<string, ProblemaData[]>);
  
  Object.entries(problemasPorModulo).forEach(([modulo, problemas]) => {
    relatorio += `### 🔧 ${modulo}\n\n`;
    
    problemas.forEach((problema, index) => {
      relatorio += `${index + 1}. **${problema.endpoint}**\n`;
      relatorio += `   - Campo: \`${problema.campo}\`\n`;
      relatorio += `   - Valor atual: \`"${problema.valor}"\`\n`;
      relatorio += `   - Formato: \`${problema.formato}\`\n`;
      relatorio += `   - ✅ Correção: \`"${problema.correcaoSugerida}"\`\n\n`;
    });
  });
  
  relatorio += `## 🎯 PRÓXIMOS PASSOS\n\n`;
  relatorio += `1. ✅ Implementar middleware de conversão automática\n`;
  relatorio += `2. ✅ Atualizar componentes React para usar InputDataBrasil\n`;
  relatorio += `3. ✅ Corrigir campos identificados nos módulos\n`;
  relatorio += `4. ✅ Testar cada módulo individualmente\n`;
  relatorio += `5. ✅ Validar que não restaram campos ISO\n\n`;
  
  relatorio += `---\n`;
  relatorio += `**Gerado automaticamente pelo sistema de auditoria AirTrust**\n`;
  
  return relatorio;
};
