import { PDFDocument } from 'pdf-lib';

export interface CompressionResult {
  compressedPdf: ArrayBuffer;
  originalSize: number;
  compressedSize: number;
  reduction: number; // Percentual
}

/**
 * Comprime PDF mantendo qualidade visual
 */
export async function compressPdf(
  pdfBuffer: ArrayBuffer,
  options: {
    quality?: 'high' | 'medium' | 'low';
    maxSize?: number; // MB
  } = {}
): Promise<CompressionResult> {
  const { quality = 'high', maxSize = 10 } = options;
  
  try {
    const originalSize = pdfBuffer.byteLength;
    
    const pdfDoc = await PDFDocument.load(pdfBuffer, {
      ignoreEncryption: true
    });
    
    const compressionSettings = {
      high: {
        objectsPerTick: 50,
        updateFieldAppearances: false
      },
      medium: {
        objectsPerTick: 25,
        updateFieldAppearances: false
      },
      low: {
        objectsPerTick: 10,
        updateFieldAppearances: false
      }
    };
    
    const compressedPdf = await pdfDoc.save({
      ...compressionSettings[quality],
      useObjectStreams: true, // Reduz tamanho
      addDefaultPage: false
    });
    
    const compressedSize = compressedPdf.byteLength;
    const reduction = ((originalSize - compressedSize) / originalSize) * 100;
    
    if (compressedSize > maxSize * 1024 * 1024) {
      console.warn(`PDF comprimido ainda está grande: ${(compressedSize / 1024 / 1024).toFixed(2)}MB`);
    }
    
    return {
      compressedPdf: compressedPdf.buffer,
      originalSize,
      compressedSize,
      reduction
    };
    
  } catch (error) {
    console.error('Erro ao comprimir PDF:', error);
    return {
      compressedPdf: pdfBuffer,
      originalSize: pdfBuffer.byteLength,
      compressedSize: pdfBuffer.byteLength,
      reduction: 0
    };
  }
}

/**
 * Verifica se PDF precisa de compressão
 */
export function needsCompression(sizeInBytes: number, threshold: number = 2): boolean {
  const sizeInMB = sizeInBytes / 1024 / 1024;
  return sizeInMB > threshold;
}

/**
 * Formata tamanho legível
 */
export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}
