import type { Env } from '../types/env';

/**
 * Feature Flags para controle de features críticas e vulnerabilidades
 * Permite desabilitar features rapidamente sem deploy
 */
export interface FeatureFlags {
  LGPD_ENDPOINT_ENABLED: boolean;
  HARD_DELETE_ENABLED: boolean;
  DEV_AUTH_BYPASS_ENABLED: boolean;
  RATE_LIMIT_IMPORT_ENABLED: boolean;
}

/**
 * Obter feature flags a partir do environment
 * Padrão: tudo desabilitado (seguro) a menos que explicitamente habilitado
 */
export function getFeatureFlags(env: Env): FeatureFlags {
  return {
    // LGPD endpoint - DESABILITADO por padrão até implementar backup seguro
    LGPD_ENDPOINT_ENABLED: env.LGPD_ENDPOINT_ENABLED === 'true' ? true : false,

    // Hard delete - DESABILITADO por padrão (usar soft delete)
    HARD_DELETE_ENABLED: env.HARD_DELETE_ENABLED === 'true' ? true : false,

    // Dev auth bypass - DESABILITADO por padrão (requer flag explícita)
    DEV_AUTH_BYPASS_ENABLED: env.ENABLE_DEV_AUTH_BYPASS === 'true' ? true : false,

    // Rate limit em import - HABILITADO por padrão
    RATE_LIMIT_IMPORT_ENABLED: env.RATE_LIMIT_IMPORT_ENABLED !== 'false' ? true : false,
  };
}

/**
 * Helper para verificar se feature está habilitada
 */
export function isFeatureEnabled(env: Env, feature: keyof FeatureFlags): boolean {
  const flags = getFeatureFlags(env);
  return flags[feature];
}
