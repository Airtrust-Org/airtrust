/**
 * Utilitários de Criptografia
 * Implementa criptografia AES-256 para dados sensíveis (CPF)
 */

export class Encryption {
  /**
   * Criptografa um CPF usando AES-256-GCM
   * Nota: Em Cloudflare Workers, usamos Web Crypto API
   */
  static async encryptCPF(cpf: string, secretKey: string): Promise<string> {
    try {
      const encoder = new TextEncoder();
      const keyData = encoder.encode(secretKey.padEnd(32, '0').substring(0, 32));
      
      const key = await crypto.subtle.importKey(
        'raw',
        keyData,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt']
      );
      
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        key,
        encoder.encode(cpf)
      );
      
      const combined = new Uint8Array(iv.length + encrypted.byteLength);
      combined.set(iv, 0);
      combined.set(new Uint8Array(encrypted), iv.length);
      
      return btoa(String.fromCharCode(...combined));
    } catch (error) {
      console.error('Erro ao criptografar CPF:', error);
      throw new Error('Falha na criptografia');
    }
  }
  
  /**
   * Descriptografa um CPF
   */
  static async decryptCPF(encryptedCPF: string, secretKey: string): Promise<string> {
    try {
      const encoder = new TextEncoder();
      const decoder = new TextDecoder();
      const keyData = encoder.encode(secretKey.padEnd(32, '0').substring(0, 32));
      
      const key = await crypto.subtle.importKey(
        'raw',
        keyData,
        { name: 'AES-GCM', length: 256 },
        false,
        ['decrypt']
      );
      
      const combined = Uint8Array.from(atob(encryptedCPF), c => c.charCodeAt(0));
      
      const iv = combined.slice(0, 12);
      const encrypted = combined.slice(12);
      
      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        key,
        encrypted
      );
      
      return decoder.decode(decrypted);
    } catch (error) {
      console.error('Erro ao descriptografar CPF:', error);
      throw new Error('Falha na descriptografia');
    }
  }
  
  /**
   * Mascara um CPF para exibição (XXX.XXX.XXX-XX)
   */
  static maskCPF(cpf: string): string {
    if (!cpf || cpf.length !== 11) return '***.***.***-**';
    return `${cpf.substring(0, 3)}.${cpf.substring(3, 6)}.${cpf.substring(6, 9)}-${cpf.substring(9, 11)}`;
  }
  
  /**
   * Mascara parcialmente um CPF (XXX.XXX.789-01)
   */
  static partialMaskCPF(cpf: string): string {
    if (!cpf || cpf.length !== 11) return '***.***.***-**';
    return `***.***. ${cpf.substring(6, 9)}-${cpf.substring(9, 11)}`;
  }
}
