/**
 * Sistema de Monitoramento e Métricas
 * Coleta: requisições/min, erros/min, latência
 * Alertas: anomalias, thresholds críticos
 */

export interface MetricPoint {
  timestamp: number;
  value: number;
}

export interface MetricsSnapshot {
  requestsPerMin: number;
  errorsPerMin: number;
  avgLatency: number;
  p95Latency: number;
  p99Latency: number;
  uptime: number;
}

export interface Alert {
  level: 'INFO' | 'WARNING' | 'CRITICAL';
  message: string;
  metric: string;
  value: number;
  threshold: number;
  timestamp: number;
}

/**
 * Collector de métricas com janela deslizante
 */
export class MetricsCollector {
  private requests: MetricPoint[] = [];
  private errors: MetricPoint[] = [];
  private latencies: MetricPoint[] = [];
  private startTime: number = Date.now();
  private windowSize: number = 60000; // 1 min em ms
  private alerts: Alert[] = [];

  private thresholds = {
    errorRate: 0.05, // 5% de erros
    avgLatency: 1000, // 1s
    p95Latency: 3000, // 3s
    p99Latency: 5000, // 5s
  };

  /**
   * Registrar requisição
   */
  recordRequest(latency: number, success: boolean): void {
    const now = Date.now();

    this.requests.push({ timestamp: now, value: 1 });

    if (!success) {
      this.errors.push({ timestamp: now, value: 1 });
    }

    this.latencies.push({ timestamp: now, value: latency });

    // Limpar dados antigos
    this.cleanup(now);

    // Verificar thresholds
    this.checkThresholds();
  }

  /**
   * Limpar métricas fora da janela
   */
  private cleanup(now: number): void {
    const cutoff = now - this.windowSize;

    this.requests = this.requests.filter((m) => m.timestamp > cutoff);
    this.errors = this.errors.filter((m) => m.timestamp > cutoff);
    this.latencies = this.latencies.filter((m) => m.timestamp > cutoff);
  }

  /**
   * Obter snapshot das métricas
   */
  getSnapshot(): MetricsSnapshot {
    const now = Date.now();
    this.cleanup(now);

    const totalRequests = this.requests.reduce((sum, m) => sum + m.value, 0);
    const totalErrors = this.errors.reduce((sum, m) => sum + m.value, 0);
    const latencies = this.latencies.map((m) => m.value).sort((a, b) => a - b);

    const avgLatency = latencies.length > 0 ? latencies.reduce((a, b) => a + b, 0) / latencies.length : 0;
    const p95Index = Math.floor(latencies.length * 0.95);
    const p99Index = Math.floor(latencies.length * 0.99);

    return {
      requestsPerMin: totalRequests,
      errorsPerMin: totalErrors,
      avgLatency,
      p95Latency: latencies[p95Index] || 0,
      p99Latency: latencies[p99Index] || 0,
      uptime: Date.now() - this.startTime,
    };
  }

  /**
   * Verificar thresholds e gerar alertas
   */
  private checkThresholds(): void {
    const snapshot = this.getSnapshot();

    // Taxa de erro
    const errorRate = snapshot.requestsPerMin > 0 ? snapshot.errorsPerMin / snapshot.requestsPerMin : 0;
    if (errorRate > this.thresholds.errorRate) {
      this.addAlert({
        level: 'CRITICAL',
        metric: 'errorRate',
        value: errorRate,
        threshold: this.thresholds.errorRate,
        message: `Error rate ${(errorRate * 100).toFixed(2)}% exceeds threshold`,
      });
    }

    // Latência média
    if (snapshot.avgLatency > this.thresholds.avgLatency) {
      this.addAlert({
        level: 'WARNING',
        metric: 'avgLatency',
        value: snapshot.avgLatency,
        threshold: this.thresholds.avgLatency,
        message: `Average latency ${snapshot.avgLatency.toFixed(0)}ms exceeds threshold`,
      });
    }

    // P95 latência
    if (snapshot.p95Latency > this.thresholds.p95Latency) {
      this.addAlert({
        level: 'WARNING',
        metric: 'p95Latency',
        value: snapshot.p95Latency,
        threshold: this.thresholds.p95Latency,
        message: `P95 latency ${snapshot.p95Latency.toFixed(0)}ms exceeds threshold`,
      });
    }

    // P99 latência (mais crítico)
    if (snapshot.p99Latency > this.thresholds.p99Latency) {
      this.addAlert({
        level: 'CRITICAL',
        metric: 'p99Latency',
        value: snapshot.p99Latency,
        threshold: this.thresholds.p99Latency,
        message: `P99 latency ${snapshot.p99Latency.toFixed(0)}ms exceeds threshold`,
      });
    }
  }

  /**
   * Adicionar alerta
   */
  private addAlert(alert: Omit<Alert, 'timestamp'>): void {
    this.alerts.push({
      ...alert,
      timestamp: Date.now(),
    });

    // Manter últimos 100 alertas
    if (this.alerts.length > 100) {
      this.alerts = this.alerts.slice(-100);
    }
  }

  /**
   * Obter alertas (com filtro opcional)
   */
  getAlerts(level?: Alert['level']): Alert[] {
    return level ? this.alerts.filter((a) => a.level === level) : this.alerts;
  }

  /**
   * Clear alertas
   */
  clearAlerts(): void {
    this.alerts = [];
  }

  /**
   * Atualizar thresholds
   */
  setThreshold(metric: keyof typeof this.thresholds, value: number): void {
    this.thresholds[metric] = value;
  }

  /**
   * Health check simplificado
   */
  isHealthy(): boolean {
    const snapshot = this.getSnapshot();
    const errorRate = snapshot.requestsPerMin > 0 ? snapshot.errorsPerMin / snapshot.requestsPerMin : 0;

    return (
      errorRate <= this.thresholds.errorRate &&
      snapshot.avgLatency <= this.thresholds.avgLatency &&
      snapshot.p99Latency <= this.thresholds.p99Latency
    );
  }
}

/**
 * Middleware para coletar métricas automaticamente
 */
export function createMetricsMiddleware(collector: MetricsCollector) {
  return async (handler: Function) => {
    const startTime = Date.now();

    try {
      const result = await handler();
      const latency = Date.now() - startTime;

      collector.recordRequest(latency, true);
      return result;
    } catch (error) {
      const latency = Date.now() - startTime;
      collector.recordRequest(latency, false);
      throw error;
    }
  };
}

/**
 * Testes de métricas
 */
export const metricsTests = [
  {
    name: 'Should track requests',
    test: () => {
      const collector = new MetricsCollector();
      collector.recordRequest(100, true);
      collector.recordRequest(150, true);

      const snapshot = collector.getSnapshot();
      return snapshot.requestsPerMin === 2;
    },
  },
  {
    name: 'Should track errors',
    test: () => {
      const collector = new MetricsCollector();
      collector.recordRequest(100, true);
      collector.recordRequest(150, false);
      collector.recordRequest(200, false);

      const snapshot = collector.getSnapshot();
      return snapshot.errorsPerMin === 2;
    },
  },
  {
    name: 'Should calculate average latency',
    test: () => {
      const collector = new MetricsCollector();
      collector.recordRequest(100, true);
      collector.recordRequest(200, true);
      collector.recordRequest(300, true);

      const snapshot = collector.getSnapshot();
      return snapshot.avgLatency === 200; // (100 + 200 + 300) / 3
    },
  },
  {
    name: 'Should calculate percentiles',
    test: () => {
      const collector = new MetricsCollector();

      // Registrar 100 requisições com latências variadas
      for (let i = 0; i < 100; i++) {
        collector.recordRequest(i * 10, true);
      }

      const snapshot = collector.getSnapshot();
      // P95 deve estar próximo a 950 (95% de 1000)
      return snapshot.p95Latency >= 900 && snapshot.p95Latency <= 1000;
    },
  },
  {
    name: 'Should detect health degradation',
    test: () => {
      const collector = new MetricsCollector();

      // 5 requisições bem-sucedidas
      for (let i = 0; i < 5; i++) {
        collector.recordRequest(100, true);
      }

      // System é saudável
      let isHealthy = collector.isHealthy();
      if (!isHealthy) return false;

      // Adicionar muitos erros (6%)
      for (let i = 0; i < 200; i++) {
        collector.recordRequest(5000, false);
      }

      // System não deve estar saudável
      isHealthy = collector.isHealthy();
      return !isHealthy;
    },
  },
  {
    name: 'Should generate alerts for high error rate',
    test: () => {
      const collector = new MetricsCollector();

      // Forçar alta taxa de erro
      for (let i = 0; i < 20; i++) {
        collector.recordRequest(100, i % 3 === 0 ? false : true); // 33% de erro
      }

      const alerts = collector.getAlerts('CRITICAL');
      return alerts.some((a) => a.metric === 'errorRate');
    },
  },
];
