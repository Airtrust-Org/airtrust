/**
 * Sistema de Validação de Funções - Extensível
 * AirTrust v2 - Outubro 2025
 */

export const FUNCOES_AERONAUTICAS = ['PC', 'SIC', 'CMS', 'MMA'] as const;

export const FUNCOES_ADMINISTRATIVAS = [
  'ADM',           // Administrativo geral
  'COORD',         // Coordenador
  'GERENTE',       // Gerente
  'DIRETOR',       // Diretor
  'INSTRUTOR',     // Instrutor de solo
  'DESPACHANTE',   // Despachante operacional
  'ALMOXARIFE',    // Almoxarife
  'MECANICO',      // Mecânico
  'COMPRAS',       // Compras
  'RH',            // Recursos Humanos
  'FINANCEIRO',    // Financeiro
  'TI',            // Tecnologia da Informação
  'OPERACOES',     // Operações
  'QUALIDADE',     // Qualidade
  'SAFETY',        // Safety/Segurança
  'MANUTENCAO',    // Manutenção
  'COMERCIAL',     // Comercial
  'MARKETING'      // Marketing
] as const;

export const FUNCOES_VALIDAS = [
  ...FUNCOES_AERONAUTICAS,
  ...FUNCOES_ADMINISTRATIVAS
] as const;

export type FuncaoAeronautica = typeof FUNCOES_AERONAUTICAS[number];
export type FuncaoAdministrativa = typeof FUNCOES_ADMINISTRATIVAS[number];
export type FuncaoValida = typeof FUNCOES_VALIDAS[number];

/**
 * Mapeamento de aliases para funções válidas
 */
const ALIASES_FUNCOES: Record<string, FuncaoValida> = {
  'PIC': 'PC',
  'COMANDANTE': 'PC',
  'CMTE': 'PC',
  'COPILOTO': 'SIC',
  'ADMINISTRATIVO': 'ADM',
  'ADMIN': 'ADM',
  'ADMINISTRADOR': 'ADM',
  'COORDENADOR': 'COORD',
  'INSTRUTOR_SOLO': 'INSTRUTOR',
  'MECANICO_AERONAUTICO': 'MECANICO',
  'TEC_INFORMATICA': 'TI',
  'TECNOLOGIA': 'TI',
  'RECURSOS_HUMANOS': 'RH',
  'SEGURANCA': 'SAFETY'
};

export interface ValidacaoFuncaoResult {
  valida: boolean;
  normalizada?: FuncaoValida;
  exigeAnac: boolean;
  erro?: string;
}

/**
 * Valida e normaliza função
 */
export function validarFuncao(funcao: string): ValidacaoFuncaoResult {
  if (!funcao) {
    return {
      valida: false,
      exigeAnac: false,
      erro: 'Função é obrigatória'
    };
  }

  const funcaoUpper = funcao.toUpperCase().trim();
  
  const funcaoFinal = (ALIASES_FUNCOES[funcaoUpper] || funcaoUpper) as FuncaoValida;
  
  if (!FUNCOES_VALIDAS.includes(funcaoFinal)) {
    return {
      valida: false,
      exigeAnac: false,
      erro: `Função inválida: "${funcao}". Válidas: ${FUNCOES_VALIDAS.join(', ')}`
    };
  }
  
  const exigeAnac = FUNCOES_AERONAUTICAS.includes(funcaoFinal as FuncaoAeronautica);
  
  return {
    valida: true,
    normalizada: funcaoFinal,
    exigeAnac
  };
}

/**
 * Verifica se função exige código ANAC
 */
export function funcaoExigeAnac(funcao: string): boolean {
  const resultado = validarFuncao(funcao);
  return resultado.valida && resultado.exigeAnac;
}

/**
 * Lista todas as funções válidas com descrição
 */
export function listarFuncoesValidas(): Array<{ codigo: string; descricao: string; exigeAnac: boolean }> {
  const funcoes: Array<{ codigo: string; descricao: string; exigeAnac: boolean }> = [];
  
  funcoes.push(
    { codigo: 'PC', descricao: 'Piloto em Comando', exigeAnac: true },
    { codigo: 'SIC', descricao: 'Segundo em Comando', exigeAnac: true },
    { codigo: 'CMS', descricao: 'Comissário de Voo', exigeAnac: true },
    { codigo: 'MMA', descricao: 'Mecânico de Manutenção Aeronáutica', exigeAnac: true }
  );
  
  funcoes.push(
    { codigo: 'ADM', descricao: 'Administrativo', exigeAnac: false },
    { codigo: 'COORD', descricao: 'Coordenador', exigeAnac: false },
    { codigo: 'GERENTE', descricao: 'Gerente', exigeAnac: false },
    { codigo: 'DIRETOR', descricao: 'Diretor', exigeAnac: false },
    { codigo: 'INSTRUTOR', descricao: 'Instrutor de Solo', exigeAnac: false },
    { codigo: 'DESPACHANTE', descricao: 'Despachante Operacional', exigeAnac: false },
    { codigo: 'ALMOXARIFE', descricao: 'Almoxarife', exigeAnac: false },
    { codigo: 'MECANICO', descricao: 'Mecânico', exigeAnac: false },
    { codigo: 'COMPRAS', descricao: 'Compras', exigeAnac: false },
    { codigo: 'RH', descricao: 'Recursos Humanos', exigeAnac: false },
    { codigo: 'FINANCEIRO', descricao: 'Financeiro', exigeAnac: false },
    { codigo: 'TI', descricao: 'Tecnologia da Informação', exigeAnac: false },
    { codigo: 'OPERACOES', descricao: 'Operações', exigeAnac: false },
    { codigo: 'QUALIDADE', descricao: 'Qualidade', exigeAnac: false },
    { codigo: 'SAFETY', descricao: 'Safety/Segurança', exigeAnac: false },
    { codigo: 'MANUTENCAO', descricao: 'Manutenção', exigeAnac: false },
    { codigo: 'COMERCIAL', descricao: 'Comercial', exigeAnac: false },
    { codigo: 'MARKETING', descricao: 'Marketing', exigeAnac: false }
  );
  
  return funcoes;
}
