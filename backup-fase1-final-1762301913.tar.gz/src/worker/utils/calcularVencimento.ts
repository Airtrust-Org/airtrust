/**
 * Sistema de Cálculo de Vencimento Flexível
 * 
 * Suporta dois tipos de vencimento:
 * - DIA_EXATO: Vence no mesmo dia após N meses (ex: 15/01 + 12 meses = 15/01)
 * - FIM_DO_MES: Vence no último dia do mês após N meses (ex: 15/01 + 12 meses = 31/01)
 */

export type TipoVencimento = 'DIA_EXATO' | 'FIM_DO_MES';

/**
 * Calcula data de vencimento a partir da data de realização
 * 
 * @param dataRealizacao - Data em que a qualificação foi realizada (YYYY-MM-DD)
 * @param validadeMeses - Número de meses de validade
 * @param vencimentoTipo - Tipo de vencimento (DIA_EXATO ou FIM_DO_MES)
 * @returns Data de vencimento (YYYY-MM-DD)
 * 
 * @example
 * // Vencimento dia exato
 * calcularVencimento('2024-01-15', 12, 'DIA_EXATO')
 * // Retorna: '2025-01-15'
 * 
 * @example
 * // Vencimento fim do mês
 * calcularVencimento('2024-01-15', 12, 'FIM_DO_MES')
 * // Retorna: '2025-01-31'
 */
export function calcularVencimento(
  dataRealizacao: string,
  validadeMeses: number,
  vencimentoTipo: TipoVencimento
): string {
  const data = new Date(dataRealizacao + 'T00:00:00Z');
  
  data.setUTCMonth(data.getUTCMonth() + validadeMeses);
  
  if (vencimentoTipo === 'FIM_DO_MES') {
    const ano = data.getUTCFullYear();
    const mes = data.getUTCMonth();
    const ultimoDia = new Date(Date.UTC(ano, mes + 1, 0));
    return ultimoDia.toISOString().split('T')[0];
  }
  
  return data.toISOString().split('T')[0];
}

/**
 * Calcula data de realização retroativa a partir do vencimento
 * Útil para importações onde só temos a data de vencimento
 * 
 * @param vencimento - Data de vencimento (YYYY-MM-DD)
 * @param validadeMeses - Número de meses de validade
 * @param vencimentoTipo - Tipo de vencimento (DIA_EXATO ou FIM_DO_MES)
 * @returns Data de realização estimada (YYYY-MM-DD)
 * 
 * @example
 * // Calcular realização de vencimento dia exato
 * calcularDataRealizacao('2025-01-15', 12, 'DIA_EXATO')
 * // Retorna: '2024-01-15'
 * 
 * @example
 * // Calcular realização de vencimento fim do mês
 * calcularDataRealizacao('2025-01-31', 12, 'FIM_DO_MES')
 * // Retorna: '2024-01-15' (usa dia 15 como padrão)
 */
export function calcularDataRealizacao(
  vencimento: string,
  validadeMeses: number,
  vencimentoTipo: TipoVencimento
): string {
  const data = new Date(vencimento + 'T00:00:00Z');
  
  if (vencimentoTipo === 'FIM_DO_MES') {
    data.setUTCDate(15);
  }
  
  data.setUTCMonth(data.getUTCMonth() - validadeMeses);
  
  return data.toISOString().split('T')[0];
}

/**
 * Valida se uma data de vencimento está correta para o tipo especificado
 * 
 * @param dataRealizacao - Data de realização
 * @param vencimento - Data de vencimento
 * @param validadeMeses - Meses de validade
 * @param vencimentoTipo - Tipo de vencimento
 * @returns true se o vencimento está correto
 */
export function validarVencimento(
  dataRealizacao: string,
  vencimento: string,
  validadeMeses: number,
  vencimentoTipo: TipoVencimento
): boolean {
  const vencimentoCalculado = calcularVencimento(dataRealizacao, validadeMeses, vencimentoTipo);
  return vencimentoCalculado === vencimento;
}

/**
 * Verifica se uma data é o último dia do mês
 */
export function isUltimoDiaDoMes(data: string): boolean {
  const d = new Date(data + 'T00:00:00Z');
  const ano = d.getUTCFullYear();
  const mes = d.getUTCMonth();
  const ultimoDia = new Date(Date.UTC(ano, mes + 1, 0));
  return d.getUTCDate() === ultimoDia.getUTCDate();
}
