/**
 * Utilitários de validação para o AirTrust v2
 * Validações robustas para CPF, email, telefone, etc.
 */

export class ValidationError extends Error {
  constructor(public field: string, message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export class Validators {
  /**
   * Valida CPF brasileiro
   */
  static validateCPF(cpf: string): boolean {
    if (!cpf) return false;
    
    cpf = cpf.replace(/[^\d]/g, '');
    
    if (cpf.length !== 11) return false;
    
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(9))) return false;
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
      sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    digit = 11 - (sum % 11);
    if (digit >= 10) digit = 0;
    if (digit !== parseInt(cpf.charAt(10))) return false;
    
    return true;
  }

  /**
   * Valida email
   */
  static validateEmail(email: string): boolean {
    if (!email) return false;
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Valida telefone brasileiro
   */
  static validatePhone(phone: string): boolean {
    if (!phone) return false;
    
    phone = phone.replace(/[^\d]/g, '');
    
    return phone.length === 10 || phone.length === 11;
  }

  /**
   * Valida matrícula (alfanumérico, 3-20 caracteres)
   */
  static validateMatricula(matricula: string): boolean {
    if (!matricula) return false;
    
    const matriculaRegex = /^[A-Za-z0-9]{3,20}$/;
    return matriculaRegex.test(matricula);
  }

  /**
   * Valida e formata matrícula para sempre ter 5 dígitos
   * Exemplo: "1" → "00001", "123" → "00123"
   */
  static validarMatricula5Digitos(matricula: string | number): {
    valido: boolean;
    matriculaFormatada: string;
    erro?: string;
  } {
    const numeros = String(matricula).replace(/\D/g, '');
    
    if (!numeros) {
      return {
        valido: false,
        matriculaFormatada: '',
        erro: 'Matrícula é obrigatória'
      };
    }
    
    if (!/^\d+$/.test(numeros)) {
      return {
        valido: false,
        matriculaFormatada: '',
        erro: 'Matrícula deve conter apenas números'
      };
    }
    
    if (numeros.length > 5) {
      return {
        valido: false,
        matriculaFormatada: '',
        erro: 'Matrícula deve ter no máximo 5 dígitos'
      };
    }
    
    const matriculaFormatada = numeros.padStart(5, '0');
    
    return {
      valido: true,
      matriculaFormatada
    };
  }

  /**
   * Valida nome (mínimo 3 caracteres, apenas letras e espaços)
   */
  static validateNome(nome: string): boolean {
    if (!nome) return false;
    
    nome = nome.trim();
    if (nome.length < 3) return false;
    
    const nomeRegex = /^[A-Za-zÀ-ÿ\s]{3,100}$/;
    return nomeRegex.test(nome);
  }

  /**
   * Valida data no formato ISO (YYYY-MM-DD)
   */
  static validateDate(date: string): boolean {
    if (!date) return false;
    
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(date)) return false;
    
    const parsedDate = new Date(date);
    return !isNaN(parsedDate.getTime());
  }

  /**
   * Valida se data não está no passado
   */
  static validateFutureDate(date: string): boolean {
    if (!this.validateDate(date)) return false;
    
    const parsedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return parsedDate >= today;
  }

  /**
   * Valida data de nascimento (maior de 18 anos)
   */
  static validateDataNascimento(date: string): boolean {
    if (!this.validateDate(date)) return false;
    
    const nascimento = new Date(date);
    const hoje = new Date();
    
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    const mes = hoje.getMonth() - nascimento.getMonth();
    
    if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
    
    return idade >= 18;
  }

  /**
   * Valida que data não é futura
   */
  static validateNotFutureDate(date: string): boolean {
    if (!this.validateDate(date)) return false;
    
    const parsedDate = new Date(date);
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    
    return parsedDate <= today;
  }

  /**
   * Sanitiza string removendo caracteres perigosos
   */
  static sanitizeString(str: string): string {
    if (!str) return '';
    
    return str
      .replace(/[<>]/g, '') // Remove < e >
      .replace(/javascript:/gi, '') // Remove javascript:
      .replace(/on\w+=/gi, '') // Remove event handlers
      .trim();
  }

  /**
   * Sanitiza HTML removendo tags perigosas
   */
  static sanitizeHTML(html: string): string {
    if (!html) return '';
    
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
      .replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '')
      .replace(/<embed[^>]*>/gi, '')
      .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')
      .replace(/javascript:/gi, '');
  }

  /**
   * Valida senha forte
   */
  static validatePassword(password: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (!password) {
      errors.push('Senha é obrigatória');
      return { valid: false, errors };
    }
    
    if (password.length < 8) {
      errors.push('Senha deve ter no mínimo 8 caracteres');
    }
    
    if (!/[A-Z]/.test(password)) {
      errors.push('Senha deve conter pelo menos uma letra maiúscula');
    }
    
    if (!/[a-z]/.test(password)) {
      errors.push('Senha deve conter pelo menos uma letra minúscula');
    }
    
    if (!/[0-9]/.test(password)) {
      errors.push('Senha deve conter pelo menos um número');
    }
    
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      errors.push('Senha deve conter pelo menos um caractere especial');
    }
    
    return { valid: errors.length === 0, errors };
  }

  /**
   * Verifica unicidade de CPF, email e matrícula
   */
  static async verificarUnicidade(db: any, data: any): Promise<string[]> {
    const conflitos: string[] = [];
    
    if (data.cpf) {
      const cpfExiste = await db.prepare(`
        SELECT id FROM funcionarios WHERE cpf = ? AND deleted_at IS NULL
      `).bind(data.cpf).first();
      
      if (cpfExiste) {
        conflitos.push(`CPF ${data.cpf} já cadastrado`);
      }
    }
    
    if (data.email) {
      const emailExiste = await db.prepare(`
        SELECT id FROM funcionarios WHERE email = ? AND deleted_at IS NULL
      `).bind(data.email).first();
      
      if (emailExiste) {
        conflitos.push(`Email ${data.email} já cadastrado`);
      }
    }
    
    if (data.matricula) {
      const matriculaExiste = await db.prepare(`
        SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL
      `).bind(data.matricula).first();
      
      if (matriculaExiste) {
        conflitos.push(`Matrícula ${data.matricula} já cadastrada`);
      }
    }
    
    return conflitos;
  }

  /**
   * Valida objeto Funcionario
   */
  static validateFuncionario(data: any): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    if (!data.nome) {
      errors.push('Nome é obrigatório');
    } else if (!this.validateNome(data.nome)) {
      errors.push('Nome inválido (mínimo 3 caracteres, apenas letras)');
    }
    
    if (!data.funcao) {
      errors.push('Função é obrigatória');
    }
    
    if (data.cpf && !this.validateCPF(data.cpf)) {
      errors.push('CPF inválido');
    }
    
    if (data.email && !this.validateEmail(data.email)) {
      errors.push('Email inválido');
    }
    
    if (data.telefone && !this.validatePhone(data.telefone)) {
      errors.push('Telefone inválido');
    }
    
    if (data.matricula && !this.validateMatricula(data.matricula)) {
      errors.push('Matrícula inválida (3-20 caracteres alfanuméricos)');
    }
    
    if (data.cma_data_vencimento && !this.validateDate(data.cma_data_vencimento)) {
      errors.push('Data de vencimento do CMA inválida');
    }
    
    if (data.aso_data_vencimento && !this.validateDate(data.aso_data_vencimento)) {
      errors.push('Data de vencimento do ASO inválida');
    }
    
    if (data.nivel_icao_data_vencimento && !this.validateDate(data.nivel_icao_data_vencimento)) {
      errors.push('Data de vencimento do Nível ICAO inválida');
    }
    
    return { valid: errors.length === 0, errors };
  }

  /**
   * Formata CPF para exibição
   */
  static formatCPF(cpf: string): string {
    if (!cpf) return '';
    
    cpf = cpf.replace(/[^\d]/g, '');
    if (cpf.length !== 11) return cpf;
    
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }

  /**
   * Formata telefone para exibição
   */
  static formatPhone(phone: string): string {
    if (!phone) return '';
    
    phone = phone.replace(/[^\d]/g, '');
    
    if (phone.length === 11) {
      return phone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    } else if (phone.length === 10) {
      return phone.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    }
    
    return phone;
  }

  /**
   * Valida e sanitiza dados de entrada
   */
  static sanitizeInput(data: any): any {
    if (typeof data === 'string') {
      return this.sanitizeString(data);
    }
    
    if (Array.isArray(data)) {
      return data.map(item => this.sanitizeInput(item));
    }
    
    if (typeof data === 'object' && data !== null) {
      const sanitized: any = {};
      for (const key in data) {
        sanitized[key] = this.sanitizeInput(data[key]);
      }
      return sanitized;
    }
    
    return data;
  }
}

/**
 * Middleware de validação para Hono
 */
export function validateRequest(validator: (data: any) => { valid: boolean; errors: string[] }) {
  return async (c: any, next: any) => {
    try {
      const data = await c.req.json();
      const result = validator(data);
      
      if (!result.valid) {
        return c.json({
          success: false,
          error: 'Dados inválidos',
          errors: result.errors
        }, 400);
      }
      
      c.set('validatedData', Validators.sanitizeInput(data));
      
      await next();
    } catch (error) {
      return c.json({
        success: false,
        error: 'Erro ao validar dados'
      }, 400);
    }
  };
}
