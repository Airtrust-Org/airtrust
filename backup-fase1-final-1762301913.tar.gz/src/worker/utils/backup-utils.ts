/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BACKUP UTILITIES - Sistema Completo de Backup/Restore
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { Env } from '../types';

export interface BackupResult {
  id: string;
  tamanho: number;
  hash: string;
  duracao: number;
  total_tabelas: number;
  total_registros: number;
  total_arquivos: number;
}

export interface BackupData {
  versao: string;
  data: string;
  sql: string;
  arquivos: Array<{ key: string; size: number }>;
  metadados: {
    total_tabelas: number;
    total_registros: number;
    total_arquivos: number;
    database_size: number;
  };
}

/**
 * Cria backup completo do sistema
 */
export async function criarBackupCompleto(
  env: Env,
  descricao?: string
): Promise<BackupResult> {
  const inicio = Date.now();
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupId = `backup-${timestamp}`;

  if (!env.BUCKET) {
    throw new Error('R2 Bucket não configurado');
  }

  try {
    const sqlDump = await exportarD1Completo(env.DB as any);

    const arquivos = await listarArquivosR2(env.BUCKET, 'documentos/');

    const totalRegistros = await contarRegistros(env.DB as any);

    const backupData: BackupData = {
      versao: '2.0',
      data: new Date().toISOString(),
      sql: sqlDump,
      arquivos: arquivos.map((a) => ({ key: a.key, size: a.size })),
      metadados: {
        total_tabelas: 18,
        total_registros: totalRegistros,
        total_arquivos: arquivos.length,
        database_size: new Blob([sqlDump]).size,
      },
    };

    const jsonString = JSON.stringify(backupData);
    const comprimido = await comprimirGzip(jsonString);

    const hash = await calcularMD5(comprimido);

    const r2Path = `backups/${backupId}.backup.gz`;
    await env.BUCKET.put(r2Path, comprimido, {
      customMetadata: {
        tipo: 'completo',
        hash_md5: hash,
        criado_em: new Date().toISOString(),
        versao: '2.0',
      },
    });

    const duracao = Math.round((Date.now() - inicio) / 1000);

    await env.DB.prepare(
      `INSERT INTO backups (
        id, data, tipo, tamanho, hash_md5, status, duracao_segundos,
        descricao, r2_path, total_tabelas, total_registros, total_arquivos,
        criado_por, criado_em
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        backupId,
        new Date().toISOString(),
        'completo',
        comprimido.byteLength,
        hash,
        'concluido',
        duracao,
        descricao || 'Backup automático',
        r2Path,
        18,
        totalRegistros,
        arquivos.length,
        'SISTEMA',
        new Date().toISOString()
      )
      .run();


    return {
      id: backupId,
      tamanho: comprimido.byteLength,
      hash,
      duracao,
      total_tabelas: 18,
      total_registros: totalRegistros,
      total_arquivos: arquivos.length,
    };
  } catch (error) {
    console.error('Erro ao criar backup:', error);

    await env.DB.prepare(
      `INSERT INTO backups (
        id, data, tipo, tamanho, hash_md5, status, descricao, r2_path,
        criado_por, criado_em, erro_mensagem
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        backupId,
        new Date().toISOString(),
        'completo',
        0,
        '',
        'falhou',
        descricao || 'Backup automático',
        `backups/${backupId}.backup.gz`,
        'SISTEMA',
        new Date().toISOString(),
        error instanceof Error ? error.message : 'Erro desconhecido'
      )
      .run();

    throw error;
  }
}

/**
 * Restaura backup completo
 */
export async function restaurarBackup(
  backupId: string,
  env: Env,
  restaurarArquivos: boolean = false,
  executadoPor: string = 'ADMIN'
): Promise<void> {
  const inicio = Date.now();

  if (!env.BUCKET) {
    throw new Error('R2 Bucket não configurado');
  }

  const restoreResult = await env.DB.prepare(
    `INSERT INTO backup_restore_historico (
      backup_id, data_restore, status, restaurou_arquivos, executado_por
    ) VALUES (?, ?, ?, ?, ?)`
  )
    .bind(
      backupId,
      new Date().toISOString(),
      'iniciado',
      restaurarArquivos ? 1 : 0,
      executadoPor
    )
    .run();

  const restoreId = restoreResult.meta.last_row_id;

  try {
    const backupInfo = await env.DB.prepare(
      'SELECT * FROM backups WHERE id = ?'
    )
      .bind(backupId)
      .first();

    if (!backupInfo) {
      throw new Error('Backup não encontrado no banco de dados');
    }

    const obj = await env.BUCKET.get(backupInfo.r2_path as string);
    if (!obj) {
      throw new Error('Backup não encontrado no R2');
    }

    const conteudo = await new Response(obj.body).arrayBuffer();

    const hashAtual = await calcularMD5(conteudo);
    const hashEsperado = backupInfo.hash_md5 as string;

    if (hashAtual !== hashEsperado) {
      throw new Error(
        `Backup corrompido - hash inválido. Esperado: ${hashEsperado}, Atual: ${hashAtual}`
      );
    }

    const descomprimido = await descomprimirGzip(conteudo);
    const jsonString = new TextDecoder().decode(descomprimido);
    const dados: BackupData = JSON.parse(jsonString);

    await env.DB.prepare(
      `UPDATE backup_restore_historico SET status = ? WHERE id = ?`
    )
      .bind('em_progresso', restoreId)
      .run();

    await executarSQLDump(env.DB as any, dados.sql);

    let arquivosRestaurados = 0;
    if (restaurarArquivos && dados.arquivos.length > 0) {
      arquivosRestaurados = dados.arquivos.length;
    }

    const duracao = Math.round((Date.now() - inicio) / 1000);

    await env.DB.prepare(
      `UPDATE backup_restore_historico 
       SET status = ?, duracao_segundos = ?, 
           total_tabelas_restauradas = ?, total_arquivos_restaurados = ?
       WHERE id = ?`
    )
      .bind(
        'concluido',
        duracao,
        dados.metadados.total_tabelas,
        arquivosRestaurados,
        restoreId
      )
      .run();

    await env.DB.prepare(
      `INSERT INTO auditlogs (usuario, acao, modulo, detalhes, data)
       VALUES (?, ?, ?, ?, ?)`
    )
      .bind(
        executadoPor,
        'RESTORE_BACKUP',
        'Sistema',
        JSON.stringify({
          backup_id: backupId,
          duracao_segundos: duracao,
          restaurou_arquivos: restaurarArquivos,
        }),
        new Date().toISOString()
      )
      .run();

  } catch (error) {
    const duracao = Math.round((Date.now() - inicio) / 1000);

    await env.DB.prepare(
      `UPDATE backup_restore_historico 
       SET status = ?, duracao_segundos = ?, erro_mensagem = ?
       WHERE id = ?`
    )
      .bind(
        'falhou',
        duracao,
        error instanceof Error ? error.message : 'Erro desconhecido',
        restoreId
      )
      .run();

    throw error;
  }
}

/**
 * Exporta D1 completo como SQL dump
 */
async function exportarD1Completo(db: D1Database): Promise<string> {
  const tabelas = [
    'funcionarios',
    'funcoes',
    'aeronaves',
    'simuladores',
    'manobras',
    'sessoes_simulador',
    'sessao_manobras',
    'treinamentos',
    'certificacoes',
    'qualificacoes',
    'tipos_qualificacoes',
    'documentos',
    'auditlogs',
    'backups',
    'backup_configuracoes',
    'backup_restore_historico',
    'configuracoes',
    'usuarios',
  ];

  let sqlDump = '-- AirTrust Database Backup\n';
  sqlDump += `-- Data: ${new Date().toISOString()}\n`;
  sqlDump += '-- Versão: 2.0\n\n';

  for (const tabela of tabelas) {
    try {
      const schemaResult = await db
        .prepare(`SELECT sql FROM sqlite_master WHERE type='table' AND name=?`)
        .bind(tabela)
        .first();

      if (schemaResult && schemaResult.sql) {
        sqlDump += `-- Tabela: ${tabela}\n`;
        sqlDump += `DROP TABLE IF EXISTS ${tabela};\n`;
        sqlDump += `${schemaResult.sql};\n\n`;

        const dados = await db.prepare(`SELECT * FROM ${tabela}`).all();

        if (dados.results && dados.results.length > 0) {
          sqlDump += `-- Dados da tabela ${tabela}\n`;

          for (const row of dados.results) {
            const colunas = Object.keys(row);
            const valores = Object.values(row).map((v) => {
              if (v === null) return 'NULL';
              if (typeof v === 'string') return `'${v.replace(/'/g, "''")}'`;
              return v;
            });

            sqlDump += `INSERT INTO ${tabela} (${colunas.join(', ')}) VALUES (${valores.join(', ')});\n`;
          }

          sqlDump += '\n';
        }
      }
    } catch (error) {
      console.error(`Erro ao exportar tabela ${tabela}:`, error);
    }
  }

  return sqlDump;
}

/**
 * Executa SQL dump no D1
 */
async function executarSQLDump(db: D1Database, sql: string): Promise<void> {
  const statements = sql
    .split(';')
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && !s.startsWith('--'));

  for (const statement of statements) {
    try {
      await db.prepare(statement).run();
    } catch (error) {
      console.error('Erro ao executar statement:', statement, error);
    }
  }
}

/**
 * Lista arquivos do R2
 */
async function listarArquivosR2(
  bucket: R2Bucket,
  prefix: string
): Promise<Array<{ key: string; size: number }>> {
  const arquivos: Array<{ key: string; size: number }> = [];
  let cursor: string | undefined;

  do {
    const listed = await bucket.list({
      prefix,
      cursor,
      limit: 1000,
    });

    for (const obj of listed.objects) {
      arquivos.push({
        key: obj.key,
        size: obj.size,
      });
    }

    cursor = listed.truncated ? listed.cursor : undefined;
  } while (cursor);

  return arquivos;
}

/**
 * Conta total de registros no banco
 */
async function contarRegistros(db: D1Database): Promise<number> {
  const tabelas = [
    'funcionarios',
    'funcoes',
    'aeronaves',
    'simuladores',
    'treinamentos',
    'certificacoes',
    'qualificacoes',
  ];

  let total = 0;

  for (const tabela of tabelas) {
    try {
      const result = await db
        .prepare(`SELECT COUNT(*) as count FROM ${tabela}`)
        .first();
      total += (result?.count as number) || 0;
    } catch (error) {
      console.error(`Erro ao contar ${tabela}:`, error);
    }
  }

  return total;
}

/**
 * Comprime dados com gzip
 */
async function comprimirGzip(data: string): Promise<ArrayBuffer> {
  const encoder = new TextEncoder();
  const uint8Array = encoder.encode(data);

  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(uint8Array);
      controller.close();
    },
  });

  const compressedStream = stream.pipeThrough(
    new CompressionStream('gzip')
  );

  const chunks: Uint8Array[] = [];
  const reader = compressedStream.getReader();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }

  const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;

  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }

  return result.buffer;
}

/**
 * Descomprime dados gzip
 */
async function descomprimirGzip(data: ArrayBuffer): Promise<ArrayBuffer> {
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(new Uint8Array(data));
      controller.close();
    },
  });

  const decompressedStream = stream.pipeThrough(
    new DecompressionStream('gzip')
  );

  const chunks: Uint8Array[] = [];
  const reader = decompressedStream.getReader();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }

  const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;

  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }

  return result.buffer;
}

/**
 * Calcula hash MD5
 */
async function calcularMD5(data: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('MD5', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  return hashHex;
}

/**
 * Limpa backups antigos
 */
export async function limparBackupsAntigos(
  env: Env,
  retencaoDias: number
): Promise<number> {
  if (!env.BUCKET) {
    throw new Error('R2 Bucket não configurado');
  }

  const dataLimite = new Date();
  dataLimite.setDate(dataLimite.getDate() - retencaoDias);

  const backupsAntigos = await env.DB.prepare(
    `SELECT id, r2_path FROM backups 
     WHERE criado_em < ? AND status = 'concluido'`
  )
    .bind(dataLimite.toISOString())
    .all();

  let removidos = 0;

  for (const backup of backupsAntigos.results) {
    try {
      await env.BUCKET.delete(backup.r2_path as string);

      await env.DB.prepare('DELETE FROM backups WHERE id = ?')
        .bind(backup.id)
        .run();

      removidos++;
    } catch (error) {
      console.error(`Erro ao remover backup ${backup.id}:`, error);
    }
  }

  return removidos;
}

/**
 * Verifica integridade do backup
 */
export async function verificarIntegridade(
  backupId: string,
  env: Env
): Promise<{ integro: boolean; hashEsperado: string; hashAtual: string }> {
  if (!env.BUCKET) {
    throw new Error('R2 Bucket não configurado');
  }

  const backupInfo = await env.DB.prepare(
    'SELECT * FROM backups WHERE id = ?'
  )
    .bind(backupId)
    .first();

  if (!backupInfo) {
    throw new Error('Backup não encontrado');
  }

  const obj = await env.BUCKET.get(backupInfo.r2_path as string);
  if (!obj) {
    throw new Error('Arquivo de backup não encontrado no R2');
  }

  const conteudo = await new Response(obj.body).arrayBuffer();
  const hashAtual = await calcularMD5(conteudo);
  const hashEsperado = backupInfo.hash_md5 as string;

  const integro = hashAtual === hashEsperado;

  await env.DB.prepare(
    `UPDATE backups SET verificado_em = ?, status = ? WHERE id = ?`
  )
    .bind(
      new Date().toISOString(),
      integro ? 'concluido' : 'corrompido',
      backupId
    )
    .run();

  return {
    integro,
    hashEsperado,
    hashAtual,
  };
}
