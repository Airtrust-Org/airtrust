/**
 * @file zod-validation.ts
 * @description Helpers para validação Zod no backend
 * @module Utils/ZodValidation
 */

import { z, ZodError } from 'zod';

/**
 * Resultado de validação bem-sucedida
 */
export interface ValidationSuccess<T> {
  success: true;
  data: T;
}

/**
 * Resultado de validação com erro
 */
export interface ValidationError {
  success: false;
  error: string;
  details?: Array<{
    path: string;
    message: string;
  }>;
}

/**
 * Tipo de retorno da validação
 */
export type ValidationResult<T> = ValidationSuccess<T> | ValidationError;

/**
 * Valida dados usando um schema Zod
 * 
 * @param schema - Schema Zod para validação
 * @param data - Dados a serem validados
 * @returns Resultado da validação com dados tipados ou erro
 * 
 * @example
 * ```typescript
 * const result = validateRequest(UserSchema, body);
 * if (!result.success) {
 *   return c.json(result, 400);
 * }
 * const user = result.data; // Tipado corretamente
 * ```
 */
export function validateRequest<T>(
  schema: z.ZodSchema<T>,
  data: unknown
): ValidationResult<T> {
  const result = schema.safeParse(data);
  
  if (!result.success) {
    return {
      success: false,
      error: 'Dados inválidos',
      details: result.error.errors.map(e => ({
        path: e.path.join('.'),
        message: e.message,
      })),
    };
  }
  
  return {
    success: true,
    data: result.data,
  };
}

/**
 * Formata erro Zod para resposta HTTP
 * 
 * @param error - Erro Zod
 * @returns Objeto de erro formatado
 */
export function formatZodError(error: ZodError) {
  return {
    success: false,
    error: 'Validação falhou',
    details: error.errors.map(e => ({
      path: e.path.join('.'),
      message: e.message,
      code: e.code,
    })),
  };
}

/**
 * Valida ID de parâmetro de rota
 * 
 * @param id - ID a ser validado
 * @returns ID como número ou null se inválido
 */
export function validateId(id: string): number | null {
  const parsed = parseInt(id, 10);
  if (isNaN(parsed) || parsed <= 0) {
    return null;
  }
  return parsed;
}

/**
 * Schema para validação de ID
 */
export const IdParamSchema = z.object({
  id: z.string().regex(/^\d+$/).transform(Number),
});

/**
 * Valida query parameters com schema
 * 
 * @param schema - Schema para query params
 * @param params - Query params do request
 * @returns Resultado da validação
 */
export function validateQueryParams<T>(
  schema: z.ZodSchema<T>,
  params: Record<string, string | undefined>
): ValidationResult<T> {
  return validateRequest(schema, params);
}
