import { describe, it, expect } from 'vitest';
import { sanitizeLike, sanitizeQuery, containsSuspiciousSQLPatterns } from '../sql-sanitize';

describe('SQL Sanitization Utilities', () => {
  describe('sanitizeLike', () => {
    it('should escape underscore for LIKE queries', () => {
      const result = sanitizeLike('_test');
      expect(result).toBe('\\_test');
    });

    it('should escape percent for LIKE queries', () => {
      const result = sanitizeLike('test%');
      expect(result).toBe('test\\%');
    });

    it('should escape backslash for LIKE queries', () => {
      const result = sanitizeLike('test\\data');
      expect(result).toBe('test\\\\data');
    });

    it('should handle multiple special characters', () => {
      const result = sanitizeLike('100%_test\\path');
      expect(result).toBe('100\\%\\_test\\\\path');
    });

    it('should not escape regular characters', () => {
      const result = sanitizeLike('normal text');
      expect(result).toBe('normal text');
    });

    it('should handle empty string', () => {
      const result = sanitizeLike('');
      expect(result).toBe('');
    });

    it('should handle only special characters', () => {
      const result = sanitizeLike('%_\\');
      expect(result).toBe('\\%\\_\\\\');
    });
  });

  describe('sanitizeQuery', () => {
    it('should trim whitespace', () => {
      const result = sanitizeQuery('  test  ');
      expect(result).toBe('test');
    });

    it('should preserve single quotes', () => {
      const result = sanitizeQuery("test'value");
      expect(result).toContain("'");
    });

    it('should preserve double quotes', () => {
      const result = sanitizeQuery('test"value');
      expect(result).toContain('"');
    });

    it('should preserve semicolons', () => {
      const result = sanitizeQuery('test;value');
      expect(result).toContain(';');
    });

    it('should handle complex strings after trimming', () => {
      const result = sanitizeQuery("  DROP TABLE users;--comment'  ");
      expect(result).toBe("DROP TABLE users;--comment'");
    });

    it('should preserve alphanumeric characters', () => {
      const result = sanitizeQuery('testValue123');
      expect(result).toContain('testValue123');
    });

    it('should handle empty string', () => {
      const result = sanitizeQuery('');
      expect(result).toBe('');
    });

    it('should trim only, not sanitize', () => {
      const result = sanitizeQuery('  data  ');
      expect(result).toBe('data');
      expect(result.length).toBe(4);
    });
  });

  describe('containsSuspiciousSQLPatterns', () => {
    it('should detect DROP keyword', () => {
      expect(containsSuspiciousSQLPatterns('DROP TABLE users')).toBe(true);
    });

    it('should detect DELETE keyword', () => {
      expect(containsSuspiciousSQLPatterns('DELETE FROM users')).toBe(true);
    });

    it('should detect INSERT keyword', () => {
      expect(containsSuspiciousSQLPatterns('INSERT INTO users VALUES')).toBe(true);
    });

    it('should detect UNION keyword', () => {
      expect(containsSuspiciousSQLPatterns('SELECT * UNION SELECT')).toBe(true);
    });

    it('should detect OR 1=1 pattern', () => {
      expect(containsSuspiciousSQLPatterns('OR 1 = 1')).toBe(true);
      expect(containsSuspiciousSQLPatterns('OR 1=1')).toBe(true);
    });

    it('should detect UPDATE keyword', () => {
      expect(containsSuspiciousSQLPatterns('UPDATE users SET')).toBe(true);
    });

    it('should be case-insensitive', () => {
      expect(containsSuspiciousSQLPatterns('drop table users')).toBe(true);
      expect(containsSuspiciousSQLPatterns('DeLeTe FROM users')).toBe(true);
    });

    it('should not flag safe queries', () => {
      expect(containsSuspiciousSQLPatterns('SELECT name FROM users WHERE id = 1')).toBe(false);
    });

    it('should not flag updates to specific fields', () => {
      expect(containsSuspiciousSQLPatterns('User updated their profile')).toBe(false);
    });

    it('should handle empty string', () => {
      expect(containsSuspiciousSQLPatterns('')).toBe(false);
    });

    it('should detect semicolon-delete pattern', () => {
      expect(containsSuspiciousSQLPatterns(';delete from users')).toBe(true);
    });

    it('should detect semicolon-drop pattern', () => {
      expect(containsSuspiciousSQLPatterns(';drop table users')).toBe(true);
    });

    it('should detect SQL comment at end (--)', () => {
      expect(containsSuspiciousSQLPatterns('SELECT * --')).toBe(true);
    });

    it('should detect block comment (/* */)', () => {
      expect(containsSuspiciousSQLPatterns('SELECT * /* comment */')).toBe(true);
    });
  });
});
