export interface PdfGeneratorData {
  funcionario_nome: string;
  qualificacao_nome: string;
  data_conclusao: string;
  data_vencimento: string;
  empresa_logo_url?: string;
  cor_primaria: string;
  cor_secundaria: string;
}

export class PdfGenerator {
  static async gerarCertificadoHtml(dados: PdfGeneratorData): Promise<string> {
    const logoImg = dados.empresa_logo_url
      ? `<img src="${dados.empresa_logo_url}" style="max-height: 80px;" alt="Logo"/>`
      : '';

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; }
    body { font-family: Arial, sans-serif; padding: 40px; }
    .container { 
      width: 100%; 
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border: 3px solid ${dados.cor_primaria};
      background: linear-gradient(to bottom, #f8f9fa 0%, #ffffff 100%);
      padding: 40px;
    }
    .header {
      text-align: center;
      margin-bottom: 40px;
    }
    .logo {
      margin-bottom: 20px;
    }
    .title {
      font-size: 48px;
      font-weight: bold;
      color: ${dados.cor_primaria};
      margin-bottom: 20px;
    }
    .content {
      text-align: center;
      font-size: 24px;
      margin: 30px 0;
      line-height: 1.8;
    }
    .funcionario {
      font-size: 28px;
      font-weight: bold;
      color: ${dados.cor_secundaria};
      margin: 20px 0;
    }
    .qualificacao {
      font-size: 20px;
      color: ${dados.cor_primaria};
      margin: 15px 0;
    }
    .datas {
      font-size: 14px;
      color: #666;
      margin-top: 30px;
    }
    .footer {
      margin-top: 60px;
      text-align: center;
      border-top: 2px solid ${dados.cor_primaria};
      padding-top: 20px;
      font-size: 12px;
      color: #999;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">${logoImg}</div>
      <div class="title">Certificado</div>
    </div>
    
    <div class="content">
      <p>Certificamos que</p>
      <div class="funcionario">${dados.funcionario_nome}</div>
      <p>completou com sucesso o curso de</p>
      <div class="qualificacao">${dados.qualificacao_nome}</div>
    </div>
    
    <div class="datas">
      <p>Data de Conclusão: ${new Date(dados.data_conclusao).toLocaleDateString('pt-BR')}</p>
      <p>Data de Vencimento: ${new Date(dados.data_vencimento).toLocaleDateString('pt-BR')}</p>
    </div>
    
    <div class="footer">
      <p>AirTrust - Sistema de Certificação Aeronáutico</p>
      <p>Este certificado é válido até ${new Date(dados.data_vencimento).toLocaleDateString('pt-BR')}</p>
    </div>
  </div>
</body>
</html>
    `;
  }

  /**
   * Converte HTML para PDF usando uma API externa
   * Em produção, usar Cloudflare's built-in PDF generation ou
   * integração com serviço como html2pdf.io
   */
  static async htmlToPdf(html: string): Promise<Buffer> {
    // Implementação alternativa: usar pdf-lib (puro JavaScript)
    // npm install pdf-lib
    
    // Para MVP, retornar HTML como string que será enviada para geração em client
    // Ou usar API externa para conversão
    
    // Placeholder: em produção, usar:
    // 1. Cloudflare PDF API
    // 2. html2pdf.io API
    // 3. PDFKit + Canvas (npm install pdfkit canvas)
    
    return Buffer.from(html);
  }
}
