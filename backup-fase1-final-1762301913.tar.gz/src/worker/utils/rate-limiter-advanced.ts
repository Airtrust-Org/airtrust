/**
 * Advanced Rate Limiting with Sliding Windows
 * Suporta diferentes limites por tipo de operação
 * Armazena estado em KV (Durable Objects pattern)
 */

export interface RateLimitConfig {
  window: number; // Janela em segundos
  maxRequests: number; // Max requisições na janela
  keyPrefix: string; // Prefixo da chave (ex: "rl:import")
}

export interface RateLimitState {
  timestamps: number[]; // Timestamps das requisições
  lastCleanup: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
  retryAfter?: number;
}

/**
 * Rate limiter com janela deslizante
 * Simula comportamento de sliding window em memória
 */
export class SlidingWindowRateLimiter {
  private state: Map<string, RateLimitState> = new Map();
  private cleanupInterval: number = 60000; // 1 min

  constructor() {
    // Cleanup periódico
    this.startCleanup();
  }

  /**
   * Verificar se request é permitida
   * @param key - Chave única (ex: IP, user_id)
   * @param config - Configuração de rate limit
   * @returns Status da requisição
   */
  checkLimit(key: string, config: RateLimitConfig): RateLimitResult {
    const now = Date.now() / 1000; // segundos
    const fullKey = `${config.keyPrefix}:${key}`;

    // Obter ou criar estado
    let state = this.state.get(fullKey) || { timestamps: [], lastCleanup: now };

    // Remover timestamps fora da janela
    const windowStart = now - config.window;
    state.timestamps = state.timestamps.filter((ts) => ts > windowStart);

    const isAllowed = state.timestamps.length < config.maxRequests;

    if (isAllowed) {
      state.timestamps.push(now);
    }

    this.state.set(fullKey, state);

    const remaining = Math.max(0, config.maxRequests - state.timestamps.length);
    const resetAt = state.timestamps.length > 0 ? state.timestamps[0] + config.window : now + config.window;

    return {
      allowed: isAllowed,
      remaining,
      resetAt: Math.ceil(resetAt),
      retryAfter: isAllowed ? undefined : Math.ceil(resetAt - now),
    };
  }

  /**
   * Limpar chaves expiradas
   */
  private startCleanup(): void {
    setInterval(() => {
      const now = Date.now() / 1000;
      for (const [key, state] of this.state.entries()) {
        // Remover estado se não teve atividade recente (5 min)
        if (now - state.lastCleanup > 300) {
          this.state.delete(key);
        }
      }
    }, this.cleanupInterval);
  }

  /**
   * Reset de limite para uma chave (admin only)
   */
  reset(key: string, prefix: string): void {
    const fullKey = `${prefix}:${key}`;
    this.state.delete(fullKey);
  }

  /**
   * Get estado atual (debugging)
   */
  getState(key: string, prefix: string): RateLimitState | undefined {
    const fullKey = `${prefix}:${key}`;
    return this.state.get(fullKey);
  }
}

/**
 * Configurações padrão por tipo de operação
 */
export const DEFAULT_RATE_LIMITS: Record<string, RateLimitConfig> = {
  import: {
    window: 3600, // 1 hora
    maxRequests: 10,
    keyPrefix: 'rl:import',
  },
  export: {
    window: 3600,
    maxRequests: 20,
    keyPrefix: 'rl:export',
  },
  auth: {
    window: 300, // 5 minutos
    maxRequests: 5, // Max 5 login attempts
    keyPrefix: 'rl:auth',
  },
  api: {
    window: 60, // 1 minuto
    maxRequests: 60, // 60 req/min por IP
    keyPrefix: 'rl:api',
  },
  hardDelete: {
    window: 86400, // 24 horas
    maxRequests: 3, // Max 3 hard deletes/dia
    keyPrefix: 'rl:harddelete',
  },
};

/**
 * Middleware factory para rate limiting
 */
export function createRateLimitMiddleware(
  limiter: SlidingWindowRateLimiter,
  config: RateLimitConfig
) {
  return (key: string) => {
    const result = limiter.checkLimit(key, config);

    if (!result.allowed) {
      return {
        statusCode: 429,
        body: {
          error: 'Too Many Requests',
          retryAfter: result.retryAfter,
          resetAt: new Date(result.resetAt * 1000).toISOString(),
        },
      };
    }

    return {
      statusCode: 200,
      headers: {
        'X-RateLimit-Limit': config.maxRequests.toString(),
        'X-RateLimit-Remaining': result.remaining.toString(),
        'X-RateLimit-Reset': result.resetAt.toString(),
      },
    };
  };
}

/**
 * Testes unitários para validação
 */
export const rateLimitTests = [
  {
    name: 'Should allow requests under limit',
    test: () => {
      const limiter = new SlidingWindowRateLimiter();
      const config: RateLimitConfig = {
        window: 60,
        maxRequests: 5,
        keyPrefix: 'test',
      };

      for (let i = 0; i < 5; i++) {
        const result = limiter.checkLimit('user1', config);
        if (!result.allowed) return false;
      }
      return true;
    },
  },
  {
    name: 'Should reject requests over limit',
    test: () => {
      const limiter = new SlidingWindowRateLimiter();
      const config: RateLimitConfig = {
        window: 60,
        maxRequests: 3,
        keyPrefix: 'test',
      };

      // Preencher limite
      for (let i = 0; i < 3; i++) {
        limiter.checkLimit('user2', config);
      }

      // 4ª requisição deve ser rejeitada
      const result = limiter.checkLimit('user2', config);
      return !result.allowed;
    },
  },
  {
    name: 'Should track remaining requests',
    test: () => {
      const limiter = new SlidingWindowRateLimiter();
      const config: RateLimitConfig = {
        window: 60,
        maxRequests: 5,
        keyPrefix: 'test',
      };

      limiter.checkLimit('user3', config);
      const result = limiter.checkLimit('user3', config);
      return result.remaining === 3; // 5 max - 2 usado = 3 remaining
    },
  },
  {
    name: 'Should reset after window expires',
    test: () => {
      const limiter = new SlidingWindowRateLimiter();
      const config: RateLimitConfig = {
        window: 1, // 1 segundo (para teste)
        maxRequests: 1,
        keyPrefix: 'test',
      };

      // Preencher limite
      limiter.checkLimit('user4', config);

      // Esperar 1.1s e tentar novamente
      return new Promise((resolve) => {
        setTimeout(() => {
          const result = limiter.checkLimit('user4', config);
          resolve(result.allowed);
        }, 1100);
      });
    },
  },
];
