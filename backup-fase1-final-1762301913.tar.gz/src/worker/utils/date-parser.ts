/**
 * Utilitário para parsing e conversão de datas no padrão brasileiro (DD/MM/AAAA)
 * AirTrust - Compliance com legislação e prática de mercado brasileiro
 */

export class DateParser {
  /**
   * Valida se uma string está no formato brasileiro DD/MM/AAAA
   */
  static isValidBrazilianDate(dateString: string): boolean {
    if (!dateString || typeof dateString !== 'string') return false;
    
    const regex = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!regex.test(dateString.trim())) return false;
    
    const [day, month, year] = dateString.trim().split('/').map(Number);
    
    if (day < 1 || day > 31) return false;
    if (month < 1 || month > 12) return false;
    if (year < 1900 || year > 2100) return false;
    
    const date = new Date(year, month - 1, day);
    
    return date instanceof Date && 
           !isNaN(date.getTime()) &&
           date.getDate() === day &&
           date.getMonth() === month - 1 &&
           date.getFullYear() === year;
  }

  /**
   * Converte data brasileira (DD/MM/AAAA) para formato ISO (YYYY-MM-DD)
   */
  static brazilianToISO(brazilianDate: string): string {
    if (!brazilianDate || brazilianDate.trim() === '') return '';
    
    const trimmed = brazilianDate.trim();
    
    if (!this.isValidBrazilianDate(trimmed)) {
      throw new Error(`Data brasileira inválida: "${trimmed}". Use formato DD/MM/AAAA`);
    }
    
    const [day, month, year] = trimmed.split('/');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  /**
   * Converte data ISO (YYYY-MM-DD) para formato brasileiro (DD/MM/AAAA)
   */
  static isoToBrazilian(isoDate: string): string {
    if (!isoDate || isoDate.trim() === '') return '';
    
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    if (!regex.test(isoDate.trim())) {
      throw new Error(`Data ISO inválida: "${isoDate}". Use formato YYYY-MM-DD`);
    }
    
    const [year, month, day] = isoDate.trim().split('-');
    return `${day}/${month}/${year}`;
  }

  /**
   * Detecta se uma string está no formato antigo ISO (YYYY-MM-DD)
   */
  static isOldISOFormat(dateString: string): boolean {
    if (!dateString || typeof dateString !== 'string') return false;
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(dateString.trim());
  }

  /**
   * Processa datas em CSV, convertendo do formato brasileiro para ISO
   */
  static processCSVDates(rowData: any): {
    data_conclusao?: string;
    data_vencimento?: string;
    warnings: string[];
  } {
    const warnings: string[] = [];
    const result: any = {};

    if (rowData.data_conclusao && rowData.data_conclusao.trim()) {
      try {
        if (this.isOldISOFormat(rowData.data_conclusao)) {
          warnings.push(`Data de conclusão no formato antigo ISO (${rowData.data_conclusao}). Converta para formato brasileiro DD/MM/AAAA`);
          throw new Error(`Data no formato antigo: ${rowData.data_conclusao}`);
        }
        
        result.data_conclusao = this.brazilianToISO(rowData.data_conclusao);
      } catch (error) {
        throw new Error(`Data de conclusão inválida: ${rowData.data_conclusao}. Use formato DD/MM/AAAA (ex: 20/08/2025)`);
      }
    }

    if (rowData.data_vencimento && rowData.data_vencimento.trim()) {
      try {
        if (this.isOldISOFormat(rowData.data_vencimento)) {
          warnings.push(`Data de vencimento no formato antigo ISO (${rowData.data_vencimento}). Converta para formato brasileiro DD/MM/AAAA`);
          throw new Error(`Data no formato antigo: ${rowData.data_vencimento}`);
        }
        
        result.data_vencimento = this.brazilianToISO(rowData.data_vencimento);
      } catch (error) {
        throw new Error(`Data de vencimento inválida: ${rowData.data_vencimento}. Use formato DD/MM/AAAA (ex: 19/09/2026)`);
      }
    }

    return { ...result, warnings };
  }

  /**
   * Gera exemplo de data brasileira para templates
   */
  static generateExampleDate(daysFromToday: number = 0): string {
    const date = new Date();
    date.setDate(date.getDate() + daysFromToday);
    
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    
    return `${day}/${month}/${year}`;
  }
}
