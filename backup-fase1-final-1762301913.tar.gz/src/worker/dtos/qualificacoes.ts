import { z } from 'zod';

export const CreateQualificacaoDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  codigo: z.string().min(1, 'Código obrigatório'),
  categoria: z.string().optional(),
  carga_horaria: z.number().int().positive().optional(),
  validade_meses: z.number().int().positive().optional(),
  descricao: z.string().optional(),
});

export type CreateQualificacaoInput = z.infer<typeof CreateQualificacaoDTO>;

export const UpdateQualificacaoDTO = z.object({
  nome: z.string().min(1).optional(),
  codigo: z.string().min(1).optional(),
  categoria: z.string().optional(),
  carga_horaria: z.number().int().positive().optional(),
  validade_meses: z.number().int().positive().optional(),
  descricao: z.string().optional(),
  ativo: z.boolean().optional(), // Nome correto: ativo (não ativa)
});

export type UpdateQualificacaoInput = z.infer<typeof UpdateQualificacaoDTO>;

export const QualificacaoResponseDTO = z.object({
  id: z.union([z.number(), z.string()]), // Aceita string ou number
  nome: z.string(),
  codigo: z.string(),
  categoria: z.string().optional().nullable(),
  carga_horaria: z.number().optional().nullable(),
  validade_meses: z.number().optional().nullable(),
  descricao: z.string().optional().nullable(),
  ativo: z
    .union([z.boolean(), z.number()])
    .optional()
    .default(true)
    .transform((v) => !!v), // SQLite retorna 0/1
  created_at: z.string(),
  updated_at: z.string().optional().nullable(),
  deleted_at: z.string().optional().nullable(),
  conteudo_programatico: z.string().optional().nullable(),
  tipo_vencimento: z.string().optional().nullable(),
});

export type QualificacaoResponse = z.infer<typeof QualificacaoResponseDTO>;
