import { z } from 'zod';

export const CreateFuncaoDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  codigo: z.string().min(1, 'Código obrigatório'),
  descricao: z.string().optional(),
  permissoes: z.array(z.string()).optional(),
});

export type CreateFuncaoInput = z.infer<typeof CreateFuncaoDTO>;

export const UpdateFuncaoDTO = z.object({
  nome: z.string().min(1).optional(),
  codigo: z.string().min(1).optional(),
  descricao: z.string().optional(),
  permissoes: z.array(z.string()).optional(),
  ativa: z.boolean().optional(),
});

export type UpdateFuncaoInput = z.infer<typeof UpdateFuncaoDTO>;

export const FuncaoResponseDTO = z.object({
  id: z.number(),
  nome: z.string(),
  codigo: z.string(),
  descricao: z.string().optional(),
  permissoes: z.array(z.string()).optional(),
  ativa: z.boolean(),
  created_at: z.string(),
  updated_at: z.string().optional(),
});

export type FuncaoResponse = z.infer<typeof FuncaoResponseDTO>;
