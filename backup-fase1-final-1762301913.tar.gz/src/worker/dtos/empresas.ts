import { z } from 'zod';

export const CreateEmpresaDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  razao_social: z.string().optional(),
  cnpj: z.string().optional(),
  logo_url: z.string().url().optional(),
});

export type CreateEmpresaInput = z.infer<typeof CreateEmpresaDTO>;

export const UpdateEmpresaDTO = z.object({
  nome: z.string().min(1).optional(),
  razao_social: z.string().optional(),
  cnpj: z.string().optional(),
  logo_url: z.string().url().optional(),
  ativa: z.boolean().optional(),
});

export type UpdateEmpresaInput = z.infer<typeof UpdateEmpresaDTO>;

export const EmpresaConfigDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  logo_url: z.string().url().optional(),
  template_certificado: z.string().optional(),
  cor_primaria: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Cor primária inválida (#RRGGBB)'),
  cor_secundaria: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Cor secundária inválida (#RRGGBB)'),
});

export type EmpresaConfigInput = z.infer<typeof EmpresaConfigDTO>;

export const EmpresaResponseDTO = z.object({
  id: z.number(),
  nome: z.string(),
  razao_social: z.string().optional(),
  cnpj: z.string().optional(),
  logo_url: z.string().optional(),
  ativa: z.boolean(),
  created_at: z.string(),
  updated_at: z.string().optional(),
});

export type EmpresaResponse = z.infer<typeof EmpresaResponseDTO>;

export const EmpresaConfigResponseDTO = z.object({
  id: z.number().optional(),
  empresa_id: z.number(),
  nome: z.string(),
  logo_url: z.string().optional(),
  template_certificado: z.string().optional(),
  cor_primaria: z.string(),
  cor_secundaria: z.string(),
  created_at: z.string().optional(),
  updated_at: z.string().optional(),
});

export type EmpresaConfigResponse = z.infer<typeof EmpresaConfigResponseDTO>;
