import { z } from 'zod';

/**
 * DTOs para Habilitações
 * ✅ Alinhado com backend: status = VÁLIDO | VENCENDO | VENCIDA
 */

export const CreateHabilitacaoDTO = z.object({
  funcionario_id: z.number().int().positive('Funcionário é obrigatório'),
  qualificacao_id: z.number().int().positive('Qualificação é obrigatória'),
  data_conclusao: z.string().datetime().or(z.string().date()),
  data_vencimento: z.string().datetime().or(z.string().date()),
  resultado: z.enum(['APROVADO', 'REPROVADO', 'PENDENTE']).default('PENDENTE'),
  nota_final: z.number().min(0).max(100).optional(),
  observacoes: z.string().optional(),
  instrutor: z.string().optional(),
  timezone: z.string().default('UTC').optional(),
  eh_renovada: z.boolean().default(false).optional(),
  habilitacao_anterior_id: z.number().int().optional(),
});

export type CreateHabilitacaoInput = z.infer<typeof CreateHabilitacaoDTO>;

export const UpdateHabilitacaoDTO = z.object({
  data_conclusao: z.string().datetime().or(z.string().date()).optional(),
  data_vencimento: z.string().datetime().or(z.string().date()).optional(),
  resultado: z.enum(['APROVADO', 'REPROVADO', 'PENDENTE']).optional(),
  nota_final: z.number().min(0).max(100).optional(),
  observacoes: z.string().optional(),
  instrutor: z.string().optional(),
  timezone: z.string().optional(),
  certificado_url: z.string().url().optional(),
});

export type UpdateHabilitacaoInput = z.infer<typeof UpdateHabilitacaoDTO>;

// Status calculado dinamicamente baseado em data_vencimento
export const HabilitacaoResponseDTO = z.object({
  id: z.number(),
  funcionario_id: z.number(),
  qualificacao_id: z.number(),
  data_conclusao: z.string(),
  data_vencimento: z.string(),
  resultado: z.string().optional(),
  observacoes: z.string().optional(),
  certificado_url: z.string().optional(),
  status: z.enum(['VÁLIDO', 'VENCENDO', 'VENCIDA']),
  dias_para_vencimento: z.number().optional(),
  nota_final: z.number().optional(),
  eh_renovada: z.boolean().default(false),
  renovada_em: z.string().optional(),
  habilitacao_anterior_id: z.number().optional(),
  qualificacao_nome: z.string().optional(),
  qualificacao_codigo: z.string().optional(),
  funcionario_nome: z.string().optional(),
  funcionario_matricula: z.string().optional(),
  categoria_nome: z.string().optional(),
  validade_meses: z.number().optional(),
  created_at: z.string(),
  updated_at: z.string().optional(),
});

export type HabilitacaoResponse = z.infer<typeof HabilitacaoResponseDTO>;
