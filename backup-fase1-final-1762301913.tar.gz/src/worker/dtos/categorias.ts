import { z } from 'zod';

export const CreateCategoriaDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  codigo: z.string().min(1, 'Código obrigatório'),
  descricao: z.string().optional(),
});

export type CreateCategoriaInput = z.infer<typeof CreateCategoriaDTO>;

export const UpdateCategoriaDTO = z.object({
  nome: z.string().min(1).optional(),
  codigo: z.string().min(1).optional(),
  descricao: z.string().optional(),
  cor: z.string().optional(),
  ativo: z.boolean().optional(),
});

export type UpdateCategoriaInput = z.infer<typeof UpdateCategoriaDTO>;

export const CategoriaResponseDTO = z.object({
  id: z.union([z.number(), z.string()]),
  nome: z.string(),
  codigo: z.string(),
  descricao: z.string().optional().nullable(),
  cor: z.string().optional().nullable(),
  ativo: z
    .union([z.boolean(), z.number()])
    .optional()
    .default(true)
    .transform((v) => !!v),
  created_at: z.string(),
  updated_at: z.string().optional().nullable(),
  deleted_at: z.string().optional().nullable(),
});

export type CategoriaResponse = z.infer<typeof CategoriaResponseDTO>;
