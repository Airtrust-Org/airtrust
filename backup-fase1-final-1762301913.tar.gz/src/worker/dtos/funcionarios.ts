import { z } from 'zod';

export const CreateFuncionarioDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  matricula: z.string().min(1, 'Matrícula obrigatória'),
  email: z.string().email().optional(),
  empresa_id: z.number().int().optional(),
  funcao: z.string().optional(),
  data_admissao: z.string().date().optional(),
});

export type CreateFuncionarioInput = z.infer<typeof CreateFuncionarioDTO>;

export const UpdateFuncionarioDTO = z.object({
  nome: z.string().min(1).optional(),
  matricula: z.string().min(1).optional(),
  email: z.string().email().optional(),
  funcao: z.string().optional(),
  ativo: z.boolean().optional(),
});

export type UpdateFuncionarioInput = z.infer<typeof UpdateFuncionarioDTO>;

export const FuncionarioResponseDTO = z
  .object({
    id: z.number(),
    nome: z.string(),
    matricula: z.string(),
    email: z.string().optional(),
    empresa_id: z.number().optional(),
    funcao: z.string().optional(),
    ativo: z.boolean().optional(),
    data_admissao: z.string().optional(),
    created_at: z.string(),
    updated_at: z.string().optional(),
  })
  .passthrough(); // Permite campos adicionais do DB

export type FuncionarioResponse = z.infer<typeof FuncionarioResponseDTO>;
