import { z } from 'zod';

export const CreateCertificadoDTO = z.object({
  habilitacao_id: z.number().int().positive('Habilitação ID é obrigatório'),
  empresa_id: z.number().int().positive('Empresa ID é obrigatório'),
  funcionario_id: z.number().int().positive('Funcionário ID é obrigatório'),
  qualificacao_id: z.number().int().optional(),
  titulo: z.string().optional().default('Certificado de Conclusão'),
  data_emissao: z.string().optional(),
});

export const UpdateCertificadoDTO = z.object({
  status: z.enum(['ativo', 'revogado', 'expirado']).optional(),
  titulo: z.string().optional(),
  descricao: z.string().optional(),
});

export const CertificadoResponseDTO = z.object({
  id: z.number(),
  numero_certificado: z.string(),
  titulo: z.string(),
  habilitacao_id: z.number(),
  empresa_id: z.number(),
  funcionario_id: z.number(),
  logo_url: z.string().url().nullable(),
  template_tipo: z.string(),
  cor_primaria: z.string(),
  r2_url: z.string().url().nullable(),
  data_emissao: z.string(),
  status: z.string(),
  created_at: z.string(),
});

export type CreateCertificadoInput = z.infer<typeof CreateCertificadoDTO>;
export type UpdateCertificadoInput = z.infer<typeof UpdateCertificadoDTO>;
export type CertificadoResponse = z.infer<typeof CertificadoResponseDTO>;
