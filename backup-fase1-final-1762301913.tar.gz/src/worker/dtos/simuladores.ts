import { z } from 'zod';

export const CreateSimuladorDTO = z.object({
  nome: z.string().min(1, 'Nome obrigatório'),
  tipo: z.string().min(1, 'Tipo obrigatório'),
  empresa_id: z.number().int().positive(),
  capacidade: z.number().int().positive().optional(),
});

export type CreateSimuladorInput = z.infer<typeof CreateSimuladorDTO>;

export const UpdateSimuladorDTO = z.object({
  nome: z.string().min(1).optional(),
  tipo: z.string().min(1).optional(),
  capacidade: z.number().int().positive().optional(),
  ativo: z.boolean().optional(),
});

export type UpdateSimuladorInput = z.infer<typeof UpdateSimuladorDTO>;

export const SimuladorResponseDTO = z.object({
  id: z.number(),
  nome: z.string(),
  tipo: z.string(),
  empresa_id: z.number(),
  capacidade: z.number().optional(),
  ativo: z.boolean(),
  created_at: z.string(),
  updated_at: z.string().optional(),
});

export type SimuladorResponse = z.infer<typeof SimuladorResponseDTO>;
