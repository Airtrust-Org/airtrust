import { z } from 'zod';

// CREATE DTO
export const CreateEmpresaConfigDTO = z.object({
  empresa_id: z.number().int().positive('Empresa ID é obrigatório'),
  nome: z.string().min(1, 'Nome é obrigatório').max(200),
  descricao: z.string().optional(),
  
  // Logo
  logo_url: z.string().url().optional(),
  logo_tipo: z.enum(['png', 'jpg', 'svg']).default('png'),
  logo_largura: z.number().int().positive().default(200),
  logo_altura: z.number().int().positive().default(100),
  
  // Cores
  cor_primaria: z.string().regex(/^#[0-9A-F]{6}$/i).default('#0066cc'),
  cor_secundaria: z.string().regex(/^#[0-9A-F]{6}$/i).default('#333333'),
  cor_acento: z.string().regex(/^#[0-9A-F]{6}$/i).default('#FF6B35'),
  
  // Template
  template_certificado: z.enum(['default', 'premium', 'simples']).default('default'),
  assinatura_digital: z.boolean().default(false),
  
  // Contato
  email_contato: z.string().email().optional(),
  telefone: z.string().optional(),
  website: z.string().url().optional(),
  endereco: z.string().optional(),
});

// UPDATE DTO (todos opcionais)
export const UpdateEmpresaConfigDTO = CreateEmpresaConfigDTO.partial();

// RESPONSE DTO
export const EmpresaConfigResponseDTO = z.object({
  id: z.number(),
  empresa_id: z.number(),
  nome: z.string(),
  descricao: z.string().nullable(),
  
  logo_url: z.string().url().nullable(),
  logo_tipo: z.string(),
  logo_largura: z.number(),
  logo_altura: z.number(),
  
  cor_primaria: z.string(),
  cor_secundaria: z.string(),
  cor_acento: z.string(),
  
  template_certificado: z.string(),
  assinatura_digital: z.boolean(),
  assinatura_url: z.string().url().nullable(),
  
  email_contato: z.string().email().nullable(),
  telefone: z.string().nullable(),
  website: z.string().url().nullable(),
  endereco: z.string().nullable(),
  
  created_at: z.string(),
  updated_at: z.string(),
});

export type CreateEmpresaConfigInput = z.infer<typeof CreateEmpresaConfigDTO>;
export type UpdateEmpresaConfigInput = z.infer<typeof UpdateEmpresaConfigDTO>;
export type EmpresaConfigResponse = z.infer<typeof EmpresaConfigResponseDTO>;
