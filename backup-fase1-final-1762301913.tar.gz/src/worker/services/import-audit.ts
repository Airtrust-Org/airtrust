/**
 * Serviço de Auditoria de Importações
 * Registra todas as operações de importação com métricas detalhadas
 */

export interface ImportAuditLog {
  id?: string;
  tipo_importacao: 'FUNCIONARIOS' | 'QUALIFICACOES';
  usuario_id?: string;
  usuario_nome?: string;
  arquivo_nome: string;
  total_linhas: number;
  linhas_sucesso: number;
  linhas_erro: number;
  tempo_processamento_ms: number;
  detalhes_erros?: string; // JSON com erros detalhados
  status: 'SUCESSO' | 'PARCIAL' | 'FALHA';
  origem: string; // 'WINDSURF', 'WEB', 'API'
  created_at?: string;
}

export class ImportAuditService {
  
  /**
   * Registra uma importação no log de auditoria
   */
  static async registrarImportacao(
    db: any,
    log: ImportAuditLog
  ): Promise<string> {
    const id = `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      await db.prepare(`
        INSERT INTO importacoes_log (
          id, tipo_importacao, usuario_id, usuario_nome, arquivo_nome,
          total_linhas, linhas_sucesso, linhas_erro, tempo_processamento_ms,
          detalhes_erros, status, origem, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(
        id,
        log.tipo_importacao,
        log.usuario_id || null,
        log.usuario_nome || 'Sistema',
        log.arquivo_nome,
        log.total_linhas,
        log.linhas_sucesso,
        log.linhas_erro,
        log.tempo_processamento_ms,
        log.detalhes_erros || null,
        log.status,
        log.origem || 'WEB'
      ).run();
      
      return id;
    } catch (error) {
      console.error('[AUDIT] Erro ao registrar importação:', error);
      throw error;
    }
  }
  
  /**
   * Busca histórico de importações
   */
  static async buscarHistorico(
    db: any,
    tipo?: 'FUNCIONARIOS' | 'QUALIFICACOES',
    limit: number = 50
  ): Promise<ImportAuditLog[]> {
    try {
      let query = `
        SELECT * FROM importacoes_log
        WHERE 1=1
      `;
      const bindings: any[] = [];
      
      if (tipo) {
        query += ` AND tipo_importacao = ?`;
        bindings.push(tipo);
      }
      
      query += ` ORDER BY created_at DESC LIMIT ?`;
      bindings.push(limit);
      
      const { results } = await db.prepare(query).bind(...bindings).all();
      return results || [];
    } catch (error) {
      console.error('[AUDIT] Erro ao buscar histórico:', error);
      return [];
    }
  }
  
  /**
   * Gera relatório de importação
   */
  static gerarRelatorio(log: ImportAuditLog, erros: any[]): string {
    const linhas: string[] = [];
    
    linhas.push('='.repeat(80));
    linhas.push(`RELATÓRIO DE IMPORTAÇÃO - ${log.tipo_importacao}`);
    linhas.push('='.repeat(80));
    linhas.push('');
    linhas.push(`Arquivo: ${log.arquivo_nome}`);
    linhas.push(`Data/Hora: ${new Date().toISOString()}`);
    linhas.push(`Usuário: ${log.usuario_nome || 'Sistema'}`);
    linhas.push(`Origem: ${log.origem}`);
    linhas.push('');
    linhas.push('-'.repeat(80));
    linhas.push('RESUMO');
    linhas.push('-'.repeat(80));
    linhas.push(`Total de linhas: ${log.total_linhas}`);
    linhas.push(`Linhas processadas com sucesso: ${log.linhas_sucesso}`);
    linhas.push(`Linhas com erro: ${log.linhas_erro}`);
    linhas.push(`Taxa de sucesso: ${((log.linhas_sucesso / log.total_linhas) * 100).toFixed(2)}%`);
    linhas.push(`Tempo de processamento: ${log.tempo_processamento_ms}ms`);
    linhas.push(`Status: ${log.status}`);
    linhas.push('');
    
    if (erros.length > 0) {
      linhas.push('-'.repeat(80));
      linhas.push('ERROS DETALHADOS');
      linhas.push('-'.repeat(80));
      
      erros.forEach((erro, index) => {
        linhas.push(`\n${index + 1}. Linha ${erro.linha}:`);
        linhas.push(`   Campo: ${erro.campo}`);
        linhas.push(`   Valor: ${erro.valor}`);
        linhas.push(`   Erro: ${erro.erro}`);
        if (erro.sugestao) {
          linhas.push(`   Sugestão: ${erro.sugestao}`);
        }
      });
    }
    
    linhas.push('');
    linhas.push('='.repeat(80));
    linhas.push('FIM DO RELATÓRIO');
    linhas.push('='.repeat(80));
    
    return linhas.join('\n');
  }
  
  /**
   * Gera relatório CSV
   */
  static gerarRelatorioCSV(erros: any[]): string {
    const linhas: string[] = [];
    
    linhas.push('Linha,Campo,Valor,Erro,Sugestao');
    
    erros.forEach(erro => {
      const valor = String(erro.valor || '').replace(/"/g, '""');
      const erroMsg = String(erro.erro || '').replace(/"/g, '""');
      const sugestao = String(erro.sugestao || '').replace(/"/g, '""');
      
      linhas.push(`${erro.linha},"${erro.campo}","${valor}","${erroMsg}","${sugestao}"`);
    });
    
    return linhas.join('\n');
  }
}
