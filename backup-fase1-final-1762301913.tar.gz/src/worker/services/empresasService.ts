
import { BaseService } from './BaseService';
import type { Empresa, EmpresaConfig } from '../../shared/types';


export class EmpresasService extends BaseService<Empresa> {
  constructor(db: any) {
    super('empresas', db);
  }

  async getAtivas(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(`SELECT * FROM empresas WHERE deleted_at IS NULL AND ativa = 1 LIMIT ? OFFSET ?`)
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM empresas WHERE deleted_at IS NULL AND ativa = 1`)
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Empresa[]) || [],
      total: countResult?.total || 0,
    };
  }

  async create(data: CreateEmpresaInput): Promise<Empresa> {
    return super.create({ ...data, ativa: true });
  }

  async update(id: number, data: UpdateEmpresaInput): Promise<Empresa> {
    return super.update(id, data);
  }

  /**
   * Obter configuração da empresa
   */
  async getConfig(empresaId: number): Promise<EmpresaConfig> {
    const config = await this.db
      .prepare(`SELECT * FROM empresa_config WHERE empresa_id = ? AND deleted_at IS NULL`)
      .bind(empresaId)
      .first<EmpresaConfig>();

    if (!config) {
      // Retornar defaults se não existir
      return {
        empresa_id: empresaId,
        nome: '',
        cor_primaria: '#0066cc',
        cor_secundaria: '#333333',
      };
    }

    return config;
  }

  /**
   * Salvar configuração da empresa (INSERT ou UPDATE)
   */
  async saveConfig(empresaId: number, data: EmpresaConfigInput): Promise<EmpresaConfig> {
    const exists = await this.db
      .prepare(`SELECT id FROM empresa_config WHERE empresa_id = ? AND deleted_at IS NULL`)
      .bind(empresaId)
      .first<{ id: number }>();

    if (exists) {
      // UPDATE
      await this.db
        .prepare(`
          UPDATE empresa_config
          SET nome = ?, logo_url = ?, template_certificado = ?,
              cor_primaria = ?, cor_secundaria = ?,
              updated_at = CURRENT_TIMESTAMP
          WHERE empresa_id = ? AND deleted_at IS NULL
        `)
        .bind(
          data.nome,
          data.logo_url || null,
          data.template_certificado || null,
          data.cor_primaria,
          data.cor_secundaria,
          empresaId
        )
        .run();
    } else {
      // INSERT
      await this.db
        .prepare(`
          INSERT INTO empresa_config
          (empresa_id, nome, logo_url, template_certificado,
           cor_primaria, cor_secundaria, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `)
        .bind(
          empresaId,
          data.nome,
          data.logo_url || null,
          data.template_certificado || null,
          data.cor_primaria,
          data.cor_secundaria
        )
        .run();
    }

    return this.getConfig(empresaId);
  }
}
