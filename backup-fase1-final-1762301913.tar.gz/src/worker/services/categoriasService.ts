import { BaseService } from './BaseService';
import type { Categoria } from '../../shared/types';

export class CategoriasService extends BaseService<Categoria> {
  constructor(db: any) {
    super('categorias_qualificacoes', db);
  }

  async getAtivas(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(
        `SELECT * FROM categorias_qualificacoes WHERE deleted_at IS NULL AND ativo = 1 LIMIT ? OFFSET ?`,
      )
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(
        `SELECT COUNT(*) as total FROM categorias_qualificacoes WHERE deleted_at IS NULL AND ativo = 1`,
      )
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Categoria[]) || [],
      total: countResult?.total || 0,
    };
  }

  async create(data: CreateCategoriaInput): Promise<Categoria> {
    return super.create({ ...data, ativo: true });
  }

  async update(id: number, data: UpdateCategoriaInput): Promise<Categoria> {
    return super.update(id, data);
  }
}
