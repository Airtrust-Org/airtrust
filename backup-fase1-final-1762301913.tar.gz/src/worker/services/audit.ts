import { Context } from 'hono';
import { User, AuditLog, AcaoAuditoria, NivelCriticidade } from '../types/index';

export const logAudit = async (
  c: Context,
  acao: AcaoAuditoria | string,
  recurso: string,
  recurso_id?: string,
  dados_antes?: any,
  dados_depois?: any,
  resultado: 'SUCCESS' | 'FAILURE' | 'ERROR' = 'SUCCESS',
  duracao_ms?: number,
  nivel_criticidade: NivelCriticidade | string = 'MEDIO'
) => {
  try {
    const user = c.get('user') as User;
    const db = c.env.DB;
    
    if (!user || !db) {
      console.error('Missing user or database connection for audit log');
      return;
    }

    const auditData: Partial<AuditLog> = {
      usuario_id: user.id,
      usuario_nome: user.name,
      ip_address: c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || undefined,
      user_agent: c.req.header('User-Agent') || undefined,
      acao: acao as AcaoAuditoria,
      recurso,
      recurso_id,
      dados_antes: dados_antes ? JSON.stringify(dados_antes) : undefined,
      dados_depois: dados_depois ? JSON.stringify(dados_depois) : undefined,
      resultado: resultado as 'SUCCESS' | 'FAILURE' | 'ERROR',
      duracao_ms,
      nivel_criticidade: nivel_criticidade as NivelCriticidade
    };

    await db.prepare(`
      INSERT INTO auditoria_avancada_v2 (
        usuario_id, usuario_nome, ip_address, user_agent, acao, 
        recurso, recurso_id, dados_antes, dados_depois, resultado, 
        duracao_ms, nivel_criticidade
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      auditData.usuario_id,
      auditData.usuario_nome,
      auditData.ip_address || null,
      auditData.user_agent || null,
      auditData.acao,
      auditData.recurso,
      auditData.recurso_id || null,
      auditData.dados_antes || null,
      auditData.dados_depois || null,
      auditData.resultado,
      auditData.duracao_ms || null,
      auditData.nivel_criticidade
    ).run();

  } catch (error) {
    console.error('Failed to log audit:', error);
  }
};
