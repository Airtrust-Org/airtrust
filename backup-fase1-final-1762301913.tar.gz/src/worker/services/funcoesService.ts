
import { BaseService } from './BaseService';
import type { Funcao } from '../../shared/types';


export class FuncoesService extends BaseService<Funcao> {
  constructor(db: any) {
    super('funcoes', db);
  }

  async getAtivas(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(`SELECT * FROM funcoes WHERE deleted_at IS NULL AND ativa = 1 LIMIT ? OFFSET ?`)
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM funcoes WHERE deleted_at IS NULL AND ativa = 1`)
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Funcao[]) || [],
      total: countResult?.total || 0,
    };
  }

  async create(data: CreateFuncaoInput): Promise<Funcao> {
    return super.create({ ...data, ativa: true });
  }

  async update(id: number, data: UpdateFuncaoInput): Promise<Funcao> {
    return super.update(id, data);
  }
}
