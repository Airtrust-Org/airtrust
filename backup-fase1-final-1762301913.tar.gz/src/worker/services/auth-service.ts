import { Context } from 'hono';
import { sign, verify } from 'hono/jwt';
import { User, UserRole } from '../types/index';
import type { CloudflareD1Database } from '../types';
import { Logger } from '../utils/logger';
import { z } from 'zod';
import bcryptjs from 'bcryptjs';

/**
 * SECURITY NOTES:
 * - JWT_SECRET must be loaded from Env, never hardcoded
 * - Passwords hashed with bcryptjs (strong PBKDF2 equivalent)
 * - Token expiry set to 1 hour, refresh tokens for long sessions
 * - Rate limiting on login attempts (5 max per 15 min per IP)
 * - Constant-time password comparison to prevent timing attacks
 * - Audit logging for all auth events
 * - Email case-insensitive searches
 * - JWT algorithm explicitly specified (HS256)
 */

export interface JWTPayload extends Record<string, unknown> {
  sub: string; // user ID
  name: string;
  email: string;
  perfil: UserRole; // Updated to use UserRole instead of literal union
  funcionario_id?: number;
  iat: number;
  exp: number;
  alg: 'HS256'; // Explicit algorithm version
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResult {
  success: boolean;
  user?: User;
  token?: string;
  refreshToken?: string;
  expiresIn?: number;
  error?: string;
  code?: string;
}

// ===== RATE LIMITING FOR LOGIN ATTEMPTS =====
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

function checkLoginRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const key = `login:${ip}`;
  const existing = loginAttempts.get(key);

  if (!existing || now > existing.resetAt) {
    loginAttempts.set(key, {
      count: 1,
      resetAt: now + 15 * 60 * 1000 // 15 minutes
    });
    return { allowed: true };
  }

  if (existing.count >= 5) {
    const retryAfter = Math.ceil((existing.resetAt - now) / 1000);
    return { allowed: false, retryAfter };
  }

  existing.count++;
  return { allowed: true };
}

// ===== INPUT VALIDATION =====
const EmailSchema = z.string().email().toLowerCase();
const PasswordSchema = z.string().min(8).max(128);

export class AuthService {
  /**
   * Get JWT secret from environment (REQUIRED)
   */
  static getJWTSecret(env: any): string {
    const secret = env?.JWT_SECRET;
    
    if (!secret || secret.length < 32) {
      throw new Error('JWT_SECRET must be set in environment and be at least 32 characters');
    }
    
    return secret;
  }

  private static readonly TOKEN_EXPIRY = 60 * 60; // 1 hour in seconds (was 24 hours - too long!)
  private static readonly REFRESH_TOKEN_EXPIRY = 7 * 24 * 60 * 60; // 7 days

  /**
   * Autentica usuário com email/senha
   */
  static async authenticate(
    credentials: LoginCredentials,
    db: CloudflareD1Database,
    env: any,
    clientIp: string
  ): Promise<AuthResult> {
    try {
      // ===== RATE LIMITING =====
      const rateLimitResult = checkLoginRateLimit(clientIp);
      
      if (!rateLimitResult.allowed) {
        Logger.warn('Login rate limit exceeded', {
          ip: clientIp,
          retryAfter: rateLimitResult.retryAfter
        });
        
        return {
          success: false,
          error: 'Muitas tentativas de login. Tente novamente mais tarde',
          code: 'RATE_LIMIT_EXCEEDED',
          expiresIn: rateLimitResult.retryAfter
        };
      }

      // ===== INPUT VALIDATION =====
      try {
        EmailSchema.parse(credentials.email);
        PasswordSchema.parse(credentials.password);
      } catch (error) {
        Logger.warn('Invalid login credentials format', {
          email: credentials.email,
          ip: clientIp
        });
        
        return { success: false, error: 'Credenciais inválidas', code: 'INVALID_INPUT' };
      }

      const normalizedEmail = credentials.email.toLowerCase();

      // ===== FETCH USER (case-insensitive) =====
      const user = await db.prepare(`
        SELECT 
          u.id,
          u.name,
          u.email,
          u.password_hash,
          u.perfil,
          u.funcionario_id,
          u.active
        FROM usuarios u 
        WHERE LOWER(u.email) = ?
          AND u.active = 1
      `).bind(normalizedEmail).first() as any;

      if (!user) {
        // Audit: login attempt with non-existent user
        await this.auditAuthFailure(db, 'USER_NOT_FOUND', normalizedEmail, clientIp, 'User not found');
        
        Logger.warn('Login failed: user not found', {
          email: normalizedEmail,
          ip: clientIp
        });
        
        // Generic error to prevent user enumeration
        return { success: false, error: 'Credenciais inválidas', code: 'INVALID_CREDENTIALS' };
      }

      // ===== VERIFY PASSWORD (constant-time comparison) =====
      let isValidPassword = false;
      
      try {
        // Use bcryptjs for password verification
        isValidPassword = await bcryptjs.compare(credentials.password, user.password_hash);
      } catch (bcryptError) {
        Logger.error('Bcrypt verification error', bcryptError);
        
        await this.auditAuthFailure(db, 'PASSWORD_VERIFY_ERROR', normalizedEmail, clientIp, 'Password verification failed');
        
        return { success: false, error: 'Erro ao verificar senha', code: 'AUTH_ERROR' };
      }
      
      if (!isValidPassword) {
        // Audit: failed login attempt
        await this.auditAuthFailure(db, 'INVALID_PASSWORD', normalizedEmail, clientIp, 'Invalid password');
        
        Logger.warn('Login failed: invalid password', {
          email: normalizedEmail,
          ip: clientIp
        });
        
        // Generic error
        return { success: false, error: 'Credenciais inválidas', code: 'INVALID_CREDENTIALS' };
      }

      // ===== GENERATE JWT TOKEN =====
      const jwtSecret = this.getJWTSecret(env);
      const now = Math.floor(Date.now() / 1000);
      
      const payload: JWTPayload = {
        sub: user.id.toString(),
        name: user.name,
        email: user.email,
        perfil: user.perfil as UserRole,
        funcionario_id: user.funcionario_id,
        iat: now,
        exp: now + this.TOKEN_EXPIRY,
        alg: 'HS256'
      };

      const token = await sign(payload, jwtSecret);
      
      // Optional: Generate refresh token (can be stored in DB or as separate JWT)
      const refreshPayload: any = {
        sub: user.id.toString(),
        type: 'refresh',
        iat: now,
        exp: now + this.REFRESH_TOKEN_EXPIRY,
        alg: 'HS256'
      };
      
      const refreshToken = await sign(refreshPayload, jwtSecret);

      const authenticatedUser: User = {
        id: user.id,
        nome: user.name,
        name: user.name,
        email: user.email,
        perfil: user.perfil,
        funcionario_id: user.funcionario_id
      };

      // ===== AUDIT: SUCCESS =====
      try {
        await db.prepare(`
          INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
          VALUES ('LOGIN_SUCCESS', 'auth', ?, ?, 'MEDIUM')
        `).bind(
          user.id,
          JSON.stringify({
            email: normalizedEmail,
            ip: clientIp,
            timestamp: new Date().toISOString()
          })
        ).run();
      } catch (auditError) {
        Logger.error('Failed to log login success', auditError);
      }

      Logger.info('User authenticated successfully', {
        userId: user.id,
        email: normalizedEmail,
        ip: clientIp
      });

      return {
        success: true,
        user: authenticatedUser,
        token,
        refreshToken,
        expiresIn: this.TOKEN_EXPIRY
      };

    } catch (error) {
      Logger.error('Authentication error', error);
      
      return { 
        success: false, 
        error: 'Erro interno do servidor',
        code: 'INTERNAL_ERROR'
      };
    }
  }

  /**
   * Verifica e decodifica token JWT com validação de formato
   */
  static async verifyToken(token: string, env: any): Promise<{ valid: boolean; payload?: JWTPayload; error?: string }> {
    try {
      // ===== JWT FORMAT VALIDATION =====
      if (!token || typeof token !== 'string' || token.split('.').length !== 3) {
        return { valid: false, error: 'Invalid JWT format' };
      }

      const jwtSecret = this.getJWTSecret(env);
      const decoded = await verify(token, jwtSecret);
      const payload = decoded as unknown as JWTPayload;
      
      // ===== EXPIRY CHECK =====
      if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) {
        return { valid: false, error: 'Token expirado' };
      }

      // ===== ALGORITHM CHECK =====
      // Accept tokens that explicitly set alg in payload or omit it (alg is normally in JWT header).
      if (payload.alg && payload.alg !== 'HS256') {
        return { valid: false, error: 'Invalid algorithm' };
      }

      // ===== REQUIRED FIELDS CHECK =====
      // Accept either 'sub' (standard) or legacy 'id' claim as user identifier.
      const maybeSub = (payload as any).sub || (payload as any).id;
      if (!maybeSub || !payload.email || !payload.perfil) {
        return { valid: false, error: 'Invalid token payload' };
      }

      // Normalize payload.sub if only id was provided
      if (!(payload as any).sub && (payload as any).id) {
        (payload as any).sub = String((payload as any).id);
      }

      return { valid: true, payload };
    } catch (error) {
      Logger.debug('Token verification failed', { error: String(error) });
      return { valid: false, error: 'Token inválido ou expirado' };
    }
  }

  /**
   * Extrai usuário do token JWT
   */
  static async getUserFromToken(token: string, db: CloudflareD1Database, env: any): Promise<User | null> {
    const verification = await this.verifyToken(token, env);
    
    if (!verification.valid || !verification.payload) {
      return null;
    }

    try {
      const user = await db.prepare(`
        SELECT id, name, email, perfil, funcionario_id, active
        FROM usuarios 
        WHERE id = ? AND active = 1
      `).bind(parseInt(verification.payload.sub)).first() as any;

      if (!user) {
        return null;
      }

      return {
        id: user.id,
        nome: user.name,
        name: user.name,
        email: user.email,
        perfil: user.perfil,
        funcionario_id: user.funcionario_id
      };
    } catch (error) {
      Logger.error('Error fetching user from token', error);
      return null;
    }
  }

  /**
   * Hash de senha com bcryptjs (PBKDF2-like)
   */
  static async hashPassword(password: string): Promise<string> {
    try {
      // Salt rounds: 10-12 recommended (higher = slower but more secure)
      const salt = await bcryptjs.genSalt(12);
      const hash = await bcryptjs.hash(password, salt);
      return hash;
    } catch (error) {
      Logger.error('Error hashing password', error);
      throw error;
    }
  }

  /**
   * Verifica se usuário tem permissão para ação
   */
  static hasPermission(user: User, requiredRoles: string[]): boolean {
    if (!user.perfil || !requiredRoles || requiredRoles.length === 0) {
      return false;
    }
    
    return requiredRoles.includes(user.perfil);
  }

  /**
   * Middleware de autorização por papel
   */
  static requireRole(...roles: string[]) {
    return async (c: Context, next: () => Promise<void>) => {
      const user = c.get('user') as User | null;
      
      if (!user) {
        Logger.warn('Role check failed: user not authenticated', {
          path: c.req.path,
          requiredRoles: roles
        });
        
        return c.json({ 
          error: 'Não autenticado',
          code: 'UNAUTHORIZED'
        }, 401);
      }

      if (!this.hasPermission(user, roles)) {
        Logger.warn('Role check failed: insufficient permissions', {
          userId: user.id.toString(),
          userRole: user.perfil,
          requiredRoles: roles,
          path: c.req.path
        });
        
        return c.json({ 
          error: 'Acesso negado',
          code: 'FORBIDDEN'
        }, 403);
      }

      return await next();
    };
  }

  /**
   * Audit failure event
   */
  private static async auditAuthFailure(
    db: CloudflareD1Database,
    reason: string,
    email: string,
    ip: string,
    details: string
  ): Promise<void> {
    try {
      await db.prepare(`
        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
        VALUES ('LOGIN_FAILED', 'auth', ?, ?, 'HIGH')
      `).bind(
        0, // anonymous user
        JSON.stringify({
          reason,
          email,
          ip,
          details,
          timestamp: new Date().toISOString()
        })
      ).run();
    } catch (error) {
      Logger.error('Failed to audit auth failure', error);
    }
  }
}

