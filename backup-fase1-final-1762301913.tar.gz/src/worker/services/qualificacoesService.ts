import { BaseService } from './BaseService';
import type {
  Qualificacao,
  CreateQualificacaoInput,
  UpdateQualificacaoInput,
  D1Database,
} from '../types';

export class QualificacoesService extends BaseService<Qualificacao> {
  constructor(db: D1Database) {
    super('qualificacoes', db);
  }

  async getByCategoria(categoria: string, page: number = 1, limit: number = 50) {
    return this.getWithFilter({ categoria }, page, limit);
  }

  async getAtivas(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(
        `SELECT * FROM qualificacoes WHERE deleted_at IS NULL AND ativa = 1 LIMIT ? OFFSET ?`,
      )
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM qualificacoes WHERE deleted_at IS NULL AND ativa = 1`)
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Qualificacao[]) || [],
      total: countResult?.total || 0,
    };
  }

  async create(data: CreateQualificacaoInput): Promise<Qualificacao> {
    // Gerar string ID
    const maxIdResult = await this.db
      .prepare('SELECT MAX(CAST(id AS INTEGER)) as max_id FROM qualificacoes')
      .first<{ max_id: number | null }>();

    const nextId = ((maxIdResult?.max_id || 0) + 1).toString();

    const keys = Object.keys(data);
    const values = Object.values(data);
    const placeholders = keys.map(() => '?').join(',');
    const columns = keys.join(',');

    const query = `INSERT INTO qualificacoes (id, ${columns}, created_at, updated_at) VALUES (?, ${placeholders}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`;

    const result = await this.db
      .prepare(query)
      .bind(nextId, ...values)
      .run();

    if (!result.success) {
      throw new Error('Erro ao criar qualificação');
    }

    return this.getById(nextId);
  }

  async update(id: number, data: UpdateQualificacaoInput): Promise<Qualificacao> {
    return super.update(id, data as unknown as Record<string, unknown>);
  }
}
