
import { BaseService } from './BaseService';
import type { Simulador } from '../../shared/types';


export class SimuladoresService extends BaseService<Simulador> {
  constructor(db: any) {
    super('simuladores', db);
  }

  async getByEmpresa(empresaId: number, page: number = 1, limit: number = 50) {
    return this.getWithFilter({ empresa_id: empresaId }, page, limit);
  }

  async getAtivos(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(`SELECT * FROM simuladores WHERE deleted_at IS NULL AND ativo = 1 LIMIT ? OFFSET ?`)
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM simuladores WHERE deleted_at IS NULL AND ativo = 1`)
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Simulador[]) || [],
      total: countResult?.total || 0,
    };
  }

  async create(data: CreateSimuladorInput): Promise<Simulador> {
    return super.create({ ...data, ativo: true });
  }

  async update(id: number, data: UpdateSimuladorInput): Promise<Simulador> {
    return super.update(id, data);
  }
}
