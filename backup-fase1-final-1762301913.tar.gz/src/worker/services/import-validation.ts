/**
 * Serviço de Validação de Importações
 * Valida dados antes de importar para garantir integridade
 */

export interface ValidationError {
  linha: number;
  campo: string;
  valor: any;
  erro: string;
  sugestao?: string;
}

export interface ValidationResult {
  valido: boolean;
  erros: ValidationError[];
  avisos: string[];
  totalLinhas: number;
  linhasValidas: number;
}

export class ImportValidator {
  
  /**
   * Valida CPF (com ou sem máscara)
   */
  static validarCPF(cpf: string): boolean {
    if (!cpf) return false;
    
    const cpfLimpo = cpf.replace(/[^0-9]/g, '');
    
    if (cpfLimpo.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cpfLimpo)) return false; // CPFs com todos dígitos iguais
    
    let soma = 0;
    for (let i = 0; i < 9; i++) {
      soma += parseInt(cpfLimpo.charAt(i)) * (10 - i);
    }
    let resto = 11 - (soma % 11);
    let digito1 = resto >= 10 ? 0 : resto;
    
    if (digito1 !== parseInt(cpfLimpo.charAt(9))) return false;
    
    soma = 0;
    for (let i = 0; i < 10; i++) {
      soma += parseInt(cpfLimpo.charAt(i)) * (11 - i);
    }
    resto = 11 - (soma % 11);
    let digito2 = resto >= 10 ? 0 : resto;
    
    return digito2 === parseInt(cpfLimpo.charAt(10));
  }
  
  /**
   * Valida email
   */
  static validarEmail(email: string): boolean {
    if (!email) return false;
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }
  
  /**
   * Valida data (aceita DD/MM/YYYY, YYYY-MM-DD, ou número serial do Excel)
   */
  static validarData(data: any): { valido: boolean; dataFormatada?: string } {
    if (!data) return { valido: false };
    
    if (typeof data === 'number') {
      try {
        const date = new Date((data - 25569) * 86400 * 1000);
        if (isNaN(date.getTime())) return { valido: false };
        const year = date.getUTCFullYear();
        const month = String(date.getUTCMonth() + 1).padStart(2, '0');
        const day = String(date.getUTCDate()).padStart(2, '0');
        return { valido: true, dataFormatada: `${year}-${month}-${day}` };
      } catch {
        return { valido: false };
      }
    }
    
    const dataStr = String(data).trim();
    
    if (/^\d{4}-\d{2}-\d{2}$/.test(dataStr)) {
      const date = new Date(dataStr);
      if (!isNaN(date.getTime())) {
        return { valido: true, dataFormatada: dataStr };
      }
    }
    
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(dataStr)) {
      const [dia, mes, ano] = dataStr.split('/');
      const date = new Date(`${ano}-${mes}-${dia}`);
      if (!isNaN(date.getTime())) {
        return { valido: true, dataFormatada: `${ano}-${mes}-${dia}` };
      }
    }
    
    return { valido: false };
  }
  
  /**
   * Valida matrícula (não vazia, alfanumérica)
   */
  static validarMatricula(matricula: string): boolean {
    if (!matricula) return false;
    const matriculaStr = String(matricula).trim();
    return matriculaStr.length > 0 && /^[a-zA-Z0-9]+$/.test(matriculaStr);
  }
  
  /**
   * Valida funcionário completo
   */
  static validarFuncionario(funcionario: any, linha: number): ValidationError[] {
    const erros: ValidationError[] = [];
    
    if (!funcionario.nome || String(funcionario.nome).trim().length < 3) {
      erros.push({
        linha,
        campo: 'nome',
        valor: funcionario.nome,
        erro: 'Nome é obrigatório e deve ter no mínimo 3 caracteres',
        sugestao: 'Forneça o nome completo do funcionário'
      });
    }
    
    if (!funcionario.cpf || !this.validarCPF(funcionario.cpf)) {
      erros.push({
        linha,
        campo: 'cpf',
        valor: funcionario.cpf,
        erro: 'CPF inválido',
        sugestao: 'Forneça um CPF válido com 11 dígitos (com ou sem máscara)'
      });
    }
    
    if (funcionario.email && !this.validarEmail(funcionario.email)) {
      erros.push({
        linha,
        campo: 'email',
        valor: funcionario.email,
        erro: 'Email inválido',
        sugestao: 'Forneça um email válido (ex: nome@empresa.com)'
      });
    }
    
    if (funcionario.data_nascimento) {
      const validacao = this.validarData(funcionario.data_nascimento);
      if (!validacao.valido) {
        erros.push({
          linha,
          campo: 'data_nascimento',
          valor: funcionario.data_nascimento,
          erro: 'Data de nascimento inválida',
          sugestao: 'Use formato DD/MM/YYYY ou YYYY-MM-DD'
        });
      }
    }
    
    if (funcionario.data_admissao) {
      const validacao = this.validarData(funcionario.data_admissao);
      if (!validacao.valido) {
        erros.push({
          linha,
          campo: 'data_admissao',
          valor: funcionario.data_admissao,
          erro: 'Data de admissão inválida',
          sugestao: 'Use formato DD/MM/YYYY ou YYYY-MM-DD'
        });
      }
    }
    
    return erros;
  }
  
  /**
   * Valida qualificação completa
   */
  static validarQualificacao(qualificacao: any, linha: number): ValidationError[] {
    const erros: ValidationError[] = [];
    
    if (!qualificacao.cpf || !this.validarCPF(qualificacao.cpf)) {
      erros.push({
        linha,
        campo: 'cpf',
        valor: qualificacao.cpf,
        erro: 'CPF é obrigatório e deve ser válido',
        sugestao: 'Forneça um CPF válido do funcionário'
      });
    }
    
    const tiposValidos = ['TREINAMENTO', 'CHECK', 'EXAME', 'TREINAMENTOS', 'CHECKS', 'EXAMES'];
    const tipo = String(qualificacao.tipo || '').trim().toUpperCase();
    if (!tipo || !tiposValidos.includes(tipo)) {
      erros.push({
        linha,
        campo: 'tipo',
        valor: qualificacao.tipo,
        erro: 'Tipo é obrigatório e deve ser TREINAMENTO, CHECK ou EXAME',
        sugestao: 'Use um dos tipos válidos'
      });
    }
    
    if (!qualificacao.codigo || String(qualificacao.codigo).trim().length === 0) {
      erros.push({
        linha,
        campo: 'codigo',
        valor: qualificacao.codigo,
        erro: 'Código é obrigatório',
        sugestao: 'Forneça o código da qualificação (ex: CRM-2025, PC-A320)'
      });
    }
    
    if (!qualificacao.data_vencimento) {
      erros.push({
        linha,
        campo: 'data_vencimento',
        valor: qualificacao.data_vencimento,
        erro: 'Data de validade é obrigatória',
        sugestao: 'Forneça a data de vencimento da qualificação'
      });
    } else {
      const validacao = this.validarData(qualificacao.data_vencimento);
      if (!validacao.valido) {
        erros.push({
          linha,
          campo: 'data_vencimento',
          valor: qualificacao.data_vencimento,
          erro: 'Data de validade inválida',
          sugestao: 'Use formato DD/MM/YYYY ou YYYY-MM-DD'
        });
      }
    }
    
    return erros;
  }
  
  /**
   * Valida lote de funcionários
   */
  static validarLoteFuncionarios(funcionarios: any[]): ValidationResult {
    const erros: ValidationError[] = [];
    const avisos: string[] = [];
    
    funcionarios.forEach((func, index) => {
      const errosLinha = this.validarFuncionario(func, index + 2); // +2 porque linha 1 é header
      erros.push(...errosLinha);
    });
    
    const matriculas = new Set<string>();
    funcionarios.forEach((func, index) => {
      if (func.matricula) {
        const matricula = String(func.matricula).trim();
        if (matriculas.has(matricula)) {
          avisos.push(`Linha ${index + 2}: Matrícula ${matricula} duplicada no arquivo`);
        }
        matriculas.add(matricula);
      }
    });
    
    return {
      valido: erros.length === 0,
      erros,
      avisos,
      totalLinhas: funcionarios.length,
      linhasValidas: funcionarios.length - new Set(erros.map(e => e.linha)).size
    };
  }
  
  /**
   * Valida lote de qualificações
   */
  static validarLoteQualificacoes(qualificacoes: any[]): ValidationResult {
    const erros: ValidationError[] = [];
    const avisos: string[] = [];
    
    qualificacoes.forEach((qual, index) => {
      const errosLinha = this.validarQualificacao(qual, index + 2);
      erros.push(...errosLinha);
    });
    
    return {
      valido: erros.length === 0,
      erros,
      avisos,
      totalLinhas: qualificacoes.length,
      linhasValidas: qualificacoes.length - new Set(erros.map(e => e.linha)).size
    };
  }
}
