/**
 * Serviço de Geração de PDF para Certificados
 * Gera um PDF binário válido sem dependências externas
 */

export interface CertificadoData {
  funcionarioNome: string;
  funcionarioMatricula: string;
  qualificacaoNome: string;
  qualificacaoCodigo: string;
  dataConclusao: string;
  cargaHoraria: number;
}

export class PDFGenerator {
  /**
   * Gera um PDF binário válido de certificado
   */
  static gerarCertificadoSimples(dados: CertificadoData): Buffer {
    const pdfContent = this.criarPDFBinario(dados);
    return Buffer.from(pdfContent, 'latin1');
  }

  private static criarPDFBinario(dados: CertificadoData): string {
    const dataFormatada = this.formatarData(dados.dataConclusao);
    const dataEmissao = new Date().toLocaleDateString('pt-BR');

    // Conteúdo do stream (texto do certificado)
    const streamContent = `BT
/F1 28 Tf
150 750 Td
(CERTIFICADO) Tj
0 -60 Td
/F1 12 Tf
(Certificamos que) Tj
0 -30 Td
/F1 14 Tf
(${dados.funcionarioNome}) Tj
0 -30 Td
/F1 12 Tf
(concluiu com aproveitamento o treinamento em) Tj
0 -30 Td
/F1 14 Tf
(${dados.qualificacaoNome}) Tj
0 -30 Td
/F1 12 Tf
(Codigo: ${dados.qualificacaoCodigo}) Tj
0 -20 Td
(Matricula ANAC: ${dados.funcionarioMatricula}) Tj
0 -20 Td
(Carga Horaria: ${dados.cargaHoraria} horas) Tj
0 -20 Td
(Data de Conclusao: ${dataFormatada}) Tj
0 -40 Td
(Emitido em: ${dataEmissao}) Tj
0 -40 Td
(Valido conforme regulamentacao ANAC) Tj
ET`;

    const streamLength = streamContent.length;

    // Estrutura PDF completa
    const pdf = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources 4 0 R /MediaBox [0 0 612 792] /Contents 5 0 R >>
endobj
4 0 obj
<< /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >>
endobj
5 0 obj
<< /Length ${streamLength} >>
stream
${streamContent}
endstream
endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000214 00000 n 
0000000313 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
${313 + streamLength + 100}
%%EOF`;

    return pdf;
  }

  private static formatarData(data: string): string {
    try {
      const date = new Date(data);
      return date.toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
      });
    } catch {
      return data;
    }
  }
}

/**
 * Normaliza nome para uso em nomes de arquivo
 */
export function normalizarNome(texto: string): string {
  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

/**
 * Gera nome de arquivo para certificado
 */
export function gerarNomeArquivoCertificado(
  funcionario: string,
  _qualificacao: string,
  codigo: string,
  data: string
): string {
  const funcNorm = normalizarNome(funcionario);
  const dataNorm = data.replace(/[^0-9]/g, '');
  return `${funcNorm}-${codigo}-${dataNorm}.pdf`;
}
