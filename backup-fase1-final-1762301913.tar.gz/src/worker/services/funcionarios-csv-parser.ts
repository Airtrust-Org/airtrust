import { CSV_FIELD_MAPPING, CAMPOS_OBRIGATORIOS, CAMPOS_DATA, STATUS_MAPPING, STATUS_VALIDOS } from '../../shared/types';

export interface FuncionarioCSVResult {
  funcionarios: any[];
  erros: ImportError[];
  warnings: ImportWarning[];
  estatisticas: {
    total_linhas: number;
    funcionarios_validos: number;
    campos_mapeados: number;
    campos_nao_mapeados: string[];
  };
}

export interface ImportError {
  linha: number;
  funcionario?: string;
  matricula?: string;
  campo?: string;
  erro: string;
  dados_originais?: any;
}

export interface ImportWarning {
  linha: number;
  funcionario?: string;
  matricula?: string;
  campo: string;
  warning: string;
  valor_original?: string;
  valor_corrigido?: string;
}

export class FuncionariosCSVParser {
  
  /**
   * ✅ PARSER PRINCIPAL COM MAPEAMENTO INTELIGENTE DE HEADERS
   */
  static async parseCSVFuncionarios(csvText: string, batchId: string = generateBatchId(), db?: any): Promise<FuncionarioCSVResult> {
    
    const lines = csvText.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV deve conter pelo menos um header e uma linha de dados');
    }

    const headers = this.parseCSVLine(lines[0]).map(h => h.trim().toLowerCase());
    const mappedHeaders = this.mapHeaders(headers);
    

    const funcionarios: any[] = [];
    const erros: ImportError[] = [];
    const warnings: ImportWarning[] = [];
    const camposNaoMapeados = new Set<string>();

    for (let i = 1; i < lines.length; i++) {
      const lineNumber = i + 1;
      const line = lines[i].trim();
      
      if (!line) continue; // Skip empty lines
      
      try {
        const values = this.parseCSVLine(line);
        const rawData: any = {};
        
        headers.forEach((header, index) => {
          rawData[header] = values[index]?.trim() || '';
        });

        const result = await this.processFuncionario(rawData, mappedHeaders, lineNumber, batchId, db);
        
        if (result.funcionario) {
          if (result.aeronavesEncontradas && result.aeronavesEncontradas.length > 0) {
            result.funcionario.aeronavesQualificadas = result.aeronavesEncontradas;
          }
          funcionarios.push(result.funcionario);
        }
        
        erros.push(...result.erros);
        warnings.push(...result.warnings);
        result.camposNaoMapeados.forEach(campo => camposNaoMapeados.add(campo));
        
      } catch (error) {
        erros.push({
          linha: lineNumber,
          erro: `Erro ao processar linha: ${(error as Error).message}`,
          dados_originais: lines[i]
        });
      }
    }

    const estatisticas = {
      total_linhas: lines.length - 1,
      funcionarios_validos: funcionarios.length,
      campos_mapeados: Object.keys(mappedHeaders).length,
      campos_nao_mapeados: Array.from(camposNaoMapeados)
    };


    return { funcionarios, erros, warnings, estatisticas };
  }

  /**
   * ✅ MAPEAR HEADERS DO CSV PARA CAMPOS DO BANCO
   */
  private static mapHeaders(headers: string[]): Record<string, string> {
    const mapped: Record<string, string> = {};
    
    headers.forEach(header => {
      const normalizedHeader = header.toLowerCase().trim();
      
      if (CSV_FIELD_MAPPING[normalizedHeader]) {
        mapped[header] = CSV_FIELD_MAPPING[normalizedHeader];
        return;
      }
      
      const cleanHeader = normalizedHeader.replace(/[_\s-]/g, '');
      const matchingKey = Object.keys(CSV_FIELD_MAPPING).find(key => 
        key.replace(/[_\s-]/g, '') === cleanHeader
      );
      
      if (matchingKey) {
        mapped[header] = CSV_FIELD_MAPPING[matchingKey];
      }
    });

    return mapped;
  }

  /**
   * ✅ PROCESSAR UM FUNCIONÁRIO INDIVIDUAL COM LOOKUP DE AERONAVES
   */
  private static async processFuncionario(
    rawData: any, 
    mappedHeaders: Record<string, string>, 
    lineNumber: number,
    _batchId: string,
    db?: any
  ): Promise<{
    funcionario: any | null;
    erros: ImportError[];
    warnings: ImportWarning[];
    camposNaoMapeados: string[];
    aeronavesEncontradas?: number[];
  }> {
    const funcionario: any = {
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    const erros: ImportError[] = [];
    const warnings: ImportWarning[] = [];
    const camposNaoMapeados: string[] = [];
    let aeronavesEncontradas: number[] = [];

    Object.entries(rawData).forEach(([csvHeader, value]) => {
      const dbField = mappedHeaders[csvHeader];
      
      if (!dbField) {
        camposNaoMapeados.push(csvHeader);
        return;
      }
      
      const processedValue = this.processFieldValue(dbField, value as string, lineNumber);
      
      if (processedValue.warning) {
        warnings.push({
          linha: lineNumber,
          campo: dbField,
          warning: processedValue.warning,
          valor_original: value as string,
          valor_corrigido: processedValue.value
        });
      }
      
      funcionario[dbField] = processedValue.value;
    });

    if (funcionario.anv && db) {
      try {
        const anvInput = funcionario.anv.trim().toUpperCase();
        
        const aeronaveResult = await db.prepare(`
          SELECT id, codigo, nome FROM aeronaves 
          WHERE UPPER(TRIM(codigo)) = ? OR UPPER(TRIM(nome)) LIKE ?
          AND ativo = 1
        `).bind(anvInput, `%${anvInput}%`).all();

        if (aeronaveResult && aeronaveResult.results && aeronaveResult.results.length > 0) {
          aeronavesEncontradas = aeronaveResult.results.map((a: any) => a.id);
          
          warnings.push({
            linha: lineNumber,
            funcionario: funcionario.nome,
            matricula: funcionario.matricula,
            campo: 'anv',
            warning: `Aeronave(s) encontrada(s): ${aeronaveResult.results.map((a: any) => `${a.codigo} (${a.nome})`).join(', ')}`,
            valor_original: anvInput
          });
        } else {
          warnings.push({
            linha: lineNumber,
            funcionario: funcionario.nome,
            matricula: funcionario.matricula,
            campo: 'anv',
            warning: `Aeronave não encontrada para código/nome: '${anvInput}'. Funcionário criado sem associação de aeronave.`,
            valor_original: anvInput
          });
        }
      } catch (error) {
        console.error(`❌ Erro ao buscar aeronave para ANV '${funcionario.anv}':`, error);
        warnings.push({
          linha: lineNumber,
          funcionario: funcionario.nome,
          matricula: funcionario.matricula,
          campo: 'anv',
          warning: `Erro ao buscar aeronave: ${(error as Error).message}`,
          valor_original: funcionario.anv
        });
      }
    }

    const missingFields = CAMPOS_OBRIGATORIOS.filter(field => !funcionario[field]?.trim());
    
    if (missingFields.length > 0) {
      erros.push({
        linha: lineNumber,
        funcionario: funcionario.nome,
        matricula: funcionario.matricula,
        erro: `Campos obrigatórios ausentes: ${missingFields.join(', ')}`,
        dados_originais: rawData
      });
      return { funcionario: null, erros, warnings, camposNaoMapeados, aeronavesEncontradas };
    }

    return { funcionario, erros, warnings, camposNaoMapeados, aeronavesEncontradas };
  }

  /**
   * ✅ PROCESSAR VALOR DE CAMPO COM VALIDAÇÃO E CONVERSÃO
   */
  private static processFieldValue(field: string, value: string, _lineNumber: number): {
    value: any;
    warning?: string;
  } {
    const trimmedValue = value?.trim() || '';
    
    if (!trimmedValue) {
      return { value: null };
    }

    if (CAMPOS_DATA.includes(field)) {
      const dateResult = this.processDateField(trimmedValue);
      if (dateResult.warning) {
        return { value: dateResult.value, warning: `Data inválida convertida: ${dateResult.warning}` };
      }
      return { value: dateResult.value };
    }

    if (field === 'status') {
      const normalizedStatus = trimmedValue.toLowerCase();
      const mappedStatus = STATUS_MAPPING[normalizedStatus];
      
      if (mappedStatus) {
        return { 
          value: mappedStatus, 
          warning: mappedStatus !== trimmedValue ? `Status normalizado de '${trimmedValue}' para '${mappedStatus}'` : undefined 
        };
      }
      
      if (!STATUS_VALIDOS.includes(trimmedValue.toUpperCase())) {
        return { 
          value: 'ATIVO', 
          warning: `Status inválido '${trimmedValue}', definido como 'ATIVO'` 
        };
      }
    }

    if (field === 'is_instrutor' || field === 'is_checador') {
      const boolValue = this.processBooleanField(trimmedValue);
      return { value: boolValue.value, warning: boolValue.warning };
    }

    return { value: trimmedValue };
  }

  /**
   * ✅ PROCESSAR CAMPOS DE DATA COM MÚLTIPLOS FORMATOS
   */
  private static processDateField(value: string): { value: string | null; warning?: string } {
    if (!value?.trim()) return { value: null };

    const formats = [
      /^\d{4}-\d{2}-\d{2}$/,     // YYYY-MM-DD (ISO)
      /^\d{2}\/\d{2}\/\d{4}$/,   // DD/MM/YYYY (Brazilian)
      /^\d{2}-\d{2}-\d{4}$/,     // DD-MM-YYYY
      /^\d{4}\/\d{2}\/\d{2}$/,   // YYYY/MM/DD
    ];

    const trimmed = value.trim();

    if (formats[0].test(trimmed)) {
      const date = new Date(trimmed);
      return date.getTime() ? { value: trimmed } : { value: null, warning: `Data inválida: ${trimmed}` };
    }

    if (formats[1].test(trimmed)) {
      const [day, month, year] = trimmed.split('/');
      const isoDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
      const date = new Date(isoDate);
      return date.getTime() ? 
        { value: isoDate, warning: `Convertido de ${trimmed} para ${isoDate}` } : 
        { value: null, warning: `Data inválida: ${trimmed}` };
    }

    if (formats[2].test(trimmed)) {
      const [day, month, year] = trimmed.split('-');
      const isoDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
      const date = new Date(isoDate);
      return date.getTime() ? 
        { value: isoDate, warning: `Convertido de ${trimmed} para ${isoDate}` } : 
        { value: null, warning: `Data inválida: ${trimmed}` };
    }

    return { value: null, warning: `Formato de data não reconhecido: ${trimmed}` };
  }

  /**
   * ✅ PROCESSAR CAMPOS BOOLEANOS
   */
  private static processBooleanField(value: string): { value: number; warning?: string } {
    const trimmed = value.toLowerCase().trim();
    const trueValues = ['sim', 'yes', '1', 'true', 'verdadeiro', 's', 'y'];
    const falseValues = ['não', 'nao', 'no', '0', 'false', 'falso', 'n'];

    if (trueValues.includes(trimmed)) {
      return { value: 1 };
    }
    
    if (falseValues.includes(trimmed)) {
      return { value: 0 };
    }

    return { value: 0, warning: `Valor booleano não reconhecido '${value}', definido como false` };
  }

  /**
   * ✅ PARSE CSV LINE COM TRATAMENTO DE ASPAS
   */
  private static parseCSVLine(line: string): string[] {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result.map(item => item.replace(/^"/, '').replace(/"$/, ''));
  }
}

/**
 * ✅ GERAR ID ÚNICO PARA BATCH
 */
function generateBatchId(): string {
  return `BATCH_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export { generateBatchId };
