/**
 * Serviço de Geração de IDs de Certificação
 * Formato: {MATRÍCULA}-{CÓDIGO}-{ANO}-{SEQUENCIAL}
 * Exemplo: 00074-SGV-2024-01
 */

/**
 * Gera o próximo ID de certificação no formato correto
 * @param colaboradorId ID do funcionário
 * @param treinamentoId ID do treinamento
 * @param dataConclusao Data de conclusão (formato: YYYY-MM-DD)
 * @param db Instância do D1Database
 * @returns ID formatado: 00074-SGV-2024-01
 */
export async function gerarProximoIdCertificacao(
  colaboradorId: number,
  treinamentoId: number,
  dataConclusao: string,
  db: D1Database
): Promise<string> {
  try {
    
    const funcionario = await db.prepare(
      'SELECT matricula FROM funcionarios WHERE id = ? AND deleted_at IS NULL'
    ).bind(colaboradorId).first();
    
    if (!funcionario) {
      throw new Error(`Funcionário ${colaboradorId} não encontrado`);
    }
    
    
    const treinamento = await db.prepare(
      'SELECT codigo FROM catalogo_treinamentos_v2 WHERE id = ? AND deleted_at IS NULL'
    ).bind(treinamentoId).first();
    
    if (!treinamento) {
      throw new Error(`Treinamento ${treinamentoId} não encontrado`);
    }
    
    
    const ano = dataConclusao.split('-')[0];
    
    const ultimaCert = await db.prepare(`
      SELECT certificacao_id FROM historico_certificacoes_v2 
      WHERE (funcionario_id = ? OR colaborador_id = ?)
      AND treinamento_id = ? 
      AND data_conclusao LIKE ? || '%'
      AND deleted_at IS NULL
      AND certificacao_id IS NOT NULL
      ORDER BY certificacao_id DESC LIMIT 1
    `).bind(colaboradorId, colaboradorId, treinamentoId, ano).first();
    
    let sequencial = 1;
    if (ultimaCert && ultimaCert.certificacao_id) {
      const partes = (ultimaCert.certificacao_id as string).split('-');
      if (partes.length >= 4) {
        sequencial = parseInt(partes[3] || '0', 10) + 1;
      }
    } else {
    }
    
    const matriculaFormatada = String(funcionario.matricula).padStart(5, '0');
    const sequencialFormatado = String(sequencial).padStart(2, '0');
    
    const idGerado = `${matriculaFormatada}-${treinamento.codigo}-${ano}-${sequencialFormatado}`;
    
    
    return idGerado;
    
  } catch (error: any) {
    console.error('❌ Erro ao gerar ID de certificação:', error);
    throw new Error(`Erro ao gerar ID de certificação: ${error.message}`);
  }
}

/**
 * Valida se um ID de certificação está no formato correto
 * @param id ID a ser validado
 * @returns true se válido, false caso contrário
 */
export function validarFormatoIdCertificacao(id: string): boolean {
  const regex = /^\d{5}-[A-Z0-9]+-\d{4}-\d{2}$/;
  return regex.test(id);
}

/**
 * Extrai informações de um ID de certificação
 * @param id ID no formato 00074-SGV-2024-01
 * @returns Objeto com matrícula, código, ano e sequencial
 */
export function parseIdCertificacao(id: string): {
  matricula: string;
  codigo: string;
  ano: string;
  sequencial: string;
} | null {
  if (!validarFormatoIdCertificacao(id)) {
    return null;
  }
  
  const partes = id.split('-');
  return {
    matricula: partes[0],
    codigo: partes[1],
    ano: partes[2],
    sequencial: partes[3]
  };
}
