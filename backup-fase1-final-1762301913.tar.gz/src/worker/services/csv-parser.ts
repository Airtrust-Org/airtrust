export class CSVParser {
  static parseCSV(csvText: string): any[] {
    const lines = csvText.trim().split('\n');
    if (lines.length === 0) {
      throw new Error('CSV está vazio');
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = [];


    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.trim()) continue; // Pular linhas vazias

      const values = this.parseCSVLine(line);
      const row: any = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index]?.trim().replace(/"/g, '') || '';
      });
      
      data.push(row);
    }

    return data;
  }

  private static parseCSVLine(line: string): string[] {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }

  static validateCatalogCSV(data: any[]): { valid: boolean, errors: string[] } {
    const errors: string[] = [];
    const requiredFields = ['codigo', 'nome', 'categoria'];
    const validCategories = ['INICIAL', 'RECORRENTE', 'ESPECIFICO', 'REGULATORIO', 'LICENCA_MEDICA', 'PROFICIENCIA'];

    if (data.length === 0) {
      errors.push('CSV não contém dados válidos');
      return { valid: false, errors };
    }

    data.forEach((row, index) => {
      const lineNumber = index + 2; // +2 porque linha 1 são headers

      requiredFields.forEach(field => {
        if (!row[field] || row[field].trim() === '') {
          errors.push(`Linha ${lineNumber}: Campo '${field}' obrigatório`);
        }
      });

      if (row.categoria && !validCategories.includes(row.categoria.toUpperCase())) {
        errors.push(`Linha ${lineNumber}: Categoria '${row.categoria}' inválida. Valores permitidos: ${validCategories.join(', ')}`);
      }

      if (row.periodicidade_meses && isNaN(parseInt(row.periodicidade_meses))) {
        errors.push(`Linha ${lineNumber}: Periodicidade deve ser um número`);
      }

      if (row.nota_minima && (isNaN(parseFloat(row.nota_minima)) || parseFloat(row.nota_minima) < 0 || parseFloat(row.nota_minima) > 10)) {
        errors.push(`Linha ${lineNumber}: Nota mínima deve ser um número entre 0 e 10`);
      }

      if (row.carga_horaria && isNaN(parseInt(row.carga_horaria))) {
        errors.push(`Linha ${lineNumber}: Carga horária deve ser um número`);
      }
    });

    return { valid: errors.length === 0, errors };
  }

  static validateCertificacoesCSV(data: any[]): { valid: boolean, errors: string[] } {
    const errors: string[] = [];
    const requiredFields = ['funcionario_matricula', 'treinamento_codigo', 'data_conclusao'];

    if (data.length === 0) {
      errors.push('CSV não contém dados válidos');
      return { valid: false, errors };
    }

    data.forEach((row, index) => {
      const lineNumber = index + 2; // +2 porque linha 1 são headers

      requiredFields.forEach(field => {
        if (!row[field] || row[field].trim() === '') {
          errors.push(`Linha ${lineNumber}: Campo '${field}' obrigatório`);
        }
      });

      if (row.data_conclusao && !this.isValidDate(row.data_conclusao)) {
        if (this.detectOldDateFormat(row.data_conclusao)) {
          errors.push(`Linha ${lineNumber}: Data de conclusão no formato antigo (${row.data_conclusao}). Use formato brasileiro DD/MM/AAAA`);
        } else {
          errors.push(`Linha ${lineNumber}: Data de conclusão inválida. Use formato DD/MM/AAAA (ex: 20/08/2025)`);
        }
      }

      if (row.data_vencimento && row.data_vencimento.trim() && !this.isValidDate(row.data_vencimento)) {
        if (this.detectOldDateFormat(row.data_vencimento)) {
          errors.push(`Linha ${lineNumber}: Data de vencimento no formato antigo (${row.data_vencimento}). Use formato brasileiro DD/MM/AAAA`);
        } else {
          errors.push(`Linha ${lineNumber}: Data de vencimento inválida. Use formato DD/MM/AAAA (ex: 19/09/2026)`);
        }
      }

      if (row.nota && row.nota.trim() && (isNaN(parseFloat(row.nota)) || parseFloat(row.nota) < 0 || parseFloat(row.nota) > 10)) {
        errors.push(`Linha ${lineNumber}: Nota final deve ser um número entre 0 e 10`);
      }
    });

    return { valid: errors.length === 0, errors };
  }

  private static isValidDate(dateString: string): boolean {
    const regexBrasil = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!regexBrasil.test(dateString)) return false;
    
    const [day, month, year] = dateString.split('/').map(Number);
    const date = new Date(year, month - 1, day);
    
    return date instanceof Date && 
           !isNaN(date.getTime()) &&
           date.getDate() === day &&
           date.getMonth() === month - 1 &&
           date.getFullYear() === year;
  }

  static convertBrazilianDateToISO(brazilianDate: string): string {
    if (!brazilianDate || brazilianDate.trim() === '') return '';
    
    const regexBrasil = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!regexBrasil.test(brazilianDate)) {
      throw new Error(`Data inválida: ${brazilianDate}. Use formato DD/MM/AAAA`);
    }
    
    const [day, month, year] = brazilianDate.split('/');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  static detectOldDateFormat(dateString: string): boolean {
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    return regexISO.test(dateString);
  }

  static generateSample(type: 'catalogo' | 'certificacoes'): string {
    if (type === 'catalogo') {
      return `codigo,nome,categoria,periodicidade_meses,nota_minima,carga_horaria,instrutor_obrigatorio,descricao
TRN-001,Nome do Treinamento,CATEGORIA,12,7.0,8,true,Descrição do treinamento`;
    } else {
      return `funcionario_matricula,treinamento_codigo,data_conclusao,data_vencimento,instrutor,nota,observacoes
00300,CMA-001,20/08/2025,19/09/2026,João Silva,8.5,Certificação médica aprovada
00301,ICAO-001,17/09/2025,16/09/2026,Maria Santos,9.0,Proficiência linguística excelente
00302,SGS-001,15/08/2025,14/02/2026,Pedro Costa,7.5,Treinamento de segurança concluído`;
    }
  }
}
