import { BaseService } from './BaseService';
import { EmpresasConfigService } from './empresasConfigService';
import { PdfGenerator } from '../utils/pdfGenerator';
import { R2Service } from '../utils/r2Service';
import type { Certificado } from '../../shared/types';
import type { PdfGeneratorData } from '../utils/pdfGenerator';
import { CreateCertificadoInput } from '../dtos/certificados';
import type { Env } from '../types/index';
import type { D1Database } from '@cloudflare/workers-types';

export class CertificadosService extends BaseService<Certificado> {
  private env: Env | undefined;

  constructor(db: D1Database, env?: Env) {
    super('certificados', db);
    this.env = env;
  }

  /**
   * Gerar novo certificado com integração de logo
   */
  async gerar(dados: {
    habilitacao_id: string | number;
    empresa_id: number;
    funcionario_id: number;
    qualificacao_id?: number;
  }): Promise<Certificado> {
    // Gerar número único
    const numero = this.gerarNumeroCertificado(dados.empresa_id);

    // Obter configurações da empresa (logo, cores)
    const configService = new EmpresasConfigService(this.db);
    const config = await configService.getByEmpresaId(dados.empresa_id);

    // Criar certificado
    const certificado = await this.create({
      habilitacao_id: dados.habilitacao_id,
      empresa_id: dados.empresa_id,
      funcionario_id: dados.funcionario_id,
      qualificacao_id: dados.qualificacao_id,
      numero_certificado: numero,
      logo_url: config?.logo_url,
      template_tipo: config?.template_certificado || 'default',
      cor_primaria: config?.cor_primaria,
      cor_secundaria: config?.cor_secundaria,
      data_emissao: new Date().toISOString().split('T')[0],
      status: 'ativo',
      titulo: 'Certificado',
    } as CreateCertificadoInput);

    return certificado;
  }

  /**
   * Gerar número único de certificado
   */
  private gerarNumeroCertificado(empresa_id: number): string {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 7).toUpperCase();
    return `CERT-${empresa_id}-${timestamp}-${random}`;
  }

  /**
   * Listar por funcionário
   */
  async getByFuncionario(funcionarioId: number, page: number = 1, limit: number = 50) {
    return this.getWithFilter({ funcionario_id: funcionarioId }, page, limit);
  }

  /**
   * Listar por habilitação
   */
  async getByHabilitacao(habilitacaoId: string | number) {
    return this.getWithFilter({ habilitacao_id: habilitacaoId });
  }

  /**
   * Listar por qualificação
   */
  async getByQualificacao(qualificacaoId: number, page: number = 1, limit: number = 50) {
    return this.getWithFilter({ qualificacao_id: qualificacaoId }, page, limit);
  }

  /**
   * Revogar certificado
   */
  async revogar(id: number): Promise<void> {
    await this.update(id, {
      status: 'revogado',
      updated_at: new Date().toISOString(),
    } as Record<string, unknown>);
  }

  async create(data: CreateCertificadoInput): Promise<Certificado> {
    return super.create(data);
  }

  /**
   * Gerar PDF do certificado
   */
  private async gerarPDF(dados: PdfGeneratorData): Promise<Buffer> {
    const html = await PdfGenerator.gerarCertificadoHtml(dados);
    const buffer = await PdfGenerator.htmlToPdf(html);
    return buffer;
  }

  /**
   * Salvar PDF em R2
   */
  private async salvarR2(key: string, buffer: Buffer): Promise<string> {
    if (!this.env) {
      throw new Error('Environment não configurado');
    }

    const r2 = new R2Service(this.env);
    const url = await r2.uploadPdf(key, buffer, {
      'content-description': `Certificado gerado em ${new Date().toISOString()}`,
    });

    return url;
  }

  /**
   * Gerar e salvar certificado com PDF
   */
  async gerarComPDF(dados: {
    habilitacao_id: string | number;
    empresa_id: number;
    funcionario_id: number;
    qualificacao_id?: number;
  }): Promise<Certificado & { pdf_url?: string }> {
    // Carregar dados necessários
    const funcionario = await this.db
      .prepare('SELECT nome FROM funcionarios WHERE id = ? AND deleted_at IS NULL')
      .bind(dados.funcionario_id)
      .first();

    const habilitacao = await this.db
      .prepare(
        'SELECT data_conclusao, data_vencimento FROM habilitacoes WHERE id = ? AND deleted_at IS NULL',
      )
      .bind(dados.habilitacao_id)
      .first();

    const qualificacao = dados.qualificacao_id
      ? await this.db
          .prepare('SELECT nome FROM qualificacoes WHERE id = ? AND deleted_at IS NULL')
          .bind(dados.qualificacao_id)
          .first()
      : null;

    const configService = new EmpresasConfigService(this.db);
    const config = await configService.getByEmpresaId(dados.empresa_id);

    if (!funcionario || !habilitacao) {
      throw new Error('Dados incompletos para gerar certificado');
    }

    // Gerar PDF
    const pdfData: PdfGeneratorData = {
      funcionario_nome: (funcionario as Record<string, unknown>).nome as string,
      qualificacao_nome:
        ((qualificacao as Record<string, unknown>)?.nome as string) || 'Certificado de Habilitação',
      data_conclusao: (habilitacao as Record<string, unknown>).data_conclusao as string,
      data_vencimento: (habilitacao as Record<string, unknown>).data_vencimento as string,
      empresa_logo_url: config?.logo_url,
      cor_primaria: config?.cor_primaria || '#0066cc',
      cor_secundaria: config?.cor_secundaria || '#333333',
    };

    const pdfBuffer = await this.gerarPDF(pdfData);

    // Salvar em R2
    const r2Key = `certificados/CERT-${dados.empresa_id}-${dados.habilitacao_id}-${Date.now()}.pdf`;
    const pdfUrl = this.env ? await this.salvarR2(r2Key, pdfBuffer) : undefined;

    // Criar certificado no BD
    const certificado = await this.create({
      habilitacao_id: dados.habilitacao_id,
      empresa_id: dados.empresa_id,
      funcionario_id: dados.funcionario_id,
      qualificacao_id: dados.qualificacao_id,
      titulo: `Certificado de ${(qualificacao as Record<string, unknown>)?.nome || 'Habilitação'}`,
      data_emissao: new Date().toISOString().split('T')[0],
    } as CreateCertificadoInput);

    return { ...certificado, pdf_url: pdfUrl };
  }
}
