/**
 * Parser Multi-Formato para Importação
 * Suporta: CSV, XLSX, e dados colados (TSV/JSON)
 * AirTrust v2 - Outubro 2025
 */

import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export type FormatoImportacao = 'csv' | 'xlsx' | 'tsv' | 'json';

export interface ResultadoParse {
  sucesso: boolean;
  dados: any[];
  formato: FormatoImportacao;
  erro?: string;
  linhasProcessadas: number;
}

/**
 * Detecta formato automaticamente baseado no conteúdo
 */
function detectarFormato(conteudo: string, contentType?: string): FormatoImportacao {
  if (contentType) {
    if (contentType.includes('text/csv')) return 'csv';
    if (contentType.includes('application/vnd.openxmlformats') || 
        contentType.includes('application/vnd.ms-excel')) return 'xlsx';
    if (contentType.includes('application/json')) return 'json';
  }

  const primeirasLinhas = conteudo.trim().split('\n').slice(0, 3).join('\n');

  if (primeirasLinhas.startsWith('[') || primeirasLinhas.startsWith('{')) {
    try {
      JSON.parse(conteudo);
      return 'json';
    } catch {
    }
  }

  if (primeirasLinhas.includes('\t')) {
    const tabs = (primeirasLinhas.match(/\t/g) || []).length;
    const virgulas = (primeirasLinhas.match(/,/g) || []).length;
    if (tabs > virgulas) return 'tsv';
  }

  return 'csv';
}

/**
 * Parse CSV
 */
function parseCSV(conteudo: string): ResultadoParse {
  try {
    conteudo = conteudo.replace(/^\uFEFF/, '');

    const resultado = Papa.parse(conteudo, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header: string) => header.trim().toLowerCase(),
      transform: (value: string) => value.trim()
    });

    if (resultado.errors.length > 0) {
      return {
        sucesso: false,
        dados: [],
        formato: 'csv',
        erro: `Erros no CSV: ${resultado.errors.map(e => e.message).join(', ')}`,
        linhasProcessadas: 0
      };
    }

    return {
      sucesso: true,
      dados: resultado.data,
      formato: 'csv',
      linhasProcessadas: resultado.data.length
    };
  } catch (error: any) {
    return {
      sucesso: false,
      dados: [],
      formato: 'csv',
      erro: error.message,
      linhasProcessadas: 0
    };
  }
}

/**
 * Parse TSV (dados colados do Excel)
 */
function parseTSV(conteudo: string): ResultadoParse {
  try {
    conteudo = conteudo.replace(/^\uFEFF/, '');

    const resultado = Papa.parse(conteudo, {
      header: true,
      skipEmptyLines: true,
      delimiter: '\t',
      transformHeader: (header: string) => header.trim().toLowerCase(),
      transform: (value: string) => value.trim()
    });

    if (resultado.errors.length > 0) {
      return {
        sucesso: false,
        dados: [],
        formato: 'tsv',
        erro: `Erros no TSV: ${resultado.errors.map(e => e.message).join(', ')}`,
        linhasProcessadas: 0
      };
    }

    return {
      sucesso: true,
      dados: resultado.data,
      formato: 'tsv',
      linhasProcessadas: resultado.data.length
    };
  } catch (error: any) {
    return {
      sucesso: false,
      dados: [],
      formato: 'tsv',
      erro: error.message,
      linhasProcessadas: 0
    };
  }
}

/**
 * Parse XLSX
 */
function parseXLSX(buffer: ArrayBuffer): ResultadoParse {
  try {
    const workbook = XLSX.read(buffer, { type: 'array' });
    
    if (workbook.SheetNames.length === 0) {
      return {
        sucesso: false,
        dados: [],
        formato: 'xlsx',
        erro: 'Arquivo Excel sem planilhas',
        linhasProcessadas: 0
      };
    }

    const primeiraAba = workbook.Sheets[workbook.SheetNames[0]];
    const dados = XLSX.utils.sheet_to_json(primeiraAba, {
      raw: false,
      defval: ''
    });

    const dadosNormalizados = dados.map((linha: any) => {
      const linhaNormalizada: any = {};
      for (const key in linha) {
        linhaNormalizada[key.toLowerCase().trim()] = linha[key];
      }
      return linhaNormalizada;
    });

    return {
      sucesso: true,
      dados: dadosNormalizados,
      formato: 'xlsx',
      linhasProcessadas: dadosNormalizados.length
    };
  } catch (error: any) {
    return {
      sucesso: false,
      dados: [],
      formato: 'xlsx',
      erro: error.message,
      linhasProcessadas: 0
    };
  }
}

/**
 * Parse JSON
 */
function parseJSON(conteudo: string): ResultadoParse {
  try {
    const dados = JSON.parse(conteudo);
    
    if (!Array.isArray(dados)) {
      return {
        sucesso: false,
        dados: [],
        formato: 'json',
        erro: 'JSON deve ser um array de objetos',
        linhasProcessadas: 0
      };
    }

    const dadosNormalizados = dados.map((linha: any) => {
      const linhaNormalizada: any = {};
      for (const key in linha) {
        linhaNormalizada[key.toLowerCase().trim()] = linha[key];
      }
      return linhaNormalizada;
    });

    return {
      sucesso: true,
      dados: dadosNormalizados,
      formato: 'json',
      linhasProcessadas: dadosNormalizados.length
    };
  } catch (error: any) {
    return {
      sucesso: false,
      dados: [],
      formato: 'json',
      erro: error.message,
      linhasProcessadas: 0
    };
  }
}

/**
 * Parser principal - detecta formato e processa
 */
export async function parseImportacao(
  conteudo: string | ArrayBuffer,
  contentType?: string
): Promise<ResultadoParse> {
  if (conteudo instanceof ArrayBuffer) {
    return parseXLSX(conteudo);
  }

  const formato = detectarFormato(conteudo, contentType);

  switch (formato) {
    case 'csv':
      return parseCSV(conteudo);
    
    case 'tsv':
      return parseTSV(conteudo);
    
    case 'json':
      return parseJSON(conteudo);
    
    case 'xlsx':
      const encoder = new TextEncoder();
      const buffer = encoder.encode(conteudo);
      return parseXLSX(buffer.buffer);
    
    default:
      return {
        sucesso: false,
        dados: [],
        formato: 'csv',
        erro: 'Formato não suportado',
        linhasProcessadas: 0
      };
  }
}

/**
 * Validar headers obrigatórios
 */
export function validarHeaders(dados: any[]): { valido: boolean; erro?: string; faltantes?: string[] } {
  if (dados.length === 0) {
    return { valido: false, erro: 'Nenhum dado para validar' };
  }

  const primeiraLinha = dados[0];
  const headersEncontrados = Object.keys(primeiraLinha).map(h => h.toLowerCase().trim());

  const obrigatorios = ['nome', 'email', 'funcao'];
  const faltantes = obrigatorios.filter(h => !headersEncontrados.includes(h));

  if (faltantes.length > 0) {
    return {
      valido: false,
      erro: `Colunas obrigatórias faltando: ${faltantes.join(', ')}`,
      faltantes
    };
  }

  return { valido: true };
}

/**
 * Normalizar nomes de colunas (aliases)
 */
export function normalizarColunas(dados: any[]): any[] {
  const aliases: Record<string, string> = {
    'nome_completo': 'nome',
    'funcionario': 'nome',
    
    'cargo': 'funcao',
    'funcao_exercida': 'funcao',
    
    'e-mail': 'email',
    'e_mail': 'email',
    
    'fone': 'telefone',
    'celular': 'telefone',
    
    'documento': 'cpf',
    
    'anac': 'codigo_anac',
    'codigo_anac': 'codigo_anac',
    'canac': 'codigo_anac',
    
    'mat': 'matricula',
    'registro': 'matricula',
    
    'data_nasc': 'data_nascimento',
    'nascimento': 'data_nascimento',
    'admissao': 'data_admissao',
    
    'cma': 'cma_numero',
    'validade_cma': 'cma_datavencimento',
    'aso': 'aso_numero',
    'validade_aso': 'aso_datavencimento',
    'icao': 'nivel_icao',
    'validade_icao': 'nivel_icao_datavencimento',
    
    'aeronave': 'aeronave_principal',
    'aeronave_principal': 'aeronave_principal'
  };

  return dados.map(linha => {
    const linhaNormalizada: any = {};
    
    for (const key in linha) {
      const keyNormalizada = key.toLowerCase().trim();
      const keyFinal = aliases[keyNormalizada] || keyNormalizada;
      linhaNormalizada[keyFinal] = linha[key];
    }
    
    return linhaNormalizada;
  });
}
