
import { BaseService } from './BaseService';
import type { Funcionario } from '../../shared/types';


export class FuncionariosService extends BaseService<Funcionario> {
  constructor(db: any) {
    super('funcionarios', db);
  }

  async getByEmpresa(empresaId: number, page: number = 1, limit: number = 50) {
    return this.getWithFilter({ empresa_id: empresaId }, page, limit);
  }

  async getAtivos(page: number = 1, limit: number = 50) {
    const offset = (page - 1) * limit;
    const result = await this.db
      .prepare(`SELECT * FROM funcionarios WHERE deleted_at IS NULL AND ativo = 1 LIMIT ? OFFSET ?`)
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL AND ativo = 1`)
      .first<{ total: number }>();

    return {
      data: (result.results as unknown as Funcionario[]) || [],
      total: countResult?.total || 0,
    };
  }

  async getByMatricula(matricula: string): Promise<Funcionario | null> {
    const result = await this.db
      .prepare(`SELECT * FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL`)
      .bind(matricula)
      .first<Funcionario>();

    return result || null;
  }

  async create(data: CreateFuncionarioInput): Promise<Funcionario> {
    return super.create({ ...data, ativo: true });
  }

  async update(id: number, data: UpdateFuncionarioInput): Promise<Funcionario> {
    return super.update(id, data);
  }
}
