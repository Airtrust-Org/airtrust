/**
 * QUERIES OTIMIZADAS - Respeitam novo schema refatorado
 * Data: 2 de novembro de 2025
 *
 * FUNCIONARIOS: 32 colunas (consolidado)
 * CERTIFICADOS: 12 colunas (simplificado)
 * QUALIFICACOES: 17 colunas (mantido)
 */

export const QUERIES = {
  // ═══════════════════════════════════════════════════════════════════
  // FUNCIONARIOS (32 colunas)
  // ═══════════════════════════════════════════════════════════════════

  GET_FUNCIONARIOS: `
    SELECT 
      id, matricula, nome, cpf, email, telefone, data_nascimento, 
      data_admissao, cargo, setor, status, guerra, codigo_anac, 
      funcao, base, contrato, licenca_aeronautica, aeronave, 
      codigo_sispat, codigo_prestserv, cma_numero, cma_data_vencimento, 
      cma_status, aso_data_vencimento, icao_nivel, icao_vencimento, 
      icao_status, is_instrutor, is_checador, created_at, updated_at
    FROM funcionarios 
    WHERE deleted_at IS NULL 
    ORDER BY created_at DESC
  `,

  GET_FUNCIONARIO_BY_ID: `
    SELECT * 
    FROM funcionarios 
    WHERE id = ? AND deleted_at IS NULL
  `,

  GET_FUNCIONARIO_BY_MATRICULA: `
    SELECT * 
    FROM funcionarios 
    WHERE matricula = ? AND deleted_at IS NULL
  `,

  GET_FUNCIONARIOS_ATIVOS_COUNT: `
    SELECT COUNT(*) as total 
    FROM funcionarios 
    WHERE deleted_at IS NULL AND status = 'ATIVO'
  `,

  GET_FUNCIONARIOS_BY_BASE: `
    SELECT * 
    FROM funcionarios 
    WHERE base = ? AND deleted_at IS NULL 
    ORDER BY nome ASC
  `,

  // ═══════════════════════════════════════════════════════════════════
  // CERTIFICADOS (12 colunas - simplificado)
  // ═══════════════════════════════════════════════════════════════════

  GET_CERTIFICADOS: `
    SELECT 
      id, qualificacao_id, arquivo_nome, arquivo_tamanho, arquivo_hash, 
      arquivo_url, tipo, data_documento, uploaded_by, created_at, updated_at, 
      deleted_at
    FROM certificados 
    WHERE deleted_at IS NULL 
    ORDER BY created_at DESC
  `,

  GET_CERTIFICADOS_BY_QUALIFICACAO: `
    SELECT * 
    FROM certificados 
    WHERE qualificacao_id = ? AND deleted_at IS NULL 
    ORDER BY created_at DESC
  `,

  GET_CERTIFICADOS_VALIDOS: `
    SELECT c.* 
    FROM certificados c
    INNER JOIN qualificacoes q ON q.id = c.qualificacao_id
    WHERE c.deleted_at IS NULL 
      AND q.deleted_at IS NULL
      AND c.arquivo_url IS NOT NULL
    ORDER BY c.created_at DESC
  `,

  COUNT_CERTIFICADOS_BY_QUALIFICACAO: `
    SELECT 
      qualificacao_id, 
      COUNT(*) as total,
      COUNT(CASE WHEN arquivo_url IS NOT NULL THEN 1 END) as com_arquivo
    FROM certificados 
    WHERE deleted_at IS NULL 
    GROUP BY qualificacao_id
  `,

  // ═══════════════════════════════════════════════════════════════════
  // QUALIFICACOES (17 colunas - schema original mantido)
  // ═══════════════════════════════════════════════════════════════════

  GET_QUALIFICACOES: `
    SELECT 
      id, funcionario_id, tipo, codigo, nome, data_conclusao, 
      data_vencimento, resultado, nota_final, instrutor, local, 
      observacoes, arquivo_url, status, created_at, updated_at, deleted_at
    FROM qualificacoes 
    WHERE deleted_at IS NULL 
    ORDER BY data_vencimento ASC
  `,

  GET_QUALIFICACOES_BY_FUNCIONARIO: `
    SELECT * 
    FROM qualificacoes 
    WHERE funcionario_id = ? AND deleted_at IS NULL 
    ORDER BY data_vencimento ASC
  `,

  GET_QUALIFICACOES_VENCIDAS: `
    SELECT * 
    FROM qualificacoes 
    WHERE deleted_at IS NULL 
      AND status != 'RENOVADA'
      AND data_vencimento IS NOT NULL
      AND julianday(data_vencimento) < julianday('now')
    ORDER BY data_vencimento ASC
  `,

  GET_QUALIFICACOES_VENCENDO: `
    SELECT * 
    FROM qualificacoes 
    WHERE deleted_at IS NULL 
      AND status != 'RENOVADA'
      AND data_vencimento IS NOT NULL
      AND julianday(data_vencimento) - julianday('now') BETWEEN 0 AND 30
    ORDER BY data_vencimento ASC
  `,

  COUNT_QUALIFICACOES_BY_STATUS: `
    SELECT 
      status,
      COUNT(*) as total
    FROM qualificacoes 
    WHERE deleted_at IS NULL
    GROUP BY status
  `,

  // ═══════════════════════════════════════════════════════════════════
  // JOINS COMPLEXOS (Funcionario + Qualificacoes + Certificados)
  // ═══════════════════════════════════════════════════════════════════

  GET_FUNCIONARIO_COM_QUALIFICACOES: `
    SELECT 
      f.id, f.matricula, f.nome, f.email, f.funcao, f.base,
      q.id as qual_id, q.tipo, q.codigo, q.nome as qual_nome, 
      q.data_vencimento, q.status, q.arquivo_url,
      COUNT(c.id) as total_certificados
    FROM funcionarios f
    LEFT JOIN qualificacoes q ON q.funcionario_id = f.id AND q.deleted_at IS NULL
    LEFT JOIN certificados c ON c.qualificacao_id = q.id AND c.deleted_at IS NULL
    WHERE f.id = ? AND f.deleted_at IS NULL
    GROUP BY f.id, q.id
    ORDER BY q.data_vencimento ASC
  `,

  GET_QUALIFICACAO_COM_CERTIFICADOS: `
    SELECT 
      q.id, q.funcionario_id, q.tipo, q.codigo, q.nome, 
      q.data_vencimento, q.status, q.arquivo_url,
      c.id as cert_id, c.arquivo_nome, c.arquivo_url as cert_url,
      f.nome as funcionario_nome
    FROM qualificacoes q
    LEFT JOIN certificados c ON c.qualificacao_id = q.id AND c.deleted_at IS NULL
    INNER JOIN funcionarios f ON f.id = q.funcionario_id
    WHERE q.id = ? AND q.deleted_at IS NULL
    ORDER BY c.created_at DESC
  `,

  // ═══════════════════════════════════════════════════════════════════
  // VALIDAÇÃO E LIMPEZA
  // ═══════════════════════════════════════════════════════════════════

  FIND_ORPHANED_QUALIFICACOES: `
    SELECT q.id 
    FROM qualificacoes q
    LEFT JOIN funcionarios f ON f.id = q.funcionario_id
    WHERE q.deleted_at IS NULL AND f.id IS NULL
  `,

  FIND_ORPHANED_CERTIFICADOS: `
    SELECT c.id 
    FROM certificados c
    LEFT JOIN qualificacoes q ON q.id = c.qualificacao_id
    WHERE c.deleted_at IS NULL AND q.id IS NULL
  `,

  COUNT_BY_TABLE: `
    SELECT 'funcionarios' as tabela, COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL
    UNION ALL
    SELECT 'qualificacoes', COUNT(*) FROM qualificacoes WHERE deleted_at IS NULL
    UNION ALL
    SELECT 'certificados', COUNT(*) FROM certificados WHERE deleted_at IS NULL
  `,
};

/**
 * Tipos de resposta
 */
export interface Funcionario {
  id: number;
  matricula: string;
  nome: string;
  cpf?: string;
  email?: string;
  telefone?: string;
  data_nascimento?: string;
  data_admissao?: string;
  cargo?: string;
  setor?: string;
  status?: string;
  guerra?: string;
  codigo_anac?: string;
  funcao?: string;
  base?: string;
  contrato?: string;
  licenca_aeronautica?: string;
  aeronave?: string;
  codigo_sispat?: string;
  codigo_prestserv?: string;
  cma_numero?: string;
  cma_data_vencimento?: string;
  cma_status?: string;
  aso_data_vencimento?: string;
  icao_nivel?: string;
  icao_vencimento?: string;
  icao_status?: string;
  is_instrutor?: number;
  is_checador?: number;
  created_at?: string;
  updated_at?: string;
}

export interface Qualificacao {
  id: number;
  funcionario_id: number;
  tipo: string;
  codigo: string;
  nome: string;
  data_conclusao?: string;
  data_vencimento?: string;
  resultado?: string;
  nota_final?: number;
  instrutor?: string;
  local?: string;
  observacoes?: string;
  arquivo_url?: string;
  status?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Certificado {
  id: number;
  qualificacao_id: number;
  arquivo_nome?: string;
  arquivo_tamanho?: number;
  arquivo_hash?: string;
  arquivo_url?: string;
  tipo?: string;
  data_documento?: string;
  uploaded_by?: number;
  created_at?: string;
  updated_at?: string;
}
