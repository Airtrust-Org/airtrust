import crypto from 'crypto';

/**
 * Service para gerenciar arquivos em Cloudflare R2
 * Responsável por upload, delete e verificação de arquivos
 */
export class R2Service {
  constructor(private bucket: R2Bucket) {}

  /**
   * Faz upload de arquivo PDF para R2
   * @param filename Nome do arquivo
   * @param buffer Conteúdo do arquivo
   * @returns URL pública e hash SHA256
   */
  async uploadPDF(filename: string, buffer: Buffer): Promise<{ url: string; hash: string }> {
    try {
      // Gerar hash SHA256 para deduplicação
      const hash = crypto.createHash('sha256').update(buffer).digest('hex');
      const key = `certificados/${filename}`;

      // Upload para R2
      await this.bucket.put(key, buffer, {
        httpMetadata: {
          contentType: 'application/pdf',
          contentDisposition: `attachment; filename="${filename}"`,
        },
      });

      // Retornar URL pública
      const url = `certificados/${filename}`;
      return { url, hash };
    } catch (error) {
      throw new Error(
        `Erro ao fazer upload: ${error instanceof Error ? error.message : 'desconhecido'}`,
      );
    }
  }

  /**
   * Deleta arquivo do R2
   * @param filename Nome do arquivo
   */
  async deletarArquivo(filename: string): Promise<void> {
    try {
      const key = `certificados/${filename}`;
      await this.bucket.delete(key);
    } catch (error) {
      console.warn(`Erro ao deletar arquivo ${filename}:`, error);
      // Não lança erro - arquivo pode já estar deletado
    }
  }

  /**
   * Verifica se arquivo existe em R2
   * @param filename Nome do arquivo
   * @returns true se existe
   */
  async verificarExistencia(filename: string): Promise<boolean> {
    try {
      const key = `certificados/${filename}`;
      const obj = await this.bucket.head(key);
      return obj !== null;
    } catch {
      return false;
    }
  }

  /**
   * Gera nome único para arquivo com timestamp
   * @param matricula Matrícula do funcionário
   * @param codigo Código da qualificação
   * @param extensao Extensão do arquivo (padrão: pdf)
   * @returns Nome único de arquivo
   */
  gerarNomeArquivo(matricula: string, codigo: string, extensao: string = 'pdf'): string {
    const timestamp = Date.now();
    const randomStr = crypto.randomBytes(4).toString('hex');
    return `CERT-${matricula}-${codigo}-${timestamp}-${randomStr}.${extensao}`;
  }

  /**
   * Obtém metadados do arquivo
   * @param filename Nome do arquivo
   * @returns Metadados ou null
   */
  async obterMetadados(filename: string): Promise<R2Object | null> {
    try {
      const key = `certificados/${filename}`;
      const obj = await this.bucket.head(key);
      return obj;
    } catch {
      return null;
    }
  }
}
