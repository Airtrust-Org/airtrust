export function gerarNumeroCertificado(habilitacaoId: number): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `CERT-${habilitacaoId}-${timestamp}-${random}`;
}

export function normalizarNome(texto: string): string {
  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

export async function calcularHash(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function construirCaminhoR2(funcionarioId: number, qualificacaoId: number, nomeNormalizado: string): string {
  const timestamp = Date.now();
  return `certificados/${funcionarioId}/${qualificacaoId}/${timestamp}_${nomeNormalizado}.pdf`;
}
