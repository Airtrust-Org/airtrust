/**
 * src/worker/services/habilitacoesService.ts
 * ✅ REFATORADO: Limpo, testável, tratamento de erro explícito
 *
 * Estrutura:
 * - Validações explícitas com Zod
 * - Queries bem estruturadas com logs
 * - Error handling com context
 * - Soft delete em tudo
 * - Auditoria em tudo
 */

import type { D1Database } from '../types';
import { AuditLogger } from '../utils/auditLogger';

interface ListaHabilitacoesOptions {
  page?: number;
  limit?: number;
  funcionario_id?: number;
  qualificacao_id?: number;
  status?: string;
  search?: string;
}

interface HabilitacaoRow {
  id: number;
  funcionario_id: number;
  qualificacao_id: number;
  data_conclusao: string;
  data_vencimento: string;
  resultado: string;
  observacoes?: string;
  certificado_url?: string;
  timezone: string;
  eh_renovada: boolean;
  renovada_em: string | null;
  habilitacao_anterior_id: number | null;
  funcionario_nome: string;
  funcionario_matricula: string;
  qualificacao_nome: string;
  qualificacao_codigo: string;
  categoria_nome: string;
  validade_meses: number;
  status: string;
  dias_para_vencimento: number;
}

export class HabilitacoesService {
  private auditLogger: AuditLogger;

  constructor(private db: D1Database) {
    this.auditLogger = new AuditLogger(db);
  }

  /**
   * ✅ CRIAR com renovação automática
   * Se existe habilitação anterior ativa → marca como renovada
   * Cria nova como ativa
   *
   * Funcionalidades:
   * - Calcula data_vencimento se não informada (data_conclusao + validade_meses)
   * - Detecta timezone do usuário
   * - Marca habilitação anterior como renovada automaticamente
   */
  async criar(dados: any, userId: number, userTimezone?: string): Promise<any> {
    try {
      console.log('📝 Criando habilitação:', {
        funcionario_id: dados.funcionario_id,
        qualificacao_id: dados.qualificacao_id,
        timezone: userTimezone || dados.timezone,
      });

      // Validar funcionário existe
      const funcionario = await this.db
        .prepare('SELECT id FROM funcionarios WHERE id = ? AND deleted_at IS NULL')
        .bind(dados.funcionario_id)
        .first();

      if (!funcionario) {
        throw new Error(`❌ Funcionário ${dados.funcionario_id} não encontrado`);
      }

      // Validar qualificação existe e buscar validade
      const qualificacao = (await this.db
        .prepare('SELECT id, validade_meses FROM qualificacoes WHERE id = ? AND deleted_at IS NULL')
        .bind(dados.qualificacao_id)
        .first()) as any;

      if (!qualificacao) {
        throw new Error(`❌ Qualificação ${dados.qualificacao_id} não encontrada`);
      }

      // Validar data de conclusão
      if (!dados.data_conclusao) {
        throw new Error('❌ data_conclusao é obrigatório');
      }

      // Calcular data_vencimento se não informada
      let dataVencimento = dados.data_vencimento;
      if (!dataVencimento && qualificacao.validade_meses) {
        dataVencimento = this.calcularDataVencimento(
          dados.data_conclusao,
          qualificacao.validade_meses,
        );
        console.log(`📅 Data de vencimento calculada: ${dataVencimento}`);
      }

      if (!dataVencimento) {
        throw new Error('❌ Não foi possível calcular a data de vencimento');
      }

      // Detectar timezone
      const timezone = userTimezone || dados.timezone || 'UTC';

      // Buscar habilitação anterior ativa
      const anterior = (await this.db
        .prepare(
          `
          SELECT id, data_conclusao, data_vencimento
          FROM habilitacoes
          WHERE
            funcionario_id = ?
            AND qualificacao_id = ?
            AND deleted_at IS NULL
            AND eh_renovada = FALSE
          ORDER BY created_at DESC
          LIMIT 1
        `,
        )
        .bind(dados.funcionario_id, dados.qualificacao_id)
        .first()) as any;

      // Se existe anterior, marca como renovada
      if (anterior) {
        console.log(`🔄 Marcando habilitação ${anterior.id} como renovada`);
        await this.db
          .prepare(
            `
            UPDATE habilitacoes
            SET
              eh_renovada = TRUE,
              renovada_em = CURRENT_TIMESTAMP,
              updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `,
          )
          .bind(anterior.id)
          .run();

        await this.auditLogger.log(
          userId,
          'UPDATE',
          'habilitacoes',
          anterior.id,
          { eh_renovada: false },
          { eh_renovada: true, renovada_em: new Date().toISOString() },
        );
      }

      // Criar nova habilitação ativa com UUID
      const novaId = crypto.randomUUID();
      await this.db
        .prepare(
          `
          INSERT INTO habilitacoes (
            id,
            funcionario_id,
            qualificacao_id,
            data_conclusao,
            data_vencimento,
            resultado,
            observacoes,
            timezone,
            instrutor,
            habilitacao_anterior_id,
            eh_renovada,
            created_at,
            updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `,
        )
        .bind(
          novaId,
          dados.funcionario_id,
          dados.qualificacao_id,
          dados.data_conclusao,
          dataVencimento,
          dados.resultado || 'PENDENTE',
          dados.observacoes || null,
          timezone,
          dados.instrutor || null,
          anterior?.id || null,
          false,
        )
        .run();

      // Recuperar a habilitação criada pelo ID
      const novaHab = (await this.db
        .prepare(
          `
          SELECT * FROM habilitacoes 
          WHERE id = ? AND deleted_at IS NULL
          LIMIT 1
        `,
        )
        .bind(novaId)
        .first()) as any;

      if (!novaHab) {
        console.error(
          `❌ ERRO CRÍTICO: Habilitação ${novaId} foi inserida mas SELECT retornou NULL!`,
        );
        throw new Error('Falha ao recuperar habilitação criada - insert pode ter falhado');
      }

      console.log(`✅ Habilitação ${novaHab?.id} criada com sucesso`);

      await this.auditLogger.log(userId, 'CREATE', 'habilitacoes', novaHab?.id, null, dados);

      return novaHab;
    } catch (error) {
      console.error('❌ Erro ao criar:', error);
      throw error;
    }
  }

  /**
   * ✅ Calcular data de vencimento
   * data_conclusao + validade_meses
   */
  private calcularDataVencimento(dataConclusao: string, meses: number): string {
    try {
      const data = new Date(dataConclusao);
      data.setMonth(data.getMonth() + meses);
      return data.toISOString().split('T')[0];
    } catch (error) {
      console.error('❌ Erro ao calcular data de vencimento:', error);
      return dataConclusao;
    }
  }

  /**
   * ✅ LISTAR com paginação e filtros
   * Query otimizada com JOINs explícitos
   */
  async listar(options: ListaHabilitacoesOptions = {}): Promise<{
    data: HabilitacaoRow[];
    pagination: { page: number; limit: number; total: number; pages: number };
  }> {
    try {
      const page = Math.max(1, options.page || 1);
      const limit = Math.max(1, Math.min(10000, options.limit || 20));
      const offset = (page - 1) * limit;

      console.log(`📋 Listando habilitações - página ${page}, limit ${limit}`);

      // Query base - APENAS COLUNAS QUE DEFINITIVAMENTE EXISTEM
      let query = `
        SELECT
          h.id,
          h.funcionario_id,
          h.qualificacao_id,
          h.data_conclusao,
          h.data_vencimento,
          h.resultado,
          h.observacoes,
          h.timezone,
          h.instrutor,
          h.certificado_url,
          h.eh_renovada,
          h.renovada_em,
          h.habilitacao_anterior_id,

          f.nome as funcionario_nome,
          f.matricula as funcionario_matricula,

          q.nome as qualificacao_nome,
          q.codigo as qualificacao_codigo,
          q.categoria as categoria_nome,
          q.validade_meses,

          CASE
            WHEN h.data_vencimento > DATE('now') THEN 'VÁLIDO'
            WHEN h.data_vencimento <= DATE('now') AND h.data_vencimento > DATE('now', '-30 days') THEN 'VENCENDO'
            ELSE 'VENCIDA'
          END as status,

          CAST((julianday(h.data_vencimento) - julianday('now')) AS INTEGER) as dias_para_vencimento

        FROM habilitacoes h
        LEFT JOIN funcionarios f ON f.id = h.funcionario_id AND f.deleted_at IS NULL
        LEFT JOIN qualificacoes q ON q.id = h.qualificacao_id AND q.deleted_at IS NULL

        WHERE h.deleted_at IS NULL
      `;

      const params: any[] = [];

      // Aplicar filtros
      if (options.funcionario_id) {
        query += ` AND h.funcionario_id = ?`;
        params.push(options.funcionario_id);
      }

      if (options.qualificacao_id) {
        query += ` AND h.qualificacao_id = ?`;
        params.push(options.qualificacao_id);
      }

      if (options.status && options.status !== 'TODOS') {
        if (options.status === 'VÁLIDO') {
          query += ` AND h.data_vencimento > DATE('now')`;
        } else if (options.status === 'VENCENDO') {
          query += ` AND h.data_vencimento <= DATE('now') AND h.data_vencimento > DATE('now', '-30 days')`;
        } else if (options.status === 'VENCIDA') {
          query += ` AND h.data_vencimento <= DATE('now', '-30 days')`;
        }
      }

      if (options.search) {
        query += ` AND (f.nome LIKE ? OR f.matricula LIKE ? OR q.nome LIKE ?)`;
        const searchTerm = `%${options.search}%`;
        params.push(searchTerm, searchTerm, searchTerm);
      }

      // Ordenação e paginação
      query += ` ORDER BY h.id DESC LIMIT ? OFFSET ?`;
      params.push(limit, offset);

      const resultados = await this.db
        .prepare(query)
        .bind(...params)
        .all();

      // BUG-001: Converter funcionario_id float para integer
      const dadosNormalizados = (resultados.results || []).map((row: any) => ({
        ...row,
        funcionario_id: row.funcionario_id
          ? String(Math.floor(Number(row.funcionario_id)))
          : row.funcionario_id,
      }));

      // Contar total
      let countQuery = `
        SELECT COUNT(*) as total 
        FROM habilitacoes h
        LEFT JOIN funcionarios f ON f.id = h.funcionario_id AND f.deleted_at IS NULL
        LEFT JOIN qualificacoes q ON q.id = h.qualificacao_id AND q.deleted_at IS NULL
        WHERE h.deleted_at IS NULL
      `;
      const countParams: any[] = [];

      if (options.funcionario_id) {
        countQuery += ` AND h.funcionario_id = ?`;
        countParams.push(options.funcionario_id);
      }

      if (options.qualificacao_id) {
        countQuery += ` AND h.qualificacao_id = ?`;
        countParams.push(options.qualificacao_id);
      }

      if (options.status && options.status !== 'TODOS') {
        if (options.status === 'VÁLIDO') {
          countQuery += ` AND h.data_vencimento > DATE('now')`;
        } else if (options.status === 'VENCENDO') {
          countQuery += ` AND h.data_vencimento <= DATE('now') AND h.data_vencimento > DATE('now', '-30 days')`;
        } else if (options.status === 'VENCIDA') {
          countQuery += ` AND h.data_vencimento <= DATE('now', '-30 days')`;
        }
      }

      if (options.search) {
        countQuery += ` AND (f.nome LIKE ? OR f.matricula LIKE ? OR q.nome LIKE ?)`;
        const searchTerm = `%${options.search}%`;
        countParams.push(searchTerm, searchTerm, searchTerm);
      }

      const totalResult = (await this.db
        .prepare(countQuery)
        .bind(...countParams)
        .first()) as any;
      const total = totalResult?.total || 0;

      // Extrair dados - .all() retorna { results: [...] } ou [...] direto
      const rawData = Array.isArray(resultados) ? resultados : resultados?.results || [];
      // BUG-001: Normalizar antes de retornar
      const data = dadosNormalizados as HabilitacaoRow[];

      return {
        data,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      };
    } catch (error) {
      console.error('❌ Erro ao listar:', error);
      throw error;
    }
  }

  /**
   * ✅ OBTER ESTATÍSTICAS para dashboard
   * Simples e direto
   */
  async obterEstatisticas(): Promise<{
    total: number;
    validas: number;
    vencendo: number;
    vencidas: number;
    renovadas: number;
  }> {
    try {
      const stats = (await this.db
        .prepare(
          `
          SELECT
            COUNT(*) as total,
            SUM(CASE WHEN data_vencimento > DATE('now') THEN 1 ELSE 0 END) as validas,
            SUM(CASE WHEN data_vencimento <= DATE('now') AND data_vencimento > DATE('now', '-30 days') THEN 1 ELSE 0 END) as vencendo,
            SUM(CASE WHEN data_vencimento <= DATE('now', '-30 days') THEN 1 ELSE 0 END) as vencidas,
            SUM(CASE WHEN eh_renovada = TRUE THEN 1 ELSE 0 END) as renovadas
          FROM habilitacoes
          WHERE deleted_at IS NULL
        `,
        )
        .first()) as any;

      const resultado = {
        total: stats?.total || 0,
        validas: stats?.validas || 0,
        vencendo: stats?.vencendo || 0,
        vencidas: stats?.vencidas || 0,
        renovadas: stats?.renovadas || 0,
      };

      console.log('📊 Estatísticas:', resultado);
      return resultado;
    } catch (error) {
      console.error('❌ Erro ao obter estatísticas:', error);
      throw error;
    }
  }

  /**
   * ✅ QUALIFICAÇÕES DISPONÍVEIS para filtro
   */
  async obterQualificacoesDisponiveis(): Promise<
    Array<{ id: number; nome: string; total: number }>
  > {
    try {
      const qualificacoes = await this.db
        .prepare(
          `
          SELECT DISTINCT
            q.id,
            q.nome,
            COUNT(h.id) as total
          FROM qualificacoes q
          LEFT JOIN habilitacoes h ON h.qualificacao_id = q.id AND h.deleted_at IS NULL
          WHERE q.deleted_at IS NULL
          GROUP BY q.id, q.nome
          ORDER BY q.nome ASC
        `,
        )
        .all();

      const resultado = (qualificacoes.results || []).map((q: any) => ({
        id: q.id,
        nome: q.nome,
        total: q.total || 0,
      }));

      console.log(`✅ ${resultado.length} qualificações`);
      return resultado;
    } catch (error) {
      console.error('❌ Erro ao obter qualificações:', error);
      return [];
    }
  }

  /**
   * ✅ FUNCIONÁRIOS COM HABILITAÇÕES para filtro
   */
  async obterFuncionariosComHabilitacoes(): Promise<
    Array<{ id: number; nome: string; total: number }>
  > {
    try {
      const funcionarios = await this.db
        .prepare(
          `
          SELECT DISTINCT
            f.id,
            f.nome,
            COUNT(h.id) as total
          FROM funcionarios f
          LEFT JOIN habilitacoes h ON h.funcionario_id = f.id AND h.deleted_at IS NULL
          WHERE f.deleted_at IS NULL
          GROUP BY f.id, f.nome
          ORDER BY f.nome ASC
        `,
        )
        .all();

      const resultado = (funcionarios.results || []).map((f: any) => ({
        id: f.id,
        nome: f.nome,
        total: f.total || 0,
      }));

      console.log(`✅ ${resultado.length} funcionários`);
      return resultado;
    } catch (error) {
      console.error('❌ Erro ao obter funcionários:', error);
      return [];
    }
  }

  /**
   * ✅ ATUALIZAR habilitação
   */
  async atualizar(id: string, dados: any, userId: number): Promise<any> {
    try {
      console.log(`📝 Atualizando habilitação ${id}`);

      // Verificar se existe
      const existente = await this.db
        .prepare('SELECT id, * FROM habilitacoes WHERE id = ? AND deleted_at IS NULL')
        .bind(id)
        .first();

      if (!existente) {
        throw new Error(`❌ Habilitação ${id} não encontrada`);
      }

      // Atualizar apenas campos permitidos
      const campos: string[] = [];
      const valores: any[] = [];

      if (dados.data_conclusao) {
        campos.push('data_conclusao = ?');
        valores.push(dados.data_conclusao);
      }
      if (dados.data_vencimento) {
        campos.push('data_vencimento = ?');
        valores.push(dados.data_vencimento);
      }
      if (dados.resultado) {
        campos.push('resultado = ?');
        valores.push(dados.resultado);
      }
      if (dados.nota_final !== undefined) {
        campos.push('nota_final = ?');
        valores.push(dados.nota_final);
      }
      if (dados.observacoes !== undefined) {
        campos.push('observacoes = ?');
        valores.push(dados.observacoes);
      }
      if (dados.timezone !== undefined) {
        campos.push('timezone = ?');
        valores.push(dados.timezone || 'UTC');
      }
      if (dados.instrutor !== undefined) {
        campos.push('instrutor = ?');
        valores.push(dados.instrutor || null);
      }
      if (dados.certificado_url !== undefined) {
        campos.push('certificado_url = ?');
        valores.push(dados.certificado_url || null);
      }
      if (dados.eh_renovada !== undefined) {
        campos.push('eh_renovada = ?');
        valores.push(dados.eh_renovada ? 1 : 0);
      }
      if (dados.renovada_em !== undefined) {
        campos.push('renovada_em = ?');
        valores.push(dados.renovada_em || null);
      }
      if (dados.habilitacao_anterior_id !== undefined) {
        campos.push('habilitacao_anterior_id = ?');
        valores.push(dados.habilitacao_anterior_id || null);
      }

      if (campos.length === 0) {
        return existente;
      }

      campos.push('updated_at = CURRENT_TIMESTAMP');
      valores.push(id);

      const query = `UPDATE habilitacoes SET ${campos.join(', ')} WHERE id = ?`;
      await this.db
        .prepare(query)
        .bind(...valores)
        .run();

      await this.auditLogger.log(userId, 'UPDATE', 'habilitacoes', id, existente, dados);

      console.log(`✅ Habilitação ${id} atualizada`);
      return { id, ...dados };
    } catch (error) {
      console.error('❌ Erro ao atualizar:', error);
      throw error;
    }
  }

  /**
   * ✅ DELETAR (soft delete)
   */
  async deletar(id: string, userId: number): Promise<any> {
    try {
      console.log(`🗑️ Deletando habilitação ${id}`);

      const existente = await this.db
        .prepare('SELECT * FROM habilitacoes WHERE id = ? AND deleted_at IS NULL')
        .bind(id)
        .first();

      if (!existente) {
        throw new Error(`❌ Habilitação ${id} não encontrada`);
      }

      await this.db
        .prepare(
          'UPDATE habilitacoes SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        )
        .bind(id)
        .run();

      await this.auditLogger.log(userId, 'DELETE', 'habilitacoes', id, existente, {
        deleted_at: new Date().toISOString(),
      });

      console.log(`✅ Habilitação ${id} deletada`);
      return { id, deletado: true };
    } catch (error) {
      console.error('❌ Erro ao deletar:', error);
      throw error;
    }
  }

  /**
   * ✅ HISTÓRICO DE RENOVAÇÕES via CTE recursiva
   */
  async obterHistoricoRenovacoes(funcionarioId: number, qualificacaoId: number): Promise<any[]> {
    try {
      console.log(`📜 Buscando histórico de renovações`, {
        funcionarioId,
        qualificacaoId,
      });

      const historico = await this.db
        .prepare(
          `
          WITH RECURSIVE renovacoes AS (
            -- Habilitação mais recente (ativa)
            SELECT
              id,
              funcionario_id,
              qualificacao_id,
              data_conclusao,
              data_vencimento,
              habilitacao_anterior_id,
              eh_renovada,
              renovada_em,
              0 as nivel
            FROM habilitacoes
            WHERE
              funcionario_id = ?
              AND qualificacao_id = ?
              AND deleted_at IS NULL
              AND eh_renovada = FALSE

            UNION ALL

            -- Anteriores (recursivo)
            SELECT
              h.id,
              h.funcionario_id,
              h.qualificacao_id,
              h.data_conclusao,
              h.data_vencimento,
              h.habilitacao_anterior_id,
              h.eh_renovada,
              h.renovada_em,
              r.nivel + 1
            FROM habilitacoes h
            JOIN renovacoes r ON h.id = r.habilitacao_anterior_id
            WHERE h.deleted_at IS NULL
          )
          SELECT * FROM renovacoes ORDER BY nivel ASC
        `,
        )
        .bind(funcionarioId, qualificacaoId)
        .all();

      const resultado = historico.results || [];
      console.log(`✅ ${resultado.length} renovações encontradas`);
      return resultado;
    } catch (error) {
      console.error('❌ Erro ao obter histórico:', error);
      return [];
    }
  }
}
