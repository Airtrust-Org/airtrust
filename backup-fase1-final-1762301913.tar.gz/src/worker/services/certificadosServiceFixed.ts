/**
 * src/worker/services/certificadosServiceFixed.ts
 * Service para certificados com versionamento e R2
 */

import crypto from 'crypto';
import type { D1Database } from '../types';
import { AuditLogger } from '../utils/auditLogger';

export class CertificadosServiceFixed {
  private auditLogger: AuditLogger;

  constructor(
    private db: D1Database,
    private R2Bucket?: any // R2Bucket do Cloudflare
  ) {
    this.auditLogger = new AuditLogger(db);
  }

  /**
   * Upload com versionamento automático
   */
  async uploadCertificado(
    habilitacaoId: number,
    file: File,
    userId: number
  ): Promise<{ id: number; versao: number; url: string; nome_arquivo: string }> {
    try {
      // Validar habilitação
      const habilitacao = await this.db
        .prepare(
          `
          SELECT h.id, f.matricula FROM habilitacoes h 
          JOIN funcionarios f ON f.id = h.funcionario_id 
          WHERE h.id = ? AND h.deleted_at IS NULL
        `
        )
        .bind(habilitacaoId)
        .first() as any;

      if (!habilitacao) {
        throw new Error('Habilitação não encontrada');
      }

      // Obter próxima versão
      const ultimoCert = await this.db
        .prepare(
          `SELECT MAX(versao) as ultima_versao FROM certificados WHERE habilitacao_id = ?`
        )
        .bind(habilitacaoId)
        .first() as any;

      const proximaVersao = (ultimoCert?.ultima_versao || 0) + 1;

      // Gerar nome único e auditável
      const ext = file.name.split('.').pop() || 'bin';
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
      const hash = crypto.randomBytes(8).toString('hex');
      const nomeArquivo = `CERT-${habilitacao.matricula}-${habilitacaoId}-v${proximaVersao}-${timestamp}-${hash}.${ext}`;

      // Calcular hash SHA-256 do arquivo (se possível)
      let hashSHA256 = '';
      try {
        const arrayBuffer = await file.arrayBuffer();
        // Usar Web Crypto API se disponível (em Workers)
        if (typeof crypto !== 'undefined' && crypto.subtle) {
          const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
          hashSHA256 = Array.from(new Uint8Array(hashBuffer))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
        }
      } catch {
        // Se não conseguir calcular, continua sem hash
        console.warn('⚠️ Não foi possível calcular hash SHA-256');
      }

      // Upload com retry
      let urlR2 = '';
      if (this.R2Bucket) {
        try {
          urlR2 = await this.uploadToR2WithRetry(nomeArquivo, file, 3);
        } catch (error: any) {
          throw new Error(`Falha ao fazer upload: ${error.message}`);
        }
      }

      // Inserir novo certificado
      const resultado = await this.db
        .prepare(
          `
          INSERT INTO certificados (
            habilitacao_id,
            nome_arquivo,
            url_r2,
            tipo,
            versao,
            tamanho_bytes,
            hash_sha256,
            created_at,
            updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `
        )
        .bind(
          habilitacaoId,
          nomeArquivo,
          urlR2,
          file.type,
          proximaVersao,
          file.size,
          hashSHA256 || null
        )
        .run();

      // Auditar
      await this.auditLogger.log(
        userId,
        'CREATE',
        'certificados',
        resultado.meta.last_row_id,
        null,
        { nomeArquivo, versao: proximaVersao, url: urlR2 }
      );

      return {
        id: resultado.meta.last_row_id,
        versao: proximaVersao,
        url: urlR2,
        nome_arquivo: nomeArquivo,
      };
    } catch (error) {
      console.error('❌ Erro ao fazer upload de certificado:', error);
      throw error;
    }
  }

  /**
   * Upload com retry automático
   */
  private async uploadToR2WithRetry(
    nomeArquivo: string,
    file: File,
    maxRetries: number = 3
  ): Promise<string> {
    if (!this.R2Bucket) {
      throw new Error('R2 Bucket não configurado');
    }

    for (let tentativa = 1; tentativa <= maxRetries; tentativa++) {
      try {
        const arrayBuffer = await file.arrayBuffer();

        await this.R2Bucket.put(nomeArquivo, arrayBuffer, {
          httpMetadata: {
            contentType: file.type,
          },
          customMetadata: {
            uploadedAt: new Date().toISOString(),
          },
        });

        // Gerar URL pública (ajustar conforme sua configuração)
        const publicUrl = process.env.R2_PUBLIC_URL || 'https://r2.airtrust.dev';
        return `${publicUrl}/${nomeArquivo}`;
      } catch (error) {
        console.warn(`⚠️ Tentativa ${tentativa}/${maxRetries} falhou:`, error);

        if (tentativa === maxRetries) {
          throw error;
        }

        // Backoff exponencial
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, tentativa) * 1000)
        );
      }
    }

    throw new Error('Falha permanente no upload');
  }

  /**
   * Obter histórico de versões
   */
  async obterHistorico(habilitacaoId: number): Promise<any[]> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT 
            id,
            versao,
            nome_arquivo,
            url_r2,
            tamanho_bytes,
            hash_sha256,
            created_at
          FROM certificados
          WHERE habilitacao_id = ? AND deleted_at IS NULL
          ORDER BY versao DESC
        `
        )
        .bind(habilitacaoId)
        .all();

      return resultado.results || [];
    } catch (error) {
      console.error('❌ Erro ao obter histórico:', error);
      return [];
    }
  }

  /**
   * Obter certificado atual (versão mais recente)
   */
  async obterCertificadoAtual(habilitacaoId: number): Promise<any> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT * FROM certificados
          WHERE habilitacao_id = ? AND deleted_at IS NULL
          ORDER BY versao DESC
          LIMIT 1
        `
        )
        .bind(habilitacaoId)
        .first();

      return resultado;
    } catch (error) {
      console.error('❌ Erro ao obter certificado atual:', error);
      return null;
    }
  }

  /**
   * Deletar certificado (soft delete)
   */
  async deletarCertificado(
    certificadoId: number,
    userId: number
  ): Promise<{ deletado: boolean }> {
    try {
      const cert = await this.db
        .prepare('SELECT * FROM certificados WHERE id = ? AND deleted_at IS NULL')
        .bind(certificadoId)
        .first();

      if (!cert) {
        throw new Error('Certificado não encontrado');
      }

      await this.db
        .prepare('UPDATE certificados SET deleted_at = CURRENT_TIMESTAMP WHERE id = ?')
        .bind(certificadoId)
        .run();

      // Auditar
      await this.auditLogger.log(userId, 'DELETE', 'certificados', certificadoId, cert, null);

      return { deletado: true };
    } catch (error) {
      console.error('❌ Erro ao deletar certificado:', error);
      throw error;
    }
  }

  /**
   * Obter estatísticas de certificados
   */
  async obterEstatisticas(): Promise<{
    total: number;
    versoes_totais: number;
    tamanho_medio: number;
    habilitacoes_com_cert: number;
  }> {
    try {
      const resultado = await this.db
        .prepare(
          `
          SELECT 
            COUNT(DISTINCT habilitacao_id) as habilitacoes_com_cert,
            COUNT(*) as total,
            SUM(versao) as versoes_totais,
            AVG(tamanho_bytes) as tamanho_medio
          FROM certificados
          WHERE deleted_at IS NULL
        `
        )
        .first() as any;

      return {
        total: resultado?.total || 0,
        versoes_totais: resultado?.versoes_totais || 0,
        tamanho_medio: resultado?.tamanho_medio || 0,
        habilitacoes_com_cert: resultado?.habilitacoes_com_cert || 0,
      };
    } catch (error) {
      console.error('❌ Erro ao obter estatísticas:', error);
      return { total: 0, versoes_totais: 0, tamanho_medio: 0, habilitacoes_com_cert: 0 };
    }
  }
}
