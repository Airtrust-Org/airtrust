import { Context } from 'hono';

export class BackupService {
  /**
   * Cria um snapshot dos dados antes de operações críticas
   */
  static async createSnapshot(c: Context, operation: string, table: string): Promise<string> {
    const timestamp = new Date().toISOString();
    const snapshotId = `backup_${table}_${Date.now()}`;
    
    try {
      const db = c.env.DB;
      
      const funcionarios = await db.prepare('SELECT * FROM funcionarios WHERE deleted_at IS NULL').all();
      const funcoes = await db.prepare('SELECT * FROM funcoes WHERE deleted_at IS NULL').all();
      const auditoria = await db.prepare('SELECT * FROM auditoria_avancada_v2 ORDER BY timestamp DESC LIMIT 10').all();
      
      const backup = {
        snapshot_id: snapshotId,
        timestamp,
        operation,
        table,
        data: {
          funcionarios: funcionarios.results,
          funcoes: funcoes.results,
          auditoria_sample: auditoria.results
        },
        counts: {
          funcionarios: funcionarios.results?.length || 0,
          funcoes: funcoes.results?.length || 0,
          auditoria: auditoria.results?.length || 0
        }
      };
      
      console.log('📦 BACKUP_CREATED:', {
        snapshot_id: snapshotId,
        operation,
        table,
        counts: backup.counts,
        timestamp
      });
      
      return snapshotId;
    } catch (error) {
      console.error('❌ BACKUP_FAILED:', error);
      throw new Error(`Backup creation failed: ${error}`);
    }
  }
  
  /**
   * Valida a operação após execução comparando com o snapshot
   */
  static async validatePostOperation(c: Context, snapshotId: string, table: string): Promise<boolean> {
    try {
      const db = c.env.DB;
      
      const result = await db.prepare(`SELECT COUNT(*) as count FROM ${table} WHERE deleted_at IS NULL`).first();
      const currentCount = (result?.count as number) || 0;
      
      console.log('🔍 POST_OPERATION_VALIDATION:', {
        snapshot_id: snapshotId,
        table,
        current_count: currentCount,
        timestamp: new Date().toISOString(),
        status: 'VALIDATED'
      });
      
      return true;
    } catch (error) {
      console.error('❌ POST_VALIDATION_FAILED:', error);
      return false;
    }
  }
}
