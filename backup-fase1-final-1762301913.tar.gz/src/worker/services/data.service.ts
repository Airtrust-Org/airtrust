/**
 * DATA SERVICE - Transformação de dados com novo schema
 * Data: 2 de novembro de 2025
 *
 * Responsável por:
 * - Buscar dados respeitando novo schema
 * - Transformar dados para frontend
 * - Validar integridade referencial
 * - Aplicar soft-delete (WHERE deleted_at IS NULL)
 */

import { D1Database } from '@cloudflare/workers-types';
import { QUERIES, Funcionario, Qualificacao, Certificado } from './queries';
import { Logger } from '../utils/logger';

export class DataService {
  constructor(private db: D1Database) {}

  // ═══════════════════════════════════════════════════════════════════
  // FUNCIONARIOS
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Busca todos os funcionarios ativos
   */
  async getFuncionarios(): Promise<Funcionario[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_FUNCIONARIOS) as any).all();
      return (result.results || []) as Funcionario[];
    } catch (error) {
      Logger.error('Error fetching funcionarios:', error);
      return [];
    }
  }

  /**
   * Busca funcionario por ID
   */
  async getFuncionarioById(id: number): Promise<Funcionario | null> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_FUNCIONARIO_BY_ID) as any).bind(id).first();
      return result ? this.transformFuncionario(result) : null;
    } catch (error) {
      Logger.error(`Error fetching funcionario ${id}:`, error);
      return null;
    }
  }

  /**
   * Busca funcionario por matricula
   */
  async getFuncionarioByMatricula(matricula: string): Promise<Funcionario | null> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_FUNCIONARIO_BY_MATRICULA) as any)
        .bind(matricula)
        .first();
      return result ? this.transformFuncionario(result) : null;
    } catch (error) {
      Logger.error(`Error fetching funcionario by matricula:`, error);
      return null;
    }
  }

  /**
   * Busca funcionarios por base
   */
  async getFuncionariosByBase(base: string): Promise<Funcionario[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_FUNCIONARIOS_BY_BASE) as any)
        .bind(base)
        .all();
      return (result.results || []) as Funcionario[];
    } catch (error) {
      Logger.error(`Error fetching funcionarios by base:`, error);
      return [];
    }
  }

  /**
   * Transforma funcionario com dados consolidados
   */
  private transformFuncionario(f: any): Funcionario {
    return {
      id: f.id,
      matricula: f.matricula || '',
      nome: f.nome || '',
      cpf: f.cpf,
      email: f.email,
      telefone: f.telefone,
      data_nascimento: f.data_nascimento,
      data_admissao: f.data_admissao,
      cargo: f.cargo,
      setor: f.setor,
      status: f.status || 'ATIVO',
      guerra: f.guerra,
      codigo_anac: f.codigo_anac,
      funcao: f.funcao,
      base: f.base,
      contrato: f.contrato,
      licenca_aeronautica: f.licenca_aeronautica,
      aeronave: f.aeronave,
      codigo_sispat: f.codigo_sispat,
      codigo_prestserv: f.codigo_prestserv,
      cma_numero: f.cma_numero,
      cma_data_vencimento: f.cma_data_vencimento,
      cma_status: f.cma_status,
      aso_data_vencimento: f.aso_data_vencimento,
      icao_nivel: f.icao_nivel,
      icao_vencimento: f.icao_vencimento,
      icao_status: f.icao_status,
      is_instrutor: f.is_instrutor,
      is_checador: f.is_checador,
      created_at: f.created_at,
      updated_at: f.updated_at,
    };
  }

  // ═══════════════════════════════════════════════════════════════════
  // QUALIFICACOES
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Busca todas as qualificacoes ativas
   */
  async getQualificacoes(): Promise<Qualificacao[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_QUALIFICACOES) as any).all();
      return (result.results || []) as Qualificacao[];
    } catch (error) {
      Logger.error('Error fetching qualificacoes:', error);
      return [];
    }
  }

  /**
   * Busca qualificacoes por funcionario
   */
  async getQualificacoesByFuncionario(funcionario_id: number): Promise<Qualificacao[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_QUALIFICACOES_BY_FUNCIONARIO) as any)
        .bind(funcionario_id)
        .all();
      return (result.results || []) as Qualificacao[];
    } catch (error) {
      Logger.error(`Error fetching qualificacoes for funcionario ${funcionario_id}:`, error);
      return [];
    }
  }

  /**
   * Busca qualificacoes vencidas
   */
  async getQualificacoesVencidas(): Promise<Qualificacao[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_QUALIFICACOES_VENCIDAS) as any).all();
      return (result.results || []) as Qualificacao[];
    } catch (error) {
      Logger.error('Error fetching vencidas qualificacoes:', error);
      return [];
    }
  }

  /**
   * Busca qualificacoes vencendo em 30 dias
   */
  async getQualificacoesVencendo(): Promise<Qualificacao[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_QUALIFICACOES_VENCENDO) as any).all();
      return (result.results || []) as Qualificacao[];
    } catch (error) {
      Logger.error('Error fetching vencendo qualificacoes:', error);
      return [];
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // CERTIFICADOS
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Busca todos os certificados ativos
   */
  async getCertificados(): Promise<Certificado[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_CERTIFICADOS) as any).all();
      return (result.results || []) as Certificado[];
    } catch (error) {
      Logger.error('Error fetching certificados:', error);
      return [];
    }
  }

  /**
   * Busca certificados por qualificacao
   */
  async getCertificadosByQualificacao(qualificacao_id: number): Promise<Certificado[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_CERTIFICADOS_BY_QUALIFICACAO) as any)
        .bind(qualificacao_id)
        .all();
      return (result.results || []) as Certificado[];
    } catch (error) {
      Logger.error(`Error fetching certificados for qualificacao ${qualificacao_id}:`, error);
      return [];
    }
  }

  /**
   * Busca certificados validos (com arquivo)
   */
  async getCertificadosValidos(): Promise<Certificado[]> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_CERTIFICADOS_VALIDOS) as any).all();
      return (result.results || []) as Certificado[];
    } catch (error) {
      Logger.error('Error fetching valid certificados:', error);
      return [];
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // JOINS COMPLEXOS
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Busca funcionario com todas as qualificacoes e certificados
   */
  async getFuncionarioComQualificacoes(funcionario_id: number): Promise<any> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_FUNCIONARIO_COM_QUALIFICACOES) as any)
        .bind(funcionario_id)
        .all();

      if (!result.results || result.results.length === 0) {
        return null;
      }

      // Agrupar qualificacoes
      const funcionario = result.results[0];
      const qualificacoes = result.results.map((row: any) => ({
        id: row.qual_id,
        tipo: row.tipo,
        codigo: row.codigo,
        nome: row.qual_nome,
        data_vencimento: row.data_vencimento,
        status: row.status,
        arquivo_url: row.arquivo_url,
        total_certificados: row.total_certificados,
      }));

      return {
        id: funcionario.id,
        matricula: funcionario.matricula,
        nome: funcionario.nome,
        email: funcionario.email,
        funcao: funcionario.funcao,
        base: funcionario.base,
        qualificacoes: qualificacoes.filter((q: any) => q.id),
      };
    } catch (error) {
      Logger.error(`Error fetching funcionario com qualificacoes:`, error);
      return null;
    }
  }

  /**
   * Busca qualificacao com certificados
   */
  async getQualificacaoComCertificados(qualificacao_id: number): Promise<any> {
    try {
      const result = await (this.db.prepare(QUERIES.GET_QUALIFICACAO_COM_CERTIFICADOS) as any)
        .bind(qualificacao_id)
        .all();

      if (!result.results || result.results.length === 0) {
        return null;
      }

      const qualificacao = result.results[0];
      const certificados = result.results
        .filter((row: any) => row.cert_id)
        .map((row: any) => ({
          id: row.cert_id,
          arquivo_nome: row.arquivo_nome,
          arquivo_url: row.cert_url,
        }));

      return {
        id: qualificacao.id,
        funcionario_id: qualificacao.funcionario_id,
        funcionario_nome: qualificacao.funcionario_nome,
        tipo: qualificacao.tipo,
        codigo: qualificacao.codigo,
        nome: qualificacao.nome,
        data_vencimento: qualificacao.data_vencimento,
        status: qualificacao.status,
        arquivo_url: qualificacao.arquivo_url,
        certificados,
      };
    } catch (error) {
      Logger.error(`Error fetching qualificacao com certificados:`, error);
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // VALIDAÇÃO E LIMPEZA
  // ═══════════════════════════════════════════════════════════════════

  /**
   * Encontra qualificacoes orfas (sem funcionario)
   */
  async findOrphanedQualificacoes(): Promise<number[]> {
    try {
      const result = await (this.db.prepare(QUERIES.FIND_ORPHANED_QUALIFICACOES) as any).all();
      return (result.results || []).map((row: any) => row.id);
    } catch (error) {
      Logger.error('Error finding orphaned qualificacoes:', error);
      return [];
    }
  }

  /**
   * Encontra certificados orfos (sem qualificacao)
   */
  async findOrphanedCertificados(): Promise<number[]> {
    try {
      const result = await (this.db.prepare(QUERIES.FIND_ORPHANED_CERTIFICADOS) as any).all();
      return (result.results || []).map((row: any) => row.id);
    } catch (error) {
      Logger.error('Error finding orphaned certificados:', error);
      return [];
    }
  }

  /**
   * Retorna contagem por tabela
   */
  async getCountByTable(): Promise<Record<string, number>> {
    try {
      const result = await (this.db.prepare(QUERIES.COUNT_BY_TABLE) as any).all();
      const counts: Record<string, number> = {};
      (result.results || []).forEach((row: any) => {
        counts[row.tabela] = row.total;
      });
      return counts;
    } catch (error) {
      Logger.error('Error fetching counts:', error);
      return {};
    }
  }
}
