import { AppError, NotFoundError } from '../utils/AppError';
import type { D1Database } from '../types/index';

/**
 * Service Base com operações comuns (CRUD)
 */

export abstract class BaseService<T> {
  protected table: string;
  protected db: D1Database;

  constructor(table: string, db: D1Database) {
    this.table = table;
    this.db = db;
  }

  /**
   * Obter todos os registros com paginação
   */
  async getAll(page: number = 1, limit: number = 50): Promise<{ data: T[]; total: number }> {
    const offset = (page - 1) * limit;

    const result = await this.db
      .prepare(`SELECT * FROM ${this.table} WHERE deleted_at IS NULL LIMIT ? OFFSET ?`)
      .bind(limit, offset)
      .all();

    const countResult = await this.db
      .prepare(`SELECT COUNT(*) as total FROM ${this.table} WHERE deleted_at IS NULL`)
      .first<{ total: number }>();

    const total = countResult?.total || 0;
    return {
      data: (result.results as T[]) || [],
      total,
    };
  }

  /**
   * Obter um registro específico pelo ID
   */
  async getById(id: number | string): Promise<T> {
    const result = await this.db
      .prepare(`SELECT * FROM ${this.table} WHERE id = ? AND deleted_at IS NULL`)
      .bind(id)
      .first();

    if (!result) {
      throw new NotFoundError(`Registro com ID ${id} não encontrado`);
    }

    return result as T;
  }

  /**
   * Obter um registro por ID

  /**
   * Criar um novo registro
   */
  async create(data: Record<string, unknown>): Promise<T> {
    const keys = Object.keys(data);
    const values = Object.values(data);
    const placeholders = keys.map(() => '?').join(',');
    const columns = keys.join(',');

    const query = `INSERT INTO ${this.table} (${columns}, created_at, updated_at) VALUES (${placeholders}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`;

    const result = await this.db
      .prepare(query)
      .bind(...values)
      .run();

    if (!result.success) {
      throw new AppError('Erro ao criar registro', 500);
    }

    // Retornar o registro criado
    return this.getById((result.meta as Record<string, unknown>).last_row_id as number);
  }

  /**
   * Atualizar um registro
   */
  async update(id: number | string, data: Record<string, unknown>): Promise<T> {
    // Verificar se existe
    await this.getById(id);

    const keys = Object.keys(data);
    const setClause = keys.map((key) => `${key} = ?`).join(',');
    const values = [...Object.values(data), id];

    const query = `UPDATE ${this.table} SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND deleted_at IS NULL`;

    const result = await this.db
      .prepare(query)
      .bind(...values)
      .run();

    if (!result.success) {
      throw new AppError('Erro ao atualizar registro', 500);
    }

    return this.getById(id);
  }

  /**
   * Deletar um registro (soft delete)
   */
  async delete(id: number | string): Promise<void> {
    // Verificar se existe
    await this.getById(id);

    const query = `UPDATE ${this.table} SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;

    const result = await this.db.prepare(query).bind(id).run();

    if (!result.success) {
      throw new AppError('Erro ao deletar registro', 500);
    }
  }

  /**
   * Obter registros com filtros personalizados
   */
  async getWithFilter(
    filter: Record<string, unknown>,
    page: number = 1,
    limit: number = 50,
  ): Promise<{ data: T[]; total: number }> {
    const offset = (page - 1) * limit;
    const keys = Object.keys(filter);
    const whereClause = keys.map((key) => `${key} = ?`).join(' AND ');
    const values = Object.values(filter);

    const query = `SELECT * FROM ${this.table} WHERE ${whereClause} AND deleted_at IS NULL LIMIT ? OFFSET ?`;
    const result = await this.db
      .prepare(query)
      .bind(...values, limit, offset)
      .all();

    const countQuery = `SELECT COUNT(*) as total FROM ${this.table} WHERE ${whereClause} AND deleted_at IS NULL`;
    const countResult = await this.db
      .prepare(countQuery)
      .bind(...values)
      .first();

    return {
      data: (result.results as T[]) || [],
      total: ((countResult as Record<string, unknown>)?.total as number) || 0,
    };
  }
}
