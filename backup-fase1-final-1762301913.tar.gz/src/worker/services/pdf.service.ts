import { PDFDocument, rgb } from 'pdf-lib';

/**
 * Service para geração de certificados PDF
 * Cria PDFs profissionais com dados da qualificação
 */
export class PDFService {
  /**
   * Gera certificado PDF com dados da qualificação
   * @param dados Dados para preenchimento do certificado
   * @returns Buffer do PDF
   */
  async gerarCertificado(dados: {
    funcionarioNome: string;
    matricula: string;
    codigoAnac?: string;
    qualificacao: string;
    tipo: string;
    dataConclusao: string;
    dataVencimento: string;
    codigo: string;
    dataGeracao?: string;
    instrutor?: string;
    local?: string;
  }): Promise<Buffer> {
    try {
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([595, 842]); // A4 size

      // Cores
      const rgb_azul = rgb(0.2, 0.4, 0.6); // #334466
      const rgb_cinza_escuro = rgb(0.3, 0.3, 0.3);
      const rgb_cinza = rgb(0.5, 0.5, 0.5);
      const rgb_branco = rgb(1, 1, 1);

      // Header
      page.drawRectangle({
        x: 0,
        y: 750,
        width: 595,
        height: 60,
        color: rgb_azul,
      });

      page.drawText('CERTIFICADO AERONAÚTICO', {
        x: 50,
        y: 770,
        size: 32,
        color: rgb_branco,
      });

      // Linha decorativa
      page.drawRectangle({
        x: 50,
        y: 730,
        width: 495,
        height: 2,
        color: rgb_azul,
      });

      // DADOS DO FUNCIONÁRIO
      const yFuncionario = 690;
      page.drawText('DADOS DO FUNCIONÁRIO', {
        x: 50,
        y: yFuncionario,
        size: 12,
        color: rgb_azul,
      });

      page.drawText(`Nome: ${dados.funcionarioNome}`, {
        x: 60,
        y: yFuncionario - 25,
        size: 11,
        color: rgb_cinza_escuro,
      });

      page.drawText(`Matrícula: ${dados.matricula}`, {
        x: 60,
        y: yFuncionario - 45,
        size: 11,
        color: rgb_cinza_escuro,
      });

      if (dados.codigoAnac) {
        page.drawText(`Código ANAC: ${dados.codigoAnac}`, {
          x: 60,
          y: yFuncionario - 65,
          size: 11,
          color: rgb_cinza_escuro,
        });
      }

      // INFORMAÇÕES DA QUALIFICAÇÃO
      const yQualificacao = yFuncionario - 120;
      page.drawText('INFORMAÇÕES DA QUALIFICAÇÃO', {
        x: 50,
        y: yQualificacao,
        size: 12,
        color: rgb_azul,
      });

      page.drawText(`Tipo: ${dados.tipo}`, {
        x: 60,
        y: yQualificacao - 25,
        size: 11,
        color: rgb_cinza_escuro,
      });

      page.drawText(`Qualificação: ${dados.qualificacao}`, {
        x: 60,
        y: yQualificacao - 45,
        size: 11,
        color: rgb_cinza_escuro,
      });

      page.drawText(`Código: ${dados.codigo}`, {
        x: 60,
        y: yQualificacao - 65,
        size: 11,
        color: rgb_cinza_escuro,
      });

      page.drawText(`Data Conclusão: ${this.formatarData(dados.dataConclusao)}`, {
        x: 60,
        y: yQualificacao - 85,
        size: 11,
        color: rgb_cinza_escuro,
      });

      page.drawText(`Data Vencimento: ${this.formatarData(dados.dataVencimento)}`, {
        x: 60,
        y: yQualificacao - 105,
        size: 11,
        color: rgb_cinza_escuro,
      });

      if (dados.instrutor) {
        page.drawText(`Instrutor: ${dados.instrutor}`, {
          x: 60,
          y: yQualificacao - 125,
          size: 11,
          color: rgb_cinza_escuro,
        });
      }

      if (dados.local) {
        page.drawText(`Local: ${dados.local}`, {
          x: 60,
          y: yQualificacao - 145,
          size: 11,
          color: rgb_cinza_escuro,
        });
      }

      // INFORMAÇÕES GERAIS
      const yInfo = 100;
      page.drawRectangle({
        x: 50,
        y: yInfo - 5,
        width: 495,
        height: 1,
        color: rgb_cinza,
      });

      page.drawText(
        `Documento gerado em: ${this.formatarDataHora(
          dados.dataGeracao ? new Date(dados.dataGeracao) : new Date(),
        )}`,
        {
          x: 60,
          y: yInfo - 20,
          size: 9,
          color: rgb_cinza,
        },
      );

      page.drawText('Este é um documento gerado automaticamente pelo sistema AirTrust.', {
        x: 60,
        y: yInfo - 35,
        size: 8,
        color: rgb_cinza,
      });

      page.drawText('Número de série: ' + this.gerarNumeroSerie(), {
        x: 60,
        y: yInfo - 50,
        size: 8,
        color: rgb_cinza,
      });

      // Converter para Buffer
      const pdfBytes = await pdfDoc.save();
      return Buffer.from(pdfBytes);
    } catch (error) {
      throw new Error(
        `Erro ao gerar PDF: ${error instanceof Error ? error.message : 'desconhecido'}`,
      );
    }
  }

  /**
   * Formata data para formato brasileiro
   * @param data Data em formato ISO ou string
   * @returns Data formatada (dd/mm/yyyy)
   */
  private formatarData(data: string): string {
    try {
      const d = new Date(data);
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      return `${day}/${month}/${year}`;
    } catch {
      return data;
    }
  }

  /**
   * Formata data e hora para formato brasileiro
   * @param data Data objeto
   * @returns Data e hora formatada (dd/mm/yyyy HH:mm:ss)
   */
  private formatarDataHora(data: Date): string {
    const day = String(data.getDate()).padStart(2, '0');
    const month = String(data.getMonth() + 1).padStart(2, '0');
    const year = data.getFullYear();
    const hours = String(data.getHours()).padStart(2, '0');
    const minutes = String(data.getMinutes()).padStart(2, '0');
    const seconds = String(data.getSeconds()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  }

  /**
   * Gera número de série único para o certificado
   * @returns Número de série (CERT-YYYYMMDDHHMMSS-RANDOM)
   */
  private gerarNumeroSerie(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `CERT-${year}${month}${day}${hours}${minutes}${seconds}-${random}`;
  }
}
