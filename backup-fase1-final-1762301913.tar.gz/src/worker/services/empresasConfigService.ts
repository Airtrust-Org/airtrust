import { BaseService } from './BaseService';
import type { EmpresaConfig, D1Database } from '../types';

export class EmpresasConfigService extends BaseService<EmpresaConfig> {
  constructor(db: D1Database) {
    super('empresa_config', db);
  }

  /**
   * Obter configuração por empresa_id
   */
  async getByEmpresaId(empresa_id: number): Promise<EmpresaConfig | null> {
    const result = await this.db
      .prepare('SELECT * FROM empresa_config WHERE empresa_id = ? AND deleted_at IS NULL')
      .bind(empresa_id)
      .first<EmpresaConfig>();
    
    return result as EmpresaConfig | null || null;
  }

  /**
   * Obter ou criar configuração padrão
   */
  async getOrCreateDefault(empresa_id: number): Promise<EmpresaConfig> {
    let config = await this.getByEmpresaId(empresa_id);
    
    if (!config) {
      // Criar configuração padrão
      const result = await this.db
        .prepare('SELECT nome FROM empresas WHERE id = ? AND deleted_at IS NULL')
        .bind(empresa_id)
        .first<{ nome: string }>();
      
      const empresaNome = (result as { nome: string } | null)?.nome || 'Empresa';
      
      config = await this.create({
        empresa_id,
        nome: empresaNome,
        cor_primaria: '#0066cc',
        cor_secundaria: '#333333',
        template_certificado: 'default',
      } as unknown as Record<string, unknown>);
    }
    
    return config;
  }

  /**
   * Atualizar configuração com INSERT OR REPLACE
   */
  async upsert(empresa_id: number, dados: Record<string, unknown>): Promise<EmpresaConfig> {
    // Primeiro tenta atualizar
    const existing = await this.getByEmpresaId(empresa_id);
    
    if (existing && existing.id) {
      return await this.update(existing.id, dados);
    } else {
      // Se não existe, cria
      return await this.create({
        empresa_id,
        ...dados,
      } as unknown as Record<string, unknown>);
    }
  }

  /**
   * Validar URL do logo
   */
  async validateLogoUrl(url: string): Promise<boolean> {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      return response.ok;
    } catch {
      return false;
    }
  }
}
