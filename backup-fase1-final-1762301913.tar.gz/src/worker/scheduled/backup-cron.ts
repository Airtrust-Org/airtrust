/**
 * Backup Automático - Cron Job
 * Executa backup diário às 3h da manhã
 */

import { Env } from '../types';
import { Logger } from '../utils/structured-logger';

export async function executeBackupCron(env: Env): Promise<void> {
  const startTime = Date.now();
  
  try {
    Logger.info('Iniciando backup automático', { scheduled: true });
    
    const { criarBackupCompleto } = await import('../utils/backup-utils');
    
    const result = await criarBackupCompleto(env, 'Backup automático diário');
    
    const duration = Date.now() - startTime;
    
    Logger.success('Backup automático concluído', {
      backup_id: result.id,
      tamanho: result.tamanho,
      duracao: duration,
      total_tabelas: result.total_tabelas,
      total_registros: result.total_registros
    });
    
    await cleanOldBackups(env);
    
  } catch (error: any) {
    Logger.error('Erro no backup automático', error);
    
    if (env.ALERT_WEBHOOK) {
      await fetch(env.ALERT_WEBHOOK, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'backup_failed',
          error: error.message,
          timestamp: new Date().toISOString()
        })
      });
    }
  }
}

async function cleanOldBackups(env: Env): Promise<void> {
  try {
    const RETENTION_DAYS = 30;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - RETENTION_DAYS);
    
    const backups = await env.BUCKET.list({ prefix: 'backup-' });
    
    let deletedCount = 0;
    for (const backup of backups.objects) {
      if (backup.uploaded && backup.uploaded < cutoffDate) {
        await env.BUCKET.delete(backup.key);
        deletedCount++;
      }
    }
    
    if (deletedCount > 0) {
      Logger.info('Backups antigos removidos', { count: deletedCount });
    }
  } catch (error: any) {
    Logger.error('Erro ao limpar backups antigos', error);
  }
}
