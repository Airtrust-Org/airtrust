import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

const mockSessoes: Record<number, any[]> = {
  100: [
    {
      id: 1,
      treinamento_id: 100,
      sessao_numero: 1,
      template_id: 1,
      template_nome: 'OPC - Operator Proficiency Check',
      nome_sessao: 'Sessão 1: Check Procedimentos IFR',
      descricao: 'Check padrão de procedimentos IFR para A320',
      ordem: 1,
      obrigatoria: 1,
      duracao_estimada_horas: 4,
      pontuacao_minima: 5,
      total_manobras: 0
    },
    {
      id: 2,
      treinamento_id: 100,
      sessao_numero: 2,
      template_id: 2,
      template_nome: 'PC - Proficiency Check',
      nome_sessao: 'Sessão 2: Emergências em Voo',
      descricao: 'Simulação de situações de emergência',
      ordem: 2,
      obrigatoria: 1,
      duracao_estimada_horas: 4,
      pontuacao_minima: 5,
      total_manobras: 0
    },
    {
      id: 3,
      treinamento_id: 100,
      sessao_numero: 3,
      template_id: 3,
      template_nome: 'PF - Pilot Flying',
      nome_sessao: 'Sessão 3: Pouso com Falha',
      descricao: 'Pouso com falha de motor simulada',
      ordem: 3,
      obrigatoria: 1,
      duracao_estimada_horas: 4,
      pontuacao_minima: 5,
      total_manobras: 0
    }
  ]
};

const mockTreinamentosSimulador = [
  {
    id: 100,
    codigo: 'SIM-SGV-001',
    nome: 'Segurança de Voo Básica - Simulador',
    categoria: 'SIMULADOR',
    descricao: 'Treinamento básico de procedimentos de segurança em simulador de voo',
    status: 'ATIVO'
  }
];

app.get('/', async (c) => {
  const treinamentoIdParam = c.req.param('treinamentoId');
  if (!treinamentoIdParam) {
    return c.json({ success: false, error: 'ID do treinamento não fornecido' }, 400);
  }
  const treinamentoId = parseInt(treinamentoIdParam);
  
  try {
    
    const treinamento = mockTreinamentosSimulador.find(t => t.id === treinamentoId);
    
    if (!treinamento) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado ou não é categoria SIMULADOR'
      }, 404);
    }
    
    const sessoes = mockSessoes[treinamentoId] || [];
    
    
    return c.json({
      success: true,
      treinamento: {
        id: treinamento.id,
        codigo: treinamento.codigo,
        nome: treinamento.nome,
        categoria: treinamento.categoria
      },
      data: sessoes,
      total: sessoes.length
    });
    
  } catch (error: any) {
    console.error('❌ Erro ao buscar sessões:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar sessões',
      details: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const treinamentoIdParam = c.req.param('treinamentoId');
  if (!treinamentoIdParam) {
    return c.json({ success: false, error: 'ID do treinamento não fornecido' }, 400);
  }
  const treinamentoId = parseInt(treinamentoIdParam);
  
  try {
    const data = await c.req.json();
    
    
    const treinamento = mockTreinamentosSimulador.find(t => t.id === treinamentoId);
    
    if (!treinamento) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado ou não é categoria SIMULADOR'
      }, 404);
    }
    
    const sessoes = mockSessoes[treinamentoId] || [];
    const novoId = Math.max(...sessoes.map(s => s.id), 0) + 1;
    
    const novaSessao = {
      id: novoId,
      treinamento_id: treinamentoId,
      sessao_numero: data.sessao_numero,
      template_id: data.template_id,
      template_nome: data.template_nome || `Template ${data.template_id}`,
      nome_sessao: data.nome_sessao,
      descricao: data.descricao || null,
      ordem: data.ordem,
      obrigatoria: data.obrigatoria !== undefined ? data.obrigatoria : 1,
      duracao_estimada_horas: data.duracao_estimada_horas || 4,
      pontuacao_minima: data.pontuacao_minima || 5,
      total_manobras: 0
    };
    
    sessoes.push(novaSessao);
    mockSessoes[treinamentoId] = sessoes;
    
    
    return c.json({
      success: true,
      id: novoId,
      message: 'Sessão adicionada ao treinamento'
    }, 201);
    
  } catch (error: any) {
    console.error('❌ Erro ao criar sessão:', error);
    return c.json({
      success: false,
      error: 'Erro ao criar sessão',
      details: error.message
    }, 500);
  }
});

app.put('/:sessaoId', async (c) => {
  const treinamentoIdParam = c.req.param('treinamentoId');
  const sessaoIdParam = c.req.param('sessaoId');
  if (!treinamentoIdParam || !sessaoIdParam) {
    return c.json({ success: false, error: 'Parâmetros inválidos' }, 400);
  }
  const treinamentoId = parseInt(treinamentoIdParam);
  const sessaoId = parseInt(sessaoIdParam);
  
  try {
    const data = await c.req.json();
    
    const sessoes = mockSessoes[treinamentoId] || [];
    const index = sessoes.findIndex(s => s.id === sessaoId);
    
    if (index === -1) {
      return c.json({
        success: false,
        error: 'Sessão não encontrada'
      }, 404);
    }
    
    sessoes[index] = {
      ...sessoes[index],
      ...data,
      id: sessaoId, // Manter ID
      treinamento_id: treinamentoId // Manter treinamento_id
    };
    
    mockSessoes[treinamentoId] = sessoes;
    
    return c.json({
      success: true,
      message: 'Sessão atualizada'
    });
    
  } catch (error: any) {
    console.error('Erro ao atualizar:', error);
    return c.json({
      success: false,
      error: 'Erro ao atualizar sessão'
    }, 500);
  }
});

app.delete('/:sessaoId', async (c) => {
  const treinamentoIdParam = c.req.param('treinamentoId');
  const sessaoIdParam = c.req.param('sessaoId');
  if (!treinamentoIdParam || !sessaoIdParam) {
    return c.json({ success: false, error: 'Parâmetros inválidos' }, 400);
  }
  const treinamentoId = parseInt(treinamentoIdParam);
  const sessaoId = parseInt(sessaoIdParam);
  
  try {
    const sessoes = mockSessoes[treinamentoId] || [];
    const index = sessoes.findIndex(s => s.id === sessaoId);
    
    if (index === -1) {
      return c.json({
        success: false,
        error: 'Sessão não encontrada'
      }, 404);
    }
    
    sessoes.splice(index, 1);
    mockSessoes[treinamentoId] = sessoes;
    
    return c.json({
      success: true,
      message: 'Sessão removida do treinamento'
    });
    
  } catch (error: any) {
    console.error('Erro ao excluir:', error);
    return c.json({
      success: false,
      error: 'Erro ao excluir sessão'
    }, 500);
  }
});

app.post('/reordenar', async (c) => {
  const treinamentoIdParam = c.req.param('treinamentoId');
  if (!treinamentoIdParam) {
    return c.json({ success: false, error: 'ID do treinamento não fornecido' }, 400);
  }
  const treinamentoId = parseInt(treinamentoIdParam);
  
  try {
    const { sessoes: novaOrdem } = await c.req.json(); // Array de { id, ordem }
    
    const sessoes = mockSessoes[treinamentoId] || [];
    
    for (const item of novaOrdem) {
      const sessao = sessoes.find(s => s.id === item.id);
      if (sessao) {
        sessao.ordem = item.ordem;
      }
    }
    
    sessoes.sort((a, b) => a.ordem - b.ordem);
    mockSessoes[treinamentoId] = sessoes;
    
    return c.json({
      success: true,
      message: 'Sessões reordenadas'
    });
    
  } catch (error: any) {
    console.error('Erro ao reordenar:', error);
    return c.json({
      success: false,
      error: 'Erro ao reordenar sessões'
    }, 500);
  }
});

export default app;
