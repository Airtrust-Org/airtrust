import { Hono } from 'hono';
import type { Env } from '../../types/env';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db
      .prepare(`
        SELECT 
          id,
          codigo,
          nome,
          descricao,
          categoria,
          tipo,
          nivel_dificuldade,
          tempo_estimado,
          pontuacao_maxima,
          observacoes,
          created_at,
          updated_at
        FROM manobras
        WHERE deleted_at IS NULL
        ORDER BY codigo ASC
      `)
      .bind()
      .all();

    return c.json({
      success: true,
      data: results || []
    });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao listar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao listar manobras' 
    }, 500);
  }
});

app.get('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    const manobra = await db
      .prepare(`
        SELECT 
          id, codigo, nome, descricao, categoria, tipo,
          nivel_dificuldade, tempo_estimado, pontuacao_maxima,
          observacoes, created_at, updated_at
        FROM manobras
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(id)
      .first();

    if (!manobra) {
      return c.json({ success: false, error: 'Manobra não encontrada' }, 404);
    }

    return c.json({ success: true, data: manobra });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao buscar:', error);
    return c.json({ success: false, error: 'Erro ao buscar manobra' }, 500);
  }
});

app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();
    
    const { codigo, nome, descricao, categoria, tipo, nivel_dificuldade, tempo_estimado, pontuacao_maxima, observacoes } = body;
    
    if (!codigo || !nome) {
      return c.json({ success: false, error: 'Código e nome são obrigatórios' }, 400);
    }
    
    const result = await db
      .prepare(`
        INSERT INTO manobras (
          codigo, nome, descricao, categoria, tipo,
          nivel_dificuldade, tempo_estimado, pontuacao_maxima,
          observacoes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `)
      .bind(codigo, nome, descricao || null, categoria || null, tipo || null,
            nivel_dificuldade || null, tempo_estimado || null, pontuacao_maxima || null,
            observacoes || null)
      .run();
    
    return c.json({
      success: true,
      message: 'Manobra criada com sucesso',
      data: { id: result.meta.last_row_id }
    });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao criar:', error);
    return c.json({ success: false, error: 'Erro ao criar manobra' }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const { codigo, nome, descricao, categoria, tipo, nivel_dificuldade, tempo_estimado, pontuacao_maxima, observacoes } = body;
    
    await db
      .prepare(`
        UPDATE manobras
        SET codigo = ?, nome = ?, descricao = ?, categoria = ?, tipo = ?,
            nivel_dificuldade = ?, tempo_estimado = ?, pontuacao_maxima = ?,
            observacoes = ?, updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(codigo, nome, descricao || null, categoria || null, tipo || null,
            nivel_dificuldade || null, tempo_estimado || null, pontuacao_maxima || null,
            observacoes || null, id)
      .run();
    
    return c.json({
      success: true,
      message: 'Manobra atualizada com sucesso'
    });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao atualizar:', error);
    return c.json({ success: false, error: 'Erro ao atualizar manobra' }, 500);
  }
});

app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    await db
      .prepare(`
        UPDATE manobras
        SET deleted_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(id)
      .run();
    
    return c.json({
      success: true,
      message: 'Manobra removida com sucesso'
    });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao deletar:', error);
    return c.json({ success: false, error: 'Erro ao deletar manobra' }, 500);
  }
});

app.get('/categorias', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db
      .prepare(`
        SELECT DISTINCT 
          categoria as nome,
          categoria as id
        FROM manobras
        WHERE deleted_at IS NULL AND categoria IS NOT NULL
        ORDER BY categoria ASC
      `)
      .bind()
      .all();

    return c.json({
      success: true,
      data: results || []
    });
  } catch (error: any) {
    Logger.error('[MANOBRAS] Erro ao listar categorias:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao listar categorias' 
    }, 500);
  }
});

export default app;
