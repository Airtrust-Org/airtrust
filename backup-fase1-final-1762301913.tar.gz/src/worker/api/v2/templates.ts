import { Hono } from 'hono';
import type { Env } from '../../types/index';

const app = new Hono<{ Bindings: Env }>();

// GET / - Listar todos os templates
app.get('/', async (c) => {
  try {
    const db = c.env.DB;

    const result = await db
      .prepare(
        `
      SELECT 
        id, codigo, nome, tipo, descricao, duracao_minutos,
        ativo, created_at, updated_at
      FROM sessoes_template
      ORDER BY nome ASC
    `,
      )
      .all();

    return c.json({
      success: true,
      data: result.results || [],
      total: (result.results || []).length,
    });
  } catch (error: any) {
    console.error('[TEMPLATE] Erro ao listar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

// GET /:id - Detalhe de um template
app.get('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');

    const template = await db
      .prepare(
        `
      SELECT 
        id, codigo, nome, tipo, descricao, duracao_minutos,
        ativo, created_at, updated_at
      FROM sessoes_template
      WHERE id = ?
    `,
      )
      .bind(id)
      .first();

    if (!template) {
      return c.json({ success: false, error: 'Template não encontrado' }, 404);
    }

    return c.json({ success: true, data: template });
  } catch (error: any) {
    console.error('[TEMPLATE] Erro ao buscar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const {
      codigo,
      nome,
      tipo,
      descricao,
      duracao_minutos,
      ativo,
      manobras, // Array de IDs
    } = body;

    if (!nome || !tipo || !manobras || manobras.length === 0) {
      return c.json(
        {
          success: false,
          error: 'Campos obrigatórios: nome, tipo, manobras',
        },
        400,
      );
    }

    await db
      .prepare(
        `
      INSERT INTO sessoes_template (
        codigo, nome, tipo, descricao, duracao_minutos, ativo,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `,
      )
      .bind(codigo, nome, tipo, descricao || null, duracao_minutos || 120, ativo ? 1 : 0)
      .run();

    const template = await db
      .prepare(
        `
      SELECT id FROM sessoes_template WHERE nome = ? ORDER BY id DESC LIMIT 1
    `,
      )
      .bind(nome)
      .first();

    if (!template) {
      throw new Error('Erro ao buscar template criado');
    }

    const templateId = template.id;

    for (let i = 0; i < manobras.length; i++) {
      await db
        .prepare(
          `
        INSERT INTO template_manobras (
          template_id, manobra_id, ordem, obrigatoria, created_at
        ) VALUES (?, ?, ?, 1, datetime('now'))
      `,
        )
        .bind(templateId, manobras[i], i + 1)
        .run();
    }

    return c.json({
      success: true,
      message: 'Template criado com sucesso',
      data: { id: templateId },
    });
  } catch (error: any) {
    console.error('[TEMPLATE] Erro ao criar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();

    const { codigo, nome, tipo, descricao, duracao_minutos, ativo, manobras } = body;

    await db
      .prepare(
        `
      UPDATE sessoes_template
      SET codigo = ?, nome = ?, tipo = ?, descricao = ?,
          duracao_minutos = ?, ativo = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `,
      )
      .bind(codigo, nome, tipo, descricao || null, duracao_minutos || 120, ativo ? 1 : 0, id)
      .run();

    if (manobras && Array.isArray(manobras)) {
      await db
        .prepare(
          `
        DELETE FROM template_manobras WHERE template_id = ?
      `,
        )
        .bind(id)
        .run();

      for (let i = 0; i < manobras.length; i++) {
        await db
          .prepare(
            `
          INSERT INTO template_manobras (
            template_id, manobra_id, ordem, obrigatoria, created_at
          ) VALUES (?, ?, ?, 1, datetime('now'))
        `,
          )
          .bind(id, manobras[i], i + 1)
          .run();
      }
    }

    return c.json({
      success: true,
      message: 'Template atualizado com sucesso',
    });
  } catch (error: any) {
    console.error('[TEMPLATE] Erro ao atualizar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.get('/:id/manobras', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');

    const result = await db
      .prepare(
        `
      SELECT 
        tm.manobra_id,
        tm.ordem,
        m.nome,
        m.codigo,
        m.categoria
      FROM template_manobras tm
      JOIN manobras m ON tm.manobra_id = m.id
      WHERE tm.template_id = ?
      ORDER BY tm.ordem
    `,
      )
      .bind(id)
      .all();

    return c.json({
      success: true,
      data: result.results || [],
    });
  } catch (error: any) {
    console.error('[TEMPLATE] Erro ao buscar manobras:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default app;
