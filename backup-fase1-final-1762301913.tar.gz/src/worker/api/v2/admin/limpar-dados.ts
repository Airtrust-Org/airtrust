
import { Hono } from 'hono';
import { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

const apenasAdmin = async (c: any, next: any) => {
  return next();
};

app.get('/contadores', apenasAdmin, async (c) => {
  try {
    const db = c.env.DB;
    
    const contadores = {
      funcionarios: 0,
      qualificacoes: 0,
      treinamentos: 0,
      funcoes: 0,
      aeronaves: 0,
      setores: 0,
      auditoria: 0,
      importacoes: 0
    };
    
    const funcResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL
    `) as any).first();
    contadores.funcionarios = funcResult?.total || 0;
    
    const qualResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM qualificacoes WHERE deleted_at IS NULL
    `) as any).first();
    contadores.qualificacoes = qualResult?.total || 0;
    
    const treinResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM treinamentos WHERE deleted_at IS NULL
    `) as any).first();
    contadores.treinamentos = treinResult?.total || 0;
    
    const funcaoResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM funcoes WHERE deleted_at IS NULL
    `) as any).first();
    contadores.funcoes = funcaoResult?.total || 0;
    
    const aeroResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM aeronaves WHERE deleted_at IS NULL
    `) as any).first();
    contadores.aeronaves = aeroResult?.total || 0;
    
    const setorResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM setores WHERE deleted_at IS NULL
    `) as any).first();
    contadores.setores = setorResult?.total || 0;
    
    const auditResult = await (db.prepare(`
      SELECT COUNT(*) as total FROM auditoria
    `) as any).first();
    contadores.auditoria = auditResult?.total || 0;
    
    try {
      const importResult = await (db.prepare(`
        SELECT COUNT(*) as total FROM importacoes_log WHERE deleted_at IS NULL
      `) as any).first();
      contadores.importacoes = importResult?.total || 0;
    } catch {
      contadores.importacoes = 0;
    }
    
    return c.json({
      success: true,
      data: contadores
    });
    
  } catch (error) {
    console.error('Erro ao contar registros:', error);
    return c.json({
      success: false,
      error: 'Erro ao contar registros'
    }, 500);
  }
});

app.post('/:modulo', apenasAdmin, async (c) => {
  try {
    const modulo = c.req.param('modulo');
    const body = await c.req.json();
    const { confirmacao, usuario_id } = body;
    
    if (confirmacao !== 'LIMPAR DADOS') {
      return c.json({
        success: false,
        error: 'Confirmação inválida. Digite exatamente: LIMPAR DADOS'
      }, 400);
    }
    
    const db = c.env.DB;
    const now = new Date().toISOString();
    let registrosAfetados = 0;
    let detalhes = '';
    
    if (modulo === 'funcionarios') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE funcionarios 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      try {
        await (db.prepare(`
          UPDATE funcionarios_aeronaves 
          SET deleted_at = ?, updated_at = ?
          WHERE deleted_at IS NULL
        `) as any).bind(now, now).run();
      } catch {}
      
      detalhes = `${registrosAfetados} funcionários removidos`;
    }
    
    else if (modulo === 'qualificacoes') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM qualificacoes WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE qualificacoes 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      detalhes = `${registrosAfetados} qualificações removidas`;
    }
    
    else if (modulo === 'treinamentos') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM treinamentos WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE treinamentos 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      detalhes = `${registrosAfetados} treinamentos do catálogo removidos`;
    }
    
    else if (modulo === 'funcoes') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM funcoes WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE funcoes 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      detalhes = `${registrosAfetados} funções removidas`;
    }
    
    else if (modulo === 'aeronaves') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM aeronaves WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE aeronaves 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      detalhes = `${registrosAfetados} aeronaves removidas`;
    }
    
    else if (modulo === 'setores') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM setores WHERE deleted_at IS NULL
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        UPDATE setores 
        SET deleted_at = ?, updated_at = ?
        WHERE deleted_at IS NULL
      `) as any).bind(now, now).run();
      
      detalhes = `${registrosAfetados} setores removidos`;
    }
    
    else if (modulo === 'auditoria') {
      const antes = await (db.prepare(`
        SELECT COUNT(*) as total FROM auditoria WHERE created_at < date('now', '-30 days')
      `) as any).first();
      registrosAfetados = antes?.total || 0;
      
      await (db.prepare(`
        DELETE FROM auditoria 
        WHERE created_at < date('now', '-30 days')
      `) as any).run();
      
      detalhes = `${registrosAfetados} registros de auditoria removidos (mantidos últimos 30 dias)`;
    }
    
    else if (modulo === 'importacoes') {
      try {
        const antes = await (db.prepare(`
          SELECT COUNT(*) as total FROM importacoes_log WHERE deleted_at IS NULL
        `) as any).first();
        registrosAfetados = antes?.total || 0;
        
        await (db.prepare(`
          UPDATE importacoes_log 
          SET deleted_at = ?, updated_at = ?
          WHERE deleted_at IS NULL
        `) as any).bind(now, now).run();
        
        detalhes = `${registrosAfetados} logs de importação removidos`;
      } catch {
        detalhes = 'Tabela de importações não existe';
      }
    }
    
    else if (modulo === 'tudo') {
      const funcCount = await (db.prepare(`SELECT COUNT(*) as t FROM funcionarios WHERE deleted_at IS NULL`) as any).first();
      const qualCount = await (db.prepare(`SELECT COUNT(*) as t FROM qualificacoes WHERE deleted_at IS NULL`) as any).first();
      const treinCount = await (db.prepare(`SELECT COUNT(*) as t FROM treinamentos WHERE deleted_at IS NULL`) as any).first();
      
      registrosAfetados = (funcCount?.t || 0) + (qualCount?.t || 0) + (treinCount?.t || 0);
      
      await (db.prepare(`UPDATE qualificacoes SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      await (db.prepare(`UPDATE funcionarios SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      await (db.prepare(`UPDATE treinamentos SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      await (db.prepare(`UPDATE funcoes SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      await (db.prepare(`UPDATE aeronaves SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      await (db.prepare(`UPDATE setores SET deleted_at = ?, updated_at = ? WHERE deleted_at IS NULL`) as any).bind(now, now).run();
      
      detalhes = `TODOS OS DADOS REMOVIDOS: ${registrosAfetados}+ registros`;
    }
    
    else {
      return c.json({
        success: false,
        error: `Módulo inválido: ${modulo}` 
      }, 400);
    }
    
    try {
      await (db.prepare(`
        INSERT INTO auditoria 
        (acao, recurso, usuario_id, detalhes, created_at)
        VALUES (?, ?, ?, ?, ?)
      `) as any).bind(
        'DELETE_BULK',
        modulo,
        usuario_id || null,
        JSON.stringify({ 
          modulo, 
          registrosAfetados,
          detalhes,
          confirmacao 
        }),
        now
      ).run();
    } catch (error) {
      console.error('Erro ao registrar auditoria:', error);
    }
    
    return c.json({
      success: true,
      message: `Dados do módulo '${modulo}' limpos com sucesso`,
      data: {
        modulo,
        registrosAfetados,
        detalhes
      }
    });
    
  } catch (error) {
    console.error('Erro ao limpar dados:', error);
    return c.json({
      success: false,
      error: 'Erro ao limpar dados',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default app;
