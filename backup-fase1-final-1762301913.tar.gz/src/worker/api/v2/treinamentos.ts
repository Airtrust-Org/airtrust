import { Hono } from 'hono';
import sessoesRouter from './treinamentos/sessoes';

const treinamentosApi = new Hono<{ Bindings: Env }>();

const mockTreinamentosCompletos = [
  {
    id: 1,
    codigo: 'SGV-001',
    nome: 'Segurança de Voo Básica',
    categoria: 'SEGURANÇA',
    total_sessoes: 3,
    periodicidade_meses: 12,
    descricao: 'Treinamento fundamental sobre procedimentos de segurança de voo, análise de riscos e prevenção de acidentes',
    instrutor_responsavel: 'Cmt. Carlos Alberto Silva',
    certificacao_relacionada: 'CERT-SGV-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 2,
    codigo: 'CRM-001',
    nome: 'Crew Resource Management',
    categoria: 'OPERACIONAL',
    total_sessoes: 3,
    periodicidade_meses: 24,
    descricao: 'Gerenciamento de recursos da tripulação, comunicação eficaz e trabalho em equipe',
    instrutor_responsavel: 'Cap. Marina Santos',
    certificacao_relacionada: 'CERT-CRM-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 3,
    codigo: 'SMS-001',
    nome: 'Safety Management System',
    categoria: 'COMPLIANCE',
    total_sessoes: 2,
    periodicidade_meses: 36,
    descricao: 'Sistema de Gerenciamento de Segurança Operacional conforme RBAC 119',
    instrutor_responsavel: 'Eng. Roberto Lima',
    certificacao_relacionada: 'CERT-SMS-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 4,
    codigo: 'EMG-001',
    nome: 'Procedimentos de Emergência',
    categoria: 'EMERGÊNCIA',
    total_sessoes: 2,
    periodicidade_meses: 6,
    descricao: 'Procedimentos de emergência em voo, evacuação de aeronave e primeiros socorros',
    instrutor_responsavel: 'Cap. Fernanda Costa',
    certificacao_relacionada: 'CERT-EMG-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 5,
    codigo: 'MNT-001',
    nome: 'Manutenção Preventiva',
    categoria: 'MANUTENÇÃO',
    total_sessoes: 1,
    periodicidade_meses: 12,
    descricao: 'Procedimentos de manutenção preventiva e inspeções programadas',
    instrutor_responsavel: 'Eng. Paulo Mendes',
    certificacao_relacionada: 'CERT-MNT-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 6,
    codigo: 'CMA',
    nome: 'Certificado Médico Aeronáutico',
    categoria: 'LICENCA_MEDICA',
    total_sessoes: 1,
    periodicidade_meses: 12,
    descricao: 'Certificado médico aeronáutico obrigatório para pilotos e mecânicos',
    instrutor_responsavel: 'Dr. Ana Beatriz',
    certificacao_relacionada: 'CERT-CMA-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 7,
    codigo: 'ASO',
    nome: 'Atestado de Saúde Ocupacional',
    categoria: 'LICENCA_MEDICA',
    total_sessoes: 1,
    periodicidade_meses: 12,
    descricao: 'Atestado de saúde ocupacional conforme NR-7',
    instrutor_responsavel: 'Dr. José Carlos',
    certificacao_relacionada: 'CERT-ASO-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 8,
    codigo: 'ICAO',
    nome: 'Nível de Inglês ICAO',
    categoria: 'PROFICIENCIA',
    total_sessoes: 1,
    periodicidade_meses: 36,
    descricao: 'Proficiência em inglês aeronáutico conforme padrões ICAO',
    instrutor_responsavel: 'Prof. Sarah Johnson',
    certificacao_relacionada: 'CERT-ICAO-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 12,
    codigo: 'REC-A',
    nome: 'Recorrente A',
    categoria: 'SIMULADOR',
    total_sessoes: 2,
    periodicidade_meses: 6,
    descricao: 'Treinamento recorrente tipo A em simulador de voo',
    instrutor_responsavel: 'Cmt. Ricardo Alves',
    certificacao_relacionada: 'CERT-REC-A',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 13,
    codigo: 'CHK-B',
    nome: 'Check B',
    categoria: 'SIMULADOR',
    total_sessoes: 2,
    periodicidade_meses: 12,
    descricao: 'Check de proficiência tipo B em simulador de voo',
    instrutor_responsavel: 'Cap. Luciano Fernandes',
    certificacao_relacionada: 'CERT-CHK-B',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  },
  {
    id: 100,
    codigo: 'SIM-SGV-001',
    nome: 'Segurança de Voo Básica - Simulador',
    categoria: 'SIMULADOR',
    total_sessoes: 3,
    periodicidade_meses: 12,
    descricao: 'Treinamento básico de procedimentos de segurança em simulador de voo',
    instrutor_responsavel: 'Cmt. Carlos Alberto Silva',
    certificacao_relacionada: 'CERT-SIM-SGV-001',
    status: 'ATIVO',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z'
  }
];

function obterTreinamentosMock() {
  return mockTreinamentosCompletos.map(t => ({ ...t }));
}

treinamentosApi.get('/', async (c) => {
  try {
    
    const treinamentos = obterTreinamentosMock();
    
    return c.json({
      success: true,
      data: treinamentos,
      total: treinamentos.length,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao listar treinamentos',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.get('/listar', async (c) => {
  try {
    
    const treinamentos = obterTreinamentosMock();
    
    return c.json({
      success: true,
      data: treinamentos,
      total: treinamentos.length,
      from_legacy_endpoint: true,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro interno do servidor',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.get('/:id', async (c) => {
  try {
    const { id } = c.req.param();
    const treinamentoId = parseInt(id);
    
    if (isNaN(treinamentoId)) {
      return c.json({
        success: false,
        error: 'ID do treinamento inválido',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const treinamentos = obterTreinamentosMock();
    const treinamento = treinamentos.find(t => t.id === treinamentoId);
    
    if (!treinamento) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado',
        timestamp: new Date().toISOString()
      }, 404);
    }
    
    const treinamentoDetalhado = {
      ...treinamento,
      sessoes: [],
      participantes_ativos: Math.floor(Math.random() * 20) + 5,
      ultima_realizacao: '2024-01-10T14:30:00Z',
      proxima_realizacao: '2024-02-15T09:00:00Z'
    };
    
    return c.json({
      success: true,
      data: treinamentoDetalhado,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao buscar treinamento',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.post('/', async (c) => {
  try {
    const dados = await c.req.json();
    
    if (!dados.nome || !dados.categoria) {
      return c.json({
        success: false,
        error: 'Nome e categoria são obrigatórios',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const novoTreinamento = {
      id: Date.now(),
      codigo: dados.codigo || `TRN-${Date.now()}`,
      nome: dados.nome,
      categoria: dados.categoria,
      total_sessoes: dados.total_sessoes || 1,
      periodicidade_meses: dados.periodicidade_meses || 12,
      descricao: dados.descricao || '',
      instrutor_responsavel: dados.instrutor_responsavel || 'A definir',
      certificacao_relacionada: dados.certificacao_relacionada || '',
      status: 'ATIVO',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    mockTreinamentosCompletos.push(novoTreinamento);
    
    return c.json({
      success: true,
      data: novoTreinamento,
      message: 'Treinamento criado com sucesso',
      timestamp: new Date().toISOString()
    }, 201);
    
  } catch (error) {
    Logger.error('❌ Erro ao criar treinamento:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao criar treinamento',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.put('/:id', async (c) => {
  try {
    const { id } = c.req.param();
    const treinamentoId = parseInt(id);
    const dados = await c.req.json();
    
    if (isNaN(treinamentoId)) {
      return c.json({
        success: false,
        error: 'ID do treinamento inválido',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const index = mockTreinamentosCompletos.findIndex(t => t.id === treinamentoId);
    
    if (index === -1) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado',
        timestamp: new Date().toISOString()
      }, 404);
    }
    
    const treinamentoAtualizado = {
      ...mockTreinamentosCompletos[index],
      ...dados,
      id: treinamentoId, // Manter ID original
      updated_at: new Date().toISOString()
    };
    
    mockTreinamentosCompletos[index] = treinamentoAtualizado;
    
    return c.json({
      success: true,
      data: treinamentoAtualizado,
      message: 'Treinamento atualizado com sucesso',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    Logger.error('❌ Erro ao atualizar treinamento:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao atualizar treinamento',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.delete('/:id', async (c) => {
  try {
    const { id } = c.req.param();
    const treinamentoId = parseInt(id);
    
    if (isNaN(treinamentoId)) {
      return c.json({
        success: false,
        error: 'ID do treinamento inválido',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const index = mockTreinamentosCompletos.findIndex(t => t.id === treinamentoId);
    
    if (index === -1) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado',
        timestamp: new Date().toISOString()
      }, 404);
    }
    
    const treinamentoExcluido = mockTreinamentosCompletos[index];
    mockTreinamentosCompletos.splice(index, 1);
    
    return c.json({
      success: true,
      data: treinamentoExcluido,
      message: 'Treinamento excluído com sucesso',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    Logger.error('❌ Erro ao excluir treinamento:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao excluir treinamento',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.get('/:id/sessoes', async (c) => {
  try {
    const { id } = c.req.param();
    const treinamentoId = parseInt(id);
    
    if (isNaN(treinamentoId)) {
      return c.json({
        success: false,
        error: 'ID do treinamento inválido',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const treinamentos = obterTreinamentosMock();
    const treinamento = treinamentos.find(t => t.id === treinamentoId);
    
    if (!treinamento) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado',
        timestamp: new Date().toISOString()
      }, 404);
    }
    
    const sessoesMock = [];
    for (let i = 1; i <= treinamento.total_sessoes; i++) {
      sessoesMock.push({
        id: i,
        numero_sessao: i,
        nome: `Sessão ${i} - ${treinamento.nome}`,
        descricao: `Descrição da sessão ${i} do treinamento ${treinamento.nome}`,
        duracao_minutos: 120,
        status: 'ATIVA'
      });
    }
    
    return c.json({
      success: true,
      data: sessoesMock,
      total: sessoesMock.length,
      treinamento: treinamento,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    Logger.error('❌ Erro ao buscar sessões:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao buscar sessões',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

treinamentosApi.route('/:treinamentoId/sessoes', sessoesRouter);

treinamentosApi.post('/:id/agendar', async (c) => {
  try {
    const { id } = c.req.param();
    const treinamentoId = parseInt(id);
    const dados = await c.req.json();
    
    if (isNaN(treinamentoId)) {
      return c.json({
        success: false,
        error: 'ID do treinamento inválido',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const treinamentos = obterTreinamentosMock();
    const treinamento = treinamentos.find(t => t.id === treinamentoId);
    
    if (!treinamento) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado',
        timestamp: new Date().toISOString()
      }, 404);
    }
    
    if (!dados.data_inicio || !dados.participantes) {
      return c.json({
        success: false,
        error: 'Data de início e participantes são obrigatórios',
        timestamp: new Date().toISOString()
      }, 400);
    }
    
    const agendamento = {
      id: Date.now(),
      treinamento_id: treinamentoId,
      treinamento_nome: treinamento.nome,
      data_inicio: dados.data_inicio,
      data_fim: dados.data_fim,
      participantes: dados.participantes || [],
      instrutor: dados.instrutor || 'A definir',
      local: dados.local || 'Sala de treinamento',
      status: 'AGENDADO',
      created_at: new Date().toISOString()
    };
    
    return c.json({
      success: true,
      data: agendamento,
      message: 'Sessão agendada com sucesso',
      timestamp: new Date().toISOString()
    }, 201);
    
  } catch (error) {
    Logger.error('❌ Erro ao agendar sessão:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor ao agendar sessão',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

export default treinamentosApi;
