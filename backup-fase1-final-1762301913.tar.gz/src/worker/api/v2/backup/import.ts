import { Hono } from 'hono';
interface Env {
  DB: any;
  BUCKET?: any;
  ENVIRONMENT?: string;
  _schema_synced?: boolean;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_BUCKET_NAME?: string;
  R2_ENDPOINT?: string;
  CLOUDFLARE_API_TOKEN?: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;
  [key: string]: any;
}

const app = new Hono<{ Bindings: Env }>();

async function validarChecksum(dados: any): Promise<boolean> {
  try {
    const { metadata, ...dadosSemMetadata } = dados;
    
    const { checksum, ...metadataSemChecksum } = metadata;
    
    const dadosParaChecksum = { metadata: metadataSemChecksum, ...dadosSemMetadata };
    
    const dataStr = JSON.stringify(dadosParaChecksum);
    const encoder = new TextEncoder();
    const data = encoder.encode(dataStr);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const calculatedChecksum = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    console.log('🔍 Validação checksum:', {
      recebido: checksum?.substring(0, 8) + '...',
      calculado: calculatedChecksum.substring(0, 8) + '...',
      igual: calculatedChecksum === checksum
    });
    
    return calculatedChecksum === checksum;
  } catch (error) {
    console.error('Erro ao validar checksum:', error);
    return false;
  }
}

async function detectarConflitos(db: any, dados: any): Promise<any[]> {
  const conflitos = [];

  try {
    if (dados.funcionarios) {
      for (const funcionario of dados.funcionarios) {
        if (funcionario.matricula) {
          const existente = await db.prepare(`
            SELECT id, nome, matricula FROM funcionarios 
            WHERE matricula = ? AND deleted_at IS NULL
          `).bind(funcionario.matricula).first();

          if (existente && existente.nome !== funcionario.nome) {
            conflitos.push({
              tipo: 'Funcionário Duplicado',
              campo: 'matricula',
              valor: funcionario.matricula,
              descricao: `Funcionário com matrícula ${funcionario.matricula} já existe com nome diferente`,
              valor_existente: existente.nome,
              valor_importacao: funcionario.nome,
              acao_sugerida: 'Atualizar dados existentes'
            });
          }
        }
      }
    }

    if (dados.treinamentos?.catalogo) {
      for (const treinamento of dados.treinamentos.catalogo) {
        if (treinamento.codigo) {
          const existente = await db.prepare(`
            SELECT id, nome, codigo FROM catalogo_treinamentos_v2 
            WHERE codigo = ? AND deleted_at IS NULL
          `).bind(treinamento.codigo).first();

          if (existente && existente.nome !== treinamento.nome) {
            conflitos.push({
              tipo: 'Treinamento Duplicado',
              campo: 'codigo',
              valor: treinamento.codigo,
              descricao: `Treinamento com código ${treinamento.codigo} já existe com nome diferente`,
              valor_existente: existente.nome,
              valor_importacao: treinamento.nome,
              acao_sugerida: 'Manter existente ou atualizar'
            });
          }
        }
      }
    }

    if (dados.configuracoes?.simuladores) {
      for (const simulador of dados.configuracoes.simuladores) {
        if (simulador.codigo_identificacao) {
          const existente = await db.prepare(`
            SELECT id, nome, codigo_identificacao FROM simuladores 
            WHERE codigo_identificacao = ? AND deleted_at IS NULL
          `).bind(simulador.codigo_identificacao).first();

          if (existente && existente.nome !== simulador.nome) {
            conflitos.push({
              tipo: 'Simulador Duplicado',
              campo: 'codigo_identificacao',
              valor: simulador.codigo_identificacao,
              descricao: `Simulador com código ${simulador.codigo_identificacao} já existe com nome diferente`,
              valor_existente: existente.nome,
              valor_importacao: simulador.nome,
              acao_sugerida: 'Manter existente ou atualizar'
            });
          }
        }
      }
    }

    if (dados.metadata?.version) {
      const versaoSistema = "1.0.0"; // Versão atual do sistema
      if (dados.metadata.version !== versaoSistema) {
        conflitos.push({
          tipo: 'Incompatibilidade de Versão',
          campo: 'version',
          valor: dados.metadata.version,
          descricao: `Backup criado na versão ${dados.metadata.version}, sistema atual é ${versaoSistema}`,
          valor_existente: versaoSistema,
          valor_importacao: dados.metadata.version,
          acao_sugerida: 'Verificar compatibilidade antes de prosseguir'
        });
      }
    }

  } catch (error) {
    console.error('Erro ao detectar conflitos:', error);
  }

  return conflitos;
}

async function criarBackupSeguranca(db: any): Promise<void> {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    
    await db.prepare(`
      CREATE TEMP TABLE IF NOT EXISTS backup_seguranca_${timestamp.slice(0, 10)} AS 
      SELECT 'funcionarios' as tabela, COUNT(*) as registros 
      FROM funcionarios WHERE deleted_at IS NULL
    `).run();

  } catch (error) {
    console.error('⚠️ Erro ao criar backup de segurança:', error);
  }
}

async function importarFuncionarios(db: any, funcionarios: any[]): Promise<number> {
  let importados = 0;

  for (const funcionario of funcionarios) {
    try {
      const existente = await db.prepare(`
        SELECT id FROM funcionarios 
        WHERE matricula = ? AND deleted_at IS NULL
      `).bind(funcionario.matricula).first();

      if (existente) {
        await db.prepare(`
          UPDATE funcionarios SET
            nome = ?, cpf = ?, codigo_anac = ?, funcao = ?, base = ?,
            contrato = ?, telefone = ?, email = ?, status = ?,
            cma_numero = ?, cma_data_vencimento = ?, cma_status = ?,
            aso_data_vencimento = ?, nivel_icao = ?, nivel_icao_data_vencimento = ?,
            nivel_icao_status = ?, is_instrutor = ?, is_checador = ?,
            aeronave_principal = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(
          funcionario.nome, funcionario.cpf, funcionario.codigo_anac,
          funcionario.funcao, funcionario.base, funcionario.contrato,
          funcionario.telefone, funcionario.email, funcionario.status,
          funcionario.cma_numero, funcionario.cma_data_vencimento,
          funcionario.cma_status, funcionario.aso_data_vencimento,
          funcionario.nivel_icao, funcionario.nivel_icao_data_vencimento,
          funcionario.nivel_icao_status, funcionario.is_instrutor,
          funcionario.is_checador, funcionario.aeronave_principal,
          existente.id
        ).run();
      } else {
        await db.prepare(`
          INSERT INTO funcionarios (
            nome, matricula, cpf, codigo_anac, funcao, base, contrato,
            telefone, email, status, cma_numero, cma_data_vencimento,
            cma_status, aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento,
            nivel_icao_status, is_instrutor, is_checador, aeronave_principal,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `).bind(
          funcionario.nome, funcionario.matricula, funcionario.cpf,
          funcionario.codigo_anac, funcionario.funcao, funcionario.base,
          funcionario.contrato, funcionario.telefone, funcionario.email,
          funcionario.status, funcionario.cma_numero, funcionario.cma_data_vencimento,
          funcionario.cma_status, funcionario.aso_data_vencimento,
          funcionario.nivel_icao, funcionario.nivel_icao_data_vencimento,
          funcionario.nivel_icao_status, funcionario.is_instrutor,
          funcionario.is_checador, funcionario.aeronave_principal
        ).run();
      }

      importados++;
    } catch (error) {
      console.error(`Erro ao importar funcionário ${funcionario.matricula}:`, error);
    }
  }

  return importados;
}

async function importarSimuladores(db: any, simuladores: any): Promise<number> {
  let importados = 0;

  try {
    if (simuladores.manobras) {
      for (const manobra of simuladores.manobras) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO manobras_catalogo (
              manobra_id_codigo, nome_manobra, descricao_detalhada,
              categoria, criterios_aprovacao, pontuacao_minima,
              ativo, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            manobra.manobra_id_codigo, manobra.nome_manobra,
            manobra.descricao_detalhada, manobra.categoria,
            manobra.criterios_aprovacao, manobra.pontuacao_minima,
            manobra.ativo
          ).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar manobra ${manobra.manobra_id_codigo}:`, error);
        }
      }
    }

    if (simuladores.sessoes) {
      for (const sessao of simuladores.sessoes) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO sessoes_template (
              treinamento_codigo, numero_sessao, nome_sessao,
              descricao, created_at, updated_at
            ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            sessao.treinamento_codigo, sessao.numero_sessao,
            sessao.nome_sessao, sessao.descricao
          ).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar sessão template ${sessao.id}:`, error);
        }
      }
    }

  } catch (error) {
    console.error('Erro ao importar simuladores:', error);
  }

  return importados;
}

async function importarTreinamentos(db: any, treinamentos: any): Promise<number> {
  let importados = 0;

  try {
    if (treinamentos.catalogo) {
      for (const item of treinamentos.catalogo) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO catalogo_treinamentos_v2 (
              codigo, nome, descricao, categoria, periodicidade_meses,
              instrutor_obrigatorio, nota_minima, carga_horaria,
              ativo, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            item.codigo, item.nome, item.descricao, item.categoria,
            item.periodicidade_meses, item.instrutor_obrigatorio,
            item.nota_minima, item.carga_horaria, item.ativo
          ).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar treinamento ${item.codigo}:`, error);
        }
      }
    }

    if (treinamentos.certificacoes) {
      for (const cert of treinamentos.certificacoes) {
        try {
          const funcionario = await db.prepare(`
            SELECT id FROM funcionarios WHERE matricula = ?
          `).bind(cert.funcionario_matricula).first();

          const treinamento = await db.prepare(`
            SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ?
          `).bind(cert.treinamento_codigo).first();

          if (funcionario && treinamento) {
            await db.prepare(`
              INSERT OR REPLACE INTO historico_certificacoes_v2 (
                funcionario_id, treinamento_id, data_conclusao,
                data_vencimento, instrutor, nota, observacoes,
                status, created_at, updated_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            `).bind(
              funcionario.id, treinamento.id, cert.data_conclusao,
              cert.data_vencimento, cert.instrutor, cert.nota,
              cert.observacoes, cert.status
            ).run();
            importados++;
          }
        } catch (error) {
          console.error(`Erro ao importar certificação:`, error);
        }
      }
    }

  } catch (error) {
    console.error('Erro ao importar treinamentos:', error);
  }

  return importados;
}

async function importarConfiguracoes(db: any, configuracoes: any): Promise<number> {
  let importados = 0;

  try {
    if (configuracoes.simuladores) {
      for (const sim of configuracoes.simuladores) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO simuladores (
              nome, codigo_identificacao, tipo_simulador,
              aeronave_base, empresa_local, certificacao_anac,
              status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            sim.nome, sim.codigo_identificacao, sim.tipo_simulador,
            sim.aeronave_base, sim.empresa_local, sim.certificacao_anac,
            sim.status
          ).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar simulador ${sim.codigo_identificacao}:`, error);
        }
      }
    }

    if (configuracoes.aeronaves) {
      for (const aeronave of configuracoes.aeronaves) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO aeronaves (
              codigo, nome, fabricante, categoria, ativo,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(
            aeronave.codigo, aeronave.nome, aeronave.fabricante,
            aeronave.categoria, aeronave.ativo
          ).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar aeronave ${aeronave.codigo}:`, error);
        }
      }
    }

    if (configuracoes.funcoes) {
      for (const funcao of configuracoes.funcoes) {
        try {
          await db.prepare(`
            INSERT OR REPLACE INTO funcoes (
              nome, descricao, categoria, created_at, updated_at
            ) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `).bind(funcao.nome, funcao.descricao, funcao.categoria).run();
          importados++;
        } catch (error) {
          console.error(`Erro ao importar função ${funcao.nome}:`, error);
        }
      }
    }

  } catch (error) {
    console.error('Erro ao importar configurações:', error);
  }

  return importados;
}

app.post('/', async (c) => {
  try {
    const dadosImportacao = await c.req.json();
    const db = c.env.DB;
    const force = c.req.query('force') === 'true';


    const checksumValido = await validarChecksum(dadosImportacao);
    if (!checksumValido) {
      console.error('❌ Checksum inválido');
      return c.json({
        success: false,
        error: "Arquivo corrompido ou inválido"
      }, 400);
    }

    const conflitos = await detectarConflitos(db, dadosImportacao);

    if (conflitos.length > 0 && !force) {
      return c.json({
        success: false,
        conflicts: conflitos,
        message: "Conflitos detectados. Use force=true para resolver automaticamente."
      }, 409);
    }

    await criarBackupSeguranca(db);

    let resultadosImportacao = {
      funcionarios: 0,
      simuladores: 0,
      treinamentos: 0,
      configuracoes: 0
    };

    try {
      
      if (dadosImportacao.funcionarios) {
        resultadosImportacao.funcionarios = await importarFuncionarios(db, dadosImportacao.funcionarios);
      }
      
      if (dadosImportacao.simuladores) {
        resultadosImportacao.simuladores = await importarSimuladores(db, dadosImportacao.simuladores);
      }
      
      if (dadosImportacao.treinamentos) {
        resultadosImportacao.treinamentos = await importarTreinamentos(db, dadosImportacao.treinamentos);
      }
      
      if (dadosImportacao.configuracoes) {
        resultadosImportacao.configuracoes = await importarConfiguracoes(db, dadosImportacao.configuracoes);
      }

      await db.prepare(`
        INSERT INTO backup_historico 
        (operacao, tipo, total_records, status, created_at)
        VALUES (?, ?, ?, ?, ?)
      `).bind(
        'IMPORT',
        'RESTORE_COMPLETO',
        Object.values(resultadosImportacao).reduce((a, b) => a + b, 0),
        'SUCCESS',
        new Date().toISOString()
      ).run().catch(() => {
      });


      return c.json({
        success: true,
        imported: resultadosImportacao,
        conflitos_resolvidos: conflitos.length,
        message: `Importação concluída: ${Object.values(resultadosImportacao).reduce((a, b) => a + b, 0)} registros importados`
      });

    } catch (importError) {
      console.error('❌ Erro durante importação:', importError);
      
      
      return c.json({
        success: false,
        error: 'Erro durante a importação',
        details: (importError as Error).message,
        partial_import: resultadosImportacao
      }, 500);
    }

  } catch (error) {
    console.error('❌ Erro na importação:', error);
    return c.json({
      success: false,
      error: 'Erro interno do servidor',
      details: (error as Error).message
    }, 500);
  }
});

export default app;
