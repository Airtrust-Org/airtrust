import { Hono } from 'hono';
interface Env {
  DB: any;
  BUCKET?: any;
  ENVIRONMENT?: string;
  _schema_synced?: boolean;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_BUCKET_NAME?: string;
  R2_ENDPOINT?: string;
  CLOUDFLARE_API_TOKEN?: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;
  [key: string]: any;
}

const app = new Hono<{ Bindings: Env }>();

function verificarCompatibilidade(versaoBackup: string): boolean {
  const versaoSistema = "1.0.0";
  
  const [majorBackup] = versaoBackup.split('.');
  const [majorSistema] = versaoSistema.split('.');
  
  return majorBackup === majorSistema;
}

async function detectarConflitosPreview(db: any, dados: any): Promise<any[]> {
  const conflitos = [];

  try {
    if (dados.funcionarios && Array.isArray(dados.funcionarios)) {
      const matriculas = dados.funcionarios
        .filter((f: any) => f.matricula)
        .map((f: any) => f.matricula);

      if (matriculas.length > 0) {
        const existentes = await db.prepare(`
          SELECT matricula, nome 
          FROM funcionarios 
          WHERE matricula IN (${matriculas.map(() => '?').join(', ')}) 
          AND deleted_at IS NULL
        `).bind(...matriculas).all();

        for (const existente of (existentes.results || [])) {
          const importado = dados.funcionarios.find((f: any) => f.matricula === existente.matricula);
          if (importado && importado.nome !== existente.nome) {
            conflitos.push({
              tipo: 'Funcionário',
              item: `Matrícula ${existente.matricula}`,
              conflito: 'Nome diferente',
              valor_atual: existente.nome,
              valor_novo: importado.nome,
              acao_sugerida: 'Atualizar com novos dados'
            });
          }
        }
      }
    }

    if (dados.treinamentos?.catalogo && Array.isArray(dados.treinamentos.catalogo)) {
      const codigos = dados.treinamentos.catalogo
        .filter((t: any) => t.codigo)
        .map((t: any) => t.codigo);

      if (codigos.length > 0) {
        const existentes = await db.prepare(`
          SELECT codigo, nome 
          FROM catalogo_treinamentos_v2 
          WHERE codigo IN (${codigos.map(() => '?').join(', ')}) 
          AND deleted_at IS NULL
        `).bind(...codigos).all();

        for (const existente of (existentes.results || [])) {
          const importado = dados.treinamentos.catalogo.find((t: any) => t.codigo === existente.codigo);
          if (importado && importado.nome !== existente.nome) {
            conflitos.push({
              tipo: 'Treinamento',
              item: `Código ${existente.codigo}`,
              conflito: 'Nome diferente',
              valor_atual: existente.nome,
              valor_novo: importado.nome,
              acao_sugerida: 'Manter atual ou atualizar'
            });
          }
        }
      }
    }

    if (dados.configuracoes?.simuladores && Array.isArray(dados.configuracoes.simuladores)) {
      const codigos = dados.configuracoes.simuladores
        .filter((s: any) => s.codigo_identificacao)
        .map((s: any) => s.codigo_identificacao);

      if (codigos.length > 0) {
        const existentes = await db.prepare(`
          SELECT codigo_identificacao, nome 
          FROM simuladores 
          WHERE codigo_identificacao IN (${codigos.map(() => '?').join(', ')}) 
          AND deleted_at IS NULL
        `).bind(...codigos).all();

        for (const existente of (existentes.results || [])) {
          const importado = dados.configuracoes.simuladores.find((s: any) => s.codigo_identificacao === existente.codigo_identificacao);
          if (importado && importado.nome !== existente.nome) {
            conflitos.push({
              tipo: 'Simulador',
              item: `Código ${existente.codigo_identificacao}`,
              conflito: 'Nome diferente',
              valor_atual: existente.nome,
              valor_novo: importado.nome,
              acao_sugerida: 'Verificar qual é o correto'
            });
          }
        }
      }
    }

  } catch (error) {
    console.error('Erro ao detectar conflitos no preview:', error);
    conflitos.push({
      tipo: 'Sistema',
      item: 'Detecção de conflitos',
      conflito: 'Erro ao verificar duplicatas',
      valor_atual: 'N/A',
      valor_novo: 'N/A',
      acao_sugerida: 'Revisar dados manualmente'
    });
  }

  return conflitos;
}

app.post('/', async (c) => {
  try {
    const dadosImportacao = await c.req.json();
    const db = c.env.DB;


    if (!dadosImportacao.metadata) {
      return c.json({
        success: false,
        error: 'Arquivo de backup inválido - metadata ausente'
      }, 400);
    }

    const conflitos = await detectarConflitosPreview(db, dadosImportacao);

    const resumo = {
      funcionarios: Array.isArray(dadosImportacao.funcionarios) ? dadosImportacao.funcionarios.length : 0,
      fichas_simulador: 0,
      manobras: 0,
      treinamentos: 0
    };

    if (dadosImportacao.simuladores) {
      resumo.fichas_simulador = Array.isArray(dadosImportacao.simuladores.fichas) ? dadosImportacao.simuladores.fichas.length : 0;
      resumo.manobras = Array.isArray(dadosImportacao.simuladores.manobras) ? dadosImportacao.simuladores.manobras.length : 0;
    }

    if (dadosImportacao.treinamentos) {
      const catalogoCount = Array.isArray(dadosImportacao.treinamentos.catalogo) ? dadosImportacao.treinamentos.catalogo.length : 0;
      const certificacoesCount = Array.isArray(dadosImportacao.treinamentos.certificacoes) ? dadosImportacao.treinamentos.certificacoes.length : 0;
      resumo.treinamentos = catalogoCount + certificacoesCount;
    }

    const compatibilidade = verificarCompatibilidade(dadosImportacao.metadata.version || "1.0.0");

    const preview = {
      metadata: dadosImportacao.metadata,
      resumo: resumo,
      conflitos: conflitos,
      compatibilidade: compatibilidade,
      
      total_registros: Object.values(resumo).reduce((a, b) => a + b, 0),
      origem: dadosImportacao.metadata.origin_domain || 'Desconhecida',
      data_backup: dadosImportacao.metadata.created_at || null,
      modulos_incluidos: dadosImportacao.metadata.modules_included || [],
      
      validacoes: {
        checksum_presente: !!dadosImportacao.metadata.checksum,
        estrutura_valida: !!(dadosImportacao.metadata && (
          dadosImportacao.funcionarios || 
          dadosImportacao.simuladores || 
          dadosImportacao.treinamentos || 
          dadosImportacao.configuracoes
        )),
        versao_compativel: compatibilidade
      },
      
      recomendacoes: [] as any[]
    };

    if (!compatibilidade) {
      preview.recomendacoes.push({
        tipo: 'warning',
        titulo: 'Incompatibilidade de Versão',
        descricao: `Backup da versão ${dadosImportacao.metadata.version} pode não ser totalmente compatível com a versão atual do sistema`,
        acao: 'Verificar compatibilidade antes de importar'
      });
    }

    if (conflitos.length > 0) {
      preview.recomendacoes.push({
        tipo: 'warning',
        titulo: `${conflitos.length} Conflitos Detectados`,
        descricao: 'Alguns dados já existem no sistema com valores diferentes',
        acao: 'Revisar conflitos antes da importação'
      });
    }

    if (resumo.funcionarios === 0 && resumo.treinamentos === 0) {
      preview.recomendacoes.push({
        tipo: 'info',
        titulo: 'Backup Parcial',
        descricao: 'Este backup contém apenas dados de configuração',
        acao: 'Verificar se este é o backup correto'
      });
    }

    if (preview.total_registros > 10000) {
      preview.recomendacoes.push({
        tipo: 'info',
        titulo: 'Importação Grande',
        descricao: `${preview.total_registros} registros serão importados. Operação pode demorar alguns minutos`,
        acao: 'Aguardar conclusão sem interromper'
      });
    }


    return c.json({
      success: true,
      preview: preview
    });

  } catch (error) {
    console.error('❌ Erro ao gerar preview:', error);
    return c.json({
      success: false,
      error: 'Erro ao processar arquivo de backup',
      details: (error as Error).message
    }, 500);
  }
});

export default app;
