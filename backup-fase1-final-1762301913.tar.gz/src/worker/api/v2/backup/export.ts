import { Hono } from 'hono';
interface Env {
  DB: any;
  BUCKET?: any;
  ENVIRONMENT?: string;
  _schema_synced?: boolean;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_BUCKET_NAME?: string;
  R2_ENDPOINT?: string;
  CLOUDFLARE_API_TOKEN?: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;
  [key: string]: any;
}

const app = new Hono<{ Bindings: Env }>();

async function exportarFuncionarios(db: any) {
  try {
    const result = await db.prepare(`
      SELECT 
        id, nome, matricula, cpf, codigo_anac, funcao, base, contrato,
        telefone, email, status, cma_numero, cma_data_vencimento, cma_status,
        aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
        is_instrutor, is_checador, aeronave_principal, avatar, anv, data_nascimento,
        licenca_aeronautica, codigo_canac, codigo_sispat, codigo_prestserv,
        data_admissao, guerra, created_at, updated_at
      FROM funcionarios 
      WHERE (deleted_at IS NULL OR deleted_at = '')
      ORDER BY id
    `).all();
    
    return result.results || [];
  } catch (error) {
    
    const result = await db.prepare(`
      SELECT 
        id, nome, matricula, cpf, codigo_anac, funcao, base, contrato,
        telefone, email, status, cma_numero, cma_data_vencimento, cma_status,
        aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
        is_instrutor, is_checador, aeronave_principal, avatar, anv, data_nascimento,
        licenca_aeronautica, codigo_canac, codigo_sispat, codigo_prestserv,
        data_admissao, guerra, created_at, updated_at
      FROM funcionarios 
      ORDER BY id
    `).all();
    
    return result.results || [];
  }
}

async function exportarSimuladores(db: any) {
  let manobras;
  try {
    manobras = await db.prepare(`
      SELECT * FROM manobras_catalogo WHERE deleted_at IS NULL ORDER BY id
    `).all();
  } catch (error) {
    manobras = await db.prepare(`
      SELECT * FROM manobras_catalogo ORDER BY id
    `).all();
  }

  const sessoes = await db.prepare(`
    SELECT 
      st.*,
      GROUP_CONCAT(stm.manobra_catalogo_id) as manobra_ids
    FROM sessoes_template st
    LEFT JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
    GROUP BY st.id
    ORDER BY st.treinamento_codigo, st.numero_sessao
  `).all();

  let fichas;
  try {
    fichas = await db.prepare(`
      SELECT 
        f.*,
        s.simulador_id, s.colaborador_id_instrutor,
        s.data_inicio, s.data_fim,
        func.nome as aluno_nome, func.matricula as aluno_matricula,
        inst.nome as instrutor_nome
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots s ON f.agendamento_slot_id = s.id
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN funcionarios inst ON s.colaborador_id_instrutor = inst.id
      WHERE f.deleted_at IS NULL
      ORDER BY f.created_at DESC
      LIMIT 1000
    `).all();
  } catch (error) {
    fichas = await db.prepare(`
      SELECT 
        f.*,
        s.simulador_id, s.colaborador_id_instrutor,
        s.data_inicio, s.data_fim,
        func.nome as aluno_nome, func.matricula as aluno_matricula,
        inst.nome as instrutor_nome
      FROM fichas_sessao f
      LEFT JOIN agendamento_slots s ON f.agendamento_slot_id = s.id
      LEFT JOIN funcionarios func ON f.colaborador_id_aluno = func.id
      LEFT JOIN funcionarios inst ON s.colaborador_id_instrutor = inst.id
      ORDER BY f.created_at DESC
      LIMIT 1000
    `).all();
  }

  const manobrasFichas = await db.prepare(`
    SELECT 
      fme.*,
      f.ficha_uuid,
      mc.manobra_id_codigo, mc.nome_manobra
    FROM fichas_manobras_executadas fme
    JOIN fichas_sessao f ON fme.ficha_id = f.id
    JOIN manobras_catalogo mc ON fme.manobra_catalogo_id = mc.id
    WHERE f.deleted_at IS NULL
  `).all();

  const matriz = await db.prepare(`
    SELECT 
      st.id as sessao_id,
      st.nome_sessao,
      mc.id as manobra_id,
      mc.manobra_id_codigo,
      mc.nome_manobra
    FROM sessoes_template st
    JOIN sessoes_template_manobras stm ON st.id = stm.sessao_template_id
    JOIN manobras_catalogo mc ON stm.manobra_catalogo_id = mc.id
    ORDER BY st.treinamento_codigo, st.numero_sessao, mc.manobra_id_codigo
  `).all();

  return {
    manobras: manobras.results || [],
    sessoes: sessoes.results || [],
    fichas: fichas.results || [],
    manobras_fichas: manobrasFichas.results || [],
    matriz: matriz.results || []
  };
}

async function exportarTreinamentos(db: any) {
  let catalogo;
  try {
    catalogo = await db.prepare(`
      SELECT * FROM catalogo_treinamentos_v2 
      WHERE deleted_at IS NULL 
      ORDER BY codigo
    `).all();
  } catch (error) {
    catalogo = await db.prepare(`
      SELECT * FROM catalogo_treinamentos_v2 
      ORDER BY codigo
    `).all();
  }

  let certificacoes;
  try {
    certificacoes = await db.prepare(`
      SELECT 
        hc.*,
        f.nome as funcionario_nome, f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome, ct.codigo as treinamento_codigo
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE hc.deleted_at IS NULL
      ORDER BY hc.data_conclusao DESC
      LIMIT 5000
    `).all();
  } catch (error) {
    certificacoes = await db.prepare(`
      SELECT 
        hc.*,
        f.nome as funcionario_nome, f.matricula as funcionario_matricula,
        ct.nome as treinamento_nome, ct.codigo as treinamento_codigo
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      ORDER BY hc.data_conclusao DESC
      LIMIT 5000
    `).all();
  }

  let certificacoesV3;
  try {
    certificacoesV3 = await db.prepare(`
      SELECT * FROM certificacoes_v3 
      WHERE deleted_at IS NULL 
      ORDER BY data_conclusao DESC
      LIMIT 5000
    `).all();
  } catch (error) {
    certificacoesV3 = await db.prepare(`
      SELECT * FROM certificacoes_v3 
      ORDER BY data_conclusao DESC
      LIMIT 5000
    `).all();
  }

  return {
    catalogo: catalogo.results || [],
    certificacoes: certificacoes.results || [],
    certificacoes_v3: certificacoesV3.results || []
  };
}

async function exportarConfiguracoes(db: any) {
  let templates;
  try {
    templates = await db.prepare(`
      SELECT * FROM simulador_templates 
      WHERE deleted_at IS NULL 
      ORDER BY nome
    `).all();
  } catch (error) {
    templates = await db.prepare(`
      SELECT * FROM simulador_templates 
      ORDER BY nome
    `).all();
  }

  let simuladores;
  try {
    simuladores = await db.prepare(`
      SELECT * FROM simuladores 
      WHERE deleted_at IS NULL 
      ORDER BY nome
    `).all();
  } catch (error) {
    simuladores = await db.prepare(`
      SELECT * FROM simuladores 
      ORDER BY nome
    `).all();
  }

  let aeronaves;
  try {
    aeronaves = await db.prepare(`
      SELECT * FROM aeronaves 
      WHERE deleted_at IS NULL 
      ORDER BY codigo
    `).all();
  } catch (error) {
    aeronaves = await db.prepare(`
      SELECT * FROM aeronaves 
      ORDER BY codigo
    `).all();
  }

  let funcoes;
  try {
    funcoes = await db.prepare(`
      SELECT * FROM funcoes 
      WHERE deleted_at IS NULL 
      ORDER BY nome
    `).all();
  } catch (error) {
    funcoes = await db.prepare(`
      SELECT * FROM funcoes 
      ORDER BY nome
    `).all();
  }

  const ciclos = await db.prepare(`
    SELECT * FROM ciclos 
    ORDER BY numero_ciclo
  `).all();

  return {
    templates: templates.results || [],
    simuladores: simuladores.results || [],
    aeronaves: aeronaves.results || [],
    funcoes: funcoes.results || [],
    ciclos: ciclos.results || []
  };
}

async function gerarChecksum(dados: any): Promise<string> {
  const { metadata, ...dadosSemMetadata } = dados;
  const { checksum, ...metadataSemChecksum } = metadata;
  
  const dadosParaChecksum = { metadata: metadataSemChecksum, ...dadosSemMetadata };
  
  const dataStr = JSON.stringify(dadosParaChecksum);
  const encoder = new TextEncoder();
  const data = encoder.encode(dataStr);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function calcularTotalRegistros(dados: any): number {
  let total = 0;
  
  if (dados.funcionarios) total += dados.funcionarios.length;
  if (dados.simuladores) {
    total += dados.simuladores.manobras?.length || 0;
    total += dados.simuladores.sessoes?.length || 0;
    total += dados.simuladores.fichas?.length || 0;
    total += dados.simuladores.matriz?.length || 0;
  }
  if (dados.treinamentos) {
    total += dados.treinamentos.catalogo?.length || 0;
    total += dados.treinamentos.certificacoes?.length || 0;
    total += dados.treinamentos.certificacoes_v3?.length || 0;
  }
  if (dados.configuracoes) {
    total += dados.configuracoes.templates?.length || 0;
    total += dados.configuracoes.simuladores?.length || 0;
    total += dados.configuracoes.aeronaves?.length || 0;
    total += dados.configuracoes.funcoes?.length || 0;
    total += dados.configuracoes.ciclos?.length || 0;
  }
  
  return total;
}

app.post('/', async (c) => {
  try {
    const { modulos } = await c.req.json();
    const db = c.env.DB;


    const dadosExportados: any = {
      metadata: {
        version: "1.0.0",
        created_at: new Date().toISOString(),
        origin_domain: c.req.header('host') || 'unknown',
        system_version: "2.1.0",
        total_records: 0,
        checksum: "",
        modules_included: modulos
      }
    };

    if (modulos.includes('funcionarios')) {
      dadosExportados.funcionarios = await exportarFuncionarios(db);
    }

    if (modulos.includes('simuladores')) {
      dadosExportados.simuladores = await exportarSimuladores(db);
      const total = Object.values(dadosExportados.simuladores).reduce((acc: number, arr: any) => acc + (Array.isArray(arr) ? arr.length : 0), 0);
    }

    if (modulos.includes('treinamentos')) {
      dadosExportados.treinamentos = await exportarTreinamentos(db);
      const total = Object.values(dadosExportados.treinamentos).reduce((acc: number, arr: any) => acc + (Array.isArray(arr) ? arr.length : 0), 0);
    }

    if (modulos.includes('configuracoes')) {
      dadosExportados.configuracoes = await exportarConfiguracoes(db);
      const total = Object.values(dadosExportados.configuracoes).reduce((acc: number, arr: any) => acc + (Array.isArray(arr) ? arr.length : 0), 0);
    }

    dadosExportados.metadata.total_records = calcularTotalRegistros(dadosExportados);
    dadosExportados.metadata.checksum = await gerarChecksum(dadosExportados);


    try {
      await db.prepare(`
        INSERT INTO backup_historico 
        (operacao, tipo, tamanho_bytes, total_records, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind(
        'EXPORT',
        'BACKUP_COMPLETO',
        JSON.stringify(dadosExportados).length,
        dadosExportados.metadata.total_records,
        'SUCCESS',
        dadosExportados.metadata.created_at
      ).run();
    } catch (historyError) {
    }

    return c.json({
      success: true,
      data: dadosExportados,
      filename: `airtrust_backup_${new Date().toISOString().split('T')[0]}.json`,
      size_bytes: JSON.stringify(dadosExportados).length,
      message: `Backup gerado com sucesso: ${dadosExportados.metadata.total_records} registros`
    });

  } catch (error) {
    console.error('❌ Erro na exportação:', error);
    return c.json({
      success: false,
      error: 'Erro ao gerar backup',
      details: (error as Error).message
    }, 500);
  }
});

export default app;
