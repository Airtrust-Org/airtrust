
export interface BackupMetadata {
  version: string;
  created_at: string;
  origin_domain: string;
  system_version: string;
  total_records: number;
  checksum: string;
  modules_included: string[];
}

export interface BackupData {
  metadata: BackupMetadata;
  funcionarios?: any[];
  simuladores?: {
    manobras: any[];
    sessoes: any[];
    fichas: any[];
    manobras_fichas: any[];
    matriz: any[];
  };
  treinamentos?: {
    catalogo: any[];
    certificacoes: any[];
    certificacoes_v3: any[];
  };
  configuracoes?: {
    templates: any[];
    simuladores: any[];
    aeronaves: any[];
    funcoes: any[];
    ciclos: any[];
  };
}

export interface ConflictItem {
  tipo: string;
  campo: string;
  valor: string;
  descricao: string;
  valor_existente: string;
  valor_importacao: string;
  acao_sugerida: string;
}

export function validarEstruturaBackup(dados: any): { valido: boolean; erros: string[] } {
  const erros: string[] = [];

  if (!dados) {
    erros.push('Dados do backup não fornecidos');
    return { valido: false, erros };
  }

  if (!dados.metadata) {
    erros.push('Metadata do backup ausente');
  } else {
    if (!dados.metadata.version) erros.push('Versão do backup não informada');
    if (!dados.metadata.created_at) erros.push('Data de criação do backup não informada');
    if (!dados.metadata.checksum) erros.push('Checksum do backup não informado');
    if (!dados.metadata.modules_included || !Array.isArray(dados.metadata.modules_included)) {
      erros.push('Módulos incluídos no backup não informados');
    }
  }

  const hasModulos = !!(
    dados.funcionarios || 
    dados.simuladores || 
    dados.treinamentos || 
    dados.configuracoes
  );

  if (!hasModulos) {
    erros.push('Nenhum módulo de dados encontrado no backup');
  }

  return { valido: erros.length === 0, erros };
}

export function calcularTamanhoEstimado(dadosStats: {
  funcionarios: number;
  simuladores: number;
  fichas: number;
  treinamentos: number;
  configuracoes: number;
}): { bytes: number; formatted: string } {
  const BYTES_POR_FUNCIONARIO = 500;  // ~500 bytes por funcionário
  const BYTES_POR_SIMULADOR = 300;    // ~300 bytes por agendamento
  const BYTES_POR_FICHA = 1000;       // ~1KB por ficha (com manobras)
  const BYTES_POR_TREINAMENTO = 400;  // ~400 bytes por certificação
  const BYTES_POR_CONFIG = 200;       // ~200 bytes por item de configuração

  const totalBytes = 
    (dadosStats.funcionarios * BYTES_POR_FUNCIONARIO) +
    (dadosStats.simuladores * BYTES_POR_SIMULADOR) +
    (dadosStats.fichas * BYTES_POR_FICHA) +
    (dadosStats.treinamentos * BYTES_POR_TREINAMENTO) +
    (dadosStats.configuracoes * BYTES_POR_CONFIG);

  return {
    bytes: totalBytes,
    formatted: formatarTamanho(totalBytes)
  };
}

export function formatarTamanho(bytes: number): string {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

export function estimarTempoOperacao(totalRecords: number, operacao: 'export' | 'import'): number {
  const RECORDS_POR_SEGUNDO = operacao === 'export' ? 100 : 50; // Import é mais lento
  const TEMPO_MINIMO = 5; // Pelo menos 5 segundos
  
  const tempoEstimado = Math.max(TEMPO_MINIMO, Math.ceil(totalRecords / RECORDS_POR_SEGUNDO));
  
  return tempoEstimado;
}

export function gerarNomeArquivo(modulos: string[], formato: 'json' | 'zip' = 'json'): string {
  const dataAtual = new Date();
  const timestamp = dataAtual.toISOString().split('T')[0]; // YYYY-MM-DD
  const hora = dataAtual.toTimeString().split(' ')[0].replace(/:/g, ''); // HHMMSS
  
  const tipoBackup = modulos.length === 4 ? 'completo' : 'parcial';
  const extensao = formato === 'zip' ? 'zip' : 'json';
  
  return `airtrust_backup_${tipoBackup}_${timestamp}_${hora}.${extensao}`;
}

export function verificarCompatibilidadeVersao(versaoBackup: string, versaoSistema: string = "1.0.0"): {
  compativel: boolean;
  nivel: 'total' | 'parcial' | 'incompativel';
  observacoes: string[];
} {
  const observacoes: string[] = [];
  
  try {
    const [majorBackup, minorBackup, patchBackup] = versaoBackup.split('.').map(Number);
    const [majorSistema, minorSistema, patchSistema] = versaoSistema.split('.').map(Number);
    
    if (majorBackup !== majorSistema) {
      observacoes.push(`Versão major diferente: backup v${majorBackup}.x.x vs sistema v${majorSistema}.x.x`);
      return { compativel: false, nivel: 'incompativel', observacoes };
    }
    
    if (minorBackup !== minorSistema) {
      if (minorBackup > minorSistema) {
        observacoes.push(`Backup de versão mais recente v${versaoBackup} - alguns recursos podem não funcionar`);
      } else {
        observacoes.push(`Backup de versão mais antiga v${versaoBackup} - será atualizado durante importação`);
      }
      return { compativel: true, nivel: 'parcial', observacoes };
    }
    
    if (patchBackup !== patchSistema) {
      observacoes.push(`Diferença apenas na versão patch - totalmente compatível`);
    } else {
      observacoes.push(`Versões idênticas - compatibilidade total`);
    }
    
    return { compativel: true, nivel: 'total', observacoes };
    
  } catch (error) {
    observacoes.push(`Erro ao analisar versões: ${(error as Error).message}`);
    return { compativel: false, nivel: 'incompativel', observacoes };
  }
}

export function criarResumoExecutivo(dados: BackupData): {
  resumo: string;
  estatisticas: Record<string, number>;
  recomendacoes: string[];
} {
  const estatisticas: Record<string, number> = {
    funcionarios: Array.isArray(dados.funcionarios) ? dados.funcionarios.length : 0,
    simuladores_manobras: Array.isArray(dados.simuladores?.manobras) ? dados.simuladores.manobras.length : 0,
    simuladores_fichas: Array.isArray(dados.simuladores?.fichas) ? dados.simuladores.fichas.length : 0,
    treinamentos_catalogo: Array.isArray(dados.treinamentos?.catalogo) ? dados.treinamentos.catalogo.length : 0,
    treinamentos_certificacoes: Array.isArray(dados.treinamentos?.certificacoes) ? dados.treinamentos.certificacoes.length : 0,
    configuracoes_simuladores: Array.isArray(dados.configuracoes?.simuladores) ? dados.configuracoes.simuladores.length : 0
  };

  const totalRegistros = Object.values(estatisticas).reduce((a, b) => a + b, 0);
  
  const resumo = `Backup criado em ${new Date(dados.metadata.created_at).toLocaleDateString('pt-BR')} ` +
    `contendo ${totalRegistros} registros de ${dados.metadata.modules_included.length} módulos. ` +
    `Origem: ${dados.metadata.origin_domain || 'Desconhecida'}`;

  const recomendacoes: string[] = [];
  
  if (totalRegistros === 0) {
    recomendacoes.push('⚠️ Backup vazio - verificar se foi gerado corretamente');
  } else if (totalRegistros < 10) {
    recomendacoes.push('📊 Backup pequeno - pode ser dados de teste');
  } else if (totalRegistros > 10000) {
    recomendacoes.push('⏱️ Backup grande - importação pode demorar alguns minutos');
  }
  
  if (estatisticas.funcionarios === 0) {
    recomendacoes.push('👥 Nenhum funcionário no backup - verificar se é intencional');
  }
  
  if (estatisticas.simuladores_fichas > estatisticas.funcionarios * 5) {
    recomendacoes.push('📋 Muitas fichas por funcionário - backup pode conter histórico extenso');
  }

  return { resumo, estatisticas, recomendacoes };
}
