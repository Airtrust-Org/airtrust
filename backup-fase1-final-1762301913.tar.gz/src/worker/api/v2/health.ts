/**
 * Health Checks Avançados
 * Verifica saúde de todos os componentes do sistema
 */

import { Hono } from 'hono';
import type { Env } from '../../types';
import { Logger } from '../../utils/logger';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  return c.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime ? process.uptime() : 'N/A',
  });
});

app.get('/detailed', async (c) => {
  const startTime = Date.now();

  const checks = {
    api: await checkAPI(),
    database: await checkDatabase(c.env.DB),
    storage: await checkR2(c.env.BUCKET),
    memory: checkMemory(),
    timestamp: new Date().toISOString(),
  };

  const allHealthy = Object.values(checks).every(
    (check) => typeof check === 'object' && check.status === 'healthy',
  );

  const responseTime = Date.now() - startTime;

  return c.json(
    {
      status: allHealthy ? 'healthy' : 'degraded',
      checks,
      responseTime: `${responseTime}ms`,
    },
    allHealthy ? 200 : 503,
  );
});

app.get('/ready', async (c) => {
  try {
    await c.env.DB.prepare('SELECT 1').first();

    return c.json({ ready: true }, 200);
  } catch (error) {
    return c.json({ ready: false, error: 'Database not ready' }, 503);
  }
});

app.get('/live', async (c) => {
  return c.json({ alive: true }, 200);
});

/**
 * Verificar API
 */
async function checkAPI(): Promise<any> {
  return {
    status: 'healthy',
    version: '2.0.0',
  };
}

/**
 * Verificar Database
 */
async function checkDatabase(db: D1Database): Promise<any> {
  const startTime = Date.now();

  try {
    await db.prepare('SELECT 1').first();

    const funcionarios = (await db
      .prepare('SELECT COUNT(*) as count FROM funcionarios WHERE deleted_at IS NULL')
      .first()) as any;
    const qualificacoes = (await db
      .prepare('SELECT COUNT(*) as count FROM qualificacoes WHERE deleted_at IS NULL')
      .first()) as any;

    const responseTime = Date.now() - startTime;

    return {
      status: 'healthy',
      responseTime: `${responseTime}ms`,
      stats: {
        funcionarios: funcionarios?.count || 0,
        qualificacoes: qualificacoes?.count || 0,
      },
    };
  } catch (error: any) {
    return {
      status: 'unhealthy',
      error: error.message,
    };
  }
}

/**
 * Verificar R2 Storage
 */
async function checkR2(bucket: R2Bucket): Promise<any> {
  const startTime = Date.now();

  try {
    const list = await bucket.list({ limit: 1 });

    const responseTime = Date.now() - startTime;

    return {
      status: 'healthy',
      responseTime: `${responseTime}ms`,
      objects: list.objects.length,
    };
  } catch (error: any) {
    return {
      status: 'unhealthy',
      error: error.message,
    };
  }
}

/**
 * Verificar Memória
 */
function checkMemory(): any {
  return {
    status: 'healthy',
    note: 'Memory monitoring not available in Workers',
  };
}

export default app;
