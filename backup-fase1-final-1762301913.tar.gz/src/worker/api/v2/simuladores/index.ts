/**
 * API /api/v2/simuladores
 * Rota simples para listar simuladores
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        id,
        nome,
        modelo,
        tipo,
        fabricante,
        localizacao,
        capacidade,
        status,
        observacoes
      FROM simuladores
      WHERE deleted_at IS NULL
      ORDER BY nome ASC
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
    
  } catch (error: any) {
    console.error('Erro ao listar simuladores:', error);
    return c.json({
      success: false,
      error: 'Erro ao carregar simuladores',
      details: error.message
    }, 500);
  }
});

app.get('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    
    const simulador = await db.prepare(`
      SELECT 
        id,
        nome,
        modelo,
        tipo,
        fabricante,
        localizacao,
        capacidade,
        status,
        observacoes,
        created_at,
        updated_at
      FROM simuladores
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!simulador) {
      return c.json({
        success: false,
        error: 'Simulador não encontrado'
      }, 404);
    }
    
    
    return c.json({
      success: true,
      data: simulador
    });
    
  } catch (error: any) {
    console.error('Erro ao buscar simulador:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar simulador',
      details: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    if (!data.nome) {
      return c.json({
        success: false,
        error: 'Nome é obrigatório'
      }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO simuladores (
        nome, modelo, tipo, fabricante, localizacao,
        capacidade, status, observacoes,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      data.nome,
      data.modelo || null,
      data.tipo || 'FULL FLIGHT',
      data.fabricante || null,
      data.localizacao || null,
      data.capacidade || 1,
      data.status || 'ATIVO',
      data.observacoes || null
    ).run();
    
    return c.json({
      success: true,
      simulador: {
        id: result.meta.last_row_id,
        ...data
      },
      message: 'Simulador criado com sucesso'
    }, 201);
    
  } catch (error: any) {
    console.error('Erro ao criar simulador:', error);
    return c.json({
      success: false,
      error: 'Erro ao criar simulador',
      details: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const data = await c.req.json();
    
    await db.prepare(`
      UPDATE simuladores
      SET 
        nome = COALESCE(?, nome),
        modelo = COALESCE(?, modelo),
        tipo = COALESCE(?, tipo),
        fabricante = COALESCE(?, fabricante),
        localizacao = COALESCE(?, localizacao),
        capacidade = COALESCE(?, capacidade),
        status = COALESCE(?, status),
        observacoes = COALESCE(?, observacoes),
        updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `).bind(
      data.nome || null,
      data.modelo || null,
      data.tipo || null,
      data.fabricante || null,
      data.localizacao || null,
      data.capacidade || null,
      data.status || null,
      data.observacoes || null,
      id
    ).run();
    
    return c.json({
      success: true,
      message: 'Simulador atualizado com sucesso'
    });
    
  } catch (error: any) {
    console.error('Erro ao atualizar simulador:', error);
    return c.json({
      success: false,
      error: 'Erro ao atualizar simulador',
      details: error.message
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    await db.prepare(`
      UPDATE simuladores
      SET deleted_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).run();
    
    return c.json({
      success: true,
      message: 'Simulador excluído com sucesso'
    });
    
  } catch (error: any) {
    console.error('Erro ao excluir simulador:', error);
    return c.json({
      success: false,
      error: 'Erro ao excluir simulador',
      details: error.message
    }, 500);
  }
});

export default app;
