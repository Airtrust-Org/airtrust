import { Hono } from 'hono';
import { logAudit } from '../../services/audit';

const app = new Hono<{ Bindings: Env }>();


app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const funcionario_id = c.req.query('funcionario_id');
    const status = c.req.query('status');
    
    let whereClause = '';
    const params = [];
    
    if (funcionario_id) {
      whereClause += ' AND cs.funcionario_id = ?';
      params.push(funcionario_id);
    }
    
    if (status) {
      whereClause += ' AND cs.status = ?';
      params.push(status);
    }
    
    const stmt = db.prepare(`
      SELECT cs.id, cs.funcionario_id, cs.treinamento_id, cs.status,
             cs.data_ultima_certificacao, cs.data_vencimento, cs.dias_para_vencimento,
             cs.historico_certificacao_id, cs.created_at, cs.updated_at,
             f.nome as funcionario_nome, f.funcao, f.base,
             t.codigo as treinamento_codigo, t.nome as treinamento_nome,
             t.categoria as treinamento_categoria
      FROM compliance_status_v2 cs
      JOIN funcionarios f ON cs.funcionario_id = f.id
      JOIN catalogo_treinamentos_v2 t ON cs.treinamento_id = t.id
      WHERE f.deleted_at IS NULL AND t.deleted_at IS NULL ${whereClause}
      ORDER BY cs.dias_para_vencimento ASC, f.nome
    `);
    
    const result = await stmt.bind(...params).all();
    const compliance = result.results;

    const stats = {
      total_registros: compliance?.length || 0,
      em_dia: compliance?.filter((c: any) => c.status === 'EM_DIA').length || 0,
      vencendo: compliance?.filter((c: any) => c.status === 'VENCENDO').length || 0,
      vencido: compliance?.filter((c: any) => c.status === 'VENCIDO').length || 0,
      pendente: compliance?.filter((c: any) => c.status === 'PENDENTE').length || 0
    };

    await logAudit(c, 'LIST', 'compliance_status_v2');
    
    return c.json({
      success: true,
      data: compliance,
      stats,
      total: compliance?.length || 0
    });
  } catch (error) {
    Logger.error('Error listing compliance:', error);
    await logAudit(c, 'LIST', 'compliance_status_v2', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.post('/recalculate', async (c) => {
  try {
    const { ComplianceService } = await import('../../services/compliance');
    
    const result = await ComplianceService.recalculateAllCompliance(c);
    
    await logAudit(c, 'RECALCULATE', 'compliance_status_v2', undefined, undefined, { 
      processed: result.processed,
      updated: result.updated 
    });
    
    return c.json({
      success: true,
      message: 'Compliance recalculado com sucesso',
      data: result
    });
  } catch (error) {
    Logger.error('Error recalculating compliance:', error);
    await logAudit(c, 'RECALCULATE', 'compliance_status_v2', undefined, undefined, undefined, 'ERROR');
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.get('/dashboard', async (c) => {
  try {
    const db = c.env.DB;
    
    const totalQualificacoes = await db.prepare(`
      SELECT COUNT(*) as total FROM qualificacoes WHERE deleted_at IS NULL
    `).first();
    
    const validas = await db.prepare(`
      SELECT COUNT(*) as count FROM qualificacoes 
      WHERE deleted_at IS NULL 
      AND date(data_vencimento) >= date('now')
    `).first();
    
    const vencendo = await db.prepare(`
      SELECT COUNT(*) as count FROM qualificacoes 
      WHERE deleted_at IS NULL 
      AND date(data_vencimento) BETWEEN date('now') AND date('now', '+30 days')
    `).first();
    
    const vencidas = await db.prepare(`
      SELECT COUNT(*) as count FROM qualificacoes 
      WHERE deleted_at IS NULL 
      AND date(data_vencimento) < date('now')
    `).first();
    
    const total = Number(totalQualificacoes?.total) || 0;
    const validasCount = Number(validas?.count) || 0;
    const compliance = total > 0 ? ((validasCount / total) * 100).toFixed(2) : '0.00';
    
    return c.json({
      success: true,
      stats: {
        total,
        validas: validasCount,
        vencendo: vencendo?.count || 0,
        vencidas: vencidas?.count || 0
      },
      compliance: `${compliance}%`,
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    Logger.error('Error getting compliance dashboard:', error);
    return c.json({ 
      success: false,
      error: 'Erro ao buscar dashboard de compliance',
      message: error.message 
    }, 500);
  }
});

export default app;
