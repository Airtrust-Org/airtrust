import { Hono } from 'hono';
import type { Env } from '../../types';
import { Logger } from '../../utils/logger';
import { batchImport, validateImportData, logImport } from '../../utils/batch-import-helper';

const app = new Hono<{ Bindings: Env }>();

app.post('/simuladores/import', async (c) => {
  try {
    const { dados } = await c.req.json();
    const db = c.env.DB;

    const validation = validateImportData(dados, ['codigo', 'nome']);
    if (!validation.valid) {
      return c.json({ success: false, error: validation.errors.join(', ') }, 400);
    }

    const result = await batchImport(db, dados, async (item, db) => {
      await db
        .prepare(
          `
        INSERT INTO simuladores (codigo, nome, modelo, tipo, fabricante, localizacao, capacidade, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'DISPONIVEL', datetime('now'))
      `,
        )
        .bind(
          item.codigo,
          item.nome,
          item.modelo || null,
          item.tipo || null,
          item.fabricante || null,
          item.localizacao || null,
          item.capacidade || 2,
        )
        .run();
    });

    await logImport(db, 'SIMULADORES', 'import.json', result);

    return c.json({
      success: result.success,
      importados: result.imported,
      total: result.total,
      erros: result.errors.map((e) => `Linha ${e.index + 1}: ${e.error}`),
    });
  } catch (error: any) {
    Logger.error('[IMPORT] Erro ao importar simuladores:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/funcoes/import', async (c) => {
  try {
    const { dados } = await c.req.json();
    const db = c.env.DB;

    const validation = validateImportData(dados, ['codigo', 'nome']);
    if (!validation.valid) {
      return c.json({ success: false, error: validation.errors.join(', ') }, 400);
    }

    const result = await batchImport(db, dados, async (item, db) => {
      await db
        .prepare(
          `
        INSERT INTO funcoes (codigo, nome, descricao, categoria, nivel_acesso, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `,
        )
        .bind(
          item.codigo,
          item.nome,
          item.descricao || '',
          item.categoria || 'OPERACIONAL',
          item.nivel_acesso || 1,
        )
        .run();
    });

    await logImport(db, 'FUNCOES', 'import.json', result);

    return c.json({
      success: result.success,
      importados: result.imported,
      total: result.total,
      erros: result.errors.map((e) => `Linha ${e.index + 1}: ${e.error}`),
    });
  } catch (error: any) {
    Logger.error('[IMPORT] Erro ao importar funções:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/treinamentos/import', async (c) => {
  try {
    const { dados } = await c.req.json();
    const db = c.env.DB;

    const validation = validateImportData(dados, ['codigo', 'nome']);
    if (!validation.valid) {
      return c.json({ success: false, error: validation.errors.join(', ') }, 400);
    }

    const result = await batchImport(db, dados, async (item, db) => {
      await db
        .prepare(
          `
        INSERT INTO catalogo_treinamentos (codigo, nome, descricao, carga_horaria, validade_meses, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `,
        )
        .bind(
          item.codigo,
          item.nome,
          item.descricao || '',
          item.carga_horaria || 0,
          item.validade_meses || 12,
        )
        .run();
    });

    await logImport(db, 'TREINAMENTOS', 'import.json', result);

    return c.json({
      success: result.success,
      importados: result.imported,
      total: result.total,
      erros: result.errors.map((e) => `Linha ${e.index + 1}: ${e.error}`),
    });
  } catch (error: any) {
    Logger.error('[IMPORT] Erro ao importar treinamentos:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.post('/manobras/import', async (c) => {
  try {
    const { dados } = await c.req.json();
    const db = c.env.DB;

    const validation = validateImportData(dados, ['codigo', 'nome']);
    if (!validation.valid) {
      return c.json({ success: false, error: validation.errors.join(', ') }, 400);
    }

    const result = await batchImport(db, dados, async (item, db) => {
      await db
        .prepare(
          `
        INSERT INTO manobras (codigo, nome, descricao, tipo, created_at)
        VALUES (?, ?, ?, ?, datetime('now'))
      `,
        )
        .bind(item.codigo, item.nome, item.descricao || '', item.tipo || 'PROCEDIMENTO')
        .run();
    });

    await logImport(db, 'MANOBRAS', 'import.json', result);

    return c.json({
      success: result.success,
      importados: result.imported,
      total: result.total,
      erros: result.errors.map((e) => `Linha ${e.index + 1}: ${e.error}`),
    });
  } catch (error: any) {
    Logger.error('[IMPORT] Erro ao importar manobras:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default app;
