/**
 * Endpoints de Compliance LGPD
 * Implementa direitos dos titulares (Art. 18)
 * 
 * ⚠️ ETAPA 1 CONTENÇÃO: Endpoint temporariamente desabilitado para implementação segura
 */

import { Hono } from 'hono';
import { jwtAuth } from '../../middleware/jwt-auth';
import { Logger } from '../../utils/structured-logger';
import { getFeatureFlags } from '../../utils/feature-flags';
import type { Env } from '../../types/env';

const app = new Hono<{ Bindings: Env }>();

app.use('*', jwtAuth);

// ⚠️ MIDDLEWARE DE CONTENÇÃO: Desabilitar endpoint LGPD até implementação segura
app.use('*', async (c, next) => {
  const flags = getFeatureFlags(c.env);
  
  if (!flags.LGPD_ENDPOINT_ENABLED) {
    Logger.warn('[SECURITY] Tentativa de acesso a endpoint LGPD desabilitado', {
      user: c.get('user')?.id,
      ip: c.req.header('cf-connecting-ip'),
      path: c.req.path,
    });
    
    return c.json({
      error: 'LGPD endpoint temporarily disabled',
      reason: 'Endpoint desabilitado para implementação segura com backup e aprovação DPO',
      contact: 'dpo@airtrust.com.br',
      status: 'MAINTENANCE',
      message: 'Este endpoint será ativado novamente na ETAPA 2 com implementação segura'
    }, 503);
  }
  
  await next();
});

app.post('/exportar-dados/:id', async (c) => {
  const id = parseInt(c.req.param('id'));
  const db = c.env.DB;
  
  try {
    const funcionario = await db.prepare(`
      SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }
    
    const qualificacoes = await db.prepare(`
      SELECT * FROM qualificacoes WHERE funcionario_id = ? AND deleted_at IS NULL
    `).bind(id).all();
    
    const dadosCompletos = {
      funcionario,
      qualificacoes: qualificacoes.results,
      exportado_em: new Date().toISOString(),
      formato: 'JSON'
    };
    
    await db.prepare(`
      INSERT INTO logs_acesso_dados (funcionario_id, usuario_id, acao, campos_acessados, ip)
      VALUES (?, ?, 'EXPORT', ?, ?)
    `).bind(id, c.get('user')?.id, JSON.stringify(['*']), c.req.header('cf-connecting-ip')).run();
    
    Logger.info('Dados exportados (LGPD)', { funcionario_id: id, user: c.get('user')?.id });
    
    return c.json({
      success: true,
      data: dadosCompletos
    });
  } catch (error: any) {
    Logger.error('Erro ao exportar dados', error, { funcionario_id: id });
    return c.json({ success: false, error: 'Erro ao exportar dados' }, 500);
  }
});

app.delete('/excluir-permanente/:id', async (c) => {
  const id = parseInt(c.req.param('id'));
  const db = c.env.DB;
  
  try {
    const funcionario = await db.prepare(`
      SELECT * FROM funcionarios WHERE id = ?
    `).bind(id).first();
    
    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }
    
    if (!(funcionario as any).deleted_at) {
      return c.json({ 
        success: false, 
        error: 'Funcionário deve ser soft deleted primeiro' 
      }, 400);
    }
    
    await db.prepare(`
      INSERT INTO funcionarios_backup_permanente (funcionario_id, data_backup, motivo)
      VALUES (?, ?, ?)
    `).bind(id, JSON.stringify(funcionario), 'Right to be forgotten - LGPD Art. 18, VI').run();
    
    await db.prepare(`DELETE FROM funcionarios WHERE id = ?`).bind(id).run();
    await db.prepare(`DELETE FROM qualificacoes WHERE funcionario_id = ?`).bind(id).run();
    await db.prepare(`DELETE FROM exames WHERE funcionario_id = ?`).bind(id).run();
    await db.prepare(`DELETE FROM checks WHERE funcionario_id = ?`).bind(id).run();
    
    Logger.info('Dados excluídos permanentemente (LGPD)', { funcionario_id: id });
    
    return c.json({ 
      success: true, 
      message: 'Dados excluídos permanentemente conforme LGPD' 
    });
  } catch (error: any) {
    Logger.error('Erro ao excluir permanentemente', error, { funcionario_id: id });
    return c.json({ success: false, error: 'Erro ao excluir dados' }, 500);
  }
});

app.post('/solicitar', async (c) => {
  const db = c.env.DB;
  const body = await c.req.json();
  const { funcionario_id, tipo, descricao } = body;
  
  try {
    const result = await db.prepare(`
      INSERT INTO solicitacoes_lgpd (funcionario_id, tipo, descricao, responsavel_id)
      VALUES (?, ?, ?, ?)
    `).bind(funcionario_id, tipo, descricao, c.get('user')?.id).run();
    
    Logger.info('Solicitação LGPD criada', { funcionario_id, tipo });
    
    return c.json({
      success: true,
      id: result.meta.last_row_id,
      message: 'Solicitação registrada. Será processada em até 15 dias conforme LGPD.'
    });
  } catch (error: any) {
    Logger.error('Erro ao criar solicitação LGPD', error);
    return c.json({ success: false, error: 'Erro ao criar solicitação' }, 500);
  }
});

app.get('/solicitacoes', async (c) => {
  const db = c.env.DB;
  const status = c.req.query('status');
  
  try {
    let query = 'SELECT * FROM solicitacoes_lgpd WHERE 1=1';
    const params: any[] = [];
    
    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY data_solicitacao DESC';
    
    const { results } = await db.prepare(query).bind(...params).all();
    
    return c.json({
      success: true,
      data: results
    });
  } catch (error: any) {
    Logger.error('Erro ao listar solicitações LGPD', error);
    return c.json({ success: false, error: 'Erro ao listar solicitações' }, 500);
  }
});

export default app;
