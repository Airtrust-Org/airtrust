// Re-export do funcionarios-crud.ts (alias para compatibilidade)import { Hono } from 'hono';import { Hono } from 'hono';

export { default } from './funcionarios-crud';

import { z } from 'zod';import { z } from 'zod';

import type { Env } from '../../types';import type { Env } from '../../types';

import { Validators } from '../../utils/validators';// TODO: Auth disabled in dev

import { invalidateCache } from '../../utils/cache';// import { authMiddleware } from '../../middleware/auth';

import { parsePaginationParams, buildPaginatedResponse, calculateOffset } from '../../utils/pagination';import { requirePermission } from '../../middleware/authorize';

import { Logger } from '../../utils/logger';

const app = new Hono<{ Bindings: Env }>();

// ===== VALIDATION SCHEMAS =====

const sanitizeString = (str: string): string => {const isValidCPF = (cpf: string): boolean => {

  if (!str) return str;  const cleaned = cpf.replace(/\D/g, '');

  return str  if (cleaned.length !== 11) return false;

    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')  if (/^(\d)\1{10}$/.test(cleaned)) return false;

    .replace(/<[^>]*>/g, '')  

    .replace(/javascript:/gi, '')  let sum = 0;

    .replace(/on\w+\s*=/gi, '')  let remainder = 0;

    .trim();  

};  for (let i = 1; i <= 9; i++) {

    sum += parseInt(cleaned.substring(i - 1, i)) * (11 - i);

const FuncionarioSchema = z.object({  }

  matricula: z.string()  remainder = (sum * 10) % 11;

    .min(1, 'Matrícula é obrigatória')  if (remainder === 10 || remainder === 11) remainder = 0;

    .transform((val) => {  if (remainder !== parseInt(cleaned.substring(9, 10))) return false;

      const numeros = val.replace(/\D/g, '');  

      return numeros.padStart(5, '0');  sum = 0;

    })  for (let i = 1; i <= 10; i++) {

    .refine((val) => val.length === 5, 'Matrícula deve ter 5 dígitos')    sum += parseInt(cleaned.substring(i - 1, i)) * (12 - i);

    .refine((val) => /^\d{5}$/.test(val), 'Matrícula deve conter apenas números'),  }

  nome: z.string()  remainder = (sum * 10) % 11;

    .min(3, 'Nome deve ter no mínimo 3 caracteres')  if (remainder === 10 || remainder === 11) remainder = 0;

    .transform(sanitizeString),  if (remainder !== parseInt(cleaned.substring(10, 11))) return false;

  cpf: z.string()  

    .transform((val) => val ? val.replace(/[^0-9]/g, '') : val)  return true;

    .refine((cpf) => !cpf || cpf.length === 11, 'CPF deve ter 11 dígitos')};

    .refine((cpf) => !cpf || Validators.validateCPF(cpf), 'CPF inválido')

    .optional(),const FuncionarioSchema = z.object({

  telefone: z.string().optional(),  nome: z.string().min(3, 'Nome deve ter pelo menos 3 caracteres').max(100, 'Nome não pode exceder 100 caracteres'),

  email: z.string().email('Email inválido').optional().or(z.literal('')),  matricula: z.string().min(1, 'Matrícula obrigatória').max(50, 'Matrícula não pode exceder 50 caracteres'),

  cargo: z.string().optional().transform((val) => val ? sanitizeString(val) : val),  cpf: z.string().optional().refine(

  funcao: z.string().optional().transform((val) => val ? sanitizeString(val) : val),    (val) => !val || isValidCPF(val),

  setor: z.string().optional().transform((val) => val ? sanitizeString(val) : val),    'CPF inválido'

  base: z.string().optional().transform((val) => val ? sanitizeString(val) : val),  ),

  status: z.enum(['ATIVO', 'INATIVO', 'AFASTADO', 'FERIAS', 'LICENCA']).default('ATIVO'),  telefone: z.string().optional(),

  data_admissao: z.string().optional(),  email: z.string().email('Email inválido'),

  data_nascimento: z.string().optional(),  cargo: z.string().optional(),

  guerra: z.string().optional(),  funcao: z.string().optional(),

  contrato: z.string().optional(),  setor: z.string().optional(),

  codigo_anac: z.union([z.string(), z.number()]).optional(),  base: z.string().optional(),

  codigo_canac: z.union([z.string(), z.number()]).optional(),  contrato: z.string().optional(),

  codigo_sispat: z.string().optional(),  status: z.enum(['ATIVO', 'INATIVO', 'LICENCA', 'AFASTADO']).optional(),

  codigo_prestserv: z.string().optional(),  data_admissao: z.string().optional(),

  licenca_aeronautica: z.string().optional(),  data_nascimento: z.string().optional(),

  anv: z.string().optional(),  codigo_anac: z.string().optional(),

  cma_numero: z.string().optional(),  codigo_canac: z.string().optional(),

  cma_data_vencimento: z.string().optional(),  licenca_aeronautica: z.string().optional(),

  cma_status: z.string().optional(),  is_instrutor: z.number().int().min(0).max(1).optional(),

  aso_data_vencimento: z.string().optional(),  is_checador: z.number().int().min(0).max(1).optional()

  nivel_icao: z.string().optional(),});

  nivel_icao_data_vencimento: z.string().optional(),

  nivel_icao_status: z.string().optional(),const PaginationSchema = z.object({

  aeronave_principal: z.string().optional(),  page: z.number().int().min(1).default(1),

  is_instrutor: z.union([z.number(), z.boolean()]).optional(),  limit: z.number().int().min(1).max(50).default(20)

  is_checador: z.union([z.number(), z.boolean()]).optional()});

});

const app = new Hono<{ Bindings: Env }>();

// GET / - Listar com paginação

app.get('/', async (c) => {// ===== MIDDLEWARE =====

  const db = c.env.DB;// TODO: app.use('*', authMiddleware); // Auth disabled in dev

  

  try {/**

    const url = new URL(c.req.url); * GET / - Lista funcionários com paginação, filtros e ordenação dinâmica

    const params = parsePaginationParams(url); */

    const search = url.searchParams.get('search') || '';app.get('/', async (c) => {

      const db = c.env.DB;

    let whereClause = 'WHERE deleted_at IS NULL';  // TODO: const user = c.get('user'); // Auth disabled in dev

    const bindings: any[] = [];  

      try {

    if (search) {    // ===== PAGINATION VALIDATION =====

      whereClause += ` AND (    const page = Math.max(1, parseInt(c.req.query('page') || '1'));

        nome LIKE ? OR     const limit = Math.min(50, Math.max(1, parseInt(c.req.query('limit') || '20')));

        cpf LIKE ? OR     const offset = (page - 1) * limit;

        matricula LIKE ? OR     

        email LIKE ?    const search = (c.req.query('search') || '').trim();

      )`;    const status = c.req.query('status');

      const searchTerm = `%${search}%`;    const funcao = c.req.query('funcao');

      bindings.push(searchTerm, searchTerm, searchTerm, searchTerm);    

    }    const orderBy = c.req.query('orderBy') || 'nome';

        const orderDir = (c.req.query('orderDir') || 'asc').toUpperCase();

    const countResult = await db.prepare(`    

      SELECT COUNT(*) as total     let whereConditions = ['deleted_at IS NULL'];

      FROM funcionarios     const params: any[] = [];

      ${whereClause}    

    `).bind(...bindings).first();    if (search) {

          whereConditions.push('(nome LIKE ? OR matricula LIKE ? OR cpf LIKE ? OR codigo_anac LIKE ?)');

    const total = (countResult?.total as number) || 0;      const searchTerm = `%${search}%`;

          params.push(searchTerm, searchTerm, searchTerm, searchTerm);

    const offset = calculateOffset(params.page, params.limit);    }

        

    const allowedSort = {    if (status && ['ATIVO', 'INATIVO', 'LICENCA', 'AFASTADO'].includes(status)) {

      nome: 'nome',      whereConditions.push('status = ?');

      matricula: 'matricula',      params.push(status);

      created_at: 'created_at',    }

      updated_at: 'updated_at'    

    } as const;    if (funcao) {

    const sortByKey = (typeof params.sortBy === 'string' && params.sortBy in allowedSort)      whereConditions.push('funcao = ?');

      ? (params.sortBy as keyof typeof allowedSort)      params.push(funcao);

      : 'created_at';    }

    const safeOrderBy = allowedSort[sortByKey];    

    const safeOrderDir = params.sortOrder === 'ASC' ? 'ASC' : 'DESC';    const whereClause = whereConditions.join(' AND ');

    

    const { results } = await db.prepare(`    const countResult = await db

      SELECT       .prepare(`SELECT COUNT(*) as total FROM funcionarios WHERE ${whereClause}`)

        id, nome, matricula, cpf, email, telefone,       .bind(...params)

        data_nascimento, guerra, cargo, funcao, setor,       .first();

        base, contrato, data_admissao, status,    

        codigo_anac, codigo_canac, codigo_sispat, codigo_prestserv,    const total = (countResult?.total as number) || 0;

        licenca_aeronautica, anv,    

        cma_numero, cma_data_vencimento, cma_status,    const orderByMap: Record<string, string> = {

        aso_data_vencimento,      'nome': 'nome',

        nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,      'matricula': 'matricula',

        aeronave_principal,      'funcao': 'funcao',

        is_instrutor, is_checador,      'cargo': 'cargo',

        created_at, updated_at      'status': 'status',

      FROM funcionarios      'codigo_anac': 'codigo_anac',

      ${whereClause}      'created_at': 'created_at'

      ORDER BY ${safeOrderBy} ${safeOrderDir}    };

      LIMIT ? OFFSET ?    

    `).bind(...bindings, params.limit, offset).all();    const orderByColumn = orderByMap[orderBy] || 'matricula';

    const orderDirection = orderDir === 'DESC' ? 'DESC' : 'ASC';

    return c.json(buildPaginatedResponse(    

      results || [],    const result = await db

      total,      .prepare(`

      params        SELECT 

    ));          id, matricula, nome, cpf, telefone, email,

  } catch (error: any) {          cargo, funcao, setor, base, contrato,

    console.error('[GET /] Erro:', error);          status, data_admissao, data_nascimento,

    return c.json({          codigo_anac, codigo_canac, licenca_aeronautica,

      success: false,          is_instrutor, is_checador,

      error: 'Erro ao listar funcionários',          created_at, updated_at

      details: error.message        FROM funcionarios

    }, 500);        WHERE ${whereClause}

  }        ORDER BY ${orderByColumn} ${orderDirection}

});        LIMIT ? OFFSET ?

      `)

// GET /:id - Detalhe      .bind(...params, limit, offset)

app.get('/:id', async (c) => {      .all();

  const id = parseInt(c.req.param('id'));    

  const db = c.env.DB;    const totalPages = Math.ceil(total / limit);

    

  try {    // ===== AUDIT LOGGING =====

    const funcionario = await db    try {

      .prepare(`      await db.prepare(`

        SELECT id, matricula, nome, funcao, setor, status,        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)

               is_instrutor, is_checador, email, telefone,        VALUES ('LIST_FUNCIONARIOS', 'funcionarios', ?, ?, 'LOW')

               data_admissao, created_at, updated_at      `).bind(

        FROM funcionarios        user?.id || null,

        WHERE id = ? AND deleted_at IS NULL        JSON.stringify({

      `)          page, limit, total, resultCount: result.results.length,

      .bind(id)          filters: { search: search ? '***' : null, status, funcao },

      .first();          usuario: user?.email,

          timestamp: new Date().toISOString()

    if (!funcionario) {        })

      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);      ).run();

    }    } catch (auditError) {

      Logger.warn('Failed to log list funcionarios', { error: String(auditError) });

    return c.json({ success: true, funcionario, data: funcionario });    }

  } catch (error: any) {    

    console.error('[GET /:id] Erro:', error);    return c.json({

    return c.json({ success: false, error: 'Erro ao buscar funcionário' }, 500);      success: true,

  }      data: result.results,

});      total,

      pagination: {

// POST / - Criar        page,

app.post('/', async (c) => {        limit,

  const db = c.env.DB;        totalPages,

          hasNext: page < totalPages,

  try {        hasPrev: page > 1

    const body = await c.req.json();      }

    const validation = FuncionarioSchema.safeParse(body);    });

      } catch (error: any) {

    if (!validation.success) {    Logger.error('[FUNCIONARIOS] Erro ao listar:', error);

      return c.json({ success: false, error: 'Dados inválidos', details: validation.error.errors }, 400);    return c.json({ success: false, error: error.message }, 500);

    }  }

});

    const data = validation.data;

/**

    const exists = await db * GET /:id - Buscar funcionário por ID

      .prepare('SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL') */

      .bind(data.matricula)app.get('/:id', async (c) => {

      .first();  const db = c.env.DB;

  // TODO: const user = c.get('user'); // Auth disabled in dev

    if (exists) {  

      return c.json({ success: false, error: 'Matrícula já cadastrada' }, 409);  try {

    }    const id = parseInt(c.req.param('id'));

    

    const result = await db    if (isNaN(id) || id < 1) {

      .prepare(`      return c.json({ success: false, error: 'ID inválido', code: 'INVALID_ID' }, 400);

        INSERT INTO funcionarios (    }

          matricula, nome, cpf, telefone, email, cargo, funcao, setor, base,    

          status, data_admissao, data_nascimento, guerra, contrato,    const result = await db

          codigo_anac, codigo_canac, codigo_sispat, codigo_prestserv,      .prepare(`

          licenca_aeronautica, anv,        SELECT 

          cma_numero, cma_data_vencimento, cma_status,          id, matricula, nome, cpf, telefone, email,

          aso_data_vencimento,          cargo, funcao, setor, base, contrato,

          nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,          status, data_admissao, data_nascimento,

          aeronave_principal, is_instrutor, is_checador,          codigo_anac, codigo_canac, licenca_aeronautica,

          created_at, updated_at          is_instrutor, is_checador,

        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))          created_at, updated_at

      `)        FROM funcionarios

      .bind(        WHERE id = ? AND deleted_at IS NULL

        data.matricula, data.nome, data.cpf || null, data.telefone || null, data.email || null,      `)

        data.cargo || null, data.funcao || null, data.setor || null, data.base || null,      .bind(id)

        data.status, data.data_admissao || null, data.data_nascimento || null,      .first();

        data.guerra || null, data.contrato || null, data.codigo_anac || null,    

        data.codigo_canac || null, data.codigo_sispat || null, data.codigo_prestserv || null,    if (!result) {

        data.licenca_aeronautica || null, data.anv || null, data.cma_numero || null,      Logger.warn('Funcionário not found', { id: String(id), userId: user?.id ? String(user.id) : undefined });

        data.cma_data_vencimento || null, data.cma_status || null,      return c.json({ success: false, error: 'Funcionário não encontrado', code: 'NOT_FOUND' }, 404);

        data.aso_data_vencimento || null, data.nivel_icao || null,    }

        data.nivel_icao_data_vencimento || null, data.nivel_icao_status || null,    

        data.aeronave_principal || null, data.is_instrutor || 0, data.is_checador || 0    // ===== AUDIT LOGGING =====

      )    try {

      .run();      await db.prepare(`

        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)

    const newId = result.meta.last_row_id;        VALUES ('GET_FUNCIONARIO', 'funcionarios', ?, ?, 'LOW')

      `).bind(

    invalidateCache('dashboard:');        user?.id || null,

    invalidateCache('funcionarios:');        JSON.stringify({

          funcionario_id: id,

    return c.json({ success: true, id: newId, funcionario: { id: newId, ...data } }, 201);          usuario: user?.email,

  } catch (error: any) {          timestamp: new Date().toISOString()

    console.error('[POST] Erro:', error);        })

    return c.json({ success: false, error: 'Erro ao criar funcionário', message: error.message }, 500);      ).run();

  }    } catch (auditError) {

});      Logger.warn('Failed to log get funcionario', { error: String(auditError) });

    }

// PUT /:id - Atualizar    

app.put('/:id', async (c) => {    return c.json({ success: true, data: result });

  const id = c.req.param('id');  } catch (error: any) {

  const db = c.env.DB;    Logger.error('[FUNCIONARIOS] Erro ao buscar:', error);

    return c.json({ success: false, error: error.message }, 500);

  try {  }

    const oldData = await db});

      .prepare(`SELECT id, matricula, nome, funcao, setor, status, is_instrutor, is_checador, email, telefone FROM funcionarios WHERE id = ? AND deleted_at IS NULL`)

      .bind(id)/**

      .first(); * POST / - Criar novo funcionário

 */

    if (!oldData) {app.post('/', async (c) => {

      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);  const db = c.env.DB;

    }  // TODO: const user = c.get('user'); // Auth disabled in dev

  

    const body = await c.req.json();  try {

    const validation = FuncionarioSchema.partial().safeParse(body);    const body = await c.req.json();

        

    if (!validation.success) {    // ===== INPUT VALIDATION =====

      return c.json({ success: false, error: 'Dados inválidos', details: validation.error.errors }, 400);    try {

    }      FuncionarioSchema.parse(body);

    } catch (validationError: any) {

    const data = validation.data;      return c.json({ 

        success: false, 

    const oldMatriculaNormalizada = oldData.matricula ? String(oldData.matricula).padStart(5, '0') : '';        error: validationError.errors?.[0]?.message || 'Validação falhou',

            code: 'VALIDATION_ERROR'

    if (data.matricula && data.matricula !== oldMatriculaNormalizada) {      }, 400);

      const exists = await db    }

        .prepare('SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND id != ? AND deleted_at IS NULL')    

        .bind(data.matricula, id)    const { 

        .first();      nome, matricula, cpf, telefone, email,

      cargo, funcao, setor, base, contrato,

      if (exists) {      data_admissao, data_nascimento,

        return c.json({ success: false, error: `Matrícula ${data.matricula} já cadastrada para ${exists.nome}` }, 409);      codigo_anac, codigo_canac, licenca_aeronautica,

      }      is_instrutor, is_checador

    }    } = body;

    

    const updates: string[] = [];    if (!nome || !matricula || !email) {

    const values: any[] = [];      return c.json({ success: false, error: 'Campos obrigatórios: nome, matricula, email', code: 'MISSING_FIELDS' }, 400);

    }

    Object.entries(data).forEach(([key, value]) => {    

      if (value !== undefined) {    // ===== CPF VALIDATION =====

        updates.push(`${key} = ?`);    if (cpf && !isValidCPF(cpf)) {

        values.push(value);      return c.json({ success: false, error: 'CPF inválido', code: 'INVALID_CPF' }, 400);

      }    }

    });    

    // ===== CHECK DUPLICATE EMAIL =====

    if (updates.length === 0) {    const emailCheck = await db

      return c.json({ success: false, error: 'Nenhum campo para atualizar' }, 400);      .prepare(`SELECT id FROM funcionarios WHERE email = ? AND deleted_at IS NULL LIMIT 1`)

    }      .bind(email)

      .first();

    updates.push('updated_at = datetime(\'now\')');    

    values.push(id);    if (emailCheck) {

      Logger.warn('Email already exists', { email: '***', userId: user?.id ? String(user.id) : undefined });

    await db      return c.json({ success: false, error: 'Email já cadastrado', code: 'EMAIL_EXISTS' }, 400);

      .prepare(`UPDATE funcionarios SET ${updates.join(', ')} WHERE id = ?`)    }

      .bind(...values)    

      .run();    // ===== CHECK DUPLICATE CPF =====

    if (cpf) {

    invalidateCache('dashboard:');      const cpfCheck = await db

    invalidateCache('funcionarios:');        .prepare(`SELECT id FROM funcionarios WHERE cpf = ? AND deleted_at IS NULL LIMIT 1`)

        .bind(cpf)

    const updated = await db        .first();

      .prepare(`SELECT id, matricula, nome, funcao, setor, status, is_instrutor, is_checador, created_at, updated_at FROM funcionarios WHERE id = ?`)      

      .bind(id)      if (cpfCheck) {

      .first();        Logger.warn('CPF already exists', { cpf: '***', userId: user?.id ? String(user.id) : undefined });

        return c.json({ success: false, error: 'CPF já cadastrado', code: 'CPF_EXISTS' }, 400);

    return c.json({ success: true, funcionario: updated });      }

  } catch (error: any) {    }

    console.error('[PUT] Erro:', error);    

    return c.json({ success: false, error: 'Erro ao atualizar funcionário', message: error.message }, 500);    const result = await db

  }      .prepare(`

});        INSERT INTO funcionarios (

          nome, matricula, cpf, telefone, email,

// DELETE /:id - Deletar          cargo, funcao, setor, base, contrato,

app.delete('/:id', async (c) => {          status, data_admissao, data_nascimento,

  const id = c.req.param('id');          codigo_anac, codigo_canac, licenca_aeronautica,

  const db = c.env.DB;          is_instrutor, is_checador,

            created_at, updated_at

  try {        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ATIVO', ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))

    const funcionario = await db.prepare(`SELECT id, nome, matricula FROM funcionarios WHERE id = ? AND deleted_at IS NULL`).bind(id).first();      `)

          .bind(

    if (!funcionario) {        nome, matricula, cpf, telefone, email,

      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);        cargo, funcao, setor, base, contrato,

    }        data_admissao, data_nascimento,

            codigo_anac, codigo_canac, licenca_aeronautica,

    await db.prepare(`UPDATE funcionarios SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`).bind(id).run();        is_instrutor || 0, is_checador || 0

          )

    invalidateCache('dashboard:');      .run();

    invalidateCache('funcionarios:');    

        // ===== AUDIT LOGGING =====

    return c.json({ success: true, message: 'Funcionário excluído com sucesso' });    try {

  } catch (error: any) {      await db.prepare(`

    console.error('❌ Erro ao excluir funcionário:', error);        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)

    return c.json({ success: false, error: 'Erro ao excluir funcionário', message: error.message }, 500);        VALUES ('CREATE_FUNCIONARIO', 'funcionarios', ?, ?, 'MEDIUM')

  }      `).bind(

});        user?.id || null,

        JSON.stringify({

// POST /batch - Múltiplos          funcionario_id: result.meta.last_row_id,

app.post('/batch', async (c) => {          nome, matricula, email: '***',

  try {          usuario: user?.email,

    const funcionarios = await c.req.json();          timestamp: new Date().toISOString()

            })

    if (!Array.isArray(funcionarios)) {      ).run();

      return c.json({ success: false, error: 'Payload deve ser um array' }, 400);    } catch (auditError) {

    }      Logger.warn('Failed to log create funcionario', { error: String(auditError) });

        }

    if (funcionarios.length > 100) {    

      return c.json({ success: false, error: 'Máximo 100 registros por batch' }, 400);    return c.json({ 

    }      success: true, 

          data: { id: result.meta.last_row_id, ...body },

    const db = c.env.DB;      message: 'Funcionário criado com sucesso!' 

    const ids: number[] = [];    }, 201);

    const erros: any[] = [];  } catch (error: any) {

        Logger.error('[FUNCIONARIOS] Erro ao criar:', error);

    for (let i = 0; i < funcionarios.length; i++) {    return c.json({ success: false, error: error.message }, 500);

      try {  }

        const validated = FuncionarioSchema.parse(funcionarios[i]);});

        const result = await db.prepare(`

          INSERT INTO funcionarios (nome, matricula, cpf, email, telefone, cargo, funcao, setor, base, status, created_at, updated_at)/**

          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now')) * PUT /:id - Atualizar funcionário

        `).bind( */

          validated.nome, validated.matricula, validated.cpf || null, validated.email || null,app.put('/:id', async (c) => {

          validated.telefone || null, validated.cargo || null, validated.funcao || null,  const db = c.env.DB;

          validated.setor || null, validated.base || null, validated.status || 'ATIVO'  // TODO: const user = c.get('user'); // Auth disabled in dev

        ).run();  

          try {

        ids.push(result.meta.last_row_id as number);    const id = parseInt(c.req.param('id'));

      } catch (error: any) {    

        erros.push({ index: i, erro: error.message });    if (isNaN(id) || id < 1) {

      }      return c.json({ success: false, error: 'ID inválido', code: 'INVALID_ID' }, 400);

    }    }

        

    invalidateCache('dashboard:');    const body = await c.req.json();

    invalidateCache('funcionarios:');    

        // ===== INPUT VALIDATION =====

    return c.json({ success: true, criados: ids.length, ids, erros: erros.length > 0 ? erros : undefined }, 201);    try {

  } catch (error: any) {      FuncionarioSchema.parse(body);

    console.error('[BATCH] Erro:', error);    } catch (validationError: any) {

    return c.json({ success: false, error: 'Erro ao processar batch', message: error.message }, 500);      return c.json({ 

  }        success: false, 

});        error: validationError.errors?.[0]?.message || 'Validação falhou',

        code: 'VALIDATION_ERROR'

export default app;      }, 400);

    }
    
    const { 
      nome, matricula, cpf, telefone, email,
      cargo, funcao, setor, base, contrato,
      status, data_admissao, data_nascimento,
      codigo_anac, codigo_canac, licenca_aeronautica,
      is_instrutor, is_checador
    } = body;
    
    if (!nome || !matricula || !email) {
      return c.json({ success: false, error: 'Campos obrigatórios: nome, matricula, email', code: 'MISSING_FIELDS' }, 400);
    }
    
    // ===== CPF VALIDATION =====
    if (cpf && !isValidCPF(cpf)) {
      return c.json({ success: false, error: 'CPF inválido', code: 'INVALID_CPF' }, 400);
    }
    
    // ===== FETCH OLD DATA FOR AUDIT =====
    const oldData = await db
      .prepare(`SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL`)
      .bind(id)
      .first();
    
    if (!oldData) {
      return c.json({ success: false, error: 'Funcionário não encontrado', code: 'NOT_FOUND' }, 404);
    }
    
    // ===== CHECK DUPLICATE EMAIL (if changed) =====
    if (email !== oldData.email) {
      const emailCheck = await db
        .prepare(`SELECT id FROM funcionarios WHERE email = ? AND id != ? AND deleted_at IS NULL LIMIT 1`)
        .bind(email, id)
        .first();
      
      if (emailCheck) {
        Logger.warn('Email already exists', { email: '***', userId: user?.id ? String(user.id) : undefined });
        return c.json({ success: false, error: 'Email já cadastrado', code: 'EMAIL_EXISTS' }, 400);
      }
    }
    
    // ===== CHECK DUPLICATE CPF (if changed) =====
    if (cpf && cpf !== oldData.cpf) {
      const cpfCheck = await db
        .prepare(`SELECT id FROM funcionarios WHERE cpf = ? AND id != ? AND deleted_at IS NULL LIMIT 1`)
        .bind(cpf, id)
        .first();
      
      if (cpfCheck) {
        Logger.warn('CPF already exists', { cpf: '***', userId: user?.id ? String(user.id) : undefined });
        return c.json({ success: false, error: 'CPF já cadastrado', code: 'CPF_EXISTS' }, 400);
      }
    }
    
    await db
      .prepare(`
        UPDATE funcionarios SET
          nome = ?, matricula = ?, cpf = ?, telefone = ?, email = ?,
          cargo = ?, funcao = ?, setor = ?, base = ?, contrato = ?,
          status = ?, data_admissao = ?, data_nascimento = ?,
          codigo_anac = ?, codigo_canac = ?, licenca_aeronautica = ?,
          is_instrutor = ?, is_checador = ?,
          updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(
        nome, matricula, cpf, telefone, email,
        cargo, funcao, setor, base, contrato,
        status || 'ATIVO', data_admissao, data_nascimento,
        codigo_anac, codigo_canac, licenca_aeronautica,
        is_instrutor || 0, is_checador || 0,
        id
      )
      .run();
    
    // ===== AUDIT LOGGING =====
    try {
      const changes = Object.keys(body).filter(key => oldData[key] !== body[key]);
      await db.prepare(`
        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
        VALUES ('UPDATE_FUNCIONARIO', 'funcionarios', ?, ?, 'MEDIUM')
      `).bind(
        user?.id || null,
        JSON.stringify({
          funcionario_id: id,
          campos_alterados: changes.length > 0 ? changes : ['none'],
          usuario: user?.email,
          timestamp: new Date().toISOString()
        })
      ).run();
    } catch (auditError) {
      Logger.warn('Failed to log update funcionario', { error: String(auditError) });
    }
    
    return c.json({ 
      success: true, 
      message: 'Funcionário atualizado com sucesso!' 
    });
  } catch (error: any) {
    Logger.error('[FUNCIONARIOS] Erro ao atualizar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * DELETE /:id - Soft delete de funcionário
 */
app.delete('/:id', async (c) => {
  const db = c.env.DB;
  // TODO: const user = c.get('user'); // Auth disabled in dev
  
  try {
    const id = parseInt(c.req.param('id'));
    
    if (isNaN(id) || id < 1) {
      return c.json({ success: false, error: 'ID inválido', code: 'INVALID_ID' }, 400);
    }
    
    // ===== FETCH DATA BEFORE DELETE =====
    const deletedData = await db
      .prepare(`SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL`)
      .bind(id)
      .first();
    
    if (!deletedData) {
      return c.json({ success: false, error: 'Funcionário não encontrado', code: 'NOT_FOUND' }, 404);
    }
    
    await db
      .prepare(`
        UPDATE funcionarios 
        SET deleted_at = datetime('now'), updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(id)
      .run();
    
    // ===== AUDIT LOGGING =====
    try {
      await db.prepare(`
        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
        VALUES ('DELETE_FUNCIONARIO', 'funcionarios', ?, ?, 'HIGH')
      `).bind(
        user?.id || null,
        JSON.stringify({
          funcionario_id: id,
          funcionario_nome: deletedData.nome,
          funcionario_matricula: deletedData.matricula,
          usuario: user?.email,
          timestamp: new Date().toISOString()
        })
      ).run();
    } catch (auditError) {
      Logger.warn('Failed to log delete funcionario', { error: String(auditError) });
    }
    
    return c.json({ 
      success: true, 
      message: 'Funcionário excluído com sucesso' 
    });
  } catch (error: any) {
    Logger.error('[FUNCIONARIOS] Erro ao excluir:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

app.get('/instrutores', async (c) => {
  try {
    const db = c.env.DB;
    // TODO: const user = c.get('user'); // Auth disabled in dev
    
    const { results } = await db
      .prepare(`
        SELECT 
          f.id,
          f.nome,
          f.matricula,
          f.email,
          f.telefone,
          f.funcao_id,
          fun.nome as funcao_nome,
          f.setor_id,
          s.nome as setor_nome,
          f.codigo_anac,
          f.is_instrutor,
          f.is_checador,
          f.created_at
        FROM funcionarios f
        LEFT JOIN funcoes fun ON f.funcao_id = fun.id
        LEFT JOIN setores s ON f.setor_id = s.id
        WHERE f.deleted_at IS NULL
          AND f.is_instrutor = 1
        ORDER BY f.nome ASC
      `)
      .bind()
      .all();

    // ===== AUDIT LOGGING =====
    try {
      await db.prepare(`
        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
        VALUES ('LIST_INSTRUTORES', 'funcionarios', ?, ?, 'LOW')
      `).bind(
        user?.id || null,
        JSON.stringify({
          resultCount: results?.length || 0,
          usuario: user?.email,
          timestamp: new Date().toISOString()
        })
      ).run();
    } catch (auditError) {
      Logger.warn('Failed to log list instrutores', { error: String(auditError) });
    }

    return c.json({
      success: true,
      data: results || [],
      total: results?.length || 0
    });
  } catch (error: any) {
    Logger.error('[FUNCIONARIOS] Erro ao buscar instrutores:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao buscar instrutores',
      code: 'INSTRUTORES_ERROR'
    }, 500);
  }
});

app.get('/examinadores', async (c) => {
  try {
    const db = c.env.DB;
    // TODO: const user = c.get('user'); // Auth disabled in dev
    
    const { results } = await db
      .prepare(`
        SELECT 
          f.id,
          f.nome,
          f.matricula,
          f.email,
          f.telefone,
          f.funcao_id,
          fun.nome as funcao_nome,
          f.setor_id,
          s.nome as setor_nome,
          f.codigo_anac,
          f.is_instrutor,
          f.is_checador,
          f.created_at
        FROM funcionarios f
        LEFT JOIN funcoes fun ON f.funcao_id = fun.id
        LEFT JOIN setores s ON f.setor_id = s.id
        WHERE f.deleted_at IS NULL
          AND f.is_checador = 1
        ORDER BY f.nome ASC
      `)
      .bind()
      .all();

    // ===== AUDIT LOGGING =====
    try {
      await db.prepare(`
        INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
        VALUES ('LIST_EXAMINADORES', 'funcionarios', ?, ?, 'LOW')
      `).bind(
        user?.id || null,
        JSON.stringify({
          resultCount: results?.length || 0,
          usuario: user?.email,
          timestamp: new Date().toISOString()
        })
      ).run();
    } catch (auditError) {
      Logger.warn('Failed to log list examinadores', { error: String(auditError) });
    }

    return c.json({
      success: true,
      data: results || [],
      total: results?.length || 0
    });
  } catch (error: any) {
    Logger.error('[FUNCIONARIOS] Erro ao buscar examinadores:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao buscar examinadores',
      code: 'EXAMINADORES_ERROR'
    }, 500);
  }
});

export default app;
