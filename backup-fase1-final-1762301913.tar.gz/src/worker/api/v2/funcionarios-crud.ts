import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../../types';
import { Logger } from '../../utils/logger';
import { Validators } from '../../utils/validators';
import { invalidateCache } from '../../utils/cache';
import {
  parsePaginationParams,
  buildPaginatedResponse,
  calculateOffset,
} from '../../utils/pagination';

const app = new Hono<{ Bindings: Env }>();

const shouldAuth =
  process.env.NODE_ENV === 'production' ||
  (process.env.NODE_ENV !== 'test' && !process.env.VITEST && process.env.DISABLE_AUTH !== 'true');

if (shouldAuth) {
}

const sanitizeString = (str: string): string => {
  if (!str) return str;
  return str
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<[^>]*>/g, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .trim();
};

const FuncionarioSchema = z.object({
  matricula: z
    .string()
    .min(1, 'Matrícula é obrigatória')
    .transform((val) => {
      const numeros = val.replace(/\D/g, '');
      return numeros.padStart(5, '0');
    })
    .refine((val) => val.length === 5, 'Matrícula deve ter 5 dígitos')
    .refine((val) => /^\d{5}$/.test(val), 'Matrícula deve conter apenas números'),
  nome: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres').transform(sanitizeString),
  cpf: z
    .string()
    .transform((val) => (val ? val.replace(/[^0-9]/g, '') : val))
    .refine((cpf) => !cpf || cpf.length === 11, 'CPF deve ter 11 dígitos')
    .refine((cpf) => !cpf || Validators.validateCPF(cpf), 'CPF inválido')
    .optional(),
  telefone: z.string().optional(),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
  cargo: z
    .string()
    .optional()
    .transform((val) => (val ? sanitizeString(val) : val)),
  funcao: z
    .string()
    .optional()
    .transform((val) => (val ? sanitizeString(val) : val)),
  setor: z
    .string()
    .optional()
    .transform((val) => (val ? sanitizeString(val) : val)),
  base: z
    .string()
    .optional()
    .transform((val) => (val ? sanitizeString(val) : val)),
  status: z.enum(['ATIVO', 'INATIVO', 'AFASTADO', 'FERIAS', 'LICENCA']).default('ATIVO'),
  data_admissao: z.string().optional(),
  data_nascimento: z.string().optional(),
  guerra: z.string().optional(),
  contrato: z.string().optional(),
  codigo_anac: z.union([z.string(), z.number()]).optional(),
  codigo_sispat: z.string().optional(),
  codigo_prestserv: z.string().optional(),
  licenca_aeronautica: z.string().optional(),
  aeronave: z.string().optional(),
  cma_numero: z.string().optional(),
  cma_data_vencimento: z.string().optional(),
  cma_status: z.string().optional(),
  aso_data_vencimento: z.string().optional(),
  icao_nivel: z.string().optional(),
  icao_vencimento: z.string().optional(),
  icao_status: z.string().optional(),
  aeronave: z.string().optional(),
  is_instrutor: z.union([z.number(), z.boolean()]).optional(),
  is_checador: z.union([z.number(), z.boolean()]).optional(),
});

app.get('/', async (c) => {
  const db = c.env.DB;

  try {
    const url = new URL(c.req.url);
    const params = parsePaginationParams(url);
    const search = url.searchParams.get('search') || '';

    let whereClause = 'WHERE deleted_at IS NULL';
    const bindings: any[] = [];

    if (search) {
      whereClause += ` AND (
        nome LIKE ? OR 
        cpf LIKE ? OR 
        matricula LIKE ? OR 
        email LIKE ?
      )`;
      const searchTerm = `%${search}%`;
      bindings.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    const countResult = await db
      .prepare(
        `
      SELECT COUNT(*) as total 
      FROM funcionarios 
      ${whereClause}
    `,
      )
      .bind(...bindings)
      .first();

    const total = (countResult?.total as number) || 0;

    const offset = calculateOffset(params.page, params.limit);

    const allowedSort = {
      nome: 'nome',
      matricula: 'matricula',
      created_at: 'created_at',
      updated_at: 'updated_at',
    } as const;
    const sortByKey =
      typeof params.sortBy === 'string' && params.sortBy in allowedSort
        ? (params.sortBy as keyof typeof allowedSort)
        : 'created_at';
    const safeOrderBy = allowedSort[sortByKey];
    const safeOrderDir = params.sortOrder === 'ASC' ? 'ASC' : 'DESC';

    const { results } = await db
      .prepare(
        `
      SELECT 
        id, nome, matricula, cpf, email, telefone, 
        data_nascimento, guerra, cargo, funcao, setor, 
        base, contrato, data_admissao, status,
        codigo_anac, codigo_sispat, codigo_prestserv,
        licenca_aeronautica,
        cma_numero, cma_data_vencimento, cma_status,
        aso_data_vencimento,
        icao_nivel, icao_vencimento, icao_status,
        is_instrutor, is_checador,
        created_at, updated_at
      FROM funcionarios
      ${whereClause}
      ORDER BY ${safeOrderBy} ${safeOrderDir}
      LIMIT ? OFFSET ?
    `,
      )
      .bind(...bindings, params.limit, offset)
      .all();

    return c.json(buildPaginatedResponse(results || [], total, params));
  } catch (error: any) {
    console.error('[GET /] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao listar funcionários',
        details: error.message,
      },
      500,
    );
  }
});

app.get('/listar', async (c) => {
  const db = c.env.DB;
  try {
    const { results } = await (
      db.prepare(`
      SELECT 
        id, nome, matricula, cpf, email, telefone, 
        funcao, setor, base, status,
        codigo_anac,
        cma_numero, cma_data_vencimento, cma_status,
        aso_data_vencimento,
        icao_nivel, icao_vencimento
      FROM funcionarios
      WHERE deleted_at IS NULL
      ORDER BY nome ASC
      LIMIT 1000
    `) as any
    ).all();

    const count = await (
      db.prepare(`SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL`) as any
    ).first();
    const total = (count?.total as number) || results?.length || 0;

    return c.json({ success: true, data: results || [], total });
  } catch (error: any) {
    return c.json({ success: false, error: error.message || 'Erro ao listar' }, 500);
  }
});

app.get('/exportar', async (c) => {
  const db = c.env.DB;
  const format = c.req.query('format') || 'csv';

  try {
    const result = await db
      .prepare(
        `
        SELECT 
          id, matricula, nome, cpf, email, telefone, data_nascimento,
          cargo, funcao, setor, base, contrato, data_admissao, status,
          codigo_anac, licenca_aeronautica,
          cma_numero, cma_data_vencimento, cma_status,
          aso_data_vencimento, icao_nivel, icao_vencimento,
          created_at, updated_at
        FROM funcionarios 
        WHERE deleted_at IS NULL 
        ORDER BY matricula ASC
      `,
      )
      .bind()
      .all();

    const results = result.results || [];

    if (format === 'json') {
      return c.json(
        {
          success: true,
          total: results.length,
          data: results,
          exported_at: new Date().toISOString(),
          format: 'json',
          metadata: {
            version: 'v2',
            endpoint: '/api/v2/funcionarios/exportar',
            query: { format: 'json' },
          },
        },
        200,
      );
    }

    const headers = [
      'Matrícula',
      'Nome',
      'CPF',
      'Email',
      'Telefone',
      'Data Nascimento',
      'Cargo',
      'Função',
      'Setor',
      'Base',
      'Contrato',
      'Data Admissão',
      'Status',
      'Código ANAC',
      'Código CANAC',
      'Licença Aeronáutica',
      'CMA Número',
      'CMA Vencimento',
      'CMA Status',
      'ASO Vencimento',
      'Nível ICAO',
      'ICAO Vencimento',
    ];

    const rows = results.map((f: any) => [
      f.matricula || '',
      f.nome || '',
      f.cpf || '',
      f.email || '',
      f.telefone || '',
      f.data_nascimento || '',
      f.cargo || '',
      f.funcao || '',
      f.setor || '',
      f.base || '',
      f.contrato || '',
      f.data_admissao || '',
      f.status || '',
      f.codigo_anac || '',
      f.licenca_aeronautica || '',
      f.cma_numero || '',
      f.cma_data_vencimento || '',
      f.cma_status || '',
      f.aso_data_vencimento || '',
      f.icao_nivel || '',
      f.icao_vencimento || '',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row: string[]) => row.map((cell: string) => `"${cell}"`).join(',')),
    ].join('\n');

    const timestamp = new Date().toISOString().split('T')[0];

    return new Response(csvContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="funcionarios_${timestamp}.csv"`,
        'Cache-Control': 'no-cache',
      },
    });
  } catch (error: any) {
    console.error('[EXPORTAR] Erro:', error);
    return c.json(
      { success: false, error: 'Erro ao exportar funcionários', message: error.message },
      500,
    );
  }
});

app.get('/export', async (c) => {
  const db = c.env.DB;
  const format = c.req.query('format') || 'csv'; // csv ou json

  try {
    const result = await db
      .prepare(
        `
        SELECT 
          id, matricula, nome, cpf, email, telefone, data_nascimento,
          cargo, funcao, setor, base, contrato, data_admissao, status,
          codigo_anac, licenca_aeronautica,
          cma_numero, cma_data_vencimento, cma_status,
          aso_data_vencimento, icao_nivel, icao_vencimento,
          created_at, updated_at
        FROM funcionarios 
        WHERE deleted_at IS NULL 
        ORDER BY matricula ASC
      `,
      )
      .bind()
      .all();

    const results = result.results;

    if (format === 'json') {
      return c.json(
        {
          success: true,
          total: results?.length || 0,
          data: results || [],
          exported_at: new Date().toISOString(),
          format: 'json',
          metadata: {
            version: 'v2',
            endpoint: '/api/v2/funcionarios/export',
            query: { format: 'json' },
          },
        },
        200,
      );
    }

    const headers = [
      'Matrícula',
      'Nome',
      'CPF',
      'Email',
      'Telefone',
      'Data Nascimento',
      'Cargo',
      'Função',
      'Setor',
      'Base',
      'Contrato',
      'Data Admissão',
      'Status',
      'Código ANAC',
      'Código CANAC',
      'Licença Aeronáutica',
      'CMA Número',
      'CMA Vencimento',
      'CMA Status',
      'ASO Vencimento',
      'Nível ICAO',
      'ICAO Vencimento',
    ];

    const rows = (results || []).map((f: any) => [
      f.matricula || '',
      f.nome || '',
      f.cpf || '',
      f.email || '',
      f.telefone || '',
      f.data_nascimento || '',
      f.cargo || '',
      f.funcao || '',
      f.setor || '',
      f.base || '',
      f.contrato || '',
      f.data_admissao || '',
      f.status || '',
      f.codigo_anac || '',
      f.licenca_aeronautica || '',
      f.cma_numero || '',
      f.cma_data_vencimento || '',
      f.cma_status || '',
      f.aso_data_vencimento || '',
      f.icao_nivel || '',
      f.icao_vencimento || '',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row: string[]) => row.map((cell: string) => `"${cell}"`).join(',')),
    ].join('\n');

    const timestamp = new Date().toISOString().split('T')[0];

    return new Response(csvContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="funcionarios_${timestamp}.csv"`,
        'Cache-Control': 'no-cache',
      },
    });
  } catch (error: any) {
    console.error('[EXPORT] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao exportar funcionários',
        message: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
      },
      500,
    );
  }
});

app.get('/instrutores', async (c) => {
  const db = c.env.DB;

  try {
    const { results } = await (
      db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        email,
        telefone
      FROM funcionarios
      WHERE is_instrutor = 1
        AND deleted_at IS NULL
        AND status = 'ATIVO'
      ORDER BY nome
    `) as any
    ).all();

    return c.json({
      success: true,
      data: results || [],
    });
  } catch (error: any) {
    console.error('❌ [INSTRUTORES] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar instrutores',
        details: error.message,
      },
      500,
    );
  }
});

app.get('/examinadores', async (c) => {
  const db = c.env.DB;

  try {
    const { results } = await (
      db.prepare(`
      SELECT 
        id,
        nome,
        matricula,
        funcao,
        email,
        telefone
      FROM funcionarios
      WHERE is_checador = 1
        AND deleted_at IS NULL
        AND status = 'ATIVO'
      ORDER BY nome
    `) as any
    ).all();

    return c.json({
      success: true,
      data: results || [],
    });
  } catch (error: any) {
    console.error('❌ [EXAMINADORES] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar examinadores',
        details: error.message,
      },
      500,
    );
  }
});

app.get('/:id', async (c) => {
  const id = parseInt(c.req.param('id'));
  const db = c.env.DB;

  try {
    const funcionario = await db
      .prepare(
        `
        SELECT id, matricula, nome, funcao, setor, status,
               is_instrutor, is_checador, email, telefone,
               data_admissao, created_at, updated_at
        FROM funcionarios
        WHERE id = ? AND deleted_at IS NULL
      `,
      )
      .bind(id)
      .first();

    if (!funcionario) {
      return c.json(
        {
          success: false,
          error: 'Funcionário não encontrado',
        },
        404,
      );
    }

    try {
      const latestCma = await db
        .prepare(
          `
        SELECT data_vencimento, numero, resultado
        FROM qualificacoes
        WHERE funcionario_id = ? 
          AND deleted_at IS NULL
          AND (UPPER(codigo) = 'CMA' OR UPPER(codigo) LIKE '%CMA%')
        ORDER BY (data_vencimento IS NULL) ASC, data_vencimento DESC, COALESCE(data_conclusao, data_conclusao, id) DESC
        LIMIT 1
      `,
        )
        .bind(id)
        .first();
      if (latestCma) {
        if (!funcionario.cma_data_vencimento)
          funcionario.cma_data_vencimento = latestCma.data_vencimento;
        if (!funcionario.cma_numero && latestCma.numero) funcionario.cma_numero = latestCma.numero;
        if (!funcionario.cma_status && latestCma.resultado)
          funcionario.cma_status = latestCma.resultado;
      }

      const latestAso = await db
        .prepare(
          `
        SELECT data_vencimento, numero
        FROM qualificacoes
        WHERE funcionario_id = ? 
          AND deleted_at IS NULL
          AND (UPPER(codigo) = 'ASO' OR UPPER(codigo) LIKE '%ASO%')
        ORDER BY (data_vencimento IS NULL) ASC, data_vencimento DESC, COALESCE(data_conclusao, data_conclusao, id) DESC
        LIMIT 1
      `,
        )
        .bind(id)
        .first();
      if (latestAso) {
        if (!funcionario.aso_data_vencimento)
          funcionario.aso_data_vencimento = latestAso.data_vencimento;
        if (!funcionario.aso_numero && latestAso.numero)
          (funcionario as any).aso_numero = latestAso.numero;
      }

      const latestIcao = await db
        .prepare(
          `
        SELECT data_vencimento, resultado, observacoes, nome
        FROM qualificacoes
        WHERE funcionario_id = ? 
          AND deleted_at IS NULL
          AND (UPPER(codigo) = 'ICAO' OR UPPER(codigo) LIKE '%ICAO%')
        ORDER BY (data_vencimento IS NULL) ASC, data_vencimento DESC, COALESCE(data_conclusao, data_conclusao, id) DESC
        LIMIT 1
      `,
        )
        .bind(id)
        .first();
      if (latestIcao) {
        if (!funcionario.icao_vencimento)
          funcionario.icao_vencimento = latestIcao.data_vencimento;
        if (!funcionario.icao_nivel) {
          const raw = String(
            latestIcao.resultado || latestIcao.observacoes || latestIcao.nome || '',
          ).trim();
          const m = raw.match(/(\d)/);
          if (m) {
            funcionario.icao_nivel = m[1];
          } else if (['1', '2', '3', '4', '5', '6'].includes(raw)) {
            funcionario.icao_nivel = raw;
          }
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Fallback de exibicao via qualificacoes falhou:', e);
    }

    try {
      const matRaw = String(funcionario.matricula || '').trim();
      const matPadded = matRaw.padStart(5, '0');
      const matUnpadded = matRaw.replace(/^0+/, '');
      const mat = matRaw;
      if (mat) {
        if (
          !funcionario.cma_data_vencimento ||
          !funcionario.cma_numero ||
          !funcionario.cma_status
        ) {
          const cmaV3 = await db
            .prepare(
              `
            SELECT datavencimento, dataconclusao, status, observacoes
            FROM certificacoesv3
            WHERE funcionariomatricula IN (?, ?, ?) 
              AND UPPER(treinamentocodigo) LIKE '%CMA%'
              AND deleted_at IS NULL
            ORDER BY COALESCE(dataconclusao, datavencimento, created_at) DESC
            LIMIT 1
          `,
            )
            .bind(mat, matPadded, matUnpadded)
            .first();
          if (cmaV3) {
            if (!funcionario.cma_data_vencimento && cmaV3.datavencimento)
              funcionario.cma_data_vencimento = cmaV3.datavencimento;
            if (!funcionario.cma_status && cmaV3.status) funcionario.cma_status = cmaV3.status;
          }
        }

        if (!funcionario.aso_data_vencimento) {
          const asoV3 = await db
            .prepare(
              `
            SELECT datavencimento, observacoes
            FROM certificacoesv3
            WHERE funcionariomatricula IN (?, ?, ?) 
              AND UPPER(treinamentocodigo) LIKE '%ASO%'
              AND deleted_at IS NULL
            ORDER BY COALESCE(dataconclusao, datavencimento, created_at) DESC
            LIMIT 1
          `,
            )
            .bind(mat, matPadded, matUnpadded)
            .first();
          if (asoV3 && asoV3.datavencimento) funcionario.aso_data_vencimento = asoV3.datavencimento;
        }

        if (!funcionario.icao_nivel || !funcionario.icao_vencimento) {
          const icaoV3 = await db
            .prepare(
              `
            SELECT datavencimento, observacoes, status
            FROM certificacoesv3
            WHERE funcionariomatricula IN (?, ?, ?) 
              AND UPPER(treinamentocodigo) LIKE '%ICAO%'
              AND deleted_at IS NULL
            ORDER BY COALESCE(dataconclusao, datavencimento, created_at) DESC
            LIMIT 1
          `,
            )
            .bind(mat, matPadded, matUnpadded)
            .first();
          if (icaoV3) {
            if (!funcionario.icao_vencimento && icaoV3.datavencimento)
              funcionario.icao_vencimento = icaoV3.datavencimento;
            if (!funcionario.icao_nivel && icaoV3.observacoes) {
              const m = String(icaoV3.observacoes).match(/N[ií]vel\s*(\d)/i);
              if (m) funcionario.icao_nivel = m[1];
            }
          }
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Fallback certificacoesv3 falhou:', e);
    }

    try {
      const matRaw = String(funcionario.matricula || '').trim();
      if (matRaw) {
        const matPadded = matRaw.padStart(5, '0');
        const matUnpadded = matRaw.replace(/^0+/, '');

        if (!funcionario.cma_data_vencimento) {
          const cmaH = await db
            .prepare(
              `
            SELECT hc.data_vencimento
            FROM historico_certificacoes_v2 hc
            JOIN funcionarios f ON hc.funcionario_id = f.id
            JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
            WHERE f.matricula IN (?, ?, ?) 
              AND UPPER(ct.codigo) LIKE '%CMA%'
              AND hc.deleted_at IS NULL
            ORDER BY COALESCE(hc.data_conclusao, hc.data_vencimento, hc.created_at) DESC
            LIMIT 1
          `,
            )
            .bind(matRaw, matPadded, matUnpadded)
            .first();
          if (cmaH && cmaH.data_vencimento) funcionario.cma_data_vencimento = cmaH.data_vencimento;
        }

        if (!funcionario.aso_data_vencimento) {
          const asoH = await db
            .prepare(
              `
            SELECT hc.data_vencimento
            FROM historico_certificacoes_v2 hc
            JOIN funcionarios f ON hc.funcionario_id = f.id
            JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
            WHERE f.matricula IN (?, ?, ?) 
              AND UPPER(ct.codigo) LIKE '%ASO%'
              AND hc.deleted_at IS NULL
            ORDER BY COALESCE(hc.data_conclusao, hc.data_vencimento, hc.created_at) DESC
            LIMIT 1
          `,
            )
            .bind(matRaw, matPadded, matUnpadded)
            .first();
          if (asoH && asoH.data_vencimento) funcionario.aso_data_vencimento = asoH.data_vencimento;
        }

        if (!funcionario.icao_vencimento || !funcionario.icao_nivel) {
          const icaoH = await db
            .prepare(
              `
            SELECT hc.data_vencimento, hc.observacoes
            FROM historico_certificacoes_v2 hc
            JOIN funcionarios f ON hc.funcionario_id = f.id
            JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
            WHERE f.matricula IN (?, ?, ?) 
              AND UPPER(ct.codigo) LIKE '%ICAO%'
              AND hc.deleted_at IS NULL
            ORDER BY COALESCE(hc.data_conclusao, hc.data_vencimento, hc.created_at) DESC
            LIMIT 1
          `,
            )
            .bind(matRaw, matPadded, matUnpadded)
            .first();
          if (icaoH) {
            if (!funcionario.icao_vencimento && icaoH.data_vencimento)
              funcionario.icao_vencimento = icaoH.data_vencimento;
            if (!funcionario.icao_nivel) {
              const raw = String(icaoH.observacoes || '').trim();
              const m = raw.match(/(\d)/);
              if (m) funcionario.icao_nivel = m[1];
            }
          }
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Fallback historico_certificacoes_v2 falhou:', e);
    }

    const enriched = { ...funcionario } as any;
    enriched.cma_numero = enriched.cma_numero || null;
    enriched.aso_numero = enriched.aso_numero || null;
    enriched.cma_data_vencimento = enriched.cma_data_vencimento || null;
    enriched.aso_data_vencimento = enriched.aso_data_vencimento || null;
    enriched.icao_nivel = enriched.icao_nivel || null;
    enriched.icao_vencimento = enriched.icao_vencimento || null;

    return c.json({
      success: true,
      funcionario: enriched,
      data: enriched,
    });
  } catch (error: any) {
    console.error('[GET /:id] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar funcionário',
      },
      500,
    );
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;

  try {
    const body = await c.req.json();

    const validation = FuncionarioSchema.safeParse(body);
    if (!validation.success) {
      return c.json(
        {
          success: false,
          error: 'Dados inválidos',
          details: validation.error.errors,
        },
        400,
      );
    }

    const data = validation.data;

    const exists = await db
      .prepare('SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL')
      .bind(data.matricula)
      .first();

    if (exists) {
      return c.json(
        {
          success: false,
          error: 'Matrícula já cadastrada',
        },
        409,
      );
    }

    const result = await db
      .prepare(
        `
        INSERT INTO funcionarios (
          matricula, nome, cpf, telefone, email, cargo, funcao, setor, base,
          status, data_admissao, data_nascimento, guerra, contrato,
          codigo_anac, codigo_sispat, codigo_prestserv,
          licenca_aeronautica,
          cma_numero, cma_data_vencimento, cma_status,
          aso_data_vencimento,
          icao_nivel, icao_vencimento, icao_status,
          is_instrutor, is_checador,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `,
      )
      .bind(
        data.matricula,
        data.nome,
        data.cpf || null,
        data.telefone || null,
        data.email || null,
        data.cargo || null,
        data.funcao || null,
        data.setor || null,
        data.base || null,
        data.status,
        data.data_admissao || null,
        data.data_nascimento || null,
        data.guerra || null,
        data.contrato || null,
        data.codigo_anac || null,
        data.codigo_sispat || null,
        data.codigo_prestserv || null,
        data.licenca_aeronautica || null,
        data.aeronave || null,
        data.cma_numero || null,
        data.cma_data_vencimento || null,
        data.cma_status || null,
        data.aso_data_vencimento || null,
        data.icao_nivel || null,
        data.icao_vencimento || null,
        data.icao_status || null,
        data.aeronave || null,
        data.is_instrutor || 0,
        data.is_checador || 0,
      )
      .run();

    const newId = result.meta.last_row_id;

    try {
      await db
        .prepare(
          `
          INSERT INTO auditoriaavancadav2 (acao, detalhes, timestamp)
          VALUES ('FUNCIONARIO_CREATED', ?, datetime('now'))
        `,
        )
        .bind(JSON.stringify({ funcionario_id: newId, data: data }))
        .run();
    } catch (auditError) {
      console.warn('[POST] Auditoria falhou:', auditError);
    }

    invalidateCache('dashboard:', {});
    invalidateCache('funcionarios:', {});

    return c.json(
      {
        success: true,
        id: newId,
        funcionario: { id: newId, ...data },
      },
      201,
    );
  } catch (error: any) {
    console.error('[POST] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao criar funcionário',
        message: error.message,
      },
      500,
    );
  }
});

app.put('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;

  try {
    const oldData = await db
      .prepare(
        `
        SELECT id, matricula, nome, funcao, setor, status,
               is_instrutor, is_checador, email, telefone
        FROM funcionarios
        WHERE id = ? AND deleted_at IS NULL
      `,
      )
      .bind(id)
      .first();

    if (!oldData) {
      return c.json(
        {
          success: false,
          error: 'Funcionário não encontrado',
        },
        404,
      );
    }

    const body = await c.req.json();

    const validation = FuncionarioSchema.partial().safeParse(body);
    if (!validation.success) {
      return c.json(
        {
          success: false,
          error: 'Dados inválidos',
          details: validation.error.errors,
        },
        400,
      );
    }

    const data = validation.data;

    const oldMatriculaNormalizada = oldData.matricula
      ? String(oldData.matricula).padStart(5, '0')
      : '';

    console.log(`[FUNCIONARIOS] PUT /${id} - Dados:`, {
      id_url: id,
      matricula_recebida: data.matricula,
      matricula_antiga: oldData.matricula,
      matricula_antiga_normalizada: oldMatriculaNormalizada,
      vai_validar: data.matricula && data.matricula !== oldMatriculaNormalizada,
    });

    if (data.matricula && data.matricula !== oldMatriculaNormalizada) {
      const exists = await db
        .prepare(
          'SELECT id, nome, matricula FROM funcionarios WHERE matricula = ? AND id != ? AND deleted_at IS NULL',
        )
        .bind(data.matricula, id)
        .first();

      if (exists) {
        return c.json(
          {
            success: false,
            error: `Matrícula ${data.matricula} já cadastrada para ${exists.nome}`,
          },
          409,
        );
      }
    } else {
    }

    const updates: string[] = [];
    const values: any[] = [];

    if (data.matricula !== undefined) {
      updates.push('matricula = ?');
      values.push(data.matricula);
    }
    if (data.nome !== undefined) {
      updates.push('nome = ?');
      values.push(data.nome);
    }
    if (data.cpf !== undefined) {
      updates.push('cpf = ?');
      values.push(data.cpf);
    }
    if (data.telefone !== undefined) {
      updates.push('telefone = ?');
      values.push(data.telefone);
    }
    if (data.email !== undefined) {
      updates.push('email = ?');
      values.push(data.email);
    }
    if (data.cargo !== undefined) {
      updates.push('cargo = ?');
      values.push(data.cargo);
    }
    if (data.funcao !== undefined) {
      updates.push('funcao = ?');
      values.push(data.funcao);
    }
    if (data.setor !== undefined) {
      updates.push('setor = ?');
      values.push(data.setor);
    }
    if (data.base !== undefined) {
      updates.push('base = ?');
      values.push(data.base);
    }
    if (data.status !== undefined) {
      updates.push('status = ?');
      values.push(data.status);
    }
    if (data.data_admissao !== undefined) {
      updates.push('data_admissao = ?');
      values.push(data.data_admissao);
    }
    if (data.data_nascimento !== undefined) {
      updates.push('data_nascimento = ?');
      values.push(data.data_nascimento);
    }
    if (data.guerra !== undefined) {
      updates.push('guerra = ?');
      values.push(data.guerra);
    }
    if (data.contrato !== undefined) {
      updates.push('contrato = ?');
      values.push(data.contrato);
    }
    if (data.codigo_anac !== undefined) {
      updates.push('codigo_anac = ?');
      values.push(data.codigo_anac);
    }
    if (data.codigo_sispat !== undefined) {
      updates.push('codigo_sispat = ?');
      values.push(data.codigo_sispat);
    }
    if (data.codigo_prestserv !== undefined) {
      updates.push('codigo_prestserv = ?');
      values.push(data.codigo_prestserv);
    }
    if (data.licenca_aeronautica !== undefined) {
      updates.push('licenca_aeronautica = ?');
      values.push(data.licenca_aeronautica);
    }
    if (data.aeronave !== undefined) {
      updates.push('aeronave = ?');
      values.push(data.aeronave);
    }
    if (data.cma_numero !== undefined) {
      updates.push('cma_numero = ?');
      values.push(data.cma_numero);
    }
    if (data.cma_data_vencimento !== undefined) {
      updates.push('cma_data_vencimento = ?');
      values.push(data.cma_data_vencimento);
    }
    if (data.cma_status !== undefined) {
      updates.push('cma_status = ?');
      values.push(data.cma_status);
    }
    if (data.aso_data_vencimento !== undefined) {
      updates.push('aso_data_vencimento = ?');
      values.push(data.aso_data_vencimento);
    }
    if (data.icao_nivel !== undefined) {
      updates.push('icao_nivel = ?');
      values.push(data.icao_nivel);
    }
    if (data.icao_vencimento !== undefined) {
      updates.push('icao_vencimento = ?');
      values.push(data.icao_vencimento);
    }
    if (data.icao_status !== undefined) {
      updates.push('icao_status = ?');
      values.push(data.icao_status);
    }
    if (data.aeronave !== undefined) {
      updates.push('aeronave = ?');
      values.push(data.aeronave);
    }
    if (data.is_instrutor !== undefined) {
      updates.push('is_instrutor = ?');
      values.push(data.is_instrutor);
    }
    if (data.is_checador !== undefined) {
      updates.push('is_checador = ?');
      values.push(data.is_checador);
    }

    if (updates.length === 0) {
      return c.json(
        {
          success: false,
          error: 'Nenhum campo para atualizar',
        },
        400,
      );
    }

    updates.push("updated_at = datetime('now')");
    values.push(id);

    await db
      .prepare(`UPDATE funcionarios SET ${updates.join(', ')} WHERE id = ? AND deleted_at IS NULL`)
      .bind(...values)
      .run();

    try {
      const cmaVal = (data as any).cma_data_vencimento;
      if (cmaVal && String(cmaVal).trim() !== '') {
        const lastCma = await db
          .prepare(
            `
          SELECT id, data_vencimento 
          FROM qualificacoes 
          WHERE funcionario_id = ? AND codigo = 'CMA' AND deleted_at IS NULL
          ORDER BY COALESCE(data_conclusao, data_conclusao, id) DESC
          LIMIT 1
        `,
          )
          .bind(id)
          .first();

        const sameDate = lastCma && lastCma.data_vencimento === cmaVal;
        if (!sameDate) {
          await db
            .prepare(
              `
            UPDATE qualificacoes
            SET is_renovada = 1, updated_at = datetime('now')
            WHERE funcionario_id = ? AND codigo = 'CMA' AND deleted_at IS NULL AND is_renovada = 0
          `,
            )
            .bind(id)
            .run();

          await db
            .prepare(
              `
            INSERT INTO qualificacoes (
              funcionario_id, tipo, codigo, nome, descricao,
              data_conclusao, data_conclusao, data_vencimento,
              instituicao, instrutor, checador, carga_horaria,
              numero, nota, resultado, observacoes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `,
            )
            .bind(
              id,
              'EXAME',
              'CMA',
              'Certificado Médico Aeronáutico',
              'Gerado automaticamente a partir da edição do funcionário',
              null,
              null,
              cmaVal,
              null,
              null,
              null,
              null,
              (data as any).cma_numero || null,
              null,
              (data as any).cma_status || null,
              null,
            )
            .run();
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Integração CMA → qualificacoes falhou:', e);
    }

    try {
      const asoVal = (data as any).aso_data_vencimento;
      if (asoVal && String(asoVal).trim() !== '') {
        const lastAso = await db
          .prepare(
            `
          SELECT id, data_vencimento FROM qualificacoes
          WHERE funcionario_id = ? AND codigo = 'ASO' AND deleted_at IS NULL
          ORDER BY COALESCE(data_conclusao, data_conclusao, id) DESC
          LIMIT 1
        `,
          )
          .bind(id)
          .first();
        const sameDate = lastAso && lastAso.data_vencimento === asoVal;
        if (!sameDate) {
          await db
            .prepare(
              `
            UPDATE qualificacoes
            SET is_renovada = 1, updated_at = datetime('now')
            WHERE funcionario_id = ? AND codigo = 'ASO' AND deleted_at IS NULL AND is_renovada = 0
          `,
            )
            .bind(id)
            .run();
          await db
            .prepare(
              `
            INSERT INTO qualificacoes (
              funcionario_id, tipo, codigo, nome, descricao,
              data_conclusao, data_conclusao, data_vencimento,
              instituicao, instrutor, checador, carga_horaria,
              numero, nota, resultado, observacoes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `,
            )
            .bind(
              id,
              'EXAME',
              'ASO',
              'Atestado de Saúde Ocupacional',
              'Gerado automaticamente a partir da edição do funcionário',
              null,
              null,
              asoVal,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
              null,
            )
            .run();
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Integração ASO → qualificacoes falhou:', e);
    }

    try {
      const icaoVal = (data as any).icao_vencimento;
      const icaoNivel = (data as any).icao_nivel;
      if (icaoVal && String(icaoVal).trim() !== '') {
        const lastIcao = await db
          .prepare(
            `
          SELECT id, data_vencimento FROM qualificacoes
          WHERE funcionario_id = ? AND codigo = 'ICAO' AND deleted_at IS NULL
          ORDER BY COALESCE(data_conclusao, data_conclusao, id) DESC
          LIMIT 1
        `,
          )
          .bind(id)
          .first();
        const sameDate = lastIcao && lastIcao.data_vencimento === icaoVal;
        if (!sameDate) {
          await db
            .prepare(
              `
            UPDATE qualificacoes
            SET is_renovada = 1, updated_at = datetime('now')
            WHERE funcionario_id = ? AND codigo = 'ICAO' AND deleted_at IS NULL AND is_renovada = 0
          `,
            )
            .bind(id)
            .run();
          await db
            .prepare(
              `
            INSERT INTO qualificacoes (
              funcionario_id, tipo, codigo, nome, descricao,
              data_conclusao, data_conclusao, data_vencimento,
              instituicao, instrutor, checador, carga_horaria,
              numero, nota, resultado, observacoes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `,
            )
            .bind(
              id,
              'EXAME',
              'ICAO',
              'Proficiência em Inglês (ICAO)',
              'Gerado automaticamente a partir da edição do funcionário',
              null,
              null,
              icaoVal,
              null,
              null,
              null,
              null,
              null,
              icaoNivel ? String(icaoNivel) : null,
              null,
            )
            .run();
        }
      }
    } catch (e) {
      console.warn('[FUNCIONARIOS] Integração ICAO → qualificacoes falhou:', e);
    }

    try {
      await db
        .prepare(
          `
          INSERT INTO auditoriaavancadav2 (acao, detalhes, timestamp)
          VALUES ('FUNCIONARIO_UPDATED', ?, datetime('now'))
        `,
        )
        .bind(JSON.stringify({ funcionario_id: id, before: oldData, after: data }))
        .run();
    } catch (auditError) {
      console.warn('[PUT] Auditoria falhou:', auditError);
    }

    const updated = await db
      .prepare(
        `
        SELECT id, matricula, nome, funcao, setor, status,
               is_instrutor, is_checador, created_at, updated_at
        FROM funcionarios
        WHERE id = ?
      `,
      )
      .bind(id)
      .first();

    invalidateCache('dashboard:', {});
    invalidateCache('funcionarios:', {});

    return c.json({
      success: true,
      funcionario: updated,
    });
  } catch (error: any) {
    console.error('[PUT] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao atualizar funcionário',
        message: error.message,
      },
      500,
    );
  }
});

app.post('/batch', async (c) => {
  try {
    const funcionarios = await c.req.json();

    if (!Array.isArray(funcionarios)) {
      return c.json({ success: false, error: 'Payload deve ser um array' }, 400);
    }

    if (funcionarios.length === 0) {
      return c.json({ success: false, error: 'Array vazio' }, 400);
    }

    if (funcionarios.length > 100) {
      return c.json({ success: false, error: 'Máximo 100 registros por batch' }, 400);
    }

    const db = c.env.DB;
    const ids: number[] = [];
    const erros: any[] = [];

    for (let i = 0; i < funcionarios.length; i++) {
      const func = funcionarios[i];

      try {
        const validated = FuncionarioSchema.parse(func);

        const result = await db
          .prepare(
            `
          INSERT INTO funcionarios (
            nome, matricula, cpf, email, telefone, 
            cargo, funcao, setor, base, status,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        `,
          )
          .bind(
            validated.nome,
            validated.matricula,
            validated.cpf || null,
            validated.email || null,
            validated.telefone || null,
            validated.cargo || null,
            validated.funcao || null,
            validated.setor || null,
            validated.base || null,
            validated.status || 'ATIVO',
          )
          .run();

        ids.push(result.meta.last_row_id as number);

        try {
          await db
            .prepare(
              `
            INSERT INTO auditoriaavancadav2 (acao, detalhes, timestamp)
            VALUES ('FUNCIONARIO_CREATED_BATCH', ?, datetime('now'))
          `,
            )
            .bind(JSON.stringify({ funcionario_id: result.meta.last_row_id, data: validated }))
            .run();
        } catch (auditError) {
          console.warn('[BATCH] Auditoria falhou:', auditError);
        }
      } catch (error: any) {
        erros.push({
          index: i,
          funcionario: func,
          erro: error.message || 'Erro desconhecido',
        });
      }
    }

    invalidateCache('dashboard:', {});
    invalidateCache('funcionarios:', {});

    return c.json(
      {
        success: true,
        criados: ids.length,
        ids,
        erros: erros.length > 0 ? erros : undefined,
      },
      201,
    );
  } catch (error: any) {
    console.error('[BATCH] Erro:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao processar batch',
        message: error.message,
      },
      500,
    );
  }
});

app.delete('/:id', async (c) => {
  const id = c.req.param('id');
  const db = c.env.DB;

  try {
    const funcionario = await db
      .prepare(
        `
      SELECT id, nome, matricula FROM funcionarios 
      WHERE id = ? AND deleted_at IS NULL
    `,
      )
      .bind(id)
      .first();

    if (!funcionario) {
      return c.json(
        {
          success: false,
          error: 'Funcionário não encontrado',
        },
        404,
      );
    }

    await db
      .prepare(
        `
      UPDATE funcionarios
      SET deleted_at = datetime('now'),
          updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `,
      )
      .bind(id)
      .run();

    try {
      await db
        .prepare(
          `
        INSERT INTO auditoriaavancadav2 (acao, detalhes, timestamp)
        VALUES ('FUNCIONARIO_DELETED', ?, datetime('now'))
      `,
        )
        .bind(
          JSON.stringify({
            funcionario_id: id,
            nome: funcionario.nome,
            matricula: funcionario.matricula,
          }),
        )
        .run();
    } catch (auditError) {
      console.warn('Auditoria falhou:', auditError);
    }

    invalidateCache('dashboard:', {});
    invalidateCache('funcionarios:', {});

    return c.json({
      success: true,
      message: 'Funcionário excluído com sucesso',
    });
  } catch (error: any) {
    console.error('❌ Erro ao excluir funcionário:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao excluir funcionário',
        message: error.message,
      },
      500,
    );
  }
});

export default app;
