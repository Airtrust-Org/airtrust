import { Hono } from 'hono';
import type { Env } from '../../types';
import { Logger } from '../../utils/logger';

declare module 'hono' {
  interface ContextVariableMap {
    user_id?: string;
    user_name?: string;
  }
}

const app = new Hono<{ Bindings: Env }>();

app.get('/me', async (c) => {
  try {
    const userId = c.get('user_id');
    const userName = c.get('user_name');

    if (!userId) {
      return c.json({ success: false, error: 'Usuário não autenticado' }, 401);
    }

    const userProfile = await c.env.DB.prepare(
      `
      SELECT 
        user_id,
        funcionario_id,
        user_name,
        perfil,
        equipe,
        ativo,
        created_at,
        updated_at
      FROM user_profiles_v2 
      WHERE user_id = ? AND ativo = 1
      LIMIT 1
    `,
    )
      .bind(userId)
      .first();

    if (!userProfile) {
      const now = new Date().toISOString();

      await c.env.DB.prepare(
        `
        INSERT INTO user_profiles_v2 
        (user_id, user_name, perfil, ativo, created_at, updated_at)
        VALUES (?, ?, 'FUNCIONARIO', 1, ?, ?)
      `,
      )
        .bind(userId, userName || 'Usuário', now, now)
        .run();

      return c.json({
        success: true,
        user_id: userId,
        user_name: userName || 'Usuário',
        perfil: 'FUNCIONARIO',
        equipe: null,
        funcionario_id: null,
        ativo: true,
        created_at: now,
        permissions: {
          pasta_virtual: false,
          admin: false,
          compliance: false,
        },
      });
    }

    const permissions = {
      pasta_virtual: ['ADMIN', 'GESTOR', 'COMPLIANCE'].includes(userProfile.perfil),
      admin: userProfile.perfil === 'ADMIN',
      compliance: ['ADMIN', 'COMPLIANCE'].includes(userProfile.perfil),
      gestao: ['ADMIN', 'GESTOR'].includes(userProfile.perfil),
    };

    return c.json({
      success: true,
      user_id: userProfile.user_id,
      user_name: userProfile.user_name,
      perfil: userProfile.perfil,
      equipe: userProfile.equipe,
      funcionario_id: userProfile.funcionario_id,
      ativo: userProfile.ativo,
      created_at: userProfile.created_at,
      updated_at: userProfile.updated_at,
      permissions: permissions,
    });
  } catch (error) {
    Logger.error('💥 [AUTH] Erro ao buscar perfil do usuário:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro interno',
      },
      500,
    );
  }
});

export default app;
