import { Hono } from 'hono';
import type { Env } from '../../types';
import { Logger } from '../../utils/logger';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  try {
    const result = await c.env.DB.prepare(
      `
      SELECT 
        e.id,
        e.funcionario_id,
        f.nome as funcionario_nome,
        f.matricula,
        e.tipo,
        e.codigo,
        e.descricao,
        e.data_conclusao,
        e.data_vencimento,
        e.resultado,
        e.observacoes,
        e.arquivo_url,
        e.created_at
      FROM exames e
      INNER JOIN funcionarios f ON f.id = e.funcionario_id
      WHERE e.deleted_at IS NULL
        AND f.deleted_at IS NULL
      ORDER BY e.data_conclusao DESC
      LIMIT 100
    `,
    ).all();

    return c.json({
      success: true,
      data: result.results || [],
      total: result.results?.length || 0,
    });
  } catch (error) {
    Logger.error('❌ Erro ao buscar exames:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar exames',
        message: error instanceof Error ? error.message : 'Erro desconhecido',
      },
      500,
    );
  }
});

// DELETE /:id - Excluir exame (soft delete)
app.delete('/:id', async (c) => {
  try {
    const id = parseInt(c.req.param('id'));

    await c.env.DB.prepare(
      `
      UPDATE exames 
      SET deleted_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `,
    )
      .bind(id)
      .run();

    return c.json({
      success: true,
      message: 'Exame excluído com sucesso',
    });
  } catch (error) {
    Logger.error('❌ Erro ao excluir exame:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao excluir exame',
        message: error instanceof Error ? error.message : 'Erro desconhecido',
      },
      500,
    );
  }
});

export default app;
