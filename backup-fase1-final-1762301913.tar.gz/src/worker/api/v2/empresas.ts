import { Hono } from 'hono';
import type { Env } from '../../types/env';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db
      .prepare(`
        SELECT 
          id,
          nome,
          cnpj,
          logo_url,
          created_at,
          updated_at
        FROM empresas
        WHERE deleted_at IS NULL
        ORDER BY nome ASC
      `)
      .all();

    return c.json({
      success: true,
      data: result.results || []
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao listar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao listar empresas' 
    }, 500);
  }
});

app.get('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    const result = await db
      .prepare(`
        SELECT 
          id,
          nome,
          cnpj,
          logo_url,
          created_at,
          updated_at
        FROM empresas
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(id)
      .first();

    if (!result) {
      return c.json({ 
        success: false, 
        error: 'Empresa não encontrada' 
      }, 404);
    }

    return c.json({
      success: true,
      data: result
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao buscar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao buscar empresa' 
    }, 500);
  }
});

app.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();
    
    const { nome, cnpj, logo_url } = body;
    
    if (!nome) {
      return c.json({ 
        success: false, 
        error: 'Nome é obrigatório' 
      }, 400);
    }
    
    const result = await db
      .prepare(`
        INSERT INTO empresas (nome, cnpj, logo_url, created_at, updated_at)
        VALUES (?, ?, ?, datetime('now'), datetime('now'))
      `)
      .bind(nome, cnpj || null, logo_url || null)
      .run();

    return c.json({
      success: true,
      data: { id: result.meta.last_row_id }
    }, 201);
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao criar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao criar empresa' 
    }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const { nome, cnpj, logo_url } = body;
    
    const result = await db
      .prepare(`
        UPDATE empresas 
        SET nome = COALESCE(?, nome),
            cnpj = COALESCE(?, cnpj),
            logo_url = COALESCE(?, logo_url),
            updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(nome, cnpj, logo_url, id)
      .run();

    if (result.meta.changes === 0) {
      return c.json({ 
        success: false, 
        error: 'Empresa não encontrada' 
      }, 404);
    }

    return c.json({
      success: true,
      message: 'Empresa atualizada com sucesso'
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao atualizar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao atualizar empresa' 
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    
    const result = await db
      .prepare(`
        UPDATE empresas 
        SET deleted_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(id)
      .run();

    if (result.meta.changes === 0) {
      return c.json({ 
        success: false, 
        error: 'Empresa não encontrada' 
      }, 404);
    }

    return c.json({
      success: true,
      message: 'Empresa deletada com sucesso'
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao deletar:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao deletar empresa' 
    }, 500);
  }
});

// Upload de logo
app.post('/:id/logo', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const { base64, contentType } = body;
    
    if (!base64) {
      return c.json({ 
        success: false, 
        error: 'Base64 é obrigatório' 
      }, 400);
    }
    
    // Converter base64 para data URL
    const dataUrl = `data:${contentType || 'image/png'};base64,${base64}`;
    
    const result = await db
      .prepare(`
        UPDATE empresas 
        SET logo_url = ?,
            updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(dataUrl, id)
      .run();

    if (result.meta.changes === 0) {
      return c.json({ 
        success: false, 
        error: 'Empresa não encontrada' 
      }, 404);
    }

    return c.json({
      success: true,
      data: { logo_url: dataUrl }
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao fazer upload de logo:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao fazer upload de logo' 
    }, 500);
  }
});

// Salvar configuração de certificados
app.put('/:id/config', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();
    
    const { template_html, cor_primaria, cor_secundaria } = body;
    
    const result = await db
      .prepare(`
        UPDATE empresas 
        SET template_html = COALESCE(?, template_html),
            cor_primaria = COALESCE(?, cor_primaria),
            cor_secundaria = COALESCE(?, cor_secundaria),
            updated_at = datetime('now')
        WHERE id = ? AND deleted_at IS NULL
      `)
      .bind(template_html, cor_primaria, cor_secundaria, id)
      .run();

    if (result.meta.changes === 0) {
      return c.json({ 
        success: false, 
        error: 'Empresa não encontrada' 
      }, 404);
    }

    return c.json({
      success: true,
      message: 'Configuração salva com sucesso'
    });
  } catch (error: any) {
    Logger.error('[EMPRESAS] Erro ao salvar configuração:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao salvar configuração' 
    }, 500);
  }
});

export default app;
