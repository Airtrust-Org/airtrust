/**
 * API CORRIGIDA: Agendamento de Simulador - AirTrust Schema Real
 *
 * Tabelas corretas:
 * - catalogo_treinamentos_v2 (não treinamentos_catalogo)
 * - historico_certificacoes_v2 (não funcionario_qualificacoes)
 * - simulador_agendamentos (nova)
 * - treinamento_sessoes (nova)
 */

import { Hono } from 'hono';
import type { Env } from '../../types/index';
import { AgendamentoCreateSchema, AgendamentoUpdateSchema, validateSchema } from '../../schemas';
import {
  parsePaginationParams,
  buildPaginatedResponse,
  calculateOffset,
} from '../../utils/pagination';

const app = new Hono<{ Bindings: Env }>();

app.get('/slots', async (c) => {
  try {
    const db = c.env.DB;
    const { results } = await db
      .prepare(
        `
      SELECT 
        id,
        simulador_id,
        data,
        hora_inicio,
        hora_fim,
        disponivel,
        reservado_por
      FROM simulador_slots
      WHERE deleted_at IS NULL
        AND data >= date('now')
      ORDER BY data ASC, hora_inicio ASC
    `,
      )
      .all();
    return c.json({ success: true, data: results || [] });
  } catch (error: any) {
    return c.json({ success: false, error: error.message || 'Erro ao carregar slots' }, 500);
  }
});

/**
 * GET /agendamentos
 * Listar todos os agendamentos
 */
app.get('/agendamentos', async (c) => {
  try {
    const db = c.env.DB;

    const url = new URL(c.req.url);
    const params = parsePaginationParams(url);
    const search = url.searchParams.get('search') || '';

    let whereClause = 'WHERE a.deleted_at IS NULL';
    const bindings: any[] = [];

    if (search) {
      whereClause += ` AND (
        s.nome LIKE ? OR 
        i.nome LIKE ? OR 
        a.observacoes LIKE ?
      )`;
      const searchTerm = `%${search}%`;
      bindings.push(searchTerm, searchTerm, searchTerm);
    }

    const countResult = await db
      .prepare(
        `
      SELECT COUNT(*) as total 
      FROM simulador_agendamentos a
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios i ON a.instrutor_id = i.id
      ${whereClause}
    `,
      )
      .bind(...bindings)
      .first();

    const total = (countResult?.total as number) || 0;

    const offset = calculateOffset(params.page, params.limit);

    const agendamentos = await db
      .prepare(
        `
      SELECT 
        a.id,
        a.uuid,
        a.data,
        a.hora_inicio,
        a.hora_fim,
        a.tipo_sessao,
        a.status,
        a.observacoes,
        a.template_id,
        s.nome as simulador_nome,
        s.modelo as simulador_modelo,
        i.nome as instrutor_nome,
        t.nome as template_nome
      FROM simulador_agendamentos a
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios i ON a.instrutor_id = i.id
      LEFT JOIN sessoes_template t ON a.template_id = t.id
      ${whereClause}
      ORDER BY a.data DESC, a.hora_inicio DESC
      LIMIT ? OFFSET ?
    `,
      )
      .bind(...bindings, params.limit, offset)
      .all();

    return c.json(buildPaginatedResponse(agendamentos.results || [], total, params));
  } catch (error: any) {
    Logger.error('[AGENDAMENTO] Erro ao listar:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar agendamentos',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * POST /agendamentos
 * Criar novo agendamento
 */
app.post('/agendamentos', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const validation = validateSchema(AgendamentoCreateSchema, body);

    if (!validation.success) {
      Logger.error('[AGENDAMENTO] Validação falhou:', validation.errors);
      return c.json(
        {
          success: false,
          error: 'Dados inválidos',
          errors: validation.errors,
        },
        400,
      );
    }

    const data = validation.data;

    const uuid = crypto.randomUUID();

    const result = await db
      .prepare(
        `
      INSERT INTO simulador_agendamentos (
        uuid, simulador_id, instrutor_id, template_id,
        data, hora_inicio, hora_fim, tipo_sessao,
        status, observacoes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'AGENDADO', ?, datetime('now'), datetime('now'))
    `,
      )
      .bind(
        uuid,
        data.simulador_id,
        data.instrutor_id,
        data.template_id,
        data.data,
        data.hora_inicio,
        data.hora_fim || null,
        data.tipo_sessao || 'PC',
        data.observacoes || null,
      )
      .run();

    const agendamentoId = result.meta.last_row_id;

    if (data.participantes && Array.isArray(data.participantes)) {
      for (const participante of data.participantes) {
        await db
          .prepare(
            `
          INSERT INTO simulador_agendamento_participantes (
            agendamento_id, funcionario_id, funcao_na_sessao, created_at
          ) VALUES (?, ?, ?, datetime('now'))
        `,
          )
          .bind(
            agendamentoId,
            participante.colaborador_id || participante.funcionario_id,
            participante.funcao,
          )
          .run();
      }
    }

    return c.json(
      {
        success: true,
        message: 'Agendamento criado com sucesso',
        data: {
          id: agendamentoId,
          uuid,
        },
      },
      201,
    );
  } catch (error: any) {
    Logger.error('[AGENDAMENTO] Erro ao criar:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao criar agendamento',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * PUT /agendamentos/:id
 * Atualizar agendamento
 */
app.put('/agendamentos/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');
    const body = await c.req.json();

    const validation = validateSchema(AgendamentoUpdateSchema, body);

    if (!validation.success) {
      Logger.error('[AGENDAMENTO] Validação falhou:', validation.errors);
      return c.json(
        {
          success: false,
          error: 'Dados inválidos',
          errors: validation.errors,
        },
        400,
      );
    }

    const data = validation.data;

    const existe = await db
      .prepare('SELECT id FROM simulador_agendamentos WHERE id = ? AND deleted_at IS NULL')
      .bind(id)
      .first();

    if (!existe) {
      return c.json(
        {
          success: false,
          error: 'Agendamento não encontrado',
        },
        404,
      );
    }

    await db
      .prepare(
        `
      UPDATE simulador_agendamentos
      SET 
        simulador_id = COALESCE(?, simulador_id),
        instrutor_id = COALESCE(?, instrutor_id),
        template_id = COALESCE(?, template_id),
        data = COALESCE(?, data),
        hora_inicio = COALESCE(?, hora_inicio),
        hora_fim = COALESCE(?, hora_fim),
        tipo_sessao = COALESCE(?, tipo_sessao),
        status = COALESCE(?, status),
        observacoes = COALESCE(?, observacoes),
        updated_at = datetime('now')
      WHERE id = ?
    `,
      )
      .bind(
        data.simulador_id || null,
        data.instrutor_id || null,
        data.template_id || null,
        data.data || null,
        data.hora_inicio || null,
        data.hora_fim || null,
        data.tipo_sessao || null,
        data.status || null,
        data.observacoes || null,
        id,
      )
      .run();

    return c.json({
      success: true,
      message: 'Agendamento atualizado com sucesso',
    });
  } catch (error: any) {
    Logger.error('[AGENDAMENTO] Erro ao atualizar:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao atualizar agendamento',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * DELETE /agendamentos/:id
 * Excluir agendamento (soft delete)
 */
app.delete('/agendamentos/:id', async (c) => {
  try {
    const db = c.env.DB;
    const id = c.req.param('id');

    const existe = await db
      .prepare('SELECT id FROM simulador_agendamentos WHERE id = ? AND deleted_at IS NULL')
      .bind(id)
      .first();

    if (!existe) {
      return c.json(
        {
          success: false,
          error: 'Agendamento não encontrado',
        },
        404,
      );
    }

    await db
      .prepare(
        `
      UPDATE simulador_agendamentos
      SET deleted_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `,
      )
      .bind(id)
      .run();

    return c.json({
      success: true,
      message: 'Agendamento excluído com sucesso',
    });
  } catch (error: any) {
    Logger.error('[AGENDAMENTO] Erro ao excluir:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao excluir agendamento',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * GET /ficha/:codigo
 * Buscar sessão de simulador por código
 */
app.get('/ficha/:codigo', async (c) => {
  const db = c.env.DB;
  const codigo = c.req.param('codigo');

  try {
    const sessao = await db
      .prepare(
        `
      SELECT 
        s.*,
        sim.nome as simulador_nome,
        sim.modelo as simulador_modelo,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula,
        checador.nome as checador_nome
      FROM sessoes_simulador s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios aluno ON s.aluno_id = aluno.id
      LEFT JOIN funcionarios inst ON s.instrutor_id = inst.id
      LEFT JOIN funcionarios checador ON s.checador_id = checador.id
      WHERE s.codigo = ?
    `,
      )
      .bind(codigo)
      .first();

    if (!sessao) {
      return c.json(
        {
          success: false,
          error: 'Sessão não encontrada',
        },
        404,
      );
    }

    const { results: manobras } = await db
      .prepare(
        `
      SELECT 
        m.*
      FROM manobras m
      ORDER BY m.codigo
      LIMIT 10
    `,
      )
      .bind()
      .all();

    return c.json({
      success: true,
      ficha: {
        ...sessao,
        manobras: manobras || [],
      },
    });
  } catch (error: any) {
    Logger.error('❌ Erro ao buscar sessão:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar sessão',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * GET /ficha/:codigo/visualizar
 * Buscar sessão de simulador para visualização (mesmo que /ficha/:codigo)
 */
app.get('/ficha/:codigo/visualizar', async (c) => {
  const db = c.env.DB;
  const codigo = c.req.param('codigo');

  try {
    const sessao = await db
      .prepare(
        `
      SELECT 
        s.*,
        sim.nome as simulador_nome,
        sim.modelo as simulador_modelo,
        aluno.nome as aluno_nome,
        aluno.matricula as aluno_matricula,
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula,
        checador.nome as checador_nome
      FROM sessoes_simulador s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios aluno ON s.aluno_id = aluno.id
      LEFT JOIN funcionarios inst ON s.instrutor_id = inst.id
      LEFT JOIN funcionarios checador ON s.checador_id = checador.id
      WHERE s.codigo = ?
    `,
      )
      .bind(codigo)
      .first();

    if (!sessao) {
      return c.json(
        {
          success: false,
          error: 'Sessão não encontrada',
        },
        404,
      );
    }

    const { results: manobras } = await db
      .prepare(
        `
      SELECT 
        m.*
      FROM manobras m
      ORDER BY m.codigo
      LIMIT 10
    `,
      )
      .bind()
      .all();

    return c.json({
      success: true,
      ficha: {
        ...sessao,
        manobras: manobras || [],
      },
    });
  } catch (error: any) {
    Logger.error('❌ Erro ao buscar sessão para visualização:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar sessão',
        details: error.message,
      },
      500,
    );
  }
});

/**
 * Função auxiliar: Criar fichas automaticamente para cada participante
 * Usa transações para garantir consistência dos dados
 */
async function criarFichasAutomaticamente(
  db: any,
  agendamentoId: number,
  participantes: any[],
  instrutorId: number | null,
) {
  const fichasCriadas = [];

  if (!participantes || participantes.length === 0) {
    Logger.warn('[FICHAS] Nenhum participante fornecido');
    return fichasCriadas;
  }

  for (const participante of participantes) {
    try {
      if (!participante.colaborador_id) {
        Logger.warn('[FICHAS] Participante sem colaborador_id, pulando');
        continue;
      }

      if (!participante.template_id) {
        Logger.warn(
          `[FICHAS] Participante ${participante.colaborador_id} sem template_id, pulando`,
        );
        continue;
      }

      const fichaUuid = crypto.randomUUID();

      const aluno = await db
        .prepare(
          `
        SELECT nome, matricula FROM funcionarios WHERE id = ?
      `,
        )
        .bind(participante.colaborador_id)
        .first();

      if (!aluno) {
        Logger.warn(`[FICHAS] Aluno ${participante.colaborador_id} não encontrado`);
        continue;
      }

      let codigoAnac = null;
      if (instrutorId) {
        const instrutor = await db
          .prepare(
            `
          SELECT codigo_anac FROM funcionarios WHERE id = ?
        `,
          )
          .bind(instrutorId)
          .first();
        codigoAnac = instrutor?.codigo_anac || null;
      }

      await db
        .prepare(
          `
        INSERT INTO simulador_fichas (
          uuid, agendamento_slot_id, colaborador_id_aluno, funcao_na_sessao,
          template_id, instrutor_id, instrutor_codigo_anac,
          carga_horaria_total, carga_horaria_pf, carga_horaria_pm,
          tempo_acumulado, aluno_nome_validado, aluno_matricula_validado,
          status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 2.0, 1.0, 1.0, 0, ?, ?, 'PENDENTE', datetime('now'), datetime('now'))
      `,
        )
        .bind(
          fichaUuid,
          agendamentoId,
          participante.colaborador_id,
          participante.funcao_na_sessao || 'PIC',
          participante.template_id || null,
          instrutorId,
          codigoAnac,
          aluno.nome,
          aluno.matricula,
        )
        .run();

      if (participante.template_id) {
        const fichaId = await db
          .prepare(
            `
          SELECT id FROM simulador_fichas WHERE uuid = ?
        `,
          )
          .bind(fichaUuid)
          .first();

        if (fichaId) {
          const { results: manobras } = await db
            .prepare(
              `
            SELECT manobra_id FROM template_manobras WHERE template_id = ? ORDER BY ordem
          `,
            )
            .bind(participante.template_id)
            .all();

          for (const manobra of manobras || []) {
            await db
              .prepare(
                `
              INSERT INTO ficha_manobras_avaliacao (
                ficha_id, manobra_id, nota, executada, created_at, updated_at
              ) VALUES (?, ?, 0, 0, datetime('now'), datetime('now'))
            `,
              )
              .bind(fichaId.id, manobra.manobra_id)
              .run();
          }
        }
      }

      fichasCriadas.push({
        uuid: fichaUuid,
        aluno: aluno.nome,
        funcao: participante.funcao_na_sessao,
      });
    } catch (error: any) {
      Logger.error(
        `❌ Erro ao criar ficha para participante ${participante.colaborador_id}:`,
        error,
      );
    }
  }

  return fichasCriadas;
}

/**
 * POST /agendamento-ultra-robusto-corrigido
 * Criar agendamento com schema correto do AirTrust
 */
app.post('/agendamento-ultra-robusto-corrigido', async (c) => {
  const db = c.env.DB;

  try {
    const payload = await c.req.json();

    const { dados_gerais, participantes } = payload;

    if (!dados_gerais?.simulador_id || !dados_gerais?.data_inicio || !dados_gerais?.hora_inicio) {
      return c.json(
        {
          success: false,
          error: 'Campos obrigatórios faltando: simulador_id, data_inicio, hora_inicio',
        },
        400,
      );
    }

    if (!participantes || participantes.length === 0) {
      return c.json(
        {
          success: false,
          error: 'Pelo menos um participante é obrigatório',
        },
        400,
      );
    }

    if (dados_gerais.treinamento_sessao_id) {
      const sessao = await db
        .prepare(
          `
        SELECT ts.*, t.codigo, t.nome 
        FROM treinamento_sessoes ts
        JOIN catalogo_treinamentos_v2 t ON t.id = ts.treinamento_id
        WHERE ts.id = ? AND ts.deleted_at IS NULL
      `,
        )
        .bind(dados_gerais.treinamento_sessao_id)
        .first();

      if (!sessao) {
        return c.json(
          {
            success: false,
            error: 'Sessão de treinamento não encontrada',
          },
          404,
        );
      }
    }

    const uuid = crypto.randomUUID();

    const resultAgendamento = await db
      .prepare(
        `
      INSERT INTO simulador_agendamentos (
        uuid,
        simulador_id,
        treinamento_sessao_id,
        data,
        hora_inicio,
        hora_fim,
        tipo_sessao,
        instrutor_id,
        template_id,
        status,
        observacoes,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'AGENDADO', ?, datetime('now'), datetime('now'))
    `,
      )
      .bind(
        uuid,
        dados_gerais.simulador_id,
        dados_gerais.treinamento_sessao_id || null,
        dados_gerais.data_inicio,
        dados_gerais.hora_inicio,
        dados_gerais.hora_fim || dados_gerais.data_fim,
        dados_gerais.tipo_sessao || 'PC',
        dados_gerais.instrutor_id || null,
        dados_gerais.template_id || null,
        dados_gerais.observacoes || null,
      )
      .run();

    const agendamentoId = resultAgendamento.meta.last_row_id;

    let participantesProcessados = 0;

    for (const participante of participantes) {
      try {
        await db
          .prepare(
            `
          INSERT INTO simulador_agendamento_participantes (
            agendamento_id,
            funcionario_id,
            funcao_na_sessao,
            created_at
          ) VALUES (?, ?, ?, datetime('now'))
        `,
          )
          .bind(agendamentoId, participante.colaborador_id, participante.funcao_na_sessao || 'PIC')
          .run();

        participantesProcessados++;
      } catch (error: any) {
        Logger.error(`❌ Erro ao processar participante ${participante.colaborador_id}:`, error);
      }
    }

    const fichasCriadas = await criarFichasAutomaticamente(
      db,
      agendamentoId,
      participantes,
      dados_gerais.instrutor_id || null,
    );

    const sessaoUuid = crypto.randomUUID();
    await db
      .prepare(
        `
      INSERT INTO simulador_sessoes (uuid, agendamento_id, status, created_at)
      VALUES (?, ?, 'PENDENTE', datetime('now'))
    `,
      )
      .bind(sessaoUuid, agendamentoId)
      .run();

    return c.json(
      {
        success: true,
        agendamento_id: agendamentoId,
        uuid: uuid,
        sessao_uuid: sessaoUuid,
        participantes_processados: participantesProcessados,
        fichas_criadas: fichasCriadas.length,
        fichas: fichasCriadas,
        message: `Sessão agendada com sucesso! ${fichasCriadas.length} fichas criadas.`,
      },
      201,
    );
  } catch (error: any) {
    Logger.error('❌ ERRO ao criar agendamento:', error);
    return c.json(
      {
        success: false,
        error: error.message || 'Erro ao criar agendamento',
      },
      500,
    );
  }
});

/**
 * GET /agendamentos
 * Listar agendamentos com informações de treinamento
 */
app.get('/agendamentos', async (c) => {
  const db = c.env.DB;

  try {
    const { results: agendamentos } = (await db
      .prepare(
        `
      SELECT 
        a.id,
        a.uuid,
        a.simulador_id,
        a.treinamento_sessao_id,
        a.data,
        a.hora_inicio,
        a.hora_fim,
        a.tipo_sessao,
        a.status,
        a.observacoes,
        s.nome as simulador_nome,
        s.codigo as simulador_codigo,
        i.nome as instrutor_nome,
        ts.nome_sessao,
        ts.sessao_numero,
        t.codigo as treinamento_codigo,
        t.nome as treinamento_nome
      FROM simulador_agendamentos a
      LEFT JOIN simuladores s ON s.id = a.simulador_id
      LEFT JOIN funcionarios i ON i.id = a.instrutor_id
      LEFT JOIN treinamento_sessoes ts ON ts.id = a.treinamento_sessao_id
      LEFT JOIN catalogo_treinamentos_v2 t ON t.id = ts.treinamento_id
      WHERE a.deleted_at IS NULL
      ORDER BY a.data DESC, a.hora_inicio DESC
      LIMIT 100
    `,
      )
      .all()) as { results: any[] };

    for (const ag of agendamentos || []) {
      const { results: participantes } = (await db
        .prepare(
          `
        SELECT p.funcionario_id, f.nome, f.matricula, p.funcao_na_sessao
        FROM simulador_agendamento_participantes p
        JOIN funcionarios f ON f.id = p.funcionario_id
        WHERE p.agendamento_id = ?
      `,
        )
        .bind(ag.id)
        .all()) as { results: any[] };

      for (const part of participantes || []) {
        const ficha = await db
          .prepare(
            `
          SELECT uuid, status
          FROM simulador_fichas
          WHERE agendamento_slot_id = ?
            AND colaborador_id_aluno = ?
            AND deleted_at IS NULL
          LIMIT 1
        `,
          )
          .bind(ag.id, part.funcionario_id)
          .first();

        part.ficha_uuid = ficha?.uuid || null;
        part.ficha_status = ficha?.status || null;
      }

      ag.participantes = participantes || [];
      ag.participantes_nomes = (participantes || []).map((p: any) => p.nome);
      ag.participantes_fichas = (participantes || []).map((p: any) => p.ficha_uuid);
    }

    return c.json({
      success: true,
      agendamentos: agendamentos || [],
      total: (agendamentos || []).length,
    });
  } catch (error: any) {
    Logger.error('❌ Erro ao buscar agendamentos:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao buscar agendamentos',
      },
      500,
    );
  }
});

/**
 * PUT /agendamento/:id/finalizar
 * Finalizar sessão e registrar no histórico de certificações
 */
app.put('/agendamento/:id/finalizar', async (c) => {
  const db = c.env.DB;
  const agendamentoId = c.req.param('id');

  try {
    const { aprovado, nota, observacoes } = await c.req.json();

    await db
      .prepare(
        `
      UPDATE simulador_agendamentos
      SET status = 'CONCLUIDO',
          updated_at = datetime('now')
      WHERE id = ?
    `,
      )
      .bind(agendamentoId)
      .run();

    const agendamento = await db
      .prepare(
        `
      SELECT 
        a.*,
        ts.treinamento_id,
        ts.sessao_numero,
        t.codigo as treinamento_codigo,
        t.periodicidade_meses
      FROM simulador_agendamentos a
      LEFT JOIN treinamento_sessoes ts ON ts.id = a.treinamento_sessao_id
      LEFT JOIN catalogo_treinamentos_v2 t ON t.id = ts.treinamento_id
      WHERE a.id = ?
    `,
      )
      .bind(agendamentoId)
      .first();

    if (!agendamento) {
      return c.json(
        {
          success: false,
          error: 'Agendamento não encontrado',
        },
        404,
      );
    }

    const { results: participantes } = (await db
      .prepare(
        `
      SELECT funcionario_id
      FROM simulador_agendamento_participantes
      WHERE agendamento_id = ?
    `,
      )
      .bind(agendamentoId)
      .all()) as { results: any[] };

    if (agendamento.treinamento_id && aprovado) {
      for (const participante of participantes || []) {
        await registrarCertificacao(
          db,
          Number(participante.funcionario_id),
          Number(agendamento.treinamento_id),
          String(agendamento.data),
          Number(agendamento.periodicidade_meses) || 12,
          agendamento.instrutor_id,
          nota,
          observacoes,
        );
      }
    }

    await db
      .prepare(
        `
      UPDATE simulador_sessoes
      SET status = 'CONCLUIDA',
          data_fim = datetime('now'),
          updated_at = datetime('now')
      WHERE agendamento_id = ?
    `,
      )
      .bind(agendamentoId)
      .run();

    return c.json({
      success: true,
      message: 'Sessão finalizada com sucesso',
    });
  } catch (error: any) {
    Logger.error('❌ Erro ao finalizar agendamento:', error);
    return c.json(
      {
        success: false,
        error: error.message,
      },
      500,
    );
  }
});

/**
 * Registrar certificação no histórico (schema correto do AirTrust)
 */
async function registrarCertificacao(
  db: any,
  funcionarioId: number,
  treinamentoId: number,
  dataConclusao: string,
  validadeMeses: number,
  instrutorId: number | null,
  notaFinal: number | null,
  observacoes: string | null,
) {
  try {
    let instrutorNome = null;
    if (instrutorId) {
      const instrutor = await db
        .prepare(
          `
        SELECT nome FROM funcionarios WHERE id = ?
      `,
        )
        .bind(instrutorId)
        .first();
      instrutorNome = instrutor?.nome;
    }

    const dataVencimento = new Date(dataConclusao);
    dataVencimento.setMonth(dataVencimento.getMonth() + validadeMeses);
    const dataVencimentoStr = dataVencimento.toISOString().split('T')[0];

    await db
      .prepare(
        `
      INSERT INTO historico_certificacoes_v2 (
        funcionario_id,
        treinamento_id,
        data_conclusao,
        data_vencimento,
        instrutor,
        nota,
        observacoes,
        status,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'ATIVO', datetime('now'), datetime('now'))
    `,
      )
      .bind(
        funcionarioId,
        treinamentoId,
        dataConclusao,
        dataVencimentoStr,
        instrutorNome,
        notaFinal,
        observacoes,
      )
      .run();
  } catch (error: any) {
    Logger.error(`❌ Erro ao registrar certificação:`, error);
  }
}

app.get('/agendamento/:codigo/ficha', async (c) => {
  try {
    const db = c.env.DB;
    const codigo = c.req.param('codigo');

    const agendamento = await db
      .prepare(
        `
      SELECT id FROM agendamento_slots 
      WHERE codigo = ? 
      AND deleted_at IS NULL
    `,
      )
      .bind(codigo)
      .first();

    if (!agendamento) {
      return c.json(
        {
          success: false,
          error: 'Agendamento não encontrado',
        },
        404,
      );
    }

    const ficha = await db
      .prepare(
        `
      SELECT 
        uuid, 
        status, 
        aprovado, 
        nota, 
        nota_minima,
        created_at
      FROM fichas_sessao
      WHERE agendamento_slot_id = ?
      AND deleted_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1
    `,
      )
      .bind(agendamento.id)
      .first();

    if (!ficha) {
      return c.json(
        {
          success: false,
          error: 'Nenhuma ficha encontrada para este agendamento',
        },
        404,
      );
    }

    return c.json({ success: true, data: ficha });
  } catch (error: any) {
    Logger.error('[FICHA] Erro ao buscar:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default app;
