import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

const mockColaboradores = [
  {
    id: 1,
    nome: 'João Silva Santos',
    matricula: '00001',
    funcao: 'INSTRUTOR',
    email: 'joao.silva@airtrust.com.br',
    telefone: '(11) 99999-0001',
    is_instrutor: 1,
    is_checador: 0,
    status: 'ATIVO',
    base: 'São Paulo',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 2,
    nome: 'Maria Santos Oliveira',
    matricula: '00002',
    funcao: 'INSTRUTOR',
    email: 'maria.santos@airtrust.com.br',
    telefone: '(11) 99999-0002',
    is_instrutor: 1,
    is_checador: 0,
    status: 'ATIVO',
    base: 'Rio de Janeiro',
    contrato: 'CLT',
    aeronave_principal: 'B737',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 3,
    nome: 'Carlos Eduardo Lima',
    matricula: '00003',
    funcao: 'INSTRUTOR',
    email: 'carlos.lima@airtrust.com.br',
    telefone: '(11) 99999-0003',
    is_instrutor: 1,
    is_checador: 0,
    status: 'ATIVO',
    base: 'Brasília',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 4,
    nome: 'Pedro Henrique Alves',
    matricula: '00004',
    funcao: 'PILOTO',
    email: 'pedro.alves@airtrust.com.br',
    telefone: '(11) 99999-0004',
    is_instrutor: 0,
    is_checador: 0,
    status: 'ATIVO',
    base: 'São Paulo',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 5,
    nome: 'Ana Carolina Costa',
    matricula: '00005',
    funcao: 'COPILOTO',
    email: 'ana.costa@airtrust.com.br',
    telefone: '(11) 99999-0005',
    is_instrutor: 0,
    is_checador: 0,
    status: 'ATIVO',
    base: 'São Paulo',
    contrato: 'CLT',
    aeronave_principal: 'B737',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 6,
    nome: 'Luis Fernando Santos',
    matricula: '00006',
    funcao: 'PILOTO',
    email: 'luis.santos@airtrust.com.br',
    telefone: '(11) 99999-0006',
    is_instrutor: 0,
    is_checador: 0,
    status: 'ATIVO',
    base: 'Rio de Janeiro',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 7,
    nome: 'Patricia Rodrigues',
    matricula: '00007',
    funcao: 'COPILOTO',
    email: 'patricia.rodrigues@airtrust.com.br',
    telefone: '(11) 99999-0007',
    is_instrutor: 0,
    is_checador: 0,
    status: 'ATIVO',
    base: 'Brasília',
    contrato: 'CLT',
    aeronave_principal: 'B737',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 8,
    nome: 'Roberto Silva Junior',
    matricula: '00008',
    funcao: 'CHECADOR',
    email: 'roberto.silva@airtrust.com.br',
    telefone: '(11) 99999-0008',
    is_instrutor: 0,
    is_checador: 1,
    status: 'ATIVO',
    base: 'São Paulo',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 9,
    nome: 'Fernando Mendes',
    matricula: '00009',
    funcao: 'INSTRUTOR',
    email: 'fernando.mendes@airtrust.com.br',
    telefone: '(11) 99999-0009',
    is_instrutor: 1,
    is_checador: 0,
    status: 'ATIVO',
    base: 'São Paulo',
    contrato: 'CLT',
    aeronave_principal: 'B737',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 10,
    nome: 'Sandra Lima',
    matricula: '00010',
    funcao: 'PILOTO',
    email: 'sandra.lima@airtrust.com.br',
    telefone: '(11) 99999-0010',
    is_instrutor: 0,
    is_checador: 0,
    status: 'ATIVO',
    base: 'Rio de Janeiro',
    contrato: 'CLT',
    aeronave_principal: 'A320',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

app.get('/', async (c) => {
  try {
    
    return c.json({
      success: true,
      data: mockColaboradores,
      total: mockColaboradores.length,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro ao buscar colaboradores',
      data: [],
      total: 0
    }, 500);
  }
});

app.get('/:id', async (c) => {
  try {
    const id = parseInt(c.req.param('id'));
    
    if (isNaN(id)) {
      return c.json({
        success: false,
        error: 'ID inválido'
      }, 400);
    }
    
    const colaborador = mockColaboradores.find(col => col.id === id);
    
    if (!colaborador) {
      return c.json({
        success: false,
        error: 'Colaborador não encontrado'
      }, 404);
    }
    
    return c.json({
      success: true,
      data: colaborador
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro interno do servidor'
    }, 500);
  }
});

app.get('/instrutores', async (c) => {
  try {
    const instrutores = mockColaboradores.filter(col => col.is_instrutor === 1);
    
    return c.json({
      success: true,
      data: instrutores,
      total: instrutores.length,
      filtro: 'instrutores',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro ao buscar instrutores',
      data: []
    }, 500);
  }
});

app.get('/checadores', async (c) => {
  try {
    const checadores = mockColaboradores.filter(col => col.is_checador === 1);
    
    return c.json({
      success: true,
      data: checadores,
      total: checadores.length,
      filtro: 'checadores',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro ao buscar checadores',
      data: []
    }, 500);
  }
});

app.get('/ativos', async (c) => {
  try {
    const ativos = mockColaboradores.filter(col => col.status === 'ATIVO');
    
    return c.json({
      success: true,
      data: ativos,
      total: ativos.length,
      filtro: 'ativos',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    return c.json({
      success: false,
      error: 'Erro ao buscar colaboradores ativos',
      data: []
    }, 500);
  }
});

export default app;
