import { Hono } from 'hono';
import { Env } from '../../types/index';
import { Logger } from '../../utils/logger';
import { z } from 'zod';
import { calcularVencimento, TipoVencimento } from '../../utils/calcularVencimento';
import {
  recalcularTodasQualificacoes,
  recalcularPorFuncionario,
} from '../../scripts/recalcular-vencimentos';
import {
  CriarQualificacaoSchema,
  AtualizarQualificacaoSchema,
} from '../../../schemas/qualificacoes.schema';
import { rateLimitRead, rateLimitWrite } from '../../middleware/rate-limit-qualificacoes';
import {
  getFromCache,
  setCache,
  invalidateCache,
  generateCacheKey,
  CACHE_CONFIG,
} from '../../utils/cache-qualificacoes';
import { securityHeaders } from '../../middleware/security-headers';

// Type Interfaces
interface CountResult {
  total: number;
}

interface StatisticsResult {
  total: number;
  validas: number;
  vencendo: number;
  vencidas: number;
  renovadas: number;
}

interface QualificacaoRow {
  id: number;
  funcionario_id: number;
  funcionario_nome: string;
  funcionario_matricula: string;
  funcionario_codigo_anac: string;
  tipo: string;
  nome: string;
  codigo: string;
  descricao: string;
  categoria: string;
  requer_simulador: number;
  requer_aeronave: number;
  requer_sala: number;
  total_sessoes: number;
  carga_horaria: number;
  data_realizado: string;
  data_vencimento: string;
  validade_meses: number;
  dias_para_vencimento: number;
  is_renovada: number;
  status_calculado: string;
}

// Schemas
const OrderBySchema = z.enum([
  'id',
  'nome',
  'data_vencimento',
  'data_conclusao',
  'funcionario_nome',
  'status_calculado',
  'tipo',
]);
const OrderDirSchema = z.enum(['ASC', 'DESC']);

const qualificacoes = new Hono<{ Bindings: Env }>();

// Middleware
qualificacoes.use('*', securityHeaders());
qualificacoes.use('/', rateLimitRead);
qualificacoes.use('/', async (c, next) => {
  if (['POST', 'PUT', 'DELETE'].includes(c.req.method)) {
    return rateLimitWrite(c, next);
  }
  return next();
});

/**
 * GET /qualificacoes - List all qualifications with pagination and filters
 */
qualificacoes.get('/', async (c) => {
  try {
    const db = c.env.DB;

    // Input validation
    const page = Math.max(1, parseInt(c.req.query('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(c.req.query('limit') || '20')));
    let orderBy = 'data_vencimento';
    let orderDir = 'ASC';

    try {
      orderBy = OrderBySchema.parse(c.req.query('orderBy') || 'data_vencimento');
      orderDir = OrderDirSchema.parse((c.req.query('orderDir') || 'asc').toUpperCase());
    } catch {
      return c.json({ error: 'Invalid parameters', code: 'INVALID_PARAMETERS' }, 400);
    }

    const busca = c.req.query('busca')?.substring(0, 100) || '';
    const tipo = c.req.query('tipo');
    const categoria = c.req.query('categoria');
    const status = c.req.query('status');
    const data_inicio = c.req.query('data_inicio');
    const data_fim = c.req.query('data_fim');
    const offset = (page - 1) * limit;

    // Try cache
    const cacheKey = generateCacheKey('qualificacoes:list', {
      page,
      limit,
      busca,
      tipo,
      categoria,
      status,
      data_inicio,
      data_fim,
      orderBy,
      orderDir,
    });

    const cached = getFromCache(cacheKey);
    if (cached) {
      c.header('X-Cache', 'HIT');
      return c.json(cached);
    }

    const whereConditions: string[] = ['q.deleted_at IS NULL', 'f.deleted_at IS NULL'];
    const bindings: (string | number)[] = [];

    if (busca && busca.length > 0) {
      whereConditions.push(
        `(f.nome LIKE ? OR f.matricula LIKE ? OR q.codigo LIKE ? OR q.nome LIKE ?)`,
      );
      const searchTerm = `%${busca}%`;
      bindings.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    if (tipo) {
      whereConditions.push(`q.tipo = ?`);
      bindings.push(tipo);
    }

    if (categoria) {
      whereConditions.push(`t.categoria = ?`);
      bindings.push(categoria);
    }

    if (data_inicio && /^\d{4}-\d{2}-\d{2}$/.test(data_inicio)) {
      whereConditions.push(`q.data_conclusao >= ?`);
      bindings.push(data_inicio);
    }

    if (data_fim && /^\d{4}-\d{2}-\d{2}$/.test(data_fim)) {
      whereConditions.push(`q.data_conclusao <= ?`);
      bindings.push(data_fim);
    }

    const whereClause = whereConditions.join(' AND ');

    // Count total
    const countQuery = `SELECT COUNT(*) as total FROM qualificacoes q INNER JOIN funcionarios f ON f.id = q.funcionario_id WHERE ${whereClause}`;
    const countResult = (await (db.prepare(countQuery) as any)
      .bind(...bindings)
      .first()) as CountResult | null;
    const total = countResult?.total || 0;

    // Main query
    const orderByMap: Record<string, string> = {
      funcionario_nome: 'f.nome',
      tipo: 'q.tipo',
      codigo: 'q.codigo',
      nome: 'q.nome',
      data_conclusao: 'q.data_conclusao',
      data_vencimento: 'q.data_vencimento',
      status: 'status_calculado',
    };

    const orderByColumn = orderByMap[orderBy] || 'q.data_vencimento';
    const orderDirection = orderDir === 'DESC' ? 'DESC' : 'ASC';

    const query = `
      SELECT 
        q.id, q.funcionario_id, f.nome as funcionario_nome, f.matricula as funcionario_matricula,
        f.codigo_anac as funcionario_codigo_anac, q.tipo, q.nome, q.codigo, q.observacoes as descricao,
        t.categoria, t.requer_simulador, t.requer_aeronave, t.requer_sala,
        t.total_sessoes, t.carga_horaria, q.data_conclusao as data_realizado,
        q.data_vencimento, COALESCE(t.validade_meses, 12) as validade_meses,
        CASE
          WHEN q.data_vencimento IS NULL THEN NULL
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN NULL
          ELSE CAST(julianday(q.data_vencimento) - julianday('now') AS INTEGER)
        END as dias_para_vencimento,
        CASE WHEN q.status = 'RENOVADA' THEN 1 ELSE 0 END as is_renovada,
        CASE
          WHEN q.status = 'RENOVADA' THEN 'RENOVADA'
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN 'VENCIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') <= 30 THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        q.instrutor as instrutor,
        q.arquivo_url as arquivo_url
      FROM qualificacoes q
      INNER JOIN funcionarios f ON f.id = q.funcionario_id
      LEFT JOIN qualificacoes t ON t.codigo = q.codigo AND t.deleted_at IS NULL
      WHERE ${whereClause}
      ORDER BY ${orderByColumn} ${orderDirection}
      LIMIT ? OFFSET ?
    `;

    bindings.push(limit, offset);
    const result = await (db.prepare(query) as any).bind(...bindings).all();

    const processedData = (result.results || []).map((item: any) => ({
      id: item.id,
      funcionario_id: item.funcionario_id,
      funcionario_nome: item.funcionario_nome,
      funcionario_matricula: item.funcionario_matricula,
      funcionario_codigo_anac: item.funcionario_codigo_anac,
      tipo: item.tipo,
      nome: item.nome,
      codigo: item.codigo,
      descricao: item.descricao,
      data_realizado: item.data_realizado,
      data_vencimento: item.data_vencimento,
      validade_meses: item.validade_meses,
      dias_para_vencimento: item.dias_para_vencimento,
      is_renovada: item.is_renovada,
      status: item.status_calculado || 'VALIDA',
      instrutor: item.instrutor,
      arquivo_url: item.arquivo_url,
    }));

    // Stats
    const statsQuery = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status != 'RENOVADA' AND (data_vencimento IS NULL OR julianday(data_vencimento) - julianday('now') > 30) THEN 1 ELSE 0 END) as validas,
        SUM(CASE WHEN status != 'RENOVADA' AND julianday(data_vencimento) - julianday('now') BETWEEN 0 AND 30 THEN 1 ELSE 0 END) as vencendo,
        SUM(CASE WHEN status != 'RENOVADA' AND julianday(data_vencimento) - julianday('now') < 0 THEN 1 ELSE 0 END) as vencidas,
        SUM(CASE WHEN status = 'RENOVADA' THEN 1 ELSE 0 END) as renovadas
      FROM qualificacoes WHERE deleted_at IS NULL
    `;

    const stats = (await (db.prepare(statsQuery) as any).first()) as StatisticsResult | null;

    const response = {
      success: true,
      data: processedData,
      stats: {
        total: stats?.total || 0,
        validas: stats?.validas || 0,
        vencendo: stats?.vencendo || 0,
        vencidas: stats?.vencidas || 0,
        renovadas: stats?.renovadas || 0,
      },
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };

    setCache(cacheKey, response, CACHE_CONFIG.LIST);
    c.header('X-Cache', 'MISS');
    return c.json(response);
  } catch (error) {
    Logger.error('[QUALIFICACOES] Error:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        data: [],
        stats: { total: 0, validas: 0, vencendo: 0, vencidas: 0 },
      },
      500,
    );
  }
});

/**
 * GET /alertas-vencimento - Expiry alerts (MUST BE BEFORE /:id!)
 */
qualificacoes.get('/alertas-vencimento', async (c) => {
  try {
    const db = c.env.DB;

    const countVencidas = await (
      db.prepare(`
      SELECT COUNT(*) as total
      FROM qualificacoes q
      WHERE q.deleted_at IS NULL AND q.status != 'RENOVADA'
        AND q.data_vencimento IS NOT NULL
        AND julianday(q.data_vencimento) < julianday('now')
    `) as any
    ).first();

    const vencidas = await (
      db.prepare(`
      SELECT 
        q.id, q.codigo, q.nome, f.nome as funcionario_nome,
        CAST(julianday(q.data_vencimento) - julianday('now') AS INTEGER) as dias_para_vencimento
      FROM qualificacoes q
      INNER JOIN funcionarios f ON f.id = q.funcionario_id
      WHERE q.deleted_at IS NULL AND q.status != 'RENOVADA'
        AND q.data_vencimento IS NOT NULL
        AND julianday(q.data_vencimento) < julianday('now')
      ORDER BY q.data_vencimento ASC
      LIMIT 20
    `) as any
    ).all();

    const vencendo7 = await (
      db.prepare(`
      SELECT COUNT(*) as total
      FROM qualificacoes q
      WHERE q.deleted_at IS NULL AND q.status != 'RENOVADA'
        AND q.data_vencimento IS NOT NULL
        AND julianday(q.data_vencimento) - julianday('now') BETWEEN 0 AND 7
    `) as any
    ).first();

    const vencendo30 = await (
      db.prepare(`
      SELECT COUNT(*) as total
      FROM qualificacoes q
      WHERE q.deleted_at IS NULL AND q.status != 'RENOVADA'
        AND q.data_vencimento IS NOT NULL
        AND julianday(q.data_vencimento) - julianday('now') BETWEEN 8 AND 30
    `) as any
    ).first();

    return c.json({
      success: true,
      alertas: [
        {
          tipo: 'vencidas',
          quantidade: (countVencidas as any)?.total || 0,
          qualificacoes: vencidas.results || [],
        },
        { tipo: 'vencendo_7', quantidade: (vencendo7 as any)?.total || 0, qualificacoes: [] },
        { tipo: 'vencendo_30', quantidade: (vencendo30 as any)?.total || 0, qualificacoes: [] },
      ],
    });
  } catch (error) {
    Logger.error('Error fetching alerts:', error);
    return c.json({ success: false, error: error instanceof Error ? error.message : 'Error' }, 500);
  }
});

/**
 * GET /qualificacoes/:id - Get by ID
 */
qualificacoes.get('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;
    const result = await (
      db.prepare(`
      SELECT 
        q.*, f.nome as funcionario_nome, f.matricula as funcionario_matricula,
        COALESCE(t.validade_meses, 12) as validade_meses,
        CASE 
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN q.data_vencimento < DATE('now') THEN 'VENCIDA'
          WHEN q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        CAST((julianday(q.data_vencimento) - julianday('now')) AS INTEGER) as dias_restantes
      FROM qualificacoes q
      INNER JOIN funcionarios f ON q.funcionario_id = f.id
      LEFT JOIN qualificacoes t ON t.codigo = q.codigo AND t.deleted_at IS NULL
      WHERE q.id = ? AND q.deleted_at IS NULL
    `) as any
    )
      .bind(id)
      .first();

    if (!result) {
      return c.json({ success: false, error: 'Not found' }, 404);
    }

    return c.json({ success: true, data: result });
  } catch (error) {
    return c.json({ success: false, error: error instanceof Error ? error.message : 'Error' }, 500);
  }
});

/**
 * POST /qualificacoes - Create new qualification
 */
qualificacoes.post('/', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const validacao = CriarQualificacaoSchema.safeParse(body);
    if (!validacao.success) {
      return c.json(
        { success: false, error: 'Invalid data', details: validacao.error.errors },
        400,
      );
    }

    const dados = validacao.data;

    const tipoExiste = await (
      db.prepare(`
      SELECT codigo, nome, validade_meses, vencimento_tipo, categoria
      FROM qualificacoes 
      WHERE codigo = ? AND deleted_at IS NULL
    `) as any
    )
      .bind(dados.codigo)
      .first();

    if (!tipoExiste) {
      return c.json(
        {
          success: false,
          error: `Código '${dados.codigo}' not found. Create type first.`,
        },
        400,
      );
    }

    let dataValidade = dados.data_vencimento;
    if (!dataValidade && dados.data_conclusao) {
      dataValidade = calcularVencimento(
        dados.data_conclusao,
        tipoExiste.validade_meses || 12,
        (tipoExiste.vencimento_tipo as TipoVencimento) || 'DIA_EXATO',
      );
    }

    const nomeQualificacao = dados.nome || tipoExiste.nome;

    // Mark previous qualifications as renovated
    await (
      db.prepare(`
      UPDATE qualificacoes 
      SET status = 'RENOVADA'
      WHERE funcionario_id = ? AND codigo = ? AND status != 'RENOVADA' AND deleted_at IS NULL
    `) as any
    )
      .bind(dados.funcionario_id, dados.codigo)
      .run();

    const result = await (
      db.prepare(`
      INSERT INTO qualificacoes (
        funcionario_id, tipo, codigo, nome,
        data_conclusao, data_vencimento, observacoes
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `) as any
    )
      .bind(
        dados.funcionario_id,
        dados.tipo,
        dados.codigo,
        nomeQualificacao,
        dados.data_conclusao || null,
        dataValidade || null,
        dados.observacoes || null,
      )
      .run();

    invalidateCache('qualificacoes:');

    return c.json({
      success: true,
      message: 'Created successfully',
      id: result.meta.last_row_id,
      vencimento_calculado: dataValidade,
    });
  } catch (error: any) {
    Logger.error('Error creating qualification', error);
    return c.json(
      {
        success: false,
        error: error.message || 'Error creating qualification',
        code: 'CREATE_ERROR',
      },
      500,
    );
  }
});

/**
 * PUT /qualificacoes/:id - Update qualification
 */
qualificacoes.put('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;
    const body = await c.req.json();

    const validacao = AtualizarQualificacaoSchema.safeParse(body);
    if (!validacao.success) {
      return c.json(
        { success: false, error: 'Invalid data', details: validacao.error.errors },
        400,
      );
    }

    const dados = validacao.data;

    const exists = await (
      db.prepare(`
      SELECT id FROM qualificacoes WHERE id = ? AND deleted_at IS NULL
    `) as any
    )
      .bind(id)
      .first();

    if (!exists) {
      return c.json({ success: false, error: 'Not found' }, 404);
    }

    await (
      db.prepare(`
      UPDATE qualificacoes 
      SET 
        tipo = ?, codigo = ?, nome = ?,
        data_conclusao = ?, data_vencimento = ?,
        observacoes = ?, updated_at = datetime('now')
      WHERE id = ?
    `) as any
    )
      .bind(
        dados.tipo,
        dados.codigo,
        dados.nome,
        dados.data_conclusao,
        dados.data_vencimento,
        dados.observacoes,
        id,
      )
      .run();

    invalidateCache('qualificacoes:');

    return c.json({
      success: true,
      message: 'Updated successfully',
    });
  } catch (error) {
    Logger.error('Error updating qualification', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Error',
        code: 'UPDATE_ERROR',
      },
      500,
    );
  }
});

/**
 * DELETE /qualificacoes/:id - Soft delete qualification
 */
qualificacoes.delete('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;

    const exists = await (
      db.prepare(`
      SELECT id FROM qualificacoes WHERE id = ? AND deleted_at IS NULL
    `) as any
    )
      .bind(id)
      .first();

    if (!exists) {
      return c.json({ success: false, error: 'Not found' }, 404);
    }

    await (
      db.prepare(`
      UPDATE qualificacoes 
      SET deleted_at = datetime('now'), updated_at = datetime('now')
      WHERE id = ?
    `) as any
    )
      .bind(id)
      .run();

    invalidateCache('qualificacoes:');

    return c.json({
      success: true,
      message: 'Deleted successfully',
    });
  } catch (error) {
    Logger.error('Error deleting qualification', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Error',
        code: 'DELETE_ERROR',
      },
      500,
    );
  }
});

/**
 * GET /qualificacoes/funcionario/:funcionario_id - List by employee
 */
qualificacoes.get('/funcionario/:funcionario_id', async (c) => {
  const funcionarioId = c.req.param('funcionario_id');
  const db = c.env.DB;

  try {
    const funcionario = await (
      db.prepare(`
      SELECT id, nome, matricula, email, cargo
      FROM funcionarios
      WHERE id = ? AND deleted_at IS NULL
    `) as any
    )
      .bind(funcionarioId)
      .first();

    if (!funcionario) {
      return c.json({ success: false, error: 'Employee not found' }, 404);
    }

    const result = await (
      db.prepare(`
      SELECT q.*,
        CASE 
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN 'VENCIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') <= 30 THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado
      FROM qualificacoes q
      WHERE q.funcionario_id = ? AND q.deleted_at IS NULL
      ORDER BY q.data_vencimento ASC
    `) as any
    )
      .bind(funcionarioId)
      .all();

    const qualificacoes = result.results || [];
    const stats = {
      total: qualificacoes.length,
      validas: qualificacoes.filter((q: any) => q.status_calculado === 'VALIDA').length,
      vencendo: qualificacoes.filter((q: any) => q.status_calculado === 'VENCENDO').length,
      vencidas: qualificacoes.filter((q: any) => q.status_calculado === 'VENCIDA').length,
      por_tipo: {
        treinamentos: qualificacoes.filter((q: any) => q.tipo === 'TREINAMENTO').length,
        checks: qualificacoes.filter((q: any) => q.tipo === 'CHECK').length,
        exames: qualificacoes.filter((q: any) => q.tipo === 'EXAME').length,
      },
    };

    return c.json({
      success: true,
      funcionario,
      qualificacoes,
      stats,
    });
  } catch (error: any) {
    Logger.error('[QUALIFICACOES EMPLOYEE] Error:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * GET /qualificacoes/dashboard-stats - Dashboard statistics
 */
qualificacoes.get('/dashboard-stats', async (c) => {
  const db = c.env.DB;

  try {
    const statsStatus = await (
      db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN data_vencimento >= DATE('now') THEN 1 ELSE 0 END) as validas,
        SUM(CASE WHEN data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 ELSE 0 END) as vencendo,
        SUM(CASE WHEN data_vencimento < DATE('now') THEN 1 ELSE 0 END) as vencidas
      FROM qualificacoes
      WHERE deleted_at IS NULL
    `) as any
    ).first();

    const statsTipo = await (
      db.prepare(`
      SELECT 
        SUM(CASE WHEN tipo = 'TREINAMENTO' THEN 1 ELSE 0 END) as treinamentos,
        SUM(CASE WHEN tipo = 'CHECK' THEN 1 ELSE 0 END) as checks,
        SUM(CASE WHEN tipo = 'EXAME' THEN 1 ELSE 0 END) as exames
      FROM qualificacoes
      WHERE deleted_at IS NULL
    `) as any
    ).first();

    return c.json({
      success: true,
      stats: {
        total: (statsStatus as any)?.total || 0,
        validas: (statsStatus as any)?.validas || 0,
        vencendo: (statsStatus as any)?.vencendo || 0,
        vencidas: (statsStatus as any)?.vencidas || 0,
        por_tipo: {
          treinamentos: (statsTipo as any)?.treinamentos || 0,
          checks: (statsTipo as any)?.checks || 0,
          exames: (statsTipo as any)?.exames || 0,
        },
      },
    });
  } catch (error: any) {
    Logger.error('[STATS] Error:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * GET /qualificacoes/historico/:funcionario_id - Full history including renovated
 */
qualificacoes.get('/historico/:funcionario_id', async (c) => {
  try {
    const funcionarioId = c.req.param('funcionario_id');
    const { tipo, codigo } = c.req.query();
    const db = c.env.DB;

    let query = `
      SELECT 
        q.*, f.nome as funcionario_nome, f.matricula as funcionario_matricula,
        f.codigo_anac as funcionario_codigo_anac,
        CASE
          WHEN q.status = 'RENOVADA' THEN 'RENOVADA'
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN 'VENCIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') <= 30 THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        CAST(julianday(q.data_vencimento) - julianday('now') AS INTEGER) as dias_para_vencimento
      FROM qualificacoes q
      INNER JOIN funcionarios f ON f.id = q.funcionario_id
      WHERE q.funcionario_id = ? AND q.deleted_at IS NULL
    `;

    const params: any[] = [parseInt(funcionarioId)];

    if (tipo) {
      query += ` AND q.tipo = ?`;
      params.push(tipo);
    }

    if (codigo) {
      query += ` AND q.codigo = ?`;
      params.push(codigo);
    }

    query += ` ORDER BY q.tipo, q.codigo, q.data_conclusao DESC, q.id DESC`;

    const result = await (db.prepare(query) as any).bind(...params).all();

    const grouped = (result.results || []).reduce((acc: any, qual: any) => {
      const key = `${qual.tipo}-${qual.codigo}`;
      if (!acc[key]) {
        acc[key] = { tipo: qual.tipo, codigo: qual.codigo, nome: qual.nome, versoes: [] };
      }
      acc[key].versoes.push(qual);
      return acc;
    }, {});

    return c.json({ success: true, data: Object.values(grouped) });
  } catch (error) {
    Logger.error('Error fetching history:', error);
    return c.json({ success: false, error: 'Error fetching history' }, 500);
  }
});

/**
 * POST /qualificacoes/recalcular-datas - Recalculate dates
 */
qualificacoes.post('/recalcular-datas', async (c) => {
  try {
    const db = c.env.DB;
    const body = await c.req.json().catch(() => ({}));

    const resultado = body.funcionario_id
      ? await recalcularPorFuncionario(db, body.funcionario_id)
      : await recalcularTodasQualificacoes(db);

    return c.json({
      success: resultado.sucesso,
      total_calculadas: resultado.total_calculadas,
      erros: resultado.erros,
      message: `${resultado.total_calculadas} qualifications updated`,
    });
  } catch (error: any) {
    Logger.error('[RECALCULATE] Error:', error);
    return c.json({ success: false, error: error.message || 'Error' }, 500);
  }
});

/**
 * POST /qualificacoes/:id/gerar-certificado - Mark qualification as certificate generated
 */
qualificacoes.post('/:id/gerar-certificado', async (c) => {
  try {
    const db = c.env.DB;
    const qualificacaoId = parseInt(c.req.param('id'));

    if (!qualificacaoId || isNaN(qualificacaoId)) {
      return c.json({ success: false, error: 'Invalid qualification ID' }, 400);
    }

    // Get current qualification
    const qual = await (
      db.prepare('SELECT * FROM qualificacoes WHERE id = ? AND deleted_at IS NULL') as any
    )
      .bind(qualificacaoId)
      .first();

    if (!qual) {
      return c.json({ success: false, error: 'Qualification not found' }, 404);
    }

    // Mark with updated_at timestamp to indicate certificate was generated
    const stmt = db.prepare(`
      UPDATE qualificacoes
      SET updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `) as any;

    await stmt.bind(qualificacaoId).run();

    Logger.info(`Certificate generation flagged for qualification ${qualificacaoId}`);

    return c.json({
      success: true,
      message: 'Certificate generation processed',
      qualificacao_id: qualificacaoId,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    Logger.error('[GENERATE_CERT] Error:', error);
    return c.json({ success: false, error: error.message || 'Error generating certificate' }, 500);
  }
});

export default qualificacoes;
