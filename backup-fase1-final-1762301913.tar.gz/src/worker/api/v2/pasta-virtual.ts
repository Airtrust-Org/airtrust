import { Hono } from 'hono';
// TODO: Auth disabled in dev
// import { authMiddleware } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { logAudit } from '../../services/audit';
import { Logger } from '../../utils/logger';
import type { Env } from '../../types/index';
import {
  sincronizarCertificadoComPastaVirtual,
  sincronizarLoteCertificados,
} from '../../services/pasta-virtual-sync';

const app = new Hono<{ Bindings: Env }>();

// TODO: app.use('*', authMiddleware); // Auth disabled in dev

const rbacPastaVirtual = async (c: any, next: any) => {
  const userId = c.get('user_id');

  if (!userId) {
    return c.json({ success: false, error: 'Acesso negado: usuário não autenticado' }, 401);
  }

  const userProfile = await c.env.DB.prepare(
    `
    SELECT perfil FROM user_profiles_v2 
    WHERE user_id = ? AND ativo = 1
    LIMIT 1
  `,
  )
    .bind(userId)
    .first();

  if (!userProfile || userProfile.perfil === 'FUNCIONARIO') {
    return c.json(
      {
        success: false,
        error: 'Acesso negado: funcionalidade restrita para gestores e administradores',
      },
      403,
    );
  }

  await next();
};

app.use('*', rbacPastaVirtual);

app.get('/dashboard', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const stats = await c.env.DB.prepare(
      `
      SELECT 
        COUNT(DISTINCT f.id) as total_funcionarios,
        COUNT(CASE WHEN pvsl.status_sincronizacao = 'PENDENTE' OR pvsl.status_sincronizacao = 'ERRO' THEN 1 END) as pendencias,
        COUNT(CASE WHEN pvsl.data_vencimento < DATE('now') AND pvsl.status_sincronizacao = 'SINCRONIZADO' THEN 1 END) as vencidas,
        COUNT(CASE WHEN pvsl.data_vencimento <= DATE('now', '+7 days') AND pvsl.data_vencimento >= DATE('now') AND pvsl.status_sincronizacao = 'SINCRONIZADO' THEN 1 END) as criticas,
        COUNT(CASE WHEN pvsl.status_sincronizacao = 'SINCRONIZADO' THEN 1 END) as sincronizados,
        SUM(CASE WHEN pvsl.tamanho_bytes IS NOT NULL THEN pvsl.tamanho_bytes ELSE 0 END) as tamanho_total_bytes
      FROM funcionarios f
      LEFT JOIN pasta_virtual_sync_log pvsl ON f.id = pvsl.funcionario_id AND pvsl.deleted_at IS NULL
      WHERE f.deleted_at IS NULL
    `,
    ).first();

    const estatisticasAdicionais = await c.env.DB.prepare(
      `
      SELECT 
        COUNT(*) as total_certificacoes_com_arquivo,
        COUNT(CASE WHEN pvsl.id IS NOT NULL THEN 1 END) as certificacoes_sincronizadas
      FROM historico_certificacoes_v2 hc
      LEFT JOIN pasta_virtual_sync_log pvsl ON hc.id = pvsl.historico_cert_id AND pvsl.deleted_at IS NULL
      WHERE hc.certificado_url IS NOT NULL 
        AND hc.certificado_url != '' 
        AND NOT hc.certificado_url LIKE 'mock://%'
        AND hc.deleted_at IS NULL
    `,
    ).first();

    const tamanhoTotalMB = stats?.tamanho_total_bytes
      ? Math.round((stats.tamanho_total_bytes / (1024 * 1024)) * 100) / 100
      : 0;

    return c.json({
      success: true,
      dashboard: {
        total_funcionarios: stats?.total_funcionarios || 0,
        com_pendencias: stats?.pendencias || 0,
        certificacoes_vencidas: stats?.vencidas || 0,
        situacoes_criticas: stats?.criticas || 0,
        certificacoes_sincronizadas: stats?.sincronizados || 0,
        tamanho_total_mb: tamanhoTotalMB,
        certificacoes_disponiveis: estatisticasAdicionais?.total_certificacoes_com_arquivo || 0,
        taxa_sincronizacao:
          estatisticasAdicionais?.total_certificacoes_com_arquivo > 0
            ? Math.round(
                (estatisticasAdicionais.certificacoes_sincronizadas /
                  estatisticasAdicionais.total_certificacoes_com_arquivo) *
                  100,
              )
            : 0,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    Logger.error('💥 [API] Erro no dashboard:', error);
    return c.json(
      { success: false, error: error instanceof Error ? error.message : 'Erro interno' },
      500,
    );
  }
});

app.get('/funcionarios-dropdown', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarios = await c.env.DB.prepare(
      `
      SELECT 
        f.id, f.nome, f.matricula, f.funcao,
        COUNT(pvsl.id) as total_certificacoes,
        COUNT(CASE WHEN pvsl.status_sincronizacao = 'SINCRONIZADO' THEN 1 END) as sincronizados,
        COUNT(CASE WHEN pvsl.status_sincronizacao = 'ERRO' THEN 1 END) as com_erro,
        COUNT(CASE WHEN pvsl.data_vencimento < DATE('now') AND pvsl.status_sincronizacao = 'SINCRONIZADO' THEN 1 END) as vencidos
      FROM funcionarios f
      LEFT JOIN pasta_virtual_sync_log pvsl ON f.id = pvsl.funcionario_id AND pvsl.deleted_at IS NULL
      WHERE f.deleted_at IS NULL AND f.status = 'ATIVO'
      GROUP BY f.id, f.nome, f.matricula, f.funcao
      HAVING COUNT(pvsl.id) > 0
      ORDER BY f.nome ASC
    `,
    ).all();

    const funcionariosFormatados = (funcionarios.results || []).map((f: any) => ({
      id: f.id,
      nome: f.nome,
      matricula: f.matricula,
      funcao: f.funcao,
      label: `${f.com_erro > 0 ? '❌' : f.vencidos > 0 ? '⚠️' : '✅'} ${f.nome} (${
        f.matricula
      }) - ${f.sincronizados}/${f.total_certificacoes} cert.`,
      total_certificacoes: f.total_certificacoes,
      sincronizados: f.sincronizados,
      com_erro: f.com_erro,
      vencidos: f.vencidos,
      status_visual: f.com_erro > 0 ? 'erro' : f.vencidos > 0 ? 'atencao' : 'ok',
    }));

    return c.json({
      success: true,
      funcionarios: funcionariosFormatados,
      total: funcionariosFormatados.length,
    });
  } catch (error) {
    Logger.error('💥 [API] Erro no dropdown funcionários:', error);
    return c.json(
      { success: false, error: error instanceof Error ? error.message : 'Erro interno' },
      500,
    );
  }
});

app.get('/funcionario/:id', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('id'));

    if (isNaN(funcionarioId)) {
      return c.json({ success: false, error: 'ID de funcionário inválido' }, 400);
    }

    const funcionario = await c.env.DB.prepare(
      `
      SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL
    `,
    )
      .bind(funcionarioId)
      .first();

    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }

    const certificacoes = await c.env.DB.prepare(
      `
      SELECT 
        pvsl.*,
        CASE 
          WHEN pvsl.data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN pvsl.data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDO'
        END as status_validade,
        CASE 
          WHEN pvsl.data_vencimento IS NOT NULL THEN 
            CASE 
              WHEN pvsl.data_vencimento < DATE('now') THEN 
                printf('-%d dias', CAST((julianday('now') - julianday(pvsl.data_vencimento)) AS INTEGER))
              ELSE 
                printf('+%d dias', CAST((julianday(pvsl.data_vencimento) - julianday('now')) AS INTEGER))
            END
          ELSE NULL
        END as dias_para_vencimento_texto
      FROM pasta_virtual_sync_log pvsl
      WHERE pvsl.funcionario_id = ? AND pvsl.deleted_at IS NULL
      ORDER BY pvsl.data_conclusao DESC, pvsl.created_at DESC
    `,
    )
      .bind(funcionarioId)
      .all();

    const resumo = {
      total_certificacoes: certificacoes.results?.length || 0,
      sincronizados: (certificacoes.results || []).filter(
        (c: any) => c.status_sincronizacao === 'SINCRONIZADO',
      ).length,
      com_erro: (certificacoes.results || []).filter((c: any) => c.status_sincronizacao === 'ERRO')
        .length,
      vencidos: (certificacoes.results || []).filter((c: any) => c.status_validade === 'VENCIDO')
        .length,
      vencendo: (certificacoes.results || []).filter((c: any) => c.status_validade === 'VENCENDO')
        .length,
    };

    await logAudit(c, 'READ', 'pasta_virtual_funcionario', String(funcionarioId));

    return c.json({
      success: true,
      funcionario: funcionario,
      certificacoes: certificacoes.results || [],
      resumo: resumo,
    });
  } catch (error) {
    Logger.error(`💥 [API] Erro na pasta do funcionário:`, error);
    return c.json(
      { success: false, error: error instanceof Error ? error.message : 'Erro interno' },
      500,
    );
  }
});

app.post('/sincronizar-tudo', requirePermission('funcionarios', 'UPDATE'), async (c) => {
  try {
    const certificacoes = await c.env.DB.prepare(
      `
      SELECT 
        hc.id, 
        hc.funcionario_id,
        f.nome as funcionario_nome, 
        f.matricula as funcionario_matricula,
        ct.codigo as treinamento_codigo,
        ct.nome as treinamento_nome,
        hc.certificado_url
      FROM historico_certificacoes_v2 hc
      LEFT JOIN funcionarios f ON hc.funcionario_id = f.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      WHERE hc.certificado_url IS NOT NULL 
        AND hc.certificado_url != ''
        AND NOT hc.certificado_url LIKE 'mock://%'
        AND hc.deleted_at IS NULL 
        AND f.deleted_at IS NULL 
        AND ct.deleted_at IS NULL
      ORDER BY hc.created_at ASC
    `,
    ).all();

    if (!certificacoes.results || certificacoes.results.length === 0) {
      return c.json({
        success: true,
        resumo: {
          total_processados: 0,
          sincronizados: 0,
          ja_existiam: 0,
          erros: 0,
          tempo_total_segundos: 0,
          taxa_sucesso: 100,
        },
        message: 'Nenhuma certificação com arquivo real encontrada',
        timestamp: new Date().toISOString(),
      });
    }

    const resultado = await sincronizarLoteCertificados(
      certificacoes.results,
      c.env.DB,
      c.env.AIRTRUST_STORAGE || c.env.R2_BUCKET,
      10, // batch size
    );

    await logAudit(c, 'BULK_SYNC', 'pasta_virtual', 'all', undefined, {
      processados: resultado.resumoFinal.total_processados,
      sincronizados: resultado.sincronizados,
      erros: resultado.erros,
    });

    return c.json({
      success: true,
      resumo: resultado.resumoFinal,
      resultados: resultado.resultados.slice(0, 100), // Limitar para não sobrecarregar resposta
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    Logger.error('💥 [BULK-SYNC] Erro geral:', error);
    return c.json(
      { success: false, error: error instanceof Error ? error.message : 'Erro interno' },
      500,
    );
  }
});

app.post('/sincronizar/:historicoId', requirePermission('funcionarios', 'UPDATE'), async (c) => {
  try {
    const historicoId = parseInt(c.req.param('historicoId'));

    if (isNaN(historicoId)) {
      return c.json({ success: false, error: 'ID de histórico inválido' }, 400);
    }

    const resultado = await sincronizarCertificadoComPastaVirtual(
      historicoId,
      c.env.DB,
      c.env.AIRTRUST_STORAGE || c.env.R2_BUCKET,
    );

    await logAudit(c, 'SYNC', 'pasta_virtual', String(historicoId), undefined, {
      action: resultado.action,
      success: resultado.success,
    });

    return c.json({
      success: resultado.success,
      resultado: resultado,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    Logger.error('💥 [SINGLE-SYNC] Erro:', error);
    return c.json(
      { success: false, error: error instanceof Error ? error.message : 'Erro interno' },
      500,
    );
  }
});

app.get(
  '/funcionario/:funcionarioId/status',
  requirePermission('funcionarios', 'READ'),
  async (c) => {
    try {
      const funcionarioId = parseInt(c.req.param('funcionarioId'));

      if (isNaN(funcionarioId)) {
        return c.json({ success: false, error: 'ID de funcionário inválido' }, 400);
      }

      // TODO: Implementar verificação de sincronização
      // const { verificarStatusSincronizacaoFuncionario } = await import(
      //   '../../services/certificado-pasta-virtual-sync'
      // );
      // const status = await verificarStatusSincronizacaoFuncionario(funcionarioId, c.env.DB);
      
      const status = { sincronizado: true, ultima_sincronizacao: new Date().toISOString() };

      await logAudit(c, 'READ', 'pasta_virtual_status', String(funcionarioId));

      return c.json({
        success: true,
        data: status,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      Logger.error('Error checking sync status:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Internal server error',
        },
        500,
      );
    }
  },
);

app.post(
  '/funcionario/:funcionarioId/sincronizar',
  requirePermission('funcionarios', 'UPDATE'),
  async (c) => {
    try {
      const funcionarioId = parseInt(c.req.param('funcionarioId'));

      if (isNaN(funcionarioId)) {
        return c.json({ success: false, error: 'ID de funcionário inválido' }, 400);
      }

      const certificacoesComAnexo = await c.env.DB.prepare(
        `
      SELECT DISTINCT ca.id as anexo_id, ca.historico_id, f.nome as funcionario_nome
      FROM certificado_anexos_v2 ca
      JOIN historico_certificacoes_v2 hc ON ca.historico_id = hc.id
      JOIN funcionarios f ON hc.funcionario_id = f.id
      WHERE hc.funcionario_id = ? 
        AND hc.deleted_at IS NULL 
        AND f.deleted_at IS NULL
        AND ca.url_arquivo IS NOT NULL
        AND ca.url_arquivo != ''
        AND NOT ca.url_arquivo LIKE 'mock://%'
      ORDER BY ca.created_at ASC
    `,
      )
        .bind(funcionarioId)
        .all();

      const anexos = certificacoesComAnexo.results || [];

      if (anexos.length === 0) {
        return c.json({
          success: true,
          message: 'Nenhum certificado com anexo encontrado para sincronizar',
          data: {
            funcionario_id: funcionarioId,
            total_processados: 0,
            sincronizados: 0,
            erros: 0,
          },
        });
      }

      // TODO: Implementar sincronização de certificados
      // const { sincronizarCertificadoParaPastaVirtual } = await import(
      //   '../../services/certificado-pasta-virtual-sync'
      // );

      let sincronizados = 0,
        erros = 0;
      const resultados = [];

      for (const anexo of anexos) {
        try {
          // TODO: Implementar sincronização
          // const resultado = await sincronizarCertificadoParaPastaVirtual(
          //   anexo.anexo_id,
          //   c.env.DB,
          //   c.env.AIRTRUST_STORAGE || c.env.R2_BUCKET,
          // );
          
          const resultado = { sucesso: true, id: anexo.anexo_id };

          if (resultado.success) {
            sincronizados++;
          } else {
            erros++;
          }

          resultados.push({
            anexo_id: anexo.anexo_id,
            historico_id: anexo.historico_id,
            status: resultado.success ? 'SUCESSO' : 'ERRO',
            action: resultado.action,
            error: resultado.error,
          });
        } catch (error) {
          erros++;
          resultados.push({
            anexo_id: anexo.anexo_id,
            status: 'ERRO',
            error: error instanceof Error ? error.message : 'Erro desconhecido',
          });
        }

        await new Promise((resolve) => setTimeout(resolve, 100));
      }

      await logAudit(c, 'MANUAL_SYNC', 'pasta_virtual', String(funcionarioId), undefined, {
        total_processados: anexos.length,
        sincronizados,
        erros,
        funcionario_nome: anexos[0]?.funcionario_nome,
      });

      return c.json({
        success: true,
        message: `Sincronização concluída para ${anexos[0]?.funcionario_nome || 'funcionário'}`,
        data: {
          funcionario_id: funcionarioId,
          total_processados: anexos.length,
          sincronizados,
          erros,
          taxa_sucesso: anexos.length > 0 ? Math.round((sincronizados / anexos.length) * 100) : 100,
          resultados: resultados,
        },
      });
    } catch (error) {
      Logger.error('Error in manual sync:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Internal server error',
        },
        500,
      );
    }
  },
);

app.get('/:funcionarioId', requirePermission('funcionarios', 'READ'), async (c) => {
  try {
    const funcionarioId = parseInt(c.req.param('funcionarioId'));
    const tipo = c.req.query('tipo'); // Filtro opcional por tipo
    const db = c.env.DB;

    if (isNaN(funcionarioId)) {
      return c.json(
        {
          success: false,
          error: 'ID de funcionário inválido',
        },
        400,
      );
    }

    const funcionario = await db
      .prepare('SELECT id, nome, matricula FROM funcionarios WHERE id = ? AND deleted_at IS NULL')
      .bind(funcionarioId)
      .first();

    if (!funcionario) {
      return c.json(
        {
          success: false,
          error: 'Funcionário não encontrado',
        },
        404,
      );
    }

    let whereClause = 'WHERE pv.funcionario_id = ? AND pv.deleted_at IS NULL';
    const params: any[] = [funcionarioId];

    if (tipo) {
      whereClause += ' AND pv.tipo_documento = ?';
      params.push(tipo);
    }

    const documentos = await db
      .prepare(
        `
      SELECT 
        pv.*,
        CASE 
          WHEN pv.certificacao_id IS NOT NULL THEN hc.treinamento_id
          ELSE NULL
        END as treinamento_id,
        CASE 
          WHEN pv.certificacao_id IS NOT NULL THEN ct.nome
          ELSE NULL
        END as treinamento_nome,
        CASE 
          WHEN pv.certificacao_id IS NOT NULL THEN ct.codigo
          ELSE NULL
        END as treinamento_codigo
      FROM pasta_virtual pv
      LEFT JOIN historico_certificacoes_v2 hc ON pv.certificacao_id = hc.id
      LEFT JOIN catalogo_treinamentos_v2 ct ON hc.treinamento_id = ct.id
      ${whereClause}
      ORDER BY pv.created_at DESC
    `,
      )
      .bind(...params)
      .all();

    const certificadosAutomaticos = await db
      .prepare(
        `
      SELECT 
        pvsl.id,
        pvsl.historico_cert_id as certificacao_id,
        pvsl.nome_arquivo_auditavel as nome_arquivo,
        pvsl.arquivo_pasta_virtual_url as caminho_arquivo,
        pvsl.treinamento_nome,
        pvsl.treinamento_codigo,
        pvsl.data_conclusao,
        pvsl.data_vencimento,
        pvsl.data_sincronizacao as created_at,
        pvsl.status_sincronizacao,
        pvsl.tamanho_bytes,
        'CERTIFICADO' as tipo_documento,
        'SINCRONIZADO_AUTOMATICAMENTE' as origem,
        CASE 
          WHEN pvsl.data_vencimento < DATE('now') THEN 'VENCIDO'
          WHEN pvsl.data_vencimento <= DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDO'
        END as status_validade
      FROM pasta_virtual_sync_log pvsl
      WHERE pvsl.funcionario_id = ? AND pvsl.deleted_at IS NULL
        AND pvsl.status_sincronizacao = 'SINCRONIZADO'
      ORDER BY pvsl.data_conclusao DESC
    `,
      )
      .bind(funcionarioId)
      .all();

    const organizados: Record<string, any[]> = {
      CERTIFICADO: [...(certificadosAutomaticos.results || [])],
      DOCUMENTO: [],
      ANEXO: [],
      OUTROS: [],
    };

    (documentos.results || []).forEach((doc: any) => {
      const categoria = organizados[doc.tipo_documento] ? doc.tipo_documento : 'OUTROS';

      if (doc.tipo_documento === 'CERTIFICADO') {
        const jaExisteAutomatico = organizados.CERTIFICADO.some(
          (cert) => cert.certificacao_id === doc.certificacao_id,
        );
        if (!jaExisteAutomatico) {
          organizados[categoria].push({
            ...doc,
            origem: 'MANUAL',
          });
        }
      } else {
        organizados[categoria].push({
          ...doc,
          origem: 'MANUAL',
        });
      }
    });

    await logAudit(c, 'READ', 'pasta_virtual', String(funcionarioId));

    return c.json({
      success: true,
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
      },
      documentos: {
        total: (documentos.results?.length || 0) + (certificadosAutomaticos.results?.length || 0),
        por_tipo: {
          certificados: organizados.CERTIFICADO.length,
          certificados_automaticos: (certificadosAutomaticos.results || []).length,
          certificados_manuais: organizados.CERTIFICADO.filter((c) => c.origem === 'MANUAL').length,
          documentos: organizados.DOCUMENTO.length,
          anexos: organizados.ANEXO.length,
          outros: organizados.OUTROS.length,
        },
        estatisticas: {
          certificados_vencidos: organizados.CERTIFICADO.filter(
            (c) => c.status_validade === 'VENCIDO',
          ).length,
          certificados_vencendo: organizados.CERTIFICADO.filter(
            (c) => c.status_validade === 'VENCENDO',
          ).length,
          certificados_validos: organizados.CERTIFICADO.filter(
            (c) => c.status_validade === 'VALIDO',
          ).length,
        },
        itens: organizados,
      },
    });
  } catch (error) {
    Logger.error('Error listing pasta virtual:', error);
    return c.json(
      {
        success: false,
        error: 'Internal server error',
      },
      500,
    );
  }
});

app.post('/', requirePermission('funcionarios', 'CREATE'), async (c) => {
  try {
    const body = await c.req.json();
    const {
      funcionario_id,
      tipo_documento,
      nome_arquivo,
      caminho_arquivo,
      certificacao_id,
      descricao,
    } = body;
    const db = c.env.DB;

    if (!funcionario_id || !tipo_documento || !nome_arquivo || !caminho_arquivo) {
      return c.json(
        {
          success: false,
          error:
            'Campos obrigatórios: funcionario_id, tipo_documento, nome_arquivo, caminho_arquivo',
        },
        400,
      );
    }

    const funcionario = await db
      .prepare('SELECT id FROM funcionarios WHERE id = ? AND deleted_at IS NULL')
      .bind(funcionario_id)
      .first();

    if (!funcionario) {
      return c.json(
        {
          success: false,
          error: 'Funcionário não encontrado',
        },
        404,
      );
    }

    const now = new Date().toISOString();

    const result = await db
      .prepare(
        `
      INSERT INTO pasta_virtual 
      (funcionario_id, tipo_documento, nome_arquivo, caminho_arquivo, certificacao_id, descricao, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `,
      )
      .bind(
        funcionario_id,
        tipo_documento,
        nome_arquivo,
        caminho_arquivo,
        certificacao_id || null,
        descricao || null,
        now,
        now,
      )
      .run();

    await logAudit(c, 'CREATE', 'pasta_virtual', String(result.meta?.last_row_id), undefined, {
      funcionario_id,
      tipo_documento,
      nome_arquivo,
    });

    return c.json(
      {
        success: true,
        data: {
          id: result.meta?.last_row_id,
          funcionario_id,
          tipo_documento,
          nome_arquivo,
          caminho_arquivo,
          certificacao_id,
          descricao,
          created_at: now,
        },
        message: 'Documento adicionado à pasta virtual',
      },
      201,
    );
  } catch (error) {
    Logger.error('Error adding to pasta virtual:', error);
    return c.json(
      {
        success: false,
        error: 'Internal server error',
      },
      500,
    );
  }
});

app.delete('/:id', requirePermission('funcionarios', 'DELETE'), async (c) => {
  try {
    const id = parseInt(c.req.param('id'));
    const db = c.env.DB;

    if (isNaN(id)) {
      return c.json(
        {
          success: false,
          error: 'ID inválido',
        },
        400,
      );
    }

    const documento = await db
      .prepare('SELECT * FROM pasta_virtual WHERE id = ? AND deleted_at IS NULL')
      .bind(id)
      .first();

    if (!documento) {
      return c.json(
        {
          success: false,
          error: 'Documento não encontrado',
        },
        404,
      );
    }

    await db
      .prepare('UPDATE pasta_virtual SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL')
      .bind(new Date().toISOString(), id)
      .run();

    await logAudit(c, 'DELETE', 'pasta_virtual', String(id), documento);

    return c.json({
      success: true,
      message: 'Documento removido da pasta virtual',
    });
  } catch (error) {
    Logger.error('Error deleting from pasta virtual:', error);
    return c.json(
      {
        success: false,
        error: 'Internal server error',
      },
      500,
    );
  }
});

export default app;
