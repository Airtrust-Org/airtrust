/**
 * CRUD de Simuladores (CONSOLIDADO)
 * 
 * Origem: simuladores.ts (558 linhas)
 * Consolidado em: 19/10/2025
 * 
 * Funcionalidades:
 * - Listar simuladores com filtros
 * - Criar simulador
 * - Atualizar simulador
 * - Soft delete de simulador
 * - Endpoint legacy /listar
 */

import { Hono } from 'hono';
import { z } from 'zod';
import type { Env } from '../../types';

const app = new Hono<{ Bindings: Env }>();

const SimuladorSchema = z.object({
  nome: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres'),
  codigo_identificacao: z.string().optional(),
  tipo_simulador: z.enum(['FFS', 'FNPT-I', 'FNPT-II']),
  aeronave_base: z.string(),
  empresa_local: z.string().optional(),
  localizacao: z.string().optional(),
  status: z.enum(['ATIVO', 'MANUTENCAO', 'INATIVO']).default('ATIVO')
});

app.get('/', async (c) => {
  const db = c.env.DB;
  
  const tipo = c.req.query('tipo');
  const aeronave = c.req.query('aeronave');
  const status = c.req.query('status');
  const localizacao = c.req.query('localizacao');
  
  try {
    let query = 'SELECT * FROM simuladores WHERE deleted_at IS NULL';
    const params: any[] = [];
    
    if (tipo) {
      query += ' AND tipo_simulador = ?';
      params.push(tipo);
    }
    
    if (aeronave) {
      query += ' AND aeronave_base = ?';
      params.push(aeronave);
    }
    
    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }
    
    if (localizacao) {
      query += ' AND localizacao = ?';
      params.push(localizacao);
    }
    
    query += ' ORDER BY nome ASC';
    
    const { results } = await db.prepare(query).bind(...params).all();
    
    return c.json({
      success: true,
      data: results,
      total: results.length
    });
  } catch (error: any) {
    console.error('[SIMULADORES] Erro ao listar:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/listar', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT * FROM simuladores 
      WHERE deleted_at IS NULL 
      ORDER BY nome ASC
    `).all();
    
    return c.json({
      success: true,
      data: results,
      total: results.length
    });
  } catch (error: any) {
    const mockSimuladores = [
      {id: 1, nome: 'Simulador A320-001', codigo_identificacao: 'SIM-A320-001', tipo_simulador: 'FFS', aeronave_base: 'A320', empresa_local: 'CAE Training Center', status: 'ATIVO'},
      {id: 2, nome: 'Simulador B737-001', codigo_identificacao: 'SIM-B737-001', tipo_simulador: 'FFS', aeronave_base: 'B737', empresa_local: 'FlightSafety Training', status: 'ATIVO'},
      {id: 3, nome: 'Simulador B737-002', codigo_identificacao: 'SIM-B737-002', tipo_simulador: 'FNPT-II', aeronave_base: 'B737', empresa_local: 'CAE Training Center', status: 'ATIVO'},
      {id: 4, nome: 'Simulador ATR72-001', codigo_identificacao: 'SIM-ATR72-001', tipo_simulador: 'FNPT-I', aeronave_base: 'ATR72', empresa_local: 'Centro Regional', status: 'ATIVO'}
    ];
    
    return c.json({
      success: true,
      data: mockSimuladores,
      total: mockSimuladores.length,
      from_mock: true
    });
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = SimuladorSchema.parse(await c.req.json());
    
    const result = await db.prepare(`
      INSERT INTO simuladores (
        nome, codigo_identificacao, tipo_simulador,
        aeronave_base, empresa_local, localizacao, status,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `).bind(
      data.nome,
      data.codigo_identificacao || null,
      data.tipo_simulador,
      data.aeronave_base,
      data.empresa_local || null,
      data.localizacao || null,
      data.status
    ).run();
    
    const id = result.meta.last_row_id;
    
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        acao, detalhes, timestamp
      ) VALUES ('SIMULADOR_CREATED', ?, datetime('now'))
    `).bind(JSON.stringify({ simulador_id: id, data: data })).run();
    
    return c.json({
      success: true,
      id,
      message: 'Simulador criado com sucesso'
    }, 201);
    
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return c.json({
        success: false,
        error: 'Validação falhou',
        details: error.errors
      }, 400);
    }
    
    console.error('[SIMULADORES] Erro ao criar:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const data = SimuladorSchema.partial().parse(await c.req.json());
    
    const existing = await db.prepare(`
      SELECT * FROM simuladores WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!existing) {
      return c.json({
        success: false,
        error: 'Simulador não encontrado'
      }, 404);
    }
    
    const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
    const values = Object.values(data);
    
    if (fields) {
      await db.prepare(`
        UPDATE simuladores 
        SET ${fields}, updated_at = datetime('now')
        WHERE id = ?
      `).bind(...values, id).run();
    }
    
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        acao, detalhes, timestamp
      ) VALUES ('SIMULADOR_UPDATED', ?, datetime('now'))
    `).bind(JSON.stringify({ simulador_id: id, before: existing, after: data })).run();
    
    return c.json({
      success: true,
      message: 'Simulador atualizado'
    });
    
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return c.json({
        success: false,
        error: 'Validação falhou',
        details: error.errors
      }, 400);
    }
    
    console.error('[SIMULADORES] Erro ao atualizar:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const existing = await db.prepare(`
      SELECT * FROM simuladores WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!existing) {
      return c.json({
        success: false,
        error: 'Simulador não encontrado'
      }, 404);
    }
    
    await db.prepare(`
      UPDATE simuladores 
      SET deleted_at = datetime('now'), updated_at = datetime('now')
      WHERE id = ?
    `).bind(id).run();
    
    await db.prepare(`
      INSERT INTO auditoriaavancadav2 (
        acao, detalhes, timestamp
      ) VALUES ('SIMULADOR_DELETED', ?, datetime('now'))
    `).bind(JSON.stringify({ simulador_id: id, data: existing })).run();
    
    return c.json({
      success: true,
      message: 'Simulador removido'
    });
    
  } catch (error: any) {
    console.error('[SIMULADORES] Erro ao deletar:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
