/**
 * Catálogo de Manobras (CONSOLIDADO)
 * 
 * Origem: simulador-manobras-catalogo-crud.ts (361 linhas)
 * Consolidado em: 19/10/2025
 * 
 * Funcionalidades:
 * - CRUD completo de manobras
 * - Listar com fallback
 * - Importação via CSV
 * - Soft delete
 * 
 * Arquivos substituídos:
 * - simulador-manobras-catalogo.ts
 * - simulador-manobras-catalogo-crud.ts
 * - simulador-avaliacao-manobras.ts
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const categoria_id = c.req.query('categoria_id');
    const search = c.req.query('search');
    const ativo = c.req.query('ativo');
    
    let query = `
      SELECT 
        m.*,
        c.codigo as categoria_codigo,
        c.nome as categoria_nome,
        c.cor as categoria_cor
      FROM manobras m
      LEFT JOIN simulador_categorias_manobra c ON c.id = m.categoria_id
      WHERE m.deleted_at IS NULL
    `;
    
    const params: any[] = [];
    
    if (categoria_id) {
      query += ' AND m.categoria_id = ?';
      params.push(categoria_id);
    }
    
    if (search) {
      query += ' AND (m.codigo LIKE ? OR m.nome LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    
    if (ativo !== undefined) {
      query += ' AND m.ativo = ?';
      params.push(ativo === 'true' ? 1 : 0);
    }
    
    query += ' ORDER BY c.ordem ASC, m.codigo ASC';
    
    const { results } = await db.prepare(query).bind(...params).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    if (!data.codigo || !data.nome || !data.categoria_id) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: codigo, nome, categoria_id'
      }, 400);
    }
    
    const existing = await db.prepare(`
      SELECT id FROM manobras WHERE codigo = ? AND deleted_at IS NULL
    `).bind(data.codigo).first();
    
    if (existing) {
      return c.json({
        success: false,
        error: 'Código já existe'
      }, 409);
    }
    
    const result = await db.prepare(`
      INSERT INTO manobras (
        codigo, nome, descricao, categoria_id, referencia_qrh,
        pontuacao_minima, criterios_avaliacao, observacoes, ativo
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.codigo,
      data.nome,
      data.descricao || null,
      data.categoria_id,
      data.referencia_qrh || null,
      data.pontuacao_minima || 5,
      data.criterios_avaliacao || null,
      data.observacoes || null,
      data.ativo !== undefined ? data.ativo : 1
    ).run();
    
    return c.json({
      success: true,
      id: result.meta.last_row_id,
      message: 'Manobra criada com sucesso'
    }, 201);
    
  } catch (error: any) {
    console.error('Erro ao criar manobra:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const { manobra_id_codigo, nome_manobra, descricao_detalhada, referencia_qrh, ativo } = await c.req.json();
    const db = c.env.DB;

    try {
      const result = await db.prepare(`
        UPDATE manobras 
        SET codigo = ?, nome = ?, descricao = ?, referencia_qrh = ?, ativo = ?, updated_at = datetime('now')
        WHERE id = ?
      `).bind(
        manobra_id_codigo,
        nome_manobra,
        descricao_detalhada || null,
        referencia_qrh || null,
        ativo !== false ? 1 : 0,
        id
      ).run();

      if (result.meta.changes === 0) {
        return c.json({ error: 'Manobra não encontrada' }, 404);
      }

      return c.json({
        success: true,
        data: {
          id: parseInt(id),
          manobra_id_codigo,
          nome_manobra,
          descricao_detalhada,
          referencia_qrh,
          ativo: ativo !== false
        },
        message: 'Manobra atualizada com sucesso'
      });

    } catch (dbError) {
      console.error('Erro no banco ao atualizar manobra:', dbError);
      return c.json({ error: 'Erro ao atualizar manobra no banco de dados' }, 500);
    }
  } catch (error) {
    console.error('Erro ao atualizar manobra:', error);
    return c.json({ error: 'Erro interno do servidor' }, 500);
  }
});

app.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    
    
    if (!id || isNaN(Number(id))) {
      return c.json({ 
        success: false,
        error: 'ID da manobra é obrigatório e deve ser um número' 
      }, 400);
    }

    const db = c.env.DB;

    try {
      const manobraExistente = await db.prepare(
        'SELECT id, nome FROM manobras WHERE id = ? AND (deleted_at IS NULL OR deleted_at = "")'
      ).bind(id).first();


      if (!manobraExistente) {
        return c.json({ 
          success: false,
          error: `Manobra com ID ${id} não encontrada ou já foi removida`
        }, 404);
      }

      const result = await db.prepare(`
        UPDATE manobras 
        SET deleted_at = datetime('now'), 
            updated_at = datetime('now')
        WHERE id = ?
      `).bind(id).run();


      if (!result.success || result.meta?.changes === 0) {
        return c.json({ 
          success: false,
          error: 'Falha ao remover manobra - nenhuma linha afetada'
        }, 500);
      }


      c.header('Content-Type', 'application/json');
      
      return c.json({
        success: true,
        message: `Manobra "${manobraExistente.nome}" removida com sucesso`,
        id: Number(id),
        timestamp: new Date().toISOString()
      });

    } catch (dbError) {
      console.error('❌ Erro no banco ao excluir manobra:', dbError);
      
      c.header('Content-Type', 'application/json');
      
      return c.json({ 
        success: false,
        error: 'Erro ao excluir manobra no banco de dados',
        details: dbError instanceof Error ? dbError.message : 'Erro desconhecido',
        timestamp: new Date().toISOString()
      }, 500);
    }
  } catch (error) {
    console.error('❌ Erro geral ao excluir manobra:', error);
    
    c.header('Content-Type', 'application/json');
    
    return c.json({ 
      success: false,
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      timestamp: new Date().toISOString()
    }, 500);
  }
});

app.get('/listar', async (c) => {
  try {
    const db = c.env.DB;
    
    let manobrasFormatadas: any[] = [];
    
    try {
      const manobras = await db.prepare(`
        SELECT 
          id,
          codigo,
          nome,
          descricao,
          categoria,
          nivel_dificuldade,
          duracao_estimada,
          pontuacao_minima,
          ordem,
          created_at
        FROM manobras
        WHERE deleted_at IS NULL
        ORDER BY ordem ASC, nome ASC
      `).all();
      
      manobrasFormatadas = (manobras.results || []).map((manobra: any) => ({
        id: manobra.id,
        codigo: manobra.codigo,
        nome: manobra.nome,
        descricao: manobra.descricao,
        categoria: manobra.categoria || 'NORMAL',
        nivel_dificuldade: manobra.nivel_dificuldade || 'BASICO',
        duracao_estimada: manobra.duracao_estimada || 30,
        pontuacao_minima: manobra.pontuacao_minima || 70.0,
        ordem: manobra.ordem || 1,
        created_at: manobra.created_at
      }));
    } catch (dbError) {
    }
    
    if (manobrasFormatadas.length === 0) {
      manobrasFormatadas = [
        {id: 1, manobra_id_codigo: 'MAN-001', nome_manobra: 'Decolagem Normal', descricao_detalhada: 'Decolagem em condições normais', referencia_qrh: 'QRH 2.1.1', ativo: true},
        {id: 2, manobra_id_codigo: 'MAN-002', nome_manobra: 'Aproximação ILS', descricao_detalhada: 'Aproximação por instrumentos ILS', referencia_qrh: 'QRH 3.2.5', ativo: true},
        {id: 3, manobra_id_codigo: 'MAN-003', nome_manobra: 'Pouso Manual', descricao_detalhada: 'Pouso manual sem piloto automático', referencia_qrh: 'QRH 4.1.2', ativo: true},
        {id: 4, manobra_id_codigo: 'MAN-004', nome_manobra: 'Emergência - Falha Motor', descricao_detalhada: 'Procedimento de falha de motor', referencia_qrh: 'QRH 5.3.1', ativo: true},
        {id: 5, manobra_id_codigo: 'MAN-005', nome_manobra: 'Go Around', descricao_detalhada: 'Procedimento de arremetida', referencia_qrh: 'QRH 4.2.3', ativo: true}
      ];
    }
    
    return c.json({
      success: true,
      data: manobrasFormatadas,
      total: manobrasFormatadas.length,
      from_fallback: manobrasFormatadas.length <= 5,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ Erro ao buscar catálogo de manobras:', error);
    return c.json({ 
      success: false,
      data: [],
      error: 'Erro ao buscar catálogo',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      from_fallback: true
    }, 500);
  }
});

app.post('/import', async (c) => {
  const db = c.env.DB;
  
  try {
    const body = await c.req.json();
    const manobras = body.manobras;
    
    if (!Array.isArray(manobras) || manobras.length === 0) {
      return c.json({
        success: false,
        error: 'Nenhuma manobra enviada ou formato inválido'
      }, 400);
    }


    let importadas = 0;
    const erros: string[] = [];

    for (let i = 0; i < manobras.length; i++) {
      const manobra = manobras[i];
      
      if (!manobra.codigo || !manobra.nome || !manobra.categoria_id) {
        erros.push(`Linha ${i + 2}: Campos obrigatórios faltando (codigo, nome, categoria_id)`);
        continue;
      }

      try {
        await db.prepare(`
          INSERT INTO manobras (
            codigo, nome, descricao, categoria_id, pontuacao_minima,
            referencia_qrh, criterios_avaliacao, observacoes, ativo
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          manobra.codigo,
          manobra.nome,
          manobra.descricao || '',
          parseInt(manobra.categoria_id) || 6,
          parseInt(manobra.pontuacao_minima) || 5,
          manobra.referencia_qrh || '',
          manobra.criterios_avaliacao || '',
          manobra.observacoes || '',
          parseInt(manobra.ativo) !== undefined ? parseInt(manobra.ativo) : 1
        ).run();

        importadas++;
      } catch (error: any) {
        if (error.message.includes('UNIQUE')) {
          erros.push(`Linha ${i + 2}: Código ${manobra.codigo} já existe`);
        } else {
          erros.push(`Linha ${i + 2}: ${error.message}`);
        }
      }
    }


    return c.json({
      success: true,
      importadas,
      total: manobras.length,
      erros
    });

  } catch (error: any) {
    console.error('[IMPORT MANOBRAS] ❌ Erro:', error);
    return c.json({
      success: false,
      error: error.message || 'Erro ao importar manobras'
    }, 500);
  }
});

export default app;
