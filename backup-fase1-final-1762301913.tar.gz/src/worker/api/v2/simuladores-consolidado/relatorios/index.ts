/**
 * Relatórios - DADOS REAIS
 * Agregações SQL de múltiplas tabelas
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.get('/uso', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        s.id,
        s.nome,
        s.tipo,
        COUNT(a.id) as total_agendamentos,
        SUM(CASE WHEN a.status = 'CONCLUIDO' THEN 1 ELSE 0 END) as concluidos,
        SUM(CASE WHEN a.status = 'AGENDADO' THEN 1 ELSE 0 END) as agendados
      FROM simuladores s
      LEFT JOIN agendamentos_simulador a ON a.simulador_id = s.id AND a.deleted_at IS NULL
      WHERE s.deleted_at IS NULL
      GROUP BY s.id
      ORDER BY total_agendamentos DESC
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length,
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao gerar relatório:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/estatisticas', async (c) => {
  const db = c.env.DB;
  
  try {
    const stats = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM simuladores WHERE deleted_at IS NULL) as total_simuladores,
        (SELECT COUNT(*) FROM agendamentos_simulador WHERE deleted_at IS NULL) as total_agendamentos,
        (SELECT COUNT(*) FROM simulador_fichas WHERE deleted_at IS NULL) as total_fichas,
        (SELECT COUNT(*) FROM manobras WHERE deleted_at IS NULL) as total_manobras
    `).first();
    
    return c.json({
      success: true,
      data: stats,
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao gerar estatísticas:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
