/**
 * Progresso do Colaborador (CONSOLIDADO)
 * 
 * Origem: simulador-progresso-fixed.ts (153 linhas)
 * Consolidado em: 19/10/2025
 * 
 * Funcionalidades:
 * - Progresso específico por treinamento
 * - Progresso geral do colaborador
 * - Estatísticas e histórico
 * - Status do endpoint
 * 
 * Arquivos substituídos:
 * - simulador-progresso.ts
 * - simulador-progresso-fixed.ts
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', async (c, next) => {
  await next();
});

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        p.*,
        f.nome as colaborador_nome
      FROM simulador_progresso p
      LEFT JOIN funcionarios f ON f.id = p.colaborador_id
      WHERE p.deleted_at IS NULL
      ORDER BY p.updated_at DESC
      LIMIT 50
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/:colaborador/:treinamento', async (c) => {
  try {
    
    const { colaborador, treinamento } = c.req.param();
    
    const db = c.env.DB;
    
    const progresso = await db.prepare(`
      SELECT 
        p.*,
        f.nome as colaborador_nome,
        f.matricula as colaborador_matricula
      FROM simulador_progresso p
      LEFT JOIN funcionarios f ON p.colaborador_id = f.id
      WHERE p.colaborador_id = ? AND p.treinamento_id = ?
    `).bind(colaborador, treinamento).first();
    
    if (!progresso) {
      return c.json({
        success: false,
        error: 'Progresso não encontrado',
        colaborador_id: colaborador,
        treinamento_id: treinamento
      }, 404);
    }
    
    const progressoMock = {
      colaborador: {
        id: progresso.colaborador_id,
        nome: progresso.colaborador_nome || `Colaborador ${colaborador}`,
        matricula: progresso.colaborador_matricula || `0000${colaborador}`
      },
      treinamento: {
        id: progresso.treinamento_id,
        codigo: `TREIN-${progresso.treinamento_id}`,
        nome: `Treinamento ${progresso.treinamento_id}`
      },
      estatisticas: {
        total_sessoes: progresso.total_sessoes || 0,
        sessoes_aprovadas: progresso.sessoes_aprovadas || 0,
        sessoes_reprovadas: progresso.sessoes_reprovadas || 0,
        sessoes_concluidas: progresso.sessoes_concluidas || 0,
        percentual_conclusao: progresso.sessoes_concluidas > 0 ? Math.round((progresso.sessoes_concluidas / progresso.total_sessoes) * 100) : 0,
        percentual_aprovacao: progresso.sessoes_concluidas > 0 ? Math.round((progresso.sessoes_aprovadas / progresso.sessoes_concluidas) * 100) : 0
      },
      ultimas_sessoes: []
    };
    
    
    return c.json({
      success: true,
      progresso: progressoMock,
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'progresso-especifico-consolidado',
        version: '2.0',
        db_available: !!db,
        mock: true
      }
    });
    
  } catch (error) {
    console.error('❌ [PROGRESSO] ERRO CAPTURADO:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack?.substring(0, 200) : 'N/A',
      name: error instanceof Error ? error.name : 'Unknown'
    });
    
    return c.json({
      error: 'Erro ao buscar progresso',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'progresso-especifico-consolidado',
      timestamp: new Date().toISOString(),
      debug: {
        error_type: error instanceof Error ? error.constructor.name : 'Unknown',
        path: c.req.path,
        method: c.req.method
      }
    }, 500);
  }
});

app.get('/:colaborador', async (c) => {
  try {
    
    const { colaborador } = c.req.param();
    const db = c.env.DB;
    
    const progresso = await db.prepare(`
      SELECT 
        colaborador_id,
        SUM(total_sessoes) as total_fichas,
        SUM(sessoes_aprovadas) as fichas_aprovadas,
        SUM(sessoes_reprovadas) as fichas_reprovadas,
        SUM(sessoes_concluidas) as fichas_concluidas,
        AVG(media_notas) as media_notas
      FROM simulador_progresso
      WHERE colaborador_id = ?
      GROUP BY colaborador_id
    `).bind(colaborador).first();
    
    const progressoGeral = progresso || {
      colaborador_id: colaborador,
      total_fichas: 0,
      fichas_aprovadas: 0,
      fichas_reprovadas: 0,
      fichas_concluidas: 0,
      media_notas: 0
    };
    
    return c.json({
      success: true,
      progresso_geral: progressoGeral,
      debug: {
        endpoint: 'progresso-geral-consolidado',
        mock: true,
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    console.error('❌ [PROGRESSO] Erro ao buscar progresso geral:', error);
    return c.json({ 
      error: 'Erro ao buscar progresso geral',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'progresso-geral-consolidado'
    }, 500);
  }
});

app.get('/status', async (c) => {
  return c.json({
    success: true,
    endpoint: 'simulador-progresso-consolidado',
    version: '2.0',
    status: 'OPERACIONAL',
    timestamp: new Date().toISOString(),
    features: [
      'GET /:colaborador/:treinamento - Progresso específico',
      'GET /:colaborador - Progresso geral',
      'GET /status - Status do endpoint'
    ]
  });
});

export default app;
