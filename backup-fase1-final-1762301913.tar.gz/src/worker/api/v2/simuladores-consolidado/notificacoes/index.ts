/**
 * Notificações (CONSOLIDADO)
 * 
 * Origem: simulador-notificacoes-fixed.ts (159 linhas)
 * Consolidado em: 19/10/2025
 * 
 * Funcionalidades:
 * - Listar notificações por usuário
 * - Marcar notificação como lida
 * - Status do endpoint
 * - Dados mock para demonstração
 * 
 * Arquivos substituídos:
 * - simulador-notificacoes.ts
 * - simulador-notificacoes-fixed.ts
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.use('*', async (c, next) => {
  await next();
});

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT * FROM simulador_notificacoes 
      WHERE deleted_at IS NULL 
      ORDER BY created_at DESC 
      LIMIT 50
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/:usuario', async (c) => {
  try {
    
    const { usuario } = c.req.param();
    
    const db = c.env.DB;
    
    if (!db) {
      return c.json({ error: 'Database não disponível' }, 500);
    }
    
    try {
      const teste = await db.prepare('SELECT 1 as teste').first();
    } catch (dbError) {
      return c.json({ 
        error: 'Erro de conectividade com banco',
        details: dbError instanceof Error ? dbError.message : 'Erro desconhecido'
      }, 500);
    }
    
    const { results } = await db.prepare(`
      SELECT 
        id, usuario_id, tipo, titulo, mensagem,
        lida, data_leitura, prioridade, created_at
      FROM simulador_notificacoes
      WHERE usuario_id = ?
      ORDER BY created_at DESC
      LIMIT 50
    `).bind(usuario).all();
    
    const notificacoes = results || [];
    
    
    const resposta = {
      success: true,
      notificacoes: notificacoes,
      total: notificacoes.length,
      nao_lidas: notificacoes.filter(n => !n.lida).length,
      usuario_id: usuario,
      timestamp: new Date().toISOString(),
      debug: {
        endpoint: 'notificacoes-consolidado',
        version: '2.0',
        db_available: !!db
      }
    };
    
    return c.json(resposta);
    
  } catch (error) {
    console.error('❌ [NOTIFICACOES] ERRO CAPTURADO:', {
      message: error instanceof Error ? error.message : 'Erro desconhecido',
      stack: error instanceof Error ? error.stack?.substring(0, 200) : 'N/A',
      name: error instanceof Error ? error.name : 'Unknown'
    });
    
    return c.json({
      error: 'Erro interno do servidor',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'notificacoes-consolidado',
      timestamp: new Date().toISOString(),
      debug: {
        error_type: error instanceof Error ? error.constructor.name : 'Unknown',
        path: c.req.path,
        method: c.req.method
      }
    }, 500);
  }
});

app.post('/:usuario/marcar-lida/:notificacao_id', async (c) => {
  try {
    
    const { usuario, notificacao_id } = c.req.param();
    const db = c.env.DB;
    
    const result = await db.prepare(`
      UPDATE simulador_notificacoes
      SET lida = 1, data_leitura = datetime('now')
      WHERE id = ? AND usuario_id = ?
    `).bind(notificacao_id, usuario).run();
    
    if (result.meta.changes === 0) {
      return c.json({ error: 'Notificação não encontrada' }, 404);
    }
    
    return c.json({
      success: true,
      message: 'Notificação marcada como lida',
      notificacao_id: notificacao_id,
      usuario_id: usuario,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('❌ [NOTIFICACOES] Erro ao marcar notificação:', error);
    return c.json({ 
      error: 'Erro ao marcar notificação',
      details: error instanceof Error ? error.message : 'Erro desconhecido',
      endpoint: 'marcar-lida-consolidado'
    }, 500);
  }
});

app.get('/status', async (c) => {
  return c.json({
    success: true,
    endpoint: 'simulador-notificacoes-consolidado',
    version: '2.0',
    status: 'OPERACIONAL',
    timestamp: new Date().toISOString(),
    features: [
      'GET /:usuario - Listar notificações',
      'POST /:usuario/marcar-lida/:id - Marcar como lida', 
      'GET /status - Status do endpoint'
    ]
  });
});

export default app;
