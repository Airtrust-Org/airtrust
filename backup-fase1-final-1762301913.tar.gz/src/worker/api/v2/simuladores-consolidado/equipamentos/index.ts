/**
 * Equipamentos - DADOS REAIS
 * Usa tabela simuladores
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        id,
        nome,
        modelo,
        tipo,
        fabricante,
        localizacao,
        capacidade,
        status,
        observacoes,
        created_at,
        updated_at
      FROM simuladores
      WHERE deleted_at IS NULL
      ORDER BY nome ASC
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length,
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao listar equipamentos:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const equipamento = await db.prepare(`
      SELECT * FROM simuladores
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!equipamento) {
      return c.json({
        success: false,
        error: 'Equipamento não encontrado'
      }, 404);
    }
    
    const { results: historico } = await db.prepare(`
      SELECT 
        a.id,
        a.data_agendamento as data,
        a.hora_inicio,
        a.hora_fim,
        a.tipo_sessao,
        a.status,
        i.nome as instrutor_nome
      FROM agendamentos_simulador a
      LEFT JOIN funcionarios i ON i.id = a.instrutor_id
      WHERE a.simulador_id = ? AND a.deleted_at IS NULL
      ORDER BY a.data_agendamento DESC, a.hora_inicio DESC
      LIMIT 10
    `).bind(id).all();
    
    return c.json({
      success: true,
      data: {
        ...equipamento,
        historico: historico || []
      },
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao buscar equipamento:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
