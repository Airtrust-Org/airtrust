/**
 * Templates de Sessão (COMPLETO)
 * 
 * Criado em: 19/10/2025
 * 
 * Funcionalidades:
 * - CRUD completo de templates
 * - Configurar manobras do template
 * - Listar manobras disponíveis por categoria
 * - Validação e duplicatas
 */

import { Hono } from 'hono';
import type { Env } from '../../../types';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results: templates } = await db.prepare(`
      SELECT * FROM sessoes_template
      WHERE deleted_at IS NULL
      ORDER BY nome ASC
    `).all();
    
    for (const template of (templates || [])) {
      const { results: manobras } = await db.prepare(`
        SELECT 
          tm.id as relacao_id,
          tm.obrigatoria,
          tm.ordem,
          m.id as manobra_id,
          m.codigo as manobra_codigo,
          m.nome as manobra_nome,
          m.categoria as categoria_nome
        FROM modelo_sessao_manobras tm
        INNER JOIN manobras m ON m.id = tm.manobra_id
        WHERE tm.modelo_id = ? AND tm.deleted_at IS NULL AND m.deleted_at IS NULL
        ORDER BY tm.ordem ASC, m.codigo ASC
      `).bind(template.id).all();
      
      template.manobras = manobras || [];
      template.total_manobras = (manobras || []).length;
    }
    
    return c.json({
      success: true,
      data: templates || [],
      total: (templates || []).length
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message,
      data: []
    }, 500);
  }
});

app.get('/manobras-disponiveis', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results: categorias } = await db.prepare(`
      SELECT * FROM simulador_categorias_manobra
      WHERE deleted_at IS NULL AND ativo = 1
      ORDER BY ordem ASC
    `).all();
    
    for (const categoria of (categorias || [])) {
      const { results: manobras } = await db.prepare(`
        SELECT 
          id as manobra_id,
          codigo,
          nome,
          pontuacao_minima
        FROM manobras
        WHERE categoria_id = ? AND deleted_at IS NULL AND ativo = 1
        ORDER BY codigo ASC
      `).bind(categoria.id).all();
      
      categoria.manobras = manobras || [];
      categoria.total = (manobras || []).length;
    }
    
    return c.json({
      success: true,
      data: categorias || []
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const template = await db.prepare(`
      SELECT * FROM simulador_templates
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!template) {
      return c.json({
        success: false,
        error: 'Template não encontrado'
      }, 404);
    }
    
    const { results: manobras } = await db.prepare(`
      SELECT 
        tm.id as relacao_id,
        tm.obrigatoria,
        tm.pontuacao_minima,
        tm.ordem,
        m.id as manobra_id,
        m.codigo as manobra_codigo,
        m.nome as manobra_nome,
        m.categoria_id,
        c.nome as categoria_nome,
        c.cor as categoria_cor
      FROM simulador_template_manobras tm
      INNER JOIN manobras m ON m.id = tm.manobra_id
      LEFT JOIN simulador_categorias_manobra c ON c.id = m.categoria_id
      WHERE tm.template_id = ? AND m.deleted_at IS NULL
      ORDER BY tm.ordem ASC, c.ordem ASC, m.codigo ASC
    `).bind(id).all();
    
    template.manobras = manobras || [];
    
    return c.json({
      success: true,
      data: template
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    if (!data.nome || !data.duracao_horas || !data.tipo) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: nome, duracao_horas, tipo'
      }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO simulador_templates (
        codigo, nome, duracao_horas, tipo, descricao, pontuacao_minima, ativo
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.codigo || null,
      data.nome,
      data.duracao_horas,
      data.tipo,
      data.descricao || null,
      data.pontuacao_minima || 5,
      data.ativo !== undefined ? data.ativo : 1
    ).run();
    
    return c.json({
      success: true,
      id: result.meta.last_row_id,
      message: 'Template criado com sucesso'
    }, 201);
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const data = await c.req.json();
    
    await db.prepare(`
      UPDATE simulador_templates
      SET codigo = COALESCE(?, codigo),
          nome = COALESCE(?, nome),
          duracao_horas = COALESCE(?, duracao_horas),
          tipo = COALESCE(?, tipo),
          descricao = COALESCE(?, descricao),
          pontuacao_minima = COALESCE(?, pontuacao_minima),
          ativo = COALESCE(?, ativo),
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      data.codigo || null,
      data.nome || null,
      data.duracao_horas || null,
      data.tipo || null,
      data.descricao || null,
      data.pontuacao_minima || null,
      data.ativo !== undefined ? data.ativo : null,
      id
    ).run();
    
    return c.json({
      success: true,
      message: 'Template atualizado com sucesso'
    });
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    await db.prepare(`
      UPDATE simulador_templates
      SET deleted_at = datetime('now')
      WHERE id = ?
    `).bind(id).run();
    
    return c.json({
      success: true,
      message: 'Template removido com sucesso'
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.post('/:id/manobras', async (c) => {
  const db = c.env.DB;
  const templateId = c.req.param('id');
  
  try {
    const body = await c.req.json();
    const manobras = body.manobras; // Array de { manobra_id, obrigatoria, pontuacao_minima, ordem }
    
    if (!Array.isArray(manobras)) {
      return c.json({
        success: false,
        error: 'manobras deve ser um array'
      }, 400);
    }
    
    await db.prepare(`
      DELETE FROM simulador_template_manobras WHERE template_id = ?
    `).bind(templateId).run();
    
    for (let i = 0; i < manobras.length; i++) {
      const m = manobras[i];
      await db.prepare(`
        INSERT INTO simulador_template_manobras (
          template_id, manobra_id, obrigatoria, pontuacao_minima, ordem
        ) VALUES (?, ?, ?, ?, ?)
      `).bind(
        templateId,
        m.manobra_id,
        m.obrigatoria !== undefined ? m.obrigatoria : 1,
        m.pontuacao_minima || 5,
        m.ordem !== undefined ? m.ordem : i
      ).run();
    }
    
    return c.json({
      success: true,
      message: 'Manobras configuradas com sucesso',
      total: manobras.length
    });
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
