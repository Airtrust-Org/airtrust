/**
 * Router Principal - Módulo Simuladores (CONSOLIDADO)
 * Consolidado em: 19/10/2025
 * 
 * Estrutura:
 * - /                      CRUD de simuladores
 * - /agendamentos          Agendamentos e slots
 * - /sessoes               Sessões de treinamento
 * - /fichas                Fichas de avaliação
 * - /templates-sessao      Templates de sessão
 * - /manobras              Catálogo de manobras
 * - /equipamentos          Gestão de equipamentos
 * - /relatorios            Relatórios e estatísticas
 * 
 * Redução: 50 arquivos → 15 arquivos (70% menos duplicação)
 */

import { Hono } from 'hono';
import type { Env } from '../../types';

import crud from './crud';
import agendamentos from './agendamentos';
import fichas from './fichas';
import templates from './templates';
import manobras from './manobras';
import sessoes from './sessoes';
import notificacoes from './notificacoes';
import progresso from './progresso';
import relatorios from './relatorios';
import equipamentos from './equipamentos';
import categorias from './categorias';

const app = new Hono<{ Bindings: Env }>();

app.route('/', crud);                           // ✅ GET /, POST /, PUT /:id, DELETE /:id
app.route('/agendamentos', agendamentos);       // ✅ CRUD + disponibilidade
app.route('/fichas', fichas);                   // ✅ CRUD + avaliação + assinatura
app.route('/templates-sessao', templates);      // ✅ CRUD + fallback + health check
app.route('/templates', templates);             // ✅ Alias para templates-sessao
app.route('/manobras', manobras);               // ✅ CRUD + import CSV + fallback
app.route('/categorias', categorias);           // ✅ CRUD de categorias de manobras
app.route('/sessoes', sessoes);                 // ✅ Listar + estatísticas + mock
app.route('/notificacoes', notificacoes);       // ✅ Listar + marcar lida + mock
app.route('/progresso', progresso);             // ✅ Geral + específico + mock
app.route('/relatorios', relatorios);           // ✅ Uso + estatísticas + PDF placeholder
app.route('/equipamentos', equipamentos);       // ✅ CRUD + manutenção + histórico

export default app;
