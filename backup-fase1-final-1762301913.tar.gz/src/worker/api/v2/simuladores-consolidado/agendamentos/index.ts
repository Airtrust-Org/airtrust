/**
 * Agendamentos de Simulador - DADOS REAIS
 * Migrado para usar agendamentos_simulador
 */

import { Hono } from 'hono';

interface Env {
  DB: any;
}

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const result = await db.prepare(`
      SELECT 
        a.id, a.simulador_id, a.instrutor_id, a.funcionario_id,
        a.data_agendamento as data,
        a.hora_inicio, a.hora_fim, a.tipo_sessao, a.status,
        a.observacoes, a.resultado, a.nota,
        s.nome as simulador_nome,
        f.nome as instrutor_nome,
        func.nome as funcionario_nome
      FROM agendamentos_simulador a
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      LEFT JOIN funcionarios f ON a.instrutor_id = f.id
      LEFT JOIN funcionarios func ON a.funcionario_id = func.id
      WHERE a.deleted_at IS NULL
      ORDER BY a.data_agendamento DESC, a.hora_inicio DESC
      LIMIT 100
    `).all();
    
    return c.json({
      success: true,
      data: result.results || [],
      total: result.results?.length || 0
    });
    
  } catch (error: any) {
    console.error('Erro ao listar agendamentos:', error);
    return c.json({
      success: false,
      error: error.message,
      data: []
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    if (!data.simulador_id || !data.data || !data.hora_inicio || !data.hora_fim) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: simulador_id, data, hora_inicio, hora_fim'
      }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO agendamentos_simulador (
        simulador_id, data, hora_inicio, hora_fim,
        tipo_sessao, instrutor_id, template_id,
        status, observacoes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'AGENDADO', ?, datetime('now'), datetime('now'))
    `).bind(
      data.simulador_id,
      data.data,
      data.hora_inicio,
      data.hora_fim,
      data.tipo_sessao || 'PC',
      data.instrutor_id || null,
      data.template_id || null,
      data.observacoes || null
    ).run();
    
    const agendamentoId = result.meta.last_row_id;
    
    if (data.participantes && Array.isArray(data.participantes)) {
      for (const participanteId of data.participantes) {
        await db.prepare(`
          INSERT INTO simulador_agendamento_participantes (
            agendamento_id, colaborador_id
          ) VALUES (?, ?)
        `).bind(agendamentoId, participanteId).run();
      }
    }
    
    return c.json({
      success: true,
      agendamento_id: agendamentoId,
      message: 'Agendamento criado com sucesso'
    }, 201);
    
  } catch (error: any) {
    console.error('Erro ao criar agendamento:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const data = await c.req.json();
    
    const result = await db.prepare(`
      UPDATE agendamentos_simulador
      SET 
        simulador_id = COALESCE(?, simulador_id),
        data = COALESCE(?, data),
        hora_inicio = COALESCE(?, hora_inicio),
        hora_fim = COALESCE(?, hora_fim),
        tipo_sessao = COALESCE(?, tipo_sessao),
        status = COALESCE(?, status),
        observacoes = COALESCE(?, observacoes),
        updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `).bind(
      data.simulador_id || null,
      data.data || null,
      data.hora_inicio || null,
      data.hora_fim || null,
      data.tipo_sessao || null,
      data.status || null,
      data.observacoes || null,
      id
    ).run();
    
    if (result.meta.changes === 0) {
      return c.json({
        success: false,
        error: 'Agendamento não encontrado'
      }, 404);
    }
    
    if (data.participantes && Array.isArray(data.participantes)) {
      await db.prepare(`
        DELETE FROM simulador_agendamento_participantes 
        WHERE agendamento_id = ?
      `).bind(id).run();
      
      for (const pId of data.participantes) {
        await db.prepare(`
          INSERT INTO simulador_agendamento_participantes (
            agendamento_id, colaborador_id
          ) VALUES (?, ?)
        `).bind(id, pId).run();
      }
    }
    
    return c.json({
      success: true,
      message: 'Agendamento atualizado com sucesso'
    });
    
  } catch (error: any) {
    console.error('Erro ao atualizar agendamento:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const result = await db.prepare(`
      UPDATE agendamentos_simulador
      SET deleted_at = datetime('now'), updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).run();
    
    if (result.meta.changes === 0) {
      return c.json({
        success: false,
        error: 'Agendamento não encontrado'
      }, 404);
    }
    
    return c.json({
      success: true,
      message: 'Agendamento removido com sucesso'
    });
    
  } catch (error: any) {
    console.error('Erro ao remover agendamento:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
