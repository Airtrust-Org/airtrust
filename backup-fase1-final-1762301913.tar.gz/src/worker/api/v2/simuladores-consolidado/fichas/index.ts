/**
 * Fichas de Avaliação - DADOS REAIS
 * Migrado para usar simulador_fichas
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

function gerarUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    
    const { results } = await db.prepare(`
      SELECT 
        f.id,
        f.uuid as ficha_uuid,
        f.agendamento_slot_id,
        f.colaborador_id_aluno,
        f.funcao_na_sessao as tipo_sessao,
        f.template_id,
        f.instrutor_id,
        f.status,
        f.nota,
        f.aprovado,
        f.created_at,
        aluno.nome as colaborador_nome,
        aluno.matricula as colaborador_matricula,
        instrutor.nome as instrutor_nome,
        a.data_agendamento as data_sessao,
        a.hora_inicio,
        a.hora_fim,
        s.nome as simulador_nome
      FROM fichas_sessao f
      LEFT JOIN funcionarios aluno ON f.colaborador_id_aluno = aluno.id
      LEFT JOIN funcionarios instrutor ON f.instrutor_id = instrutor.id
      LEFT JOIN agendamentos_simulador a ON f.agendamento_slot_id = a.id
      LEFT JOIN simuladores s ON a.simulador_id = s.id
      WHERE f.deleted_at IS NULL
      ORDER BY f.created_at DESC
      LIMIT 100
    `).all();
    
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
    
  } catch (error: any) {
    console.error('[FICHAS] Erro ao buscar fichas:', error);
    return c.json({
      success: false,
      error: error.message,
      data: [],
      total: 0
    }, 500);
  }
});

app.get('/old', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        f.*,
        a.data_agendamento as data_sessao,
        i.nome as instrutor_nome,
        c.nome as colaborador_nome,
        s.nome as simulador_nome
      FROM simulador_fichas f
      LEFT JOIN agendamentos_simulador a ON a.id = f.agendamento_id
      LEFT JOIN funcionarios i ON i.id = f.instrutor_id
      LEFT JOIN funcionarios c ON c.id = f.colaborador_id
      LEFT JOIN simuladores s ON s.id = a.simulador_id
      WHERE f.deleted_at IS NULL
      ORDER BY f.created_at DESC
      LIMIT 50
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length,
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao listar fichas:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

const mockFichas: Record<string, any> = {
  'abc-123': {
    id: 1,
    uuid: 'abc-123',
    agendamento_id: 1,
    colaborador_id: 1,
    colaborador_nome: 'Piloto Fernando',
    colaborador_matricula: 'FUN-001',
    instrutor_id: 3,
    instrutor_nome: 'Carlos Instrutor',
    simulador_nome: 'Simulador A320',
    data_sessao: '2025-10-30',
    hora_inicio: '08:00',
    hora_fim: '10:00',
    tipo_sessao: 'PC',
    status: 'CONCLUIDA',
    observacoes_gerais: 'Sessão realizada com sucesso',
    created_at: '2025-10-30T08:00:00Z'
  },
  'def-456': {
    id: 2,
    uuid: 'def-456',
    agendamento_id: 2,
    colaborador_id: 2,
    colaborador_nome: 'Adriana Brasil',
    colaborador_matricula: 'FUN-002',
    instrutor_id: 3,
    instrutor_nome: 'Carlos Instrutor',
    simulador_nome: 'Simulador A320',
    data_sessao: '2025-11-29',
    hora_inicio: '14:00',
    hora_fim: '16:00',
    tipo_sessao: 'OPC',
    status: 'PENDENTE',
    observacoes_gerais: null,
    created_at: '2025-11-29T14:00:00Z'
  }
};

app.get('/:uuid', async (c) => {
  const uuid = c.req.param('uuid');
  
  try {
    
    const ficha = mockFichas[uuid];
    
    if (!ficha) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    
    return c.json({
      success: true,
      data: ficha
    });
  } catch (error: any) {
    console.error('❌ Erro ao buscar ficha:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar ficha',
      details: error.message
    }, 500);
  }
});

app.delete('/:uuid', async (c) => {
  const uuid = c.req.param('uuid');
  
  try {
    
    if (!mockFichas[uuid]) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    delete mockFichas[uuid];
    
    
    return c.json({
      success: true,
      message: 'Ficha excluída com sucesso'
    });
  } catch (error: any) {
    console.error('❌ Erro ao excluir ficha:', error);
    return c.json({
      success: false,
      error: 'Erro ao excluir ficha',
      details: error.message
    }, 500);
  }
});

app.put('/:uuid', async (c) => {
  const uuid = c.req.param('uuid');
  
  try {
    const data = await c.req.json();
    
    
    if (!mockFichas[uuid]) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    mockFichas[uuid] = {
      ...mockFichas[uuid],
      ...data,
      uuid // Manter UUID
    };
    
    
    return c.json({
      success: true,
      message: 'Ficha atualizada com sucesso',
      data: mockFichas[uuid]
    });
  } catch (error: any) {
    console.error('❌ Erro ao atualizar ficha:', error);
    return c.json({
      success: false,
      error: 'Erro ao atualizar ficha',
      details: error.message
    }, 500);
  }
});

app.get('/:uuid/old', async (c) => {
  const db = c.env.DB;
  const uuid = c.req.param('uuid');
  
  try {
    const ficha = await db.prepare(`
      SELECT 
        f.*,
        a.data_agendamento as data_sessao,
        a.hora_inicio,
        a.hora_fim,
        a.tipo_sessao,
        i.nome as instrutor_nome,
        c.nome as colaborador_nome,
        c.matricula as colaborador_matricula,
        s.nome as simulador_nome
      FROM simulador_fichas f
      LEFT JOIN agendamentos_simulador a ON a.id = f.agendamento_id
      LEFT JOIN funcionarios i ON i.id = f.instrutor_id
      LEFT JOIN funcionarios c ON c.id = f.colaborador_id
      LEFT JOIN simuladores s ON s.id = a.simulador_id
      WHERE f.ficha_uuid = ? AND f.deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada',
        uuid
      }, 404);
    }
    
    const { results: notas } = await db.prepare(`
      SELECT 
        fn.*,
        m.codigo as manobra_codigo,
        m.nome as manobra_nome,
        m.categoria as manobra_categoria
      FROM simulador_ficha_notas fn
      LEFT JOIN manobras m ON m.id = fn.manobra_id
      WHERE fn.ficha_id = ?
      ORDER BY m.categoria, m.codigo
    `).bind(ficha.id).all();
    
    return c.json({
      success: true,
      data: {
        ...ficha,
        notas: notas || []
      },
      from_mock: false
    });
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: 'Erro ao buscar ficha',
      details: error.message
    }, 500);
  }
});

app.delete('/:uuid', async (c) => {
  const db = c.env.DB;
  const uuid = c.req.param('uuid');
  
  try {
    const ficha = await db.prepare(`
      SELECT id FROM simulador_fichas WHERE ficha_uuid = ? AND deleted_at IS NULL
    `).bind(uuid).first();
    
    if (!ficha) {
      return c.json({
        success: false,
        error: 'Ficha não encontrada'
      }, 404);
    }
    
    await db.prepare(`
      UPDATE simulador_fichas
      SET deleted_at = datetime('now')
      WHERE ficha_uuid = ?
    `).bind(uuid).run();
    
    return c.json({
      success: true,
      message: 'Ficha excluída com sucesso'
    });
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: 'Erro ao excluir ficha',
      details: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    const uuid = gerarUUID();
    
    const result = await db.prepare(`
      INSERT INTO simulador_fichas (
        ficha_uuid, agendamento_id, colaborador_id, instrutor_id,
        status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'PENDENTE', datetime('now'), datetime('now'))
    `).bind(
      uuid,
      data.agendamento_id,
      data.colaborador_id,
      data.instrutor_id
    ).run();
    
    return c.json({
      success: true,
      ficha_id: result.meta.last_row_id,
      uuid: uuid,
      message: 'Ficha criada com sucesso'
    }, 201);
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
