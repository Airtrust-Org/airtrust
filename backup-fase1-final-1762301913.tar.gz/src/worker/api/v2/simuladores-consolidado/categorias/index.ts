/**
 * Categorias de Manobras (CONSOLIDADO)
 * 
 * Criado em: 19/10/2025
 * 
 * Funcionalidades:
 * - CRUD completo de categorias
 * - Listagem ordenada
 * - Validação de dados
 */

import { Hono } from 'hono';
import type { Env } from '../../../types';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT * FROM simulador_categorias_manobra 
      WHERE deleted_at IS NULL AND ativo = 1
      ORDER BY ordem ASC, nome ASC
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length
    });
  } catch (error: any) {
    console.error('[CATEGORIAS] Erro ao buscar:', error);
    
    const mockCategorias = [
      { id: 1, codigo: 'NORMAL', nome: 'Operações Normais', cor: '#10B981', ordem: 1 },
      { id: 2, codigo: 'ANORMAL', nome: 'Operações Anormais', cor: '#F59E0B', ordem: 2 },
      { id: 3, codigo: 'EMERGENCIA', nome: 'Emergências', cor: '#EF4444', ordem: 3 }
    ];
    
    return c.json({
      success: true,
      data: mockCategorias,
      total: mockCategorias.length
    });
  }
});

app.get('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const categoria = await db.prepare(`
      SELECT * FROM simulador_categorias_manobra 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
    
    if (!categoria) {
      return c.json({
        success: false,
        error: 'Categoria não encontrada'
      }, 404);
    }
    
    return c.json({
      success: true,
      data: categoria
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.post('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const data = await c.req.json();
    
    if (!data.codigo || !data.nome) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: codigo, nome'
      }, 400);
    }
    
    const result = await db.prepare(`
      INSERT INTO simulador_categorias_manobra (
        codigo, nome, descricao, cor, ordem
      ) VALUES (?, ?, ?, ?, ?)
    `).bind(
      data.codigo,
      data.nome,
      data.descricao || null,
      data.cor || '#3B82F6',
      data.ordem || 0
    ).run();
    
    return c.json({
      success: true,
      id: result.meta.last_row_id,
      message: 'Categoria criada com sucesso'
    }, 201);
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.put('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    const data = await c.req.json();
    
    await db.prepare(`
      UPDATE simulador_categorias_manobra
      SET codigo = COALESCE(?, codigo),
          nome = COALESCE(?, nome),
          descricao = COALESCE(?, descricao),
          cor = COALESCE(?, cor),
          ordem = COALESCE(?, ordem),
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(
      data.codigo || null,
      data.nome || null,
      data.descricao || null,
      data.cor || null,
      data.ordem !== undefined ? data.ordem : null,
      id
    ).run();
    
    return c.json({
      success: true,
      message: 'Categoria atualizada com sucesso'
    });
    
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.delete('/:id', async (c) => {
  const db = c.env.DB;
  const id = c.req.param('id');
  
  try {
    await db.prepare(`
      UPDATE simulador_categorias_manobra
      SET deleted_at = datetime('now')
      WHERE id = ?
    `).bind(id).run();
    
    return c.json({
      success: true,
      message: 'Categoria removida com sucesso'
    });
  } catch (error: any) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
