/**
 * Sessões - DADOS REAIS
 * Agregação de agendamentos + fichas
 */

import { Hono } from 'hono';
import type { Env } from '../../../types/index';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  const db = c.env.DB;
  
  try {
    const { results } = await db.prepare(`
      SELECT 
        a.id,
        a.data_agendamento as data,
        a.hora_inicio,
        a.hora_fim,
        a.tipo_sessao,
        a.status,
        s.nome as simulador_nome,
        i.nome as instrutor_nome,
        COUNT(f.id) as total_fichas
      FROM agendamentos_simulador a
      LEFT JOIN simuladores s ON s.id = a.simulador_id
      LEFT JOIN funcionarios i ON i.id = a.instrutor_id
      LEFT JOIN simulador_fichas f ON f.agendamento_id = a.id
      WHERE a.deleted_at IS NULL
      GROUP BY a.id
      ORDER BY a.data_agendamento DESC, a.hora_inicio DESC
      LIMIT 50
    `).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: (results || []).length,
      from_mock: false
    });
    
  } catch (error: any) {
    console.error('Erro ao listar sessões:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;
