/**
 * ENDPOINTS API V2 - DADOS REFATORADOS
 * Data: 2 de novembro de 2025
 *
 * Endpoints para buscar dados do novo schema refatorado
 * - Funcionarios: /api/v2/funcionarios
 * - Qualificacoes: /api/v2/qualificacoes
 * - Certificados: /api/v2/certificados
 */

import { Hono } from 'hono';
import { DataService } from '../services/data.service';
import { Logger } from '../utils/logger';
import { securityHeaders } from '../middleware/security-headers';

type Env = {
  DB: any;
};

const createDataRoutes = () => {
  const router = new Hono<{ Bindings: Env }>();

  // Security middleware
  router.use('*', securityHeaders());

  // ═══════════════════════════════════════════════════════════════════
  // FUNCIONARIOS
  // ═══════════════════════════════════════════════════════════════════

  /**
   * GET /api/v2/funcionarios - Lista todos os funcionarios
   */
  router.get('/funcionarios', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const funcionarios = await service.getFuncionarios();

      return c.json({
        success: true,
        data: funcionarios,
        count: funcionarios.length,
      });
    } catch (error) {
      Logger.error('Error fetching funcionarios:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/funcionarios/:id - Busca funcionario por ID
   */
  router.get('/funcionarios/:id', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new DataService(c.env.DB);
      const funcionario = await service.getFuncionarioById(id);

      if (!funcionario) {
        return c.json({ success: false, error: 'Funcionario não encontrado' }, 404);
      }

      return c.json({ success: true, data: funcionario });
    } catch (error) {
      Logger.error('Error fetching funcionario:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/funcionarios/matricula/:matricula - Busca por matrícula
   */
  router.get('/funcionarios/matricula/:matricula', async (c) => {
    try {
      const matricula = c.req.param('matricula');
      if (!matricula) {
        return c.json({ success: false, error: 'Matrícula não fornecida' }, 400);
      }

      const service = new DataService(c.env.DB);
      const funcionario = await service.getFuncionarioByMatricula(matricula);

      if (!funcionario) {
        return c.json({ success: false, error: 'Funcionario não encontrado' }, 404);
      }

      return c.json({ success: true, data: funcionario });
    } catch (error) {
      Logger.error('Error fetching funcionario by matricula:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/funcionarios/base/:base - Busca por base
   */
  router.get('/funcionarios/base/:base', async (c) => {
    try {
      const base = c.req.param('base');
      if (!base) {
        return c.json({ success: false, error: 'Base não fornecida' }, 400);
      }

      const service = new DataService(c.env.DB);
      const funcionarios = await service.getFuncionariosByBase(base);

      return c.json({
        success: true,
        data: funcionarios,
        count: funcionarios.length,
      });
    } catch (error) {
      Logger.error('Error fetching funcionarios by base:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/funcionarios/:id/completo - Funcionario + Qualificacoes + Certificados
   */
  router.get('/funcionarios/:id/completo', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new DataService(c.env.DB);
      const data = await service.getFuncionarioComQualificacoes(id);

      if (!data) {
        return c.json({ success: false, error: 'Funcionario não encontrado' }, 404);
      }

      return c.json({ success: true, data });
    } catch (error) {
      Logger.error('Error fetching funcionario completo:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  // ═══════════════════════════════════════════════════════════════════
  // QUALIFICACOES
  // ═══════════════════════════════════════════════════════════════════

  /**
   * GET /api/v2/qualificacoes - Lista todas as qualificacoes
   */
  router.get('/qualificacoes', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const qualificacoes = await service.getQualificacoes();

      return c.json({
        success: true,
        data: qualificacoes,
        stats: {
          count: qualificacoes.length,
          totalPages: Math.ceil(qualificacoes.length / 10), // Exemplo de paginação
        },
      });
    } catch (error) {
      Logger.error('Error fetching qualificacoes:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/qualificacoes/vencidas - Qualificacoes vencidas
   */
  router.get('/qualificacoes/vencidas', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const qualificacoes = await service.getQualificacoesVencidas();

      return c.json({
        success: true,
        data: qualificacoes,
        count: qualificacoes.length,
      });
    } catch (error) {
      Logger.error('Error fetching vencidas qualificacoes:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/qualificacoes/vencendo - Qualificacoes vencendo em 30 dias
   */
  router.get('/qualificacoes/vencendo', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const qualificacoes = await service.getQualificacoesVencendo();

      return c.json({
        success: true,
        data: qualificacoes,
        count: qualificacoes.length,
      });
    } catch (error) {
      Logger.error('Error fetching vencendo qualificacoes:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/funcionarios/:id/qualificacoes - Qualificacoes de um funcionario
   */
  router.get('/funcionarios/:id/qualificacoes', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new DataService(c.env.DB);
      const qualificacoes = await service.getQualificacoesByFuncionario(id);

      return c.json({
        success: true,
        data: qualificacoes,
        count: qualificacoes.length,
      });
    } catch (error) {
      Logger.error('Error fetching qualificacoes by funcionario:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/qualificacoes/:id/completo - Qualificacao + Certificados
   */
  router.get('/qualificacoes/:id/completo', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new DataService(c.env.DB);
      const data = await service.getQualificacaoComCertificados(id);

      if (!data) {
        return c.json({ success: false, error: 'Qualificacao não encontrada' }, 404);
      }

      return c.json({ success: true, data });
    } catch (error) {
      Logger.error('Error fetching qualificacao completo:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  // ═══════════════════════════════════════════════════════════════════
  // CERTIFICADOS
  // ═══════════════════════════════════════════════════════════════════

  /**
   * GET /api/v2/certificados - Lista todos os certificados
   */
  router.get('/certificados', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const certificados = await service.getCertificados();

      return c.json({
        success: true,
        data: certificados,
        count: certificados.length,
      });
    } catch (error) {
      Logger.error('Error fetching certificados:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/certificados/validos - Certificados com arquivo
   */
  router.get('/certificados/validos', async (c) => {
    try {
      const service = new DataService(c.env.DB);
      const certificados = await service.getCertificadosValidos();

      return c.json({
        success: true,
        data: certificados,
        count: certificados.length,
      });
    } catch (error) {
      Logger.error('Error fetching valid certificados:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/qualificacoes/:id/certificados - Certificados de uma qualificacao
   */
  router.get('/qualificacoes/:id/certificados', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new DataService(c.env.DB);
      const certificados = await service.getCertificadosByQualificacao(id);

      return c.json({
        success: true,
        data: certificados,
        count: certificados.length,
      });
    } catch (error) {
      Logger.error('Error fetching certificados by qualificacao:', error);
      return c.json(
        {
          success: false,
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  // ═══════════════════════════════════════════════════════════════════
  // HEALTH / VALIDAÇÃO
  // ═══════════════════════════════════════════════════════════════════

  /**
   * GET /api/v2/data/health - Verificar saúde dos dados
   */
  router.get('/data/health', async (c) => {
    try {
      const service = new DataService(c.env.DB);

      const counts = await service.getCountByTable();
      const orphanedQuals = await service.findOrphanedQualificacoes();
      const orphanedCerts = await service.findOrphanedCertificados();

      return c.json({
        success: true,
        status: 'healthy',
        counts,
        orphans: {
          qualificacoes: orphanedQuals.length,
          certificados: orphanedCerts.length,
        },
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      Logger.error('Error checking data health:', error);
      return c.json(
        {
          success: false,
          status: 'unhealthy',
          error: error instanceof Error ? error.message : 'Erro desconhecido',
        },
        500,
      );
    }
  });

  return router;
};

export default createDataRoutes;
