import { Hono } from 'hono';

const app = new Hono();

app.get('/:id', async (c) => {
  try {
    const fichaId = c.req.param('id');
    const env = c.env;
    
    
    const sessao = await env.DB.prepare(`
      SELECT 
        s.*,
        sim.nome as simulador_nome,
        sim.codigo as simulador_codigo,
        inst.nome as instrutor_nome,
        inst.matricula as instrutor_matricula
      FROM sessoes_simulador s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios inst ON s.instrutor_id = inst.id
      WHERE s.uuid = ? AND s.deleted_at IS NULL
    `).bind(fichaId).first();
    
    if (!sessao) {
      return c.json({ 
        success: false, 
        error: 'Sessão não encontrada' 
      }, 404);
    }
    
    const participantes = await env.DB.prepare(`
      SELECT 
        sp.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula
      FROM sessoes_participantes sp
      JOIN funcionarios f ON sp.funcionario_id = f.id
      WHERE sp.sessao_id = ? AND sp.deleted_at IS NULL
      ORDER BY sp.ordem
    `).bind(sessao.id).all();
    
    const manobras = await env.DB.prepare(`
      SELECT 
        sm.*,
        m.nome as manobra_nome,
        m.descricao as manobra_descricao
      FROM sessoes_manobras sm
      JOIN manobras m ON sm.manobra_id = m.id
      WHERE sm.sessao_id = ? AND sm.deleted_at IS NULL
      ORDER BY sm.ordem
    `).bind(sessao.id).all();
    
    
    return c.json({
      success: true,
      data: {
        sessao,
        participantes: participantes.results || [],
        manobras: manobras.results || []
      }
    });
    
  } catch (error) {
    Logger.error('❌ [FICHAS] Erro ao buscar ficha:', error);
    return c.json({ 
      success: false, 
      error: 'Erro ao buscar ficha',
      details: error.message 
    }, 500);
  }
});

app.get('/:id/editar', async (c) => {
  const fichaId = c.req.param('id');
  
  return app.fetch(new Request(`${c.req.url.replace('/editar', '')}`, c.req.raw));
});

export default app;
