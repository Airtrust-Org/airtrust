import { Hono } from 'hono';
import { Env } from '../../types/index';

const qualificacoes = new Hono<{ Bindings: Env }>();

/**
 * GET /qualificacoes - Lista todas com paginação e filtros avançados
 * TABELA UNIFICADA: qualificacoes (TREINAMENTO, EXAME, CHECK)
 */
qualificacoes.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');
    const busca = c.req.query('busca');
    const tipo = c.req.query('tipo');
    const status = c.req.query('status');
    const data_inicio = c.req.query('data_inicio');
    const data_fim = c.req.query('data_fim');
    const incluir_renovadas = c.req.query('incluir_renovadas'); // ✅ NOVO
    const offset = (page - 1) * limit;
    
    let whereConditions: string[] = ['q.deleted_at IS NULL', 'f.deleted_at IS NULL'];
    const bindings: any[] = [];
    
    if (incluir_renovadas !== 'true') {
      whereConditions.push('q.is_renovada = 0');
    }
    
    if (busca) {
      whereConditions.push(`(f.nome LIKE ? OR f.matricula LIKE ? OR q.codigo LIKE ? OR q.nome LIKE ?)`);
      bindings.push(`%${busca}%`, `%${busca}%`, `%${busca}%`, `%${busca}%`);
    }
    
    if (tipo && ['TREINAMENTO', 'CHECK', 'EXAME'].includes(tipo)) {
      whereConditions.push(`q.tipo = ?`);
      bindings.push(tipo);
    }
    
    if (data_inicio) {
      whereConditions.push(`COALESCE(q.data_conclusao, q.data_conclusao) >= ?`);
      bindings.push(data_inicio);
    }
    
    if (data_fim) {
      whereConditions.push(`COALESCE(q.data_conclusao, q.data_conclusao) <= ?`);
      bindings.push(data_fim);
    }
    
    const whereClause = whereConditions.join(' AND ');
    
    let query = `
      SELECT 
        q.id,
        q.funcionario_id,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        f.codigo_anac as funcionario_codigo_anac,
        q.tipo,
        q.nome,
        q.codigo,
        q.descricao,
        COALESCE(q.data_conclusao, q.data_conclusao) as data_realizado,
        q.data_vencimento as data_vencimento,
        COALESCE(t.validade_meses, 12) as validade_meses,
        CASE
          WHEN q.data_vencimento IS NULL THEN NULL
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN NULL
          ELSE CAST(julianday(q.data_vencimento) - julianday('now') AS INTEGER)
        END as dias_para_vencimento,
        q.is_renovada,
        CASE
          WHEN q.is_renovada = 1 THEN 'RENOVADA'
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN 'VENCIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') <= 30 THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        COALESCE(q.instrutor, q.checador) as instrutor,
        q.nota,
        COALESCE(q.certificado_url, q.arquivo_url) as certificado_url
      FROM qualificacoes q
      INNER JOIN funcionarios f ON f.id = q.funcionario_id
      LEFT JOIN qualificacoes t ON t.codigo = q.codigo AND t.deleted_at IS NULL
      WHERE ${whereClause}
    `;
    
    if (status) {
      if (status === 'RENOVADA' || status === 'renovada') {
        query += ` AND q.is_renovada = 1`;
      } else if (status === 'VALIDA') {
        query += ` AND q.is_renovada = 0 AND (q.data_vencimento IS NULL OR julianday(q.data_vencimento) - julianday('now') > 30)`;
      } else if (status === 'VENCENDO') {
        query += ` AND q.is_renovada = 0 AND julianday(q.data_vencimento) - julianday('now') BETWEEN 0 AND 30`;
      } else if (status === 'VENCIDA') {
        query += ` AND q.is_renovada = 0 AND julianday(q.data_vencimento) - julianday('now') < 0`;
      }
    }
    
    const countQuery = `SELECT COUNT(*) as total FROM qualificacoes q INNER JOIN funcionarios f ON f.id = q.funcionario_id WHERE ${whereClause}`;
    const countResult = await (db.prepare(countQuery) as any).bind(...bindings).first();
    const total = (countResult as any)?.total || 0;
    
    query += ` ORDER BY q.data_vencimento ASC, COALESCE(q.data_conclusao, q.data_conclusao) DESC LIMIT ? OFFSET ?`;
    bindings.push(limit, offset);
    
    const result = await (db.prepare(query) as any).bind(...bindings).all();
    
    const processedData = (result.results || []).map((item: any) => ({
      id: item.id,
      funcionario_id: item.funcionario_id,
      funcionario_nome: item.funcionario_nome,
      funcionario_matricula: item.funcionario_matricula,
      funcionario_codigo_anac: item.funcionario_codigo_anac,
      tipo: item.tipo,
      nome: item.nome,
      codigo: item.codigo,
      descricao: item.descricao,
      data_realizado: item.data_realizado,
      data_vencimento: item.data_vencimento,
      validade_meses: item.validade_meses,
      dias_para_vencimento: item.dias_para_vencimento,
      is_renovada: item.is_renovada,
      status: item.status_calculado || 'VALIDA',
      instrutor: item.instrutor,
      nota: item.nota,
      certificado_url: item.certificado_url
    }));
    
    const statsQuery = `
      SELECT 
        COUNT(*) as total,
        SUM(CASE 
          WHEN is_renovada = 0 AND (data_vencimento IS NULL OR julianday(data_vencimento) - julianday('now') > 30)
          THEN 1 ELSE 0 
        END) as validas,
        SUM(CASE 
          WHEN is_renovada = 0 AND julianday(data_vencimento) - julianday('now') BETWEEN 0 AND 30 
          THEN 1 ELSE 0 
        END) as vencendo,
        SUM(CASE 
          WHEN is_renovada = 0 AND julianday(data_vencimento) - julianday('now') < 0 
          THEN 1 ELSE 0 
        END) as vencidas,
        SUM(CASE 
          WHEN is_renovada = 1 
          THEN 1 ELSE 0 
        END) as renovadas
      FROM qualificacoes
      WHERE deleted_at IS NULL
    `;
    
    const stats = await (db.prepare(statsQuery) as any).first();
    
    return c.json({
      success: true,
      data: processedData,
      stats: {
        total: (stats as any)?.total || 0,
        validas: (stats as any)?.validas || 0,
        vencendo: (stats as any)?.vencendo || 0,
        vencidas: (stats as any)?.vencidas || 0,
        renovadas: (stats as any)?.renovadas || 0
      },
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    });
    
  } catch (error) {
    Logger.error('[QUALIFICACOES] Erro:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      data: [],
      stats: { total: 0, validas: 0, vencendo: 0, vencidas: 0 }
    }, 500);
  }
});

/**
 * GET /qualificacoes/:id - Buscar por ID
 */
qualificacoes.get('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;
    const result = await (db.prepare(`
      SELECT 
        q.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        CASE 
          WHEN q.data_vencimento < DATE('now') THEN 'VENCIDA'
          WHEN q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        CAST((julianday(q.data_vencimento) - julianday('now')) AS INTEGER) as dias_restantes
      FROM qualificacoes q
      INNER JOIN funcionarios f ON q.funcionario_id = f.id
      WHERE q.id = ? AND q.deleted_at IS NULL
    `) as any).bind(id).first();
    
    if (!result) {
      return c.json({ 
        success: false, 
        error: 'Qualificação não encontrada' 
      }, 404);
    }
    
    return c.json({ 
      success: true, 
      qualificacao: result
    });
  } catch (error) {
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * PUT /qualificacoes/:id - Atualizar qualificação
 */
qualificacoes.put('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;
    const body = await c.req.json();
    
    const exists = await (db.prepare(`
      SELECT id FROM qualificacoes WHERE id = ? AND deleted_at IS NULL
    `) as any).bind(id).first();
    
    if (!exists) {
      return c.json({ 
        success: false, 
        error: 'Qualificação não encontrada' 
      }, 404);
    }
    
    await (db.prepare(`
      UPDATE qualificacoes 
      SET 
        tipo = ?,
        codigo = ?,
        nome = ?,
        descricao = ?,
        data_conclusao = ?,
        data_conclusao = ?,
        data_vencimento = ?,
        instituicao = ?,
        instrutor = ?,
        checador = ?,
        carga_horaria = ?,
        numero = ?,
        nota = ?,
        resultado = ?,
        observacoes = ?,
        updated_at = datetime('now')
      WHERE id = ?
    `) as any).bind(
      body.tipo,
      body.codigo,
      body.nome,
      body.descricao,
      body.data_conclusao,
      body.data_conclusao,
      body.data_vencimento,
      body.instituicao,
      body.instrutor,
      body.checador,
      body.carga_horaria,
      body.numero,
      body.nota,
      body.resultado,
      body.observacoes,
      id
    ).run();
    
    return c.json({ 
      success: true, 
      message: 'Qualificação atualizada com sucesso'
    });
  } catch (error) {
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * DELETE /qualificacoes/:id - Excluir qualificação (soft delete)
 */
qualificacoes.delete('/:id', async (c) => {
  const id = c.req.param('id');
  try {
    const db = c.env.DB;
    
    const exists = await (db.prepare(`
      SELECT id FROM qualificacoes WHERE id = ? AND deleted_at IS NULL
    `) as any).bind(id).first();
    
    if (!exists) {
      return c.json({ 
        success: false, 
        error: 'Qualificação não encontrada' 
      }, 404);
    }
    
    await (db.prepare(`
      UPDATE qualificacoes 
      SET deleted_at = datetime('now'), updated_at = datetime('now')
      WHERE id = ?
    `) as any).bind(id).run();
    
    return c.json({ 
      success: true, 
      message: 'Qualificação excluída com sucesso'
    });
  } catch (error) {
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * GET /qualificacoes/funcionario/:funcionario_id
 * Lista qualificações de um funcionário específico
 */
qualificacoes.get('/funcionario/:funcionario_id', async (c) => {
  const funcionarioId = c.req.param('funcionario_id');
  const db = c.env.DB;

  try {
    const funcionario = await (db.prepare(`
      SELECT id, nome, matricula, email, cargo
      FROM funcionarios
      WHERE id = ? AND deleted_at IS NULL
    `) as any).bind(funcionarioId).first();

    if (!funcionario) {
      return c.json({
        success: false,
        error: 'Funcionário não encontrado'
      }, 404);
    }

    const result = await (db.prepare(`
      SELECT *,
        CASE 
          WHEN data_vencimento < DATE('now') THEN 'VENCIDA'
          WHEN data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado
      FROM qualificacoes
      WHERE funcionario_id = ? AND deleted_at IS NULL
      ORDER BY data_vencimento ASC
    `) as any).bind(funcionarioId).all();

    const qualificacoes = result.results || [];
    const stats = {
      total: qualificacoes.length,
      validas: qualificacoes.filter((q: any) => q.status_calculado === 'VALIDA').length,
      vencendo: qualificacoes.filter((q: any) => q.status_calculado === 'VENCENDO').length,
      vencidas: qualificacoes.filter((q: any) => q.status_calculado === 'VENCIDA').length,
      por_tipo: {
        treinamentos: qualificacoes.filter((q: any) => q.tipo === 'TREINAMENTO').length,
        checks: qualificacoes.filter((q: any) => q.tipo === 'CHECK').length,
        exames: qualificacoes.filter((q: any) => q.tipo === 'EXAME').length
      }
    };

    return c.json({
      success: true,
      funcionario,
      qualificacoes,
      stats
    });

  } catch (error: any) {
    Logger.error('[QUALIFICACOES FUNCIONARIO] Erro:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

/**
 * GET /qualificacoes/dashboard-stats
 * Estatísticas para dashboard
 */
qualificacoes.get('/dashboard-stats', async (c) => {
  const db = c.env.DB;

  try {
    const statsStatus = await (db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN data_vencimento >= DATE('now') THEN 1 ELSE 0 END) as validas,
        SUM(CASE WHEN data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') THEN 1 ELSE 0 END) as vencendo,
        SUM(CASE WHEN data_vencimento < DATE('now') THEN 1 ELSE 0 END) as vencidas
      FROM qualificacoes
      WHERE deleted_at IS NULL
    `) as any).first();

    const statsTipo = await (db.prepare(`
      SELECT 
        SUM(CASE WHEN tipo = 'TREINAMENTO' THEN 1 ELSE 0 END) as treinamentos,
        SUM(CASE WHEN tipo = 'CHECK' THEN 1 ELSE 0 END) as checks,
        SUM(CASE WHEN tipo = 'EXAME' THEN 1 ELSE 0 END) as exames
      FROM qualificacoes
      WHERE deleted_at IS NULL
    `) as any).first();

    return c.json({
      success: true,
      stats: {
        total: (statsStatus as any)?.total || 0,
        validas: (statsStatus as any)?.validas || 0,
        vencendo: (statsStatus as any)?.vencendo || 0,
        vencidas: (statsStatus as any)?.vencidas || 0,
        por_tipo: {
          treinamentos: (statsTipo as any)?.treinamentos || 0,
          checks: (statsTipo as any)?.checks || 0,
          exames: (statsTipo as any)?.exames || 0
        }
      }
    });

  } catch (error: any) {
    Logger.error('[STATS] Erro:', error);
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

/**
 * GET /qualificacoes/historico/:funcionario_id
 * Retorna TODAS as qualificações (incluindo renovadas)
 */
qualificacoes.get('/historico/:funcionario_id', async (c) => {
  try {
    const funcionarioId = c.req.param('funcionario_id');
    const { tipo, codigo } = c.req.query();
    const db = c.env.DB;
    
    let query = `
      SELECT 
        q.*,
        f.nome as funcionario_nome,
        f.matricula as funcionario_matricula,
        f.codigo_anac as funcionario_codigo_anac,
        CASE
          WHEN q.is_renovada = 1 THEN 'renovada'
          WHEN q.data_vencimento IS NULL THEN 'VALIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') < 0 THEN 'VENCIDA'
          WHEN julianday(q.data_vencimento) - julianday('now') <= 30 THEN 'VENCENDO'
          ELSE 'VALIDA'
        END as status_calculado,
        CAST(julianday(q.data_vencimento) - julianday('now') AS INTEGER) as dias_para_vencimento
      FROM qualificacoes q
      INNER JOIN funcionarios f ON f.id = q.funcionario_id
      WHERE q.funcionario_id = ?
        AND q.deleted_at IS NULL
    `;
    
    const params: any[] = [parseInt(funcionarioId)];
    
    if (tipo) {
      query += ` AND q.tipo = ?`;
      params.push(tipo);
    }
    
    if (codigo) {
      query += ` AND q.codigo = ?`;
      params.push(codigo);
    }
    
    query += ` ORDER BY q.tipo, q.codigo, q.data_conclusao DESC, q.id DESC`;
    
    const result = await (db.prepare(query) as any).bind(...params).all();
    
    const grouped = (result.results || []).reduce((acc: any, qual: any) => {
      const key = `${qual.tipo}-${qual.codigo}`;
      if (!acc[key]) {
        acc[key] = {
          tipo: qual.tipo,
          codigo: qual.codigo,
          nome: qual.nome,
          versoes: []
        };
      }
      acc[key].versoes.push(qual);
      return acc;
    }, {});
    
    return c.json({
      success: true,
      data: Object.values(grouped)
    });
    
  } catch (error) {
    Logger.error('Erro ao buscar histórico:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar histórico de qualificações'
    }, 500);
  }
});

export default qualificacoes;
