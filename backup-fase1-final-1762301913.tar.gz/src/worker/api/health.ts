/**
 * Health Check e Métricas
 * Endpoint para monitoramento da aplicação
 */

import { Hono } from 'hono';
import { Env } from '../types/index';
import { metrics, counters } from '../utils/metrics';
import { getCacheStats } from '../utils/cache-qualificacoes';

const health = new Hono<{ Bindings: Env }>();

/**
 * GET /health - Health check básico
 */
health.get('/', async (c) => {
  const db = c.env.DB;

  try {
    // Testar conexão com banco
    await (db.prepare('SELECT 1') as any).first();

    return c.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.5.0',
      uptime: process.uptime ? process.uptime() : 'N/A',
    });
  } catch (error) {
    return c.json(
      {
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString(),
      },
      503
    );
  }
});

/**
 * GET /health/metrics - Métricas detalhadas
 */
health.get('/metrics', async (c) => {
  const qualificacoesStats = metrics.getPerformanceStats('/api/v2/qualificacoes');
  const cacheStats = getCacheStats();

  return c.json({
    timestamp: new Date().toISOString(),
    performance: {
      qualificacoes: qualificacoesStats,
      overall: metrics.getPerformanceStats(),
    },
    cache: cacheStats,
    counters: {
      qualificacoes: {
        created: counters.qualificacoes.created.value,
        updated: counters.qualificacoes.updated.value,
        deleted: counters.qualificacoes.deleted.value,
        fetched: counters.qualificacoes.fetched.value,
      },
      cache: {
        hits: counters.cache.hits.value,
        misses: counters.cache.misses.value,
        hitRate:
          counters.cache.hits.value + counters.cache.misses.value > 0
            ? (
                (counters.cache.hits.value /
                  (counters.cache.hits.value + counters.cache.misses.value)) *
                100
              ).toFixed(2) + '%'
            : '0%',
      },
      rateLimit: {
        blocked: counters.rateLimit.blocked.value,
      },
    },
  });
});

/**
 * GET /health/ready - Readiness probe
 */
health.get('/ready', async (c) => {
  const db = c.env.DB;

  try {
    // Verificar se banco está pronto
    await (db.prepare('SELECT 1') as any).first();

    // Verificar se cache está funcionando
    const cacheStats = getCacheStats();

    return c.json({
      ready: true,
      checks: {
        database: 'ok',
        cache: cacheStats.total >= 0 ? 'ok' : 'degraded',
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return c.json(
      {
        ready: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString(),
      },
      503
    );
  }
});

/**
 * GET /health/live - Liveness probe
 */
health.get('/live', (c) => {
  return c.json({
    alive: true,
    timestamp: new Date().toISOString(),
  });
});

export default health;
