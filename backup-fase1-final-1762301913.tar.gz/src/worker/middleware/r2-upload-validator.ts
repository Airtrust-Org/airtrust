/**
 * Middleware para validar permissões de upload em R2
 * Garante que usuários só possam fazer upload de certificados para suas próprias qualificações
 * ou que sejam ADMIN
 */

import { Context } from 'hono';
import { Logger } from '../utils/logger';

export interface R2UploadContext {
  usuarioId?: number;
  usuarioPerfil?: string;
  funcionarioId?: number;
  recursoFuncionarioId?: number;
  podeUploar: boolean;
  motivo?: string;
}

/**
 * Validar se usuário tem permissão para fazer upload de arquivo
 * Regras:
 * - ADMIN pode fazer upload para qualquer funcionário
 * - Usuário comum só pode fazer upload para sua própria qualificação
 *
 * @param usuarioId - ID do usuário fazendo o upload
 * @param usuarioPerfil - Perfil do usuário (ADMIN, USER, etc)
 * @param usuarioFuncionarioId - ID do funcionário associado ao usuário
 * @param recursoFuncionarioId - ID do funcionário para quem está sendo feito upload
 * @returns Objeto com informações de permissão
 */
export function validarPermissaoR2Upload(
  usuarioId: number | undefined,
  usuarioPerfil: string | undefined,
  usuarioFuncionarioId: number | undefined,
  recursoFuncionarioId: number | undefined
): R2UploadContext {
  const contexto: R2UploadContext = {
    usuarioId,
    usuarioPerfil,
    funcionarioId: usuarioFuncionarioId,
    recursoFuncionarioId,
    podeUploar: false,
  };

  // Validação 1: Usuário autenticado?
  if (!usuarioId) {
    contexto.motivo = 'Usuário não autenticado';
    return contexto;
  }

  // Validação 2: Perfil definido?
  if (!usuarioPerfil) {
    contexto.motivo = 'Perfil do usuário não definido';
    return contexto;
  }

  // Validação 3: ADMIN sempre pode fazer upload
  if (usuarioPerfil === 'ADMIN') {
    contexto.podeUploar = true;
    contexto.motivo = 'ADMIN: permissão total';
    return contexto;
  }

  // Validação 4: Usuário comum - validar ownership
  if (!usuarioFuncionarioId) {
    contexto.motivo = 'Usuário não associado a funcionário';
    return contexto;
  }

  if (!recursoFuncionarioId) {
    contexto.motivo = 'Recurso não associado a funcionário';
    return contexto;
  }

  // Validação 5: Usuário só pode fazer upload para sua própria qualificação
  if (usuarioFuncionarioId === recursoFuncionarioId) {
    contexto.podeUploar = true;
    contexto.motivo = 'Usuário: ownership validado';
    return contexto;
  }

  // Negado por padrão
  contexto.motivo = `Usuário (funcionario_id: ${usuarioFuncionarioId}) tentou fazer upload para funcionário ${recursoFuncionarioId}`;
  return contexto;
}

/**
 * Middleware Hono para verificar permissões de R2 upload
 */
export function checkR2UploadPermission() {
  return async (c: Context, next: () => Promise<void>) => {
    const user = c.get('user');

    if (!user) {
      Logger.warn('[R2 UPLOAD] Acesso negado: usuário não autenticado', {
        path: c.req.path,
        ip: c.req.header('cf-connecting-ip'),
      });

      return c.json(
        {
          error: 'Unauthorized',
          message: 'Você precisa estar autenticado para fazer upload',
        },
        401
      );
    }

    // Extrair ID do funcionário do path: /api/v2/qualificacoes/:id/upload-certificado
    const pathParts = c.req.path.split('/');
    const qualificacaoIdStr = pathParts[pathParts.length - 2];
    const qualificacaoId = parseInt(qualificacaoIdStr);

    if (isNaN(qualificacaoId)) {
      Logger.warn('[R2 UPLOAD] ID de qualificação inválido', {
        path: c.req.path,
        userId: user.id.toString(),
      });

      return c.json(
        {
          error: 'Bad Request',
          message: 'ID de qualificação inválido',
        },
        400
      );
    }

    // Armazenar contexto de upload no contexto Hono para uso posterior
    c.set('uploadContext', {
      qualificacaoId,
      user,
    });

    await next();
  };
}

/**
 * Validar ownership de qualificação antes de permitir upload
 * Esta função deve ser chamada DEPOIS de buscar a qualificação do banco
 */
export async function validarOwnershipQualificacao(
  db: any,
  usuarioId: number,
  usuarioPerfil: string,
  usuarioFuncionarioId: number | undefined,
  qualificacaoId: number
): Promise<{
  valido: boolean;
  qualificacao?: any;
  motivo?: string;
}> {
  try {
    // Buscar qualificação
    const qualificacao = await db
      .prepare(
        `SELECT q.*, f.funcionario_id 
         FROM qualificacoes q
         JOIN funcionarios f ON q.funcionario_id = f.id
         WHERE q.id = ? AND q.deleted_at IS NULL`
      )
      .bind(qualificacaoId)
      .first();

    if (!qualificacao) {
      return {
        valido: false,
        motivo: 'Qualificação não encontrada',
      };
    }

    // Validar permissão
    const permissao = validarPermissaoR2Upload(
      usuarioId,
      usuarioPerfil,
      usuarioFuncionarioId,
      qualificacao.funcionario_id
    );

    if (!permissao.podeUploar) {
      Logger.warn('[R2 UPLOAD] Acesso negado: sem ownership', {
        userId: usuarioId.toString(),
        userFuncionarioId: usuarioFuncionarioId?.toString(),
        recursoFuncionarioId: qualificacao.funcionario_id.toString(),
        qualificacaoId: qualificacaoId.toString(),
        motivo: permissao.motivo,
      });

      return {
        valido: false,
        motivo: permissao.motivo,
      };
    }

    Logger.info('[R2 UPLOAD] Permissão validada', {
      userId: usuarioId.toString(),
      qualificacaoId: qualificacaoId.toString(),
      motivo: permissao.motivo,
    });

    return {
      valido: true,
      qualificacao,
    };
  } catch (error) {
    Logger.error('[R2 UPLOAD] Erro ao validar ownership', error, {
      qualificacaoId,
    });

    return {
      valido: false,
      motivo: 'Erro ao validar permissão',
    };
  }
}
