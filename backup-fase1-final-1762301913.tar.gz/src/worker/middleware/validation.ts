import { Context, Next } from 'hono';
import { ZodSchema, ZodError } from 'zod';

/**
 * Middleware para validar body da requisição com Zod
 */
export function validateBody(schema: ZodSchema) {
  return async (c: Context, next: Next) => {
    try {
      const body = await c.req.json();
      const validated = schema.parse(body);
      
      c.set('validatedData', validated);
      
      return next();
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json({
          success: false,
          error: 'Validação falhou',
          details: error.errors.map(e => ({
            field: e.path.join('.'),
            message: e.message,
            code: e.code
          }))
        }, 400);
      }
      
      return c.json({
        success: false,
        error: 'Erro de validação desconhecido',
        message: error instanceof Error ? error.message : 'Unknown error'
      }, 500);
    }
  };
}

/**
 * Middleware para validar query params com Zod
 */
export function validateQuery(schema: ZodSchema) {
  return async (c: Context, next: Next) => {
    try {
      const query = c.req.query();
      const validated = schema.parse(query);
      
      c.set('validatedQuery', validated);
      
      return next();
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json({
          success: false,
          error: 'Query params inválidos',
          details: error.errors.map(e => ({
            field: e.path.join('.'),
            message: e.message
          }))
        }, 400);
      }
      
      return c.json({ 
        success: false, 
        error: 'Erro de validação' 
      }, 500);
    }
  };
}

/**
 * Middleware para validar params da URL com Zod
 */
export function validateParams(schema: ZodSchema) {
  return async (c: Context, next: Next) => {
    try {
      const params = c.req.param();
      const validated = schema.parse(params);
      
      c.set('validatedParams', validated);
      
      return next();
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json({
          success: false,
          error: 'Parâmetros inválidos',
          details: error.errors
        }, 400);
      }
      
      return c.json({ 
        success: false, 
        error: 'Erro de validação' 
      }, 500);
    }
  };
}

/**
 * Helper para obter dados validados do contexto
 */
export function getValidatedData<T>(c: Context): T {
  return c.get('validatedData') as T;
}

export function getValidatedQuery<T>(c: Context): T {
  return c.get('validatedQuery') as T;
}

export function getValidatedParams<T>(c: Context): T {
  return c.get('validatedParams') as T;
}
