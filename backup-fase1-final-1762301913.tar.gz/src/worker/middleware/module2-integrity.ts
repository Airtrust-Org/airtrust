import { MiddlewareHandler } from 'hono';

/**
 * Monitor de Integridade específico do Módulo 2
 * Executa verificações críticas APÓS operações de escrita em treinamentos
 */
export const validateModule2Integrity: MiddlewareHandler = async (c, next) => {
  const method = c.req.method;
  const path = c.req.path;

  if (method === 'POST' && path.includes('/historico-certificacoes')) {
    await next(); // Executa a API primeiro

    try {
      const db = c.env.DB;
      
      const funcionarioViolations = await db.prepare(`
        SELECT COUNT(*) as count FROM historico_certificacoes_v2 h 
        WHERE h.funcionario_id NOT IN (SELECT id FROM funcionarios WHERE deleted_at IS NULL)
        AND h.deleted_at IS NULL
      `).first();
      
      const treinamentoViolations = await db.prepare(`
        SELECT COUNT(*) as count FROM historico_certificacoes_v2 h 
        WHERE h.treinamento_id NOT IN (SELECT id FROM catalogo_treinamentos_v2 WHERE deleted_at IS NULL)
        AND h.deleted_at IS NULL
      `).first();
      
      const totalViolations = (funcionarioViolations?.count || 0) + (treinamentoViolations?.count || 0);
      
      if (totalViolations > 0) {
        console.error('🚨 MODULE2_INTEGRITY_VIOLATION:', {
          funcionario_violations: funcionarioViolations?.count || 0,
          treinamento_violations: treinamentoViolations?.count || 0,
          endpoint: c.req.url,
          method: c.req.method,
          timestamp: new Date().toISOString()
        });
        
        const environment = c.env?.ENVIRONMENT || 'development';
        if (environment === 'production') {
          console.error('⛔ CRITICAL: Module 2 integrity violations in production!');
        }
      } else {
      }
    } catch (error) {
      console.error('❌ MODULE2_INTEGRITY_MONITOR_ERROR:', error);
    }
  } else {
    await next();
  }
};
