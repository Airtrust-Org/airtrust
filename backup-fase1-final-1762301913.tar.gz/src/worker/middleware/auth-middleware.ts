
import { Context, Next } from 'hono';
import { jwtUtils } from '../utils/jwt';

export const authMiddleware = async (c: Context, next: Next) => {
  const authHeader = c.req.header('Authorization');
  const token = jwtUtils.extractToken(authHeader);

  if (!token) {
    return c.json({
      success: false,
      error: 'Token não fornecido'
    }, 401);
  }

  const payload = await jwtUtils.verifyToken(token);

  if (!payload) {
    return c.json({
      success: false,
      error: 'Token inválido ou expirado'
    }, 401);
  }

  c.set('user', payload);

  await next();
};

export const requireRole = (...roles: string[]) => {
  return async (c: Context, next: Next) => {
    const user = c.get('user');

    if (!user || !roles.includes(user.role)) {
      return c.json({
        success: false,
        error: 'Permissão negada'
      }, 403);
    }

    await next();
  };
};
