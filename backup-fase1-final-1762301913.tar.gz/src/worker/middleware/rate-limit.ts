import { Context } from 'hono';

interface RateLimitStore {
  [key: string]: { count: number; resetTime: number };
}

const store: RateLimitStore = {};

export function rateLimit(limit: number = 100, windowMs: number = 15 * 60 * 1000) {
  return async (c: Context, next: () => Promise<void>) => {
    const ip = c.req.header('cf-connecting-ip') || '0.0.0.0';
    const now = Date.now();

    if (!store[ip]) {
      store[ip] = { count: 0, resetTime: now + windowMs };
    }

    const record = store[ip];
    if (now > record.resetTime) {
      record.count = 0;
      record.resetTime = now + windowMs;
    }

    record.count++;
    c.header('X-RateLimit-Limit', limit.toString());
    c.header('X-RateLimit-Remaining', Math.max(0, limit - record.count).toString());
    c.header('X-RateLimit-Reset', record.resetTime.toString());

    if (record.count > limit) {
      return c.json({ error: 'Rate limit exceeded' }, { status: 429 });
    }

    await next();
  };
}
