/**
 * 🇧🇷 MIDDLEWARE DE CONVERSÃO AUTOMÁTICA DE DATAS BRASILEIRAS
 * 
 * Converte automaticamente datas brasileiras (dd/mm/aaaa) recebidas
 * do frontend para Date objects antes de salvar no banco.
 * 
 * Também converte Date objects para formato brasileiro nas respostas.
 */

import { Context, Next } from 'hono';
import { DatesBrasil } from '../../shared/utils/datesBrasil';

/**
 * Middleware principal para conversão automática
 */
export const datesBrasilMiddleware = async (c: Context, next: Next) => {
  const method = c.req.method;
  
  if (['POST', 'PUT', 'PATCH'].includes(method)) {
    try {
      const contentType = c.req.header('content-type');
      
      if (contentType?.includes('application/json')) {
        const originalJson = c.req.json;
        
        c.req.json = async () => {
          const body = await originalJson.call(c.req);
          return converterDatasBrasileirasPorObj(body);
        };
      }
    } catch (error) {
      console.warn('Middleware datas Brasil: erro ao interceptar JSON:', error);
    }
  }
  
  await next();
  
  const response = c.res;
  if (response && method === 'GET') {
    try {
      const originalResponse = await response.clone().json().catch(() => null);
      
      if (originalResponse) {
        const convertedResponse = converterDatasParaBrasil(originalResponse);
        return c.json(convertedResponse);
      }
    } catch (error) {
      console.warn('Middleware datas Brasil: erro na conversão de resposta:', error);
    }
  }
};

/**
 * Lista de campos que são reconhecidos como datas
 */
const CAMPOS_DATA = [
  'data_inicio', 'data_fim', 'data_nascimento', 'data_contratacao',
  'data_emissao', 'data_vencimento', 'data_conclusao', 'data_vencimento',
  'created_at', 'updated_at', 'deleted_at',
  
  'data_certificacao', 'data_renovacao', 'data_certificado',
  'cma_data_vencimento', 'nivel_icao_data_vencimento',
  'aso_data_vencimento', 'data_admissao',
  
  'data_sessao', 'data_agendamento', 'data_execucao',
  'assinatura_aluno_timestamp', 'assinatura_instrutor_timestamp',
  'assinatura_final_instrutor_timestamp', 'assinatura_checador_timestamp',
  'certificacao_automatica_timestamp',
  
  'data_checkin', 'data_checkout', 'data_reserva',
  'data_evento', 'data_notificacao'
];

/**
 * Converte recursivamente campos de data brasileira para Date objects
 */
function converterDatasBrasileirasPorObj(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  
  if (Array.isArray(obj)) {
    return obj.map(item => converterDatasBrasileirasPorObj(item));
  }
  
  const converted: any = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string' && ehCampoData(key)) {
      if (DatesBrasil.validarFormatoBrasil(value)) {
        const dateObj = DatesBrasil.brasilParaDate(value);
        converted[key] = dateObj ? dateObj.toISOString() : value;
      } else if (value.includes('T') || value.match(/^\d{4}-\d{2}-\d{2}/)) {
        converted[key] = value;
      } else {
        converted[key] = value;
      }
    } else if (typeof value === 'object' && value !== null) {
      converted[key] = converterDatasBrasileirasPorObj(value);
    } else {
      converted[key] = value;
    }
  }
  
  return converted;
}

/**
 * Converte recursivamente Date objects/ISO strings para formato brasileiro
 */
function converterDatasParaBrasil(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  
  if (Array.isArray(obj)) {
    return obj.map(item => converterDatasParaBrasil(item));
  }
  
  const converted: any = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === 'string' && ehCampoData(key)) {
      if (value.match(/^\d{4}-\d{2}-\d{2}/) || value.includes('T')) {
        converted[key] = DatesBrasil.converterParaBrasil(value);
      } else {
        converted[key] = value;
      }
    } else if (value instanceof Date) {
      converted[key] = DatesBrasil.isoParaBrasil(value);
    } else if (typeof value === 'object' && value !== null) {
      converted[key] = converterDatasParaBrasil(value);
    } else {
      converted[key] = value;
    }
  }
  
  return converted;
}

/**
 * Verifica se um campo é reconhecido como data
 */
function ehCampoData(nomeField: string): boolean {
  const campo = nomeField.toLowerCase();
  
  if (CAMPOS_DATA.some(c => c.toLowerCase() === campo)) {
    return true;
  }
  
  const padroes = [
    /data_/i,
    /date/i,
    /_at$/i,
    /_date$/i,
    /nascimento/i,
    /validade/i,
    /vencimento/i,
    /conclusao/i,
    /certificacao/i,
    /assinatura/i,
    /timestamp/i
  ];
  
  return padroes.some(padrao => padrao.test(campo));
}

/**
 * Middleware específico para auditoria de datas
 */
export const auditoriaDatasMiddleware = async (c: Context, next: Next) => {
  const method = c.req.method;
  const url = c.req.url;
  
  const conversoes: Array<{campo: string, valorOriginal: any, valorConvertido: any}> = [];
  
  if (['POST', 'PUT', 'PATCH'].includes(method)) {
    try {
      const body = await c.req.json().catch(() => null);
      
      if (body) {
        auditarCamposDatas(body, '', conversoes);
        
        if (conversoes.length > 0) {
          conversoes.forEach(conv => {
          });
        }
      }
    } catch (error) {
      console.warn('Auditoria datas: erro ao processar body:', error);
    }
  }
  
  await next();
};

/**
 * Audita recursivamente os campos de data em um objeto
 */
function auditarCamposDatas(obj: any, caminho: string, conversoes: any[]): void {
  if (!obj || typeof obj !== 'object') return;
  
  if (Array.isArray(obj)) {
    obj.forEach((item, index) => {
      auditarCamposDatas(item, `${caminho}[${index}]`, conversoes);
    });
    return;
  }
  
  for (const [key, value] of Object.entries(obj)) {
    const novoCaminho = caminho ? `${caminho}.${key}` : key;
    
    if (typeof value === 'string' && ehCampoData(key)) {
      if (DatesBrasil.validarFormatoBrasil(value)) {
        const iso = DatesBrasil.brasilParaISO(value);
        conversoes.push({
          campo: novoCaminho,
          valorOriginal: value,
          valorConvertido: iso
        });
      } else if (value.match(/^\d{4}-\d{2}-\d{2}/)) {
        const brasil = DatesBrasil.converterParaBrasil(value);
        conversoes.push({
          campo: novoCaminho,
          valorOriginal: value,
          valorConvertido: brasil
        });
      }
    } else if (typeof value === 'object' && value !== null) {
      auditarCamposDatas(value, novoCaminho, conversoes);
    }
  }
}

/**
 * Wrapper para SQLite que converte datas automaticamente
 */
export class DatesBrasilSQLWrapper {
  
  /**
   * Prepara dados para inserção no banco
   * Converte datas brasileiras para ISO antes de salvar
   */
  static prepararParaBanco(dados: any): any {
    return converterDatasBrasileirasPorObj(dados);
  }
  
  /**
   * Prepara dados vindos do banco para o frontend
   * Converte ISO para datas brasileiras
   */
  static prepararParaFrontend(dados: any): any {
    return converterDatasParaBrasil(dados);
  }
  
  /**
   * Converte WHERE clause com datas brasileiras
   * "data_inicio = '20/09/2025'" → "data_inicio = '2025-09-20'"
   */
  static converterWhereClause(whereClause: string): string {
    const regex = /(\w+)\s*(=|>=|<=|>|<|\sLIKE\s)\s*'(\d{2}\/\d{2}\/\d{4})'/gi;
    
    return whereClause.replace(regex, (match, campo, operador, dataBrasil) => {
      if (DatesBrasil.validarFormatoBrasil(dataBrasil)) {
        const iso = DatesBrasil.brasilParaISO(dataBrasil);
        return `${campo} ${operador} '${iso}'`;
      }
      return match;
    });
  }
}
