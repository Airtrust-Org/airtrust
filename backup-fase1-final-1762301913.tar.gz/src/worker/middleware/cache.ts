import { Context } from 'hono';

/**
 * Cache Middleware para GET requests
 * 
 * Uso:
 * app.get('/', cacheMiddleware(300), async (c) => { ... });
 */

interface CacheOptions {
  ttl?: number; // Time to live em segundos
  key?: (c: Context) => string; // Custom cache key generator
}

export function cacheMiddleware(options: CacheOptions | number = {}) {
  const opts: CacheOptions = typeof options === 'number' ? { ttl: options } : options;
  const ttl = opts.ttl || 300; // 5 minutos default

  return async (c: Context, next: () => Promise<void>) => {
    // Apenas cachear GET requests
    if (c.req.method !== 'GET') {
      return next();
    }

    // Gerar chave de cache
    const cacheKey = opts.key
      ? opts.key(c)
      : `cache:${new URL(c.req.url).pathname}${c.req.url.search}`;

    try {
      // Verificar se tem no KV Cache (simularmos com context)
      // Nota: Em Cloudflare Workers, usar c.env.CACHE (KV namespace)
      // Por enquanto, apenas passar forward

      await next();

      // Cachear respostas bem-sucedidas
      if (c.res.status === 200 && c.env?.CACHE) {
        const body = await c.res.text();
        const cache = c.env.CACHE as unknown as { put: (key: string, value: string, options: { expirationTtl: number }) => Promise<void> };
        await cache.put(cacheKey, body, {
          expirationTtl: ttl,
        });

        // Retornar com header indicando cache
        return new Response(body, {
          status: 200,
          headers: {
            ...c.res.headers,
            'X-Cache': 'MISS',
            'X-Cache-TTL': ttl.toString(),
            'Content-Type': 'application/json',
          },
        });
      }
    } catch (err) {
      // Se cache falhar, continue sem cachear
      console.warn('Cache middleware error:', err);
      await next();
    }
  };
}
