import { MiddlewareHandler } from 'hono';
import { z } from 'zod';

/**
 * Security Middleware para AirTrust
 * Implementa proteções contra ataques comuns
 */

const sanitizeSchema = z.string().max(1000).refine(
  (val) => !/<script[\s\S]*?>[\s\S]*?<\/script>/gi.test(val),
  { message: 'Script tags not allowed' }
).refine(
  (val) => !/javascript:|data:|vbscript:|on\w+\s*=/gi.test(val),
  { message: 'Potentially malicious content detected' }
);

export const securityMiddleware: MiddlewareHandler = async (c, next) => {
  const start = Date.now();
  
  try {
    const clientId = c.req.header('x-forwarded-for') || c.req.header('x-real-ip') || 'unknown';
    
    
    const environment = c.env?.ENVIRONMENT || 'development';
    const cspDirectives = [
      "default-src 'self'",
      environment === 'development' 
        ? "script-src 'self' 'unsafe-inline' 'unsafe-eval'" // Apenas em dev
        : "script-src 'self'", // Produção restritiva
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https:",
      "connect-src 'self' https://api.mocha.com",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "object-src 'none'",
      "upgrade-insecure-requests"
    ];
    
    c.header('Content-Security-Policy', cspDirectives.join('; '));
    
    c.header('X-Content-Type-Options', 'nosniff');
    c.header('X-Frame-Options', 'DENY');
    c.header('X-XSS-Protection', '1; mode=block');
    c.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    c.header('Permissions-Policy', [
      'camera=()',
      'microphone=()',
      'geolocation=()',
      'payment=()'
    ].join(', '));
    
    if (c.req.header('x-forwarded-proto') === 'https') {
      c.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    }
    
    if (['POST', 'PUT', 'PATCH'].includes(c.req.method)) {
      try {
        const body = await c.req.json().catch(() => ({}));
        const path = new URL(c.req.url).pathname;
        
        const BYPASS_ROUTES = [
          '/api/v2/funcionarios-batch',
          '/api/v2/qualificacoes/importar-json',
          '/api/v2/importacoes'
        ];
        
        if (BYPASS_ROUTES.some(route => path.includes(route))) {
          return await next();
        }
        
        const BYPASS_FIELDS = ['csv_data', 'csvdata', 'dados', 'funcionarios', 'qualificacoes'];
        
        for (const field of BYPASS_FIELDS) {
          if (body[field]) {
            delete body[field];
          }
        }
        
        for (const [key, value] of Object.entries(body)) {
          if (typeof value === 'string') {
            try {
              sanitizeSchema.parse(value);
            } catch (error) {
              console.warn(`[Security] Potentially malicious input in field ${key}:`, value.substring(0, 100));
              return c.json({
                error: 'Invalid input detected',
                field: key,
                code: 'SECURITY_VALIDATION_FAILED'
              }, 400);
            }
          }
        }
        
        c.set('validatedBody', body);
      } catch (error) {
      }
    }
    
    const url = c.req.url.toLowerCase();
    const suspiciousPatterns = [
      /drop\s+table/i,
      /delete\s+from/i,
      /insert\s+into.*values/i,
      /update\s+.*set/i,
      /union\s+select/i,
      /or\s+1\s*=\s*1/i,
      /';\s*(drop|delete|insert|update)/i
    ];
    
    for (const pattern of suspiciousPatterns) {
      if (pattern.test(url)) {
        console.error('[Security] SQL injection attempt detected:', url);
        return c.json({
          error: 'Malicious request detected',
          code: 'SQL_INJECTION_BLOCKED'
        }, 403);
      }
    }
    
    await next();
    
    const duration = Date.now() - start;
    
  } catch (error) {
    console.error('[Security] Security middleware error:', error);
    return c.json({
      error: 'Security validation failed',
      code: 'SECURITY_ERROR'
    }, 500);
  }
};

/**
 * Middleware específico para autenticação e autorização
 */
export const authSecurityMiddleware: MiddlewareHandler = async (c, next) => {
  const authHeader = c.req.header('authorization');
  
  if (c.env?.ENVIRONMENT !== 'production') {
    await next();
    return;
  }
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({
      error: 'Missing or invalid authorization header',
      code: 'UNAUTHORIZED'
    }, 401);
  }
  
  const token = authHeader.substring(7);
  
  try {
    
    if (token === 'invalid_token') {
      throw new Error('Invalid token');
    }
    
    await next();
  } catch (error) {
    console.warn('[Security] Invalid JWT token:', error);
    return c.json({
      error: 'Invalid or expired token',
      code: 'INVALID_TOKEN'
    }, 403);
  }
};

/**
 * Utilitários de segurança
 */
export const SecurityUtils = {
  /**
   * Sanitiza string removendo scripts e conteúdo perigoso
   */
  sanitizeString(input: string): string {
    return input
      .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
      .replace(/javascript:|data:|vbscript:/gi, '')
      .replace(/on\w+\s*=/gi, '')
      .trim();
  },
  
  /**
   * Valida se um email é seguro
   */
  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email) && email.length <= 254;
  },
  
  /**
   * Gera hash seguro para logging (não armazena dados sensíveis)
   */
  hashForLogging(data: string): string {
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36);
  }
};

export default securityMiddleware;
