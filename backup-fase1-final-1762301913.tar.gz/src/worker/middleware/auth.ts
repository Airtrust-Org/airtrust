import { AuthService } from '../services/auth-service';
import type { CloudflareD1Database } from '../types';

export const authMiddleware = async (c: any, next: any) => {
  try {
    const authHeader = c.req.header('Authorization');
    
    if (!authHeader?.startsWith('Bearer ')) {
      return c.json({ error: 'Não autenticado', code: 'UNAUTHORIZED' }, 401);
    }

    const token = authHeader.substring(7);
    const user = await AuthService.getUserFromToken(token, c.env.DB as CloudflareD1Database, c.env);

    if (!user) {
      return c.json({ error: 'Não autenticado', code: 'UNAUTHORIZED' }, 401);
    }

    c.set('user', user);
    await next();
  } catch (error) {
    console.error('[AUTH_ERROR]', error);
    return c.json({ error: 'Não autenticado', code: 'UNAUTHORIZED' }, 401);
  }
};
