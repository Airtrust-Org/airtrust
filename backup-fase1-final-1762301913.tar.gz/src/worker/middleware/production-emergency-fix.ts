/**
 * 🚨 MIDDLEWARE DE CORREÇÃO EMERGENCIAL PARA PRODUÇÃO
 * Executa diagnóstico e correção automática no primeiro request
 */

export async function emergencyProductionFix(c: any, next: () => Promise<void>): Promise<void> {
  if (c.env._emergency_fix_executed) {
    await next();
    return;
  }

  try {
    const db = c.env.DB;
    const diagnostics: any = {};

    try {
      const schemaResult = await db.prepare('PRAGMA table_info(funcionarios)').all();
      diagnostics.schema = schemaResult.results || [];
      
      const hasDeletedAt = diagnostics.schema.some((col: any) => col.name === 'deleted_at');
      diagnostics.hasDeletedAt = hasDeletedAt;
      
      
      if (!hasDeletedAt) {
        
        await db.prepare('ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP').run();
        diagnostics.deletedAtAdded = true;
      }
    } catch (schemaError: any) {
      console.error('❌ Erro no diagnóstico de schema:', schemaError);
      diagnostics.schemaError = schemaError?.message || 'Erro desconhecido';
    }

    try {
      const tableSQL = await db.prepare(`SELECT sql FROM sqlite_master WHERE name = 'funcionarios'`).first();
      diagnostics.tableSQL = tableSQL?.sql || '';
      
      const hasFuncaoNotNull = tableSQL?.sql?.includes('funcao TEXT NOT NULL');
      diagnostics.hasFuncaoNotNull = hasFuncaoNotNull;
      
      
      if (hasFuncaoNotNull) {
        diagnostics.needsFuncaoFix = true;
      }
    } catch (constraintError: any) {
      console.error('❌ Erro ao verificar constraints:', constraintError);
      diagnostics.constraintError = constraintError?.message || 'Erro desconhecido';
    }

    try {
      const testFuncionario = await db.prepare(`
        SELECT id, nome FROM funcionarios 
        WHERE deleted_at IS NULL OR deleted_at = '' 
        LIMIT 1
      `).first();
      
      if (testFuncionario) {
        
        const testResult = await db.prepare(`
          SELECT id FROM funcionarios 
          WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '')
        `).bind(testFuncionario.id).first();
        
        diagnostics.testFuncionarioExists = !!testResult;
      }
    } catch (testError: any) {
      console.error('❌ Erro no teste de DELETE:', testError);
      diagnostics.testError = testError?.message || 'Erro desconhecido';
    }

    try {
      const counts = await db.prepare(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN deleted_at IS NULL OR deleted_at = '' THEN 1 END) as ativos,
          COUNT(CASE WHEN deleted_at IS NOT NULL AND deleted_at != '' THEN 1 END) as deletados
        FROM funcionarios
      `).first();
      
      diagnostics.counts = counts;
    } catch (countError: any) {
      console.error('❌ Erro na contagem:', countError);
      diagnostics.countError = countError?.message || 'Erro desconhecido';
    }

    try {
      await db.prepare('CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at)').run();
      
      const cleanupResult = await db.prepare("UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = ''").run();
      diagnostics.cleanupRows = cleanupResult.meta?.changes || 0;
      
    } catch (cleanupError: any) {
      console.error('❌ Erro na limpeza:', cleanupError);
      diagnostics.cleanupError = cleanupError?.message || 'Erro desconhecido';
    }


    c.env._emergency_fix_executed = true;
    c.env._diagnostics = diagnostics;

  } catch (error: any) {
    console.error('❌ ERRO CRÍTICO NO DIAGNÓSTICO EMERGENCIAL:', error);
    c.env._emergency_fix_executed = true; // Evitar loops
  }

  await next();
}

/**
 * Aplicar correção de schema completa se necessário
 */
export async function applySchemaFix(db: any): Promise<boolean> {
  try {
    
    const tableSQL = await db.prepare(`SELECT sql FROM sqlite_master WHERE name = 'funcionarios'`).first();
    
    if (tableSQL?.sql?.includes('funcao TEXT NOT NULL')) {
      
      await db.prepare(`CREATE TABLE funcionarios_backup AS SELECT * FROM funcionarios`).run();
      
      await db.prepare(`DROP TABLE funcionarios`).run();
      
      await db.prepare(`
        CREATE TABLE funcionarios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome TEXT NOT NULL,
          matricula TEXT UNIQUE,
          cpf TEXT,
          codigo_anac TEXT,
          funcao TEXT,  -- SEM NOT NULL
          base TEXT,
          contrato TEXT,
          telefone TEXT,
          email TEXT,
          status TEXT DEFAULT 'ATIVO',
          cma_numero TEXT,
          cma_data_vencimento DATE,
          cma_status TEXT,
          aso_data_vencimento DATE,
          nivel_icao TEXT,
          nivel_icao_data_vencimento DATE,
          nivel_icao_status TEXT,
          is_instrutor INTEGER DEFAULT 0,
          is_checador INTEGER DEFAULT 0,
          aeronave_principal TEXT,
          avatar TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP,
          anv TEXT,
          data_nascimento DATE,
          licenca_aeronautica TEXT,
          codigo_canac TEXT,
          codigo_sispat TEXT,
          codigo_prestserv TEXT,
          data_admissao DATE
        )
      `).run();
      
      await db.prepare(`INSERT INTO funcionarios SELECT * FROM funcionarios_backup`).run();
      
      await db.prepare(`DROP TABLE funcionarios_backup`).run();
      
      return true;
    }
    
    return false;
  } catch (error: any) {
    console.error('❌ Erro na correção de schema:', error);
    return false;
  }
}
