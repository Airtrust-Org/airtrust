/**
 * Integração com Sentry
 * Monitoramento de erros e performance
 */

import { Context, Next } from 'hono';

interface SentryConfig {
  dsn: string;
  environment: string;
  release?: string;
  tracesSampleRate?: number;
}

export class SentryIntegration {
  private config: SentryConfig;
  
  constructor(config: SentryConfig) {
    this.config = config;
  }
  
  /**
   * Middleware para capturar erros
   */
  middleware() {
    return async (c: Context, next: Next) => {
      const startTime = Date.now();
      const transaction = {
        op: 'http.server',
        name: `${c.req.method} ${c.req.path}`,
        startTimestamp: startTime / 1000
      };
      
      try {
        await next();
        
        const duration = Date.now() - startTime;
        if (duration > 1000) { // Alertar se > 1s
          await this.captureMessage('Slow request', {
            level: 'warning',
            extra: {
              path: c.req.path,
              method: c.req.method,
              duration
            }
          });
        }
        
      } catch (error: any) {
        await this.captureException(error, {
          request: {
            url: c.req.url,
            method: c.req.method,
            headers: this.sanitizeHeaders(c.req.header())
          },
          user: c.get('user') || undefined
        });
        
        throw error;
      }
    };
  }
  
  /**
   * Capturar exceção
   */
  async captureException(error: Error, context?: any): Promise<void> {
    try {
      const event = {
        message: error.message,
        level: 'error',
        exception: {
          values: [{
            type: error.name,
            value: error.message,
            stacktrace: this.parseStackTrace(error.stack)
          }]
        },
        timestamp: Date.now() / 1000,
        environment: this.config.environment,
        release: this.config.release,
        ...context
      };
      
      await this.sendToSentry(event);
    } catch (e) {
      console.error('Erro ao enviar para Sentry:', e);
    }
  }
  
  /**
   * Capturar mensagem
   */
  async captureMessage(message: string, context?: any): Promise<void> {
    try {
      const event = {
        message,
        level: context?.level || 'info',
        timestamp: Date.now() / 1000,
        environment: this.config.environment,
        release: this.config.release,
        ...context
      };
      
      await this.sendToSentry(event);
    } catch (e) {
      console.error('Erro ao enviar para Sentry:', e);
    }
  }
  
  /**
   * Enviar evento para Sentry
   */
  private async sendToSentry(event: any): Promise<void> {
    const url = `https://sentry.io/api/${this.extractProjectId()}/store/`;
    
    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Sentry-Auth': this.getAuthHeader()
      },
      body: JSON.stringify(event)
    });
  }
  
  /**
   * Sanitizar headers (remover dados sensíveis)
   */
  private sanitizeHeaders(headers: any): any {
    const sanitized = { ...headers };
    delete sanitized.authorization;
    delete sanitized.cookie;
    return sanitized;
  }
  
  /**
   * Parse stack trace
   */
  private parseStackTrace(stack?: string): any {
    if (!stack) return { frames: [] };
    
    const frames = stack.split('\n').map(line => ({
      filename: line,
      function: line
    }));
    
    return { frames };
  }
  
  /**
   * Extrair project ID do DSN
   */
  private extractProjectId(): string {
    const match = this.config.dsn.match(/sentry\.io\/(\d+)/);
    return match ? match[1] : '';
  }
  
  /**
   * Gerar header de autenticação
   */
  private getAuthHeader(): string {
    const key = this.config.dsn.split('@')[0].split('//')[1];
    return `Sentry sentry_version=7, sentry_key=${key}`;
  }
}

/**
 * Factory function
 */
export function createSentryMiddleware(config: SentryConfig) {
  const sentry = new SentryIntegration(config);
  return sentry.middleware();
}
