
import { Context, Next } from 'hono';

interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const rateLimitStore = new Map<string, RateLimitRecord>();
const blacklist = new Set<string>();
const BLACKLIST_THRESHOLD = 100; // Bloquear após 100 tentativas em 1 minuto

export const rateLimiter = (options: {
  windowMs?: number;
  maxRequests?: number;
} = {}) => {
  const windowMs = options.windowMs || 60000; // 1 minuto
  const maxRequests = options.maxRequests || 30; // 30 requisições (reduzido de 100)

  return async (c: Context, next: Next) => {
    const ip = c.req.header('cf-connecting-ip') || 
               c.req.header('x-forwarded-for') || 
               c.req.header('x-real-ip') || 
               'unknown';

    if (blacklist.has(ip)) {
      console.warn(`[RATE LIMIT] IP bloqueado tentou acessar: ${ip}`);
      return c.json({
        success: false,
        error: 'IP bloqueado',
        message: 'Seu IP foi bloqueado devido a excesso de requisições. Contate o suporte.'
      }, 403);
    }

    const now = Date.now();
    const record = rateLimitStore.get(ip);

    if (Math.random() < 0.01) { // 1% de chance
      for (const [key, value] of rateLimitStore.entries()) {
        if (now > value.resetAt) {
          rateLimitStore.delete(key);
        }
      }
    }

    if (!record || now > record.resetAt) {
      rateLimitStore.set(ip, {
        count: 1,
        resetAt: now + windowMs
      });
      
      c.header('X-RateLimit-Limit', maxRequests.toString());
      c.header('X-RateLimit-Remaining', (maxRequests - 1).toString());
      c.header('X-RateLimit-Reset', new Date(now + windowMs).toISOString());
      
      return next();
    }

    if (record.count >= maxRequests) {
      if (record.count >= BLACKLIST_THRESHOLD) {
        blacklist.add(ip);
        console.error(`[RATE LIMIT] IP adicionado à blacklist: ${ip} (${record.count} requisições)`);
        
        return c.json({
          success: false,
          error: 'IP bloqueado',
          message: 'Seu IP foi bloqueado permanentemente devido a excesso de requisições.'
        }, 403);
      }
      
      c.header('X-RateLimit-Limit', maxRequests.toString());
      c.header('X-RateLimit-Remaining', '0');
      c.header('X-RateLimit-Reset', new Date(record.resetAt).toISOString());
      c.header('Retry-After', Math.ceil((record.resetAt - now) / 1000).toString());
      
      console.warn(`[RATE LIMIT] IP ${ip} excedeu limite: ${record.count}/${maxRequests}`);
      
      return c.json({
        success: false,
        error: 'Rate limit excedido',
        message: `Você excedeu o limite de ${maxRequests} requisições por minuto. Tente novamente em ${Math.ceil((record.resetAt - now) / 1000)} segundos.`,
        retryAfter: Math.ceil((record.resetAt - now) / 1000)
      }, 429);
    }

    record.count++;
    rateLimitStore.set(ip, record);
    
    c.header('X-RateLimit-Limit', maxRequests.toString());
    c.header('X-RateLimit-Remaining', (maxRequests - record.count).toString());
    c.header('X-RateLimit-Reset', new Date(record.resetAt).toISOString());
    
    return next();
  };
};
