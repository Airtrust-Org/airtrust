/**
 * Métricas de Observabilidade
 * Coleta métricas de performance e uso
 */

import { Context, Next } from 'hono';

interface MetricData {
  endpoint: string;
  method: string;
  status: number;
  duration: number;
  timestamp: number;
}

class MetricsCollector {
  private metrics: MetricData[] = [];
  private readonly MAX_METRICS = 1000;
  
  /**
   * Registrar métrica
   */
  record(data: MetricData): void {
    this.metrics.push(data);
    
    if (this.metrics.length > this.MAX_METRICS) {
      this.metrics.shift();
    }
  }
  
  /**
   * Calcular estatísticas
   */
  getStats(): any {
    if (this.metrics.length === 0) {
      return {
        total_requests: 0,
        avg_duration: 0,
        p50: 0,
        p95: 0,
        p99: 0
      };
    }
    
    const durations = this.metrics.map(m => m.duration).sort((a, b) => a - b);
    const total = durations.reduce((sum, d) => sum + d, 0);
    
    return {
      total_requests: this.metrics.length,
      avg_duration: Math.round(total / this.metrics.length),
      p50: this.percentile(durations, 50),
      p95: this.percentile(durations, 95),
      p99: this.percentile(durations, 99),
      min: durations[0],
      max: durations[durations.length - 1]
    };
  }
  
  /**
   * Estatísticas por endpoint
   */
  getStatsByEndpoint(): any {
    const byEndpoint: Record<string, MetricData[]> = {};
    
    for (const metric of this.metrics) {
      const key = `${metric.method} ${metric.endpoint}`;
      if (!byEndpoint[key]) {
        byEndpoint[key] = [];
      }
      byEndpoint[key].push(metric);
    }
    
    const stats: Record<string, any> = {};
    for (const [endpoint, metrics] of Object.entries(byEndpoint)) {
      const durations = metrics.map(m => m.duration);
      const total = durations.reduce((sum, d) => sum + d, 0);
      
      stats[endpoint] = {
        count: metrics.length,
        avg_duration: Math.round(total / metrics.length),
        min: Math.min(...durations),
        max: Math.max(...durations)
      };
    }
    
    return stats;
  }
  
  /**
   * Taxa de erro
   */
  getErrorRate(): any {
    const total = this.metrics.length;
    const errors = this.metrics.filter(m => m.status >= 400).length;
    
    return {
      total_requests: total,
      errors,
      error_rate: total > 0 ? ((errors / total) * 100).toFixed(2) + '%' : '0%',
      by_status: this.getErrorsByStatus()
    };
  }
  
  /**
   * Erros por status code
   */
  private getErrorsByStatus(): Record<number, number> {
    const byStatus: Record<number, number> = {};
    
    for (const metric of this.metrics) {
      if (metric.status >= 400) {
        byStatus[metric.status] = (byStatus[metric.status] || 0) + 1;
      }
    }
    
    return byStatus;
  }
  
  /**
   * Calcular percentil
   */
  private percentile(sorted: number[], p: number): number {
    const index = Math.ceil((p / 100) * sorted.length) - 1;
    return sorted[index] || 0;
  }
  
  /**
   * Limpar métricas antigas
   */
  clear(): void {
    this.metrics = [];
  }
}

const metricsCollector = new MetricsCollector();

/**
 * Middleware de métricas
 */
export const metricsMiddleware = async (c: Context, next: Next) => {
  const startTime = Date.now();
  
  await next();
  
  const duration = Date.now() - startTime;
  
  metricsCollector.record({
    endpoint: c.req.path,
    method: c.req.method,
    status: c.res.status,
    duration,
    timestamp: Date.now()
  });
};

/**
 * Endpoint de métricas
 */
export function getMetrics() {
  return {
    stats: metricsCollector.getStats(),
    by_endpoint: metricsCollector.getStatsByEndpoint(),
    errors: metricsCollector.getErrorRate(),
    timestamp: new Date().toISOString()
  };
}

export { metricsCollector };
