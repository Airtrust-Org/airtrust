/**
 * MIDDLEWARE DE HEALTH CHECK NO STARTUP
 * Verifica a saúde da aplicação e executa correções automáticas
 */

export async function startupHealthCheck(c: any): Promise<boolean> {
  try {
    
    const db = c.env.DB;
    
    await db.prepare('SELECT 1').first();
    
    const essentialTables = ['funcionarios', 'funcoes', 'catalogo_treinamentos_v2', 'historico_certificacoes_v2'];
    
    for (const table of essentialTables) {
      try {
        await db.prepare(`SELECT COUNT(*) FROM ${table} LIMIT 1`).first();
      } catch (error) {
        console.error(`❌ Problema com tabela ${table}:`, error);
        return false;
      }
    }
    
    const funcionariosCount = await db.prepare(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN deleted_at IS NULL OR deleted_at = '' THEN 1 END) as ativos,
        COUNT(CASE WHEN deleted_at IS NOT NULL AND deleted_at != '' THEN 1 END) as deletados
      FROM funcionarios
    `).first();
    
    
    try {
      const testQuery = await db.prepare(`
        SELECT id FROM funcionarios 
        WHERE deleted_at IS NULL OR deleted_at = '' 
        LIMIT 1
      `).first();
      
      if (testQuery) {
        await db.prepare(`
          SELECT id FROM funcionarios 
          WHERE id = ? AND (deleted_at IS NULL OR deleted_at = '')
        `).bind(testQuery.id).first();
        
      }
    } catch (error) {
      console.warn('⚠️ Teste de soft delete falhou:', error);
    }
    
    return true;
    
  } catch (error) {
    console.error('❌ Health check de startup falhou:', error);
    return false;
  }
}

/**
 * Middleware que executa health check automático
 */
export function createStartupHealthMiddleware() {
  let healthCheckExecuted = false;
  
  return async (c: any, next: () => Promise<void>) => {
    if (!healthCheckExecuted) {
      const isHealthy = await startupHealthCheck(c);
      healthCheckExecuted = true;
      
      if (!isHealthy) {
        console.warn('⚠️ Sistema com problemas de saúde, mas continuando...');
      }
    }
    
    await next();
  };
}
