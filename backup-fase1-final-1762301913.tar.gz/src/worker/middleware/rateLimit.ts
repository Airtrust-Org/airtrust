/**
 * Rate Limiting Middleware
 * Proteção contra ataques DoS e uso abusivo
 */

import { Context } from 'hono';

interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
  message?: string;
}

/**
 * Rate limiter usando Cloudflare Workers KV
 */
export function rateLimitByIP(config: RateLimitConfig) {
  return async (c: Context, next: () => Promise<void>) => {
    const ip = c.req.header('CF-Connecting-IP') || c.req.header('X-Forwarded-For') || 'unknown';
    const path = c.req.path;
    const key = `ratelimit:${path}:${ip}`;
    
    try {
      if (!c.env.KV) {
        console.warn('[RATE LIMIT] KV não configurado, pulando rate limit');
        await next();
        return;
      }
      
      const currentStr = await c.env.KV.get(key);
      const current = currentStr ? parseInt(currentStr) : 0;
      
      if (current >= config.maxRequests) {
        console.warn(`[RATE LIMIT] IP ${ip} excedeu limite em ${path}`);
        return c.json({
          error: config.message || 'Rate limit excedido',
          message: `Máximo ${config.maxRequests} requisições por ${config.windowMs / 1000} segundos`,
          retry_after: config.windowMs / 1000
        }, 429);
      }
      
      await c.env.KV.put(key, String(current + 1), {
        expirationTtl: Math.floor(config.windowMs / 1000)
      });
      
      c.header('X-RateLimit-Limit', String(config.maxRequests));
      c.header('X-RateLimit-Remaining', String(config.maxRequests - current - 1));
      c.header('X-RateLimit-Reset', String(Date.now() + config.windowMs));
      
      await next();
      
    } catch (error) {
      console.error('[RATE LIMIT] Erro:', error);
      await next();
    }
  };
}

/**
 * Rate limiter por usuário autenticado
 */
export function rateLimitByUser(config: RateLimitConfig) {
  return async (c: Context, next: () => Promise<void>) => {
    const user = c.get('user');
    const userId = user?.id || 'anonymous';
    const path = c.req.path;
    const key = `ratelimit:${path}:user:${userId}`;
    
    try {
      if (!c.env.KV) {
        console.warn('[RATE LIMIT] KV não configurado, pulando rate limit');
        await next();
        return;
      }
      
      const currentStr = await c.env.KV.get(key);
      const current = currentStr ? parseInt(currentStr) : 0;
      
      if (current >= config.maxRequests) {
        console.warn(`[RATE LIMIT] Usuário ${userId} excedeu limite em ${path}`);
        return c.json({
          error: config.message || 'Rate limit excedido',
          message: `Máximo ${config.maxRequests} requisições por ${config.windowMs / 1000} segundos`,
          retry_after: config.windowMs / 1000
        }, 429);
      }
      
      await c.env.KV.put(key, String(current + 1), {
        expirationTtl: Math.floor(config.windowMs / 1000)
      });
      
      c.header('X-RateLimit-Limit', String(config.maxRequests));
      c.header('X-RateLimit-Remaining', String(config.maxRequests - current - 1));
      c.header('X-RateLimit-Reset', String(Date.now() + config.windowMs));
      
      await next();
      
    } catch (error) {
      console.error('[RATE LIMIT] Erro:', error);
      await next();
    }
  };
}

/**
 * Configurações pré-definidas
 */
export const RateLimitPresets = {
  IMPORT: {
    maxRequests: 10,
    windowMs: 60 * 60 * 1000, // 1 hora
    message: 'Limite de importações excedido'
  },
  
  CREATE: {
    maxRequests: 100,
    windowMs: 60 * 60 * 1000,
    message: 'Limite de criações excedido'
  },
  
  UPDATE: {
    maxRequests: 200,
    windowMs: 60 * 60 * 1000,
    message: 'Limite de atualizações excedido'
  },
  
  DELETE: {
    maxRequests: 50,
    windowMs: 60 * 60 * 1000,
    message: 'Limite de exclusões excedido'
  },
  
  READ: {
    maxRequests: 1000,
    windowMs: 60 * 60 * 1000,
    message: 'Limite de consultas excedido'
  }
};
