/**
 * Rate Limiting para endpoints de Qualificações
 * Protege contra abuse e DDoS
 */

import { Context } from 'hono';

interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
}

const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

/**
 * Middleware de rate limiting
 */
export function rateLimitQualificacoes(config: RateLimitConfig = {
  windowMs: 15 * 60 * 1000, // 15 minutos
  maxRequests: 100, // 100 requests
}) {
  return async (c: Context, next: () => Promise<void>) => {
    const ip = c.req.header('cf-connecting-ip') || 
               c.req.header('x-forwarded-for') || 
               'unknown';
    
    const now = Date.now();
    const key = `ratelimit:${ip}`;
    
    // Limpar entradas expiradas
    if (rateLimitStore.size > 10000) {
      for (const [k, v] of rateLimitStore.entries()) {
        if (v.resetTime < now) {
          rateLimitStore.delete(k);
        }
      }
    }
    
    let record = rateLimitStore.get(key);
    
    // Se não existe ou expirou, criar novo
    if (!record || record.resetTime < now) {
      record = {
        count: 0,
        resetTime: now + config.windowMs,
      };
      rateLimitStore.set(key, record);
    }
    
    // Incrementar contador
    record.count++;
    
    // Verificar se excedeu o limite
    if (record.count > config.maxRequests) {
      const retryAfter = Math.ceil((record.resetTime - now) / 1000);
      
      return c.json({
        success: false,
        error: 'Too many requests',
        message: `Rate limit exceeded. Try again in ${retryAfter} seconds.`,
        retryAfter,
      }, 429, {
        'Retry-After': retryAfter.toString(),
        'X-RateLimit-Limit': config.maxRequests.toString(),
        'X-RateLimit-Remaining': '0',
        'X-RateLimit-Reset': new Date(record.resetTime).toISOString(),
      });
    }
    
    // Adicionar headers informativos
    c.header('X-RateLimit-Limit', config.maxRequests.toString());
    c.header('X-RateLimit-Remaining', (config.maxRequests - record.count).toString());
    c.header('X-RateLimit-Reset', new Date(record.resetTime).toISOString());
    
    await next();
  };
}

/**
 * Rate limit mais restritivo para operações de escrita
 */
export const rateLimitWrite = rateLimitQualificacoes({
  windowMs: 5 * 60 * 1000, // 5 minutos
  maxRequests: 20, // 20 requests
});

/**
 * Rate limit padrão para leitura
 */
export const rateLimitRead = rateLimitQualificacoes({
  windowMs: 15 * 60 * 1000, // 15 minutos
  maxRequests: 100, // 100 requests
});
