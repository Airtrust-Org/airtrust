/**
 * src/worker/middleware/auditMiddleware.ts
 * Middleware para extrair contexto de auditoria de requisições
 */

import type { Context, Next } from 'hono';
import crypto from 'crypto';

export interface AuditContext {
  userId: number;
  userEmail: string;
  userRole: string;
  timestamp: string;
  requestId: string;
}

export async function auditMiddleware(context: Context, next: Next) {
  try {
    const authHeader = context.req.header('Authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      context.set('audit', null);
      context.set('requestId', crypto.randomUUID());
      await next();
      return;
    }

    // Decodificar JWT - usar sua função existente
    // const decoded = decodeJWT(token);
    
    // Por enquanto, extrair do header (ajustar conforme sua implementação)
    try {
      // Placeholder - substituir com decodeJWT real do projeto
      const decoded = JSON.parse(
        Buffer.from(token.split('.')[1], 'base64').toString()
      );

      const auditContext: AuditContext = {
        userId: decoded.id || decoded.sub,
        userEmail: decoded.email,
        userRole: decoded.role || 'user',
        timestamp: new Date().toISOString(),
        requestId: crypto.randomUUID(),
      };

      context.set('audit', auditContext);
      context.set('userId', decoded.id || decoded.sub);
      context.set('requestId', auditContext.requestId);
    } catch {
      context.set('audit', null);
      context.set('requestId', crypto.randomUUID());
    }

    await next();
  } catch (error) {
    context.set('audit', null);
    context.set('requestId', crypto.randomUUID());
    await next();
  }
}

export function getAuditContext(context: Context): AuditContext | null {
  return context.get('audit') || null;
}

export function getRequestId(context: Context): string {
  return context.get('requestId') || 'unknown';
}
