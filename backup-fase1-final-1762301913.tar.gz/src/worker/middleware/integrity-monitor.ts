import { MiddlewareHandler } from 'hono';
import { validateReferentialIntegrity } from '../services/validation';

/**
 * Monitor de Integridade em Tempo Real
 * Executa verificações críticas APÓS operações de escrita
 */
export const integrityMonitor: MiddlewareHandler = async (c, next) => {
  await next();
  
  const method = c.req.method;
  if (!['POST', 'PUT', 'DELETE'].includes(method)) {
    return;
  }

  try {
    const violations = await validateReferentialIntegrity(c);
    
    if (violations.length > 0) {
      console.error('🚨 INTEGRITY VIOLATION DETECTED:', {
        violations,
        timestamp: new Date().toISOString(),
        endpoint: c.req.url,
        method: c.req.method
      });
      
      const environment = c.env?.ENVIRONMENT || 'development';
      if (environment === 'production') {
        console.error('⛔ CRITICAL: Integrity violations in production!');
      }
    } else {
    }
  } catch (error) {
    console.error('❌ INTEGRITY MONITOR ERROR:', error);
  }
};
