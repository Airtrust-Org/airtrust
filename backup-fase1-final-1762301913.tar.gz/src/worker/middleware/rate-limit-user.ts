/**
 * Rate Limiting por Usuário
 * Limites diferentes para anônimos, autenticados e admins
 */

import { Context, Next } from 'hono';

interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const rateLimitStore = new Map<string, RateLimitRecord>();

interface RateLimitConfig {
  anonymous: number;      // req/hour
  authenticated: number;  // req/hour
  admin: number;         // req/hour ou Infinity
}

const DEFAULT_CONFIG: RateLimitConfig = {
  anonymous: 100,
  authenticated: 1000,
  admin: Infinity
};

export const rateLimiterByUser = (config: Partial<RateLimitConfig> = {}) => {
  const finalConfig = { ...DEFAULT_CONFIG, ...config };
  const windowMs = 60 * 60 * 1000; // 1 hora
  
  return async (c: Context, next: Next) => {
    const user = c.get('user') as any;
    const ip = c.req.header('cf-connecting-ip') || 
               c.req.header('x-forwarded-for') || 
               'unknown';
    
    let maxRequests: number;
    let key: string;
    
    if (!user) {
      maxRequests = finalConfig.anonymous;
      key = `anon:${ip}`;
    } else if (user.role === 'admin' || user.role === 'ADMIN') {
      maxRequests = finalConfig.admin;
      key = `admin:${user.id}`;
    } else {
      maxRequests = finalConfig.authenticated;
      key = `user:${user.id}`;
    }
    
    if (maxRequests === Infinity) {
      return next();
    }
    
    const now = Date.now();
    const record = rateLimitStore.get(key);
    
    if (Math.random() < 0.01) {
      for (const [k, v] of rateLimitStore.entries()) {
        if (now > v.resetAt) {
          rateLimitStore.delete(k);
        }
      }
    }
    
    if (!record || now > record.resetAt) {
      rateLimitStore.set(key, {
        count: 1,
        resetAt: now + windowMs
      });
      
      c.header('X-RateLimit-Limit', maxRequests.toString());
      c.header('X-RateLimit-Remaining', (maxRequests - 1).toString());
      c.header('X-RateLimit-Reset', new Date(now + windowMs).toISOString());
      
      return next();
    }
    
    if (record.count >= maxRequests) {
      c.header('X-RateLimit-Limit', maxRequests.toString());
      c.header('X-RateLimit-Remaining', '0');
      c.header('X-RateLimit-Reset', new Date(record.resetAt).toISOString());
      c.header('Retry-After', Math.ceil((record.resetAt - now) / 1000).toString());
      
      return c.json({
        success: false,
        error: 'Rate limit excedido',
        message: `Limite de ${maxRequests} requisições por hora excedido. Tente novamente em ${Math.ceil((record.resetAt - now) / 1000 / 60)} minutos.`,
        retryAfter: Math.ceil((record.resetAt - now) / 1000),
        userType: user ? (user.role === 'admin' ? 'admin' : 'authenticated') : 'anonymous'
      }, 429);
    }
    
    record.count++;
    rateLimitStore.set(key, record);
    
    c.header('X-RateLimit-Limit', maxRequests.toString());
    c.header('X-RateLimit-Remaining', (maxRequests - record.count).toString());
    c.header('X-RateLimit-Reset', new Date(record.resetAt).toISOString());
    
    return next();
  };
};
