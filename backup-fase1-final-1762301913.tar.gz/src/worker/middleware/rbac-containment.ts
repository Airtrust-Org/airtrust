import { Context } from 'hono';
import { Logger } from '../utils/structured-logger';

/**
 * Middleware para validar role do usuário
 * Permite acesso apenas para roles específicas
 */
export function checkRole(allowedRoles: string[]) {
  return async (c: Context, next: () => Promise<void>) => {
    const user = c.get('user');
    
    if (!user) {
      Logger.warn('[RBAC] Acesso negado: usuário não autenticado', {
        path: c.req.path,
        ip: c.req.header('cf-connecting-ip'),
      });
      
      return c.json({
        error: 'Unauthorized',
        message: 'Usuário não autenticado'
      }, 401);
    }
    
    // Verificar se role do usuário está na lista de roles permitidas
    if (!allowedRoles.includes(user.perfil)) {
      Logger.warn('[RBAC] Acesso negado: role insuficiente', {
        user_id: user.id,
        user_role: user.perfil,
        required_roles: allowedRoles,
        path: c.req.path,
        ip: c.req.header('cf-connecting-ip'),
      });
      
      return c.json({
        error: 'Forbidden',
        message: 'Você não tem permissão para acessar este recurso',
        required_roles: allowedRoles,
        your_role: user.perfil
      }, 403);
    }
    
    Logger.info('[RBAC] Acesso permitido', {
      user_id: user.id,
      user_role: user.perfil,
      path: c.req.path,
    });
    
    await next();
  };
}

/**
 * Middleware para validar permissão específica
 * Permite acesso apenas com permissão em tabela role_permissions
 */
export function checkPermission(resource: string, action: string) {
  return async (c: Context, next: () => Promise<void>) => {
    const user = c.get('user');
    
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    // TODO: Implementar validação contra tabela role_permissions em ETAPA 2
    // Por enquanto: apenas ADMIN tem permissão em recursos críticos
    if (user.perfil !== 'ADMIN') {
      Logger.warn('[RBAC] Acesso negado: permissão insuficiente', {
        user_id: user.id,
        resource,
        action,
        path: c.req.path,
      });
      
      return c.json({
        error: 'Forbidden',
        message: 'Você não tem permissão para este recurso',
        resource,
        action
      }, 403);
    }
    
    await next();
  };
}
