/**
 * Security Headers Middleware
 * Adiciona headers de segurança em todas as respostas
 */

import { Context } from 'hono';

/**
 * Content Security Policy
 */
const CSP_DIRECTIVES = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // unsafe-eval necessário para Vite dev
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: https:",
  "font-src 'self' data:",
  "connect-src 'self' https://cloudflare.com",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

/**
 * Middleware de Security Headers
 */
export function securityHeaders() {
  return async (c: Context, next: () => Promise<void>) => {
    await next();
    
    // Content Security Policy
    c.header('Content-Security-Policy', CSP_DIRECTIVES);
    
    // Prevenir MIME sniffing
    c.header('X-Content-Type-Options', 'nosniff');
    
    // Prevenir clickjacking
    c.header('X-Frame-Options', 'DENY');
    
    // XSS Protection (legacy, mas ainda útil)
    c.header('X-XSS-Protection', '1; mode=block');
    
    // Referrer Policy
    c.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    // Permissions Policy
    c.header('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    
    // HSTS (apenas em produção)
    if (c.req.url.startsWith('https://')) {
      c.header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    }
  };
}

/**
 * CORS Headers para API
 */
export function corsHeaders(allowedOrigins: string[] = ['*']) {
  return async (c: Context, next: () => Promise<void>) => {
    const origin = c.req.header('Origin') || '';
    
    // Verificar se origem é permitida
    const isAllowed = allowedOrigins.includes('*') || allowedOrigins.includes(origin);
    
    if (isAllowed) {
      c.header('Access-Control-Allow-Origin', origin || '*');
      c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      c.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      c.header('Access-Control-Max-Age', '86400');
      c.header('Access-Control-Allow-Credentials', 'true');
    }
    
    // Handle preflight
    if (c.req.method === 'OPTIONS') {
      return new Response('', { status: 204 });
    }
    
    await next();
  };
}
