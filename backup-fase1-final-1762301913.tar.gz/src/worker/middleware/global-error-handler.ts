/**
 * Global Error Handler Middleware
 * ================================
 * Responsabilidades:
 * 1. Capturar exceções não tratadas
 * 2. Logar com contexto (stack trace, request)
 * 3. Implementar retry para falhas de conexão
 * 4. Retornar response AppError padronizada
 * 5. Rastrear requests com ID único
 */

import { Context } from 'hono';
import { AppError } from '../utils/AppError';
import { Logger } from '../utils/logger';

export const REQUEST_ID_HEADER = 'X-Request-ID';

export function generateRequestId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Retry com backoff exponencial
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  initialDelayMs: number = 100,
): Promise<T> {
  let lastError: Error = new Error('Unknown error');

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      // Não fazer retry em certos tipos de erro
      if (lastError.message.includes('not found') || lastError.message.includes('validation')) {
        throw lastError;
      }

      if (attempt < maxRetries) {
        const delayMs = initialDelayMs * Math.pow(2, attempt);
        Logger.debug(`Retry attempt ${attempt + 1}/${maxRetries} in ${delayMs}ms`, {
          error: lastError.message,
        });
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }

  throw lastError;
}

/**
 * Classificar tipo de erro para melhor resposta
 */
export function classifyError(error: unknown): {
  type: 'validation' | 'auth' | 'notfound' | 'timeout' | 'db' | 'storage' | 'external' | 'unknown';
  statusCode: number;
  isRetryable: boolean;
} {
  const msg = error instanceof Error ? error.message : String(error);

  if (msg.includes('validation') || msg.includes('invalid')) {
    return { type: 'validation', statusCode: 400, isRetryable: false };
  }
  if (msg.includes('unauthorized') || msg.includes('auth')) {
    return { type: 'auth', statusCode: 401, isRetryable: false };
  }
  if (msg.includes('not found') || msg.includes('404')) {
    return { type: 'notfound', statusCode: 404, isRetryable: false };
  }
  if (msg.includes('timeout') || msg.includes('timed out')) {
    return { type: 'timeout', statusCode: 504, isRetryable: true };
  }
  if (msg.includes('database') || msg.includes('D1') || msg.includes('sql')) {
    return { type: 'db', statusCode: 503, isRetryable: true };
  }
  if (msg.includes('R2') || msg.includes('storage')) {
    return { type: 'storage', statusCode: 503, isRetryable: true };
  }
  if (msg.includes('external') || msg.includes('api')) {
    return { type: 'external', statusCode: 502, isRetryable: true };
  }

  return { type: 'unknown', statusCode: 500, isRetryable: false };
}

/**
 * Middleware: Capturar e tratar erro globalmente
 */
export function globalErrorHandler() {
  return async (c: Context, next: () => Promise<void>): Promise<Response | void> => {
    const requestId = generateRequestId();
    c.set(REQUEST_ID_HEADER, requestId);

    const startTime = Date.now();

    try {
      await next();

      // Log de sucesso para requests lentos
      const duration = Date.now() - startTime;
      if (duration > 1000) {
        Logger.debug(`Slow request: ${c.req.method} ${c.req.path} took ${duration}ms`, {
          requestId,
          method: c.req.method,
          path: c.req.path,
          duration,
        });
      }
    } catch (error) {
      const duration = Date.now() - startTime;
      const classification = classifyError(error);

      // Logging estruturado
      const errorMessage =
        error instanceof Error ? error.message : `${typeof error} - ${String(error)}`;
      const errorStack = error instanceof Error ? error.stack : '';

      Logger.error(`Request failed: ${c.req.method} ${c.req.path}`, error as Error, {
        requestId,
        method: c.req.method,
        path: c.req.path,
        duration,
        classification: classification.type,
        statusCode: classification.statusCode,
        isRetryable: classification.isRetryable,
        timestamp: new Date().toISOString(),
        stack: errorStack,
      });

      // Retornar response padronizada
      const appError = new AppError(
        errorMessage,
        classification.statusCode,
        classification.type.toUpperCase(),
      );

      const responseBody = {
        ...appError.toJSON(),
        requestId,
        isRetryable: classification.isRetryable,
      };

      // Cast status code para ContentfulStatusCode válido
      const statusCode = Math.min(Math.max(classification.statusCode, 200), 599);
      return c.json(responseBody, statusCode as 200);
    }
  };
}

/**
 * Error Boundary com retry: Para operations críticas
 */
export async function withErrorBoundary<T>(
  operation: () => Promise<T>,
  operationName: string,
  options?: {
    maxRetries?: number;
    timeoutMs?: number;
    requestId?: string;
  },
): Promise<T> {
  const { maxRetries = 2, timeoutMs = 15000, requestId = 'unknown' } = options || {};

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await retryWithBackoff(
      async () => {
        try {
          return await Promise.race([
            operation(),
            new Promise<T>((_, reject) =>
              controller.signal.addEventListener('abort', () => {
                reject(new Error(`Operation ${operationName} timed out after ${timeoutMs}ms`));
              }),
            ),
          ]);
        } catch (err) {
          const error = err instanceof Error ? err : new Error(String(err));
          Logger.warn(`Operation ${operationName} failed`, {
            requestId,
            error: error.message,
          });
          throw error;
        }
      },
      maxRetries,
      100,
    );
  } catch (error) {
    const classification = classifyError(error);
    Logger.error(`Error boundary caught: ${operationName}`, error as Error, {
      requestId,
      classification: classification.type,
    });
    throw new AppError(
      error instanceof Error ? error.message : `${operationName} failed`,
      classification.statusCode,
      `${operationName}_ERROR`,
    );
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Wrapper para D1 operations com retry
 */
export async function withD1Error<T>(
  operation: () => Promise<T>,
  context?: { requestId?: string; operationName?: string },
): Promise<T> {
  return withErrorBoundary(operation, context?.operationName || 'D1_OPERATION', {
    maxRetries: 3,
    timeoutMs: 15000,
    requestId: context?.requestId,
  });
}

/**
 * Wrapper para R2 operations com retry
 */
export async function withR2Error<T>(
  operation: () => Promise<T>,
  context?: { requestId?: string; operationName?: string },
): Promise<T> {
  return withErrorBoundary(operation, context?.operationName || 'R2_OPERATION', {
    maxRetries: 2,
    timeoutMs: 30000,
    requestId: context?.requestId,
  });
}
