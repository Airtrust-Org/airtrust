import { Context, Next } from 'hono';

/**
 * Middleware para garantir respostas JSON limpas
 * Remove qualquer output anterior e garante Content-Type correto
 */
export const cleanResponse = async (c: Context, next: Next) => {
  await next();
  
  const contentType = c.res.headers.get('content-type');
  if (contentType?.includes('json')) {
    c.res.headers.set('Content-Type', 'application/json; charset=utf-8');
  }
};
