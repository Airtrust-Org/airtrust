import { MiddlewareHandler } from 'hono';
import { User, UserRole } from '../types/index';
import { Logger } from '../utils/logger';
import { z } from 'zod';

/**
 * SECURITY FIXES:
 * - Fixed inconsistent permission values (all uppercase)
 * - Added owner-based access checks for data resources
 * - Added audit logging for all permission checks
 * - Added input validation for module/action names
 * - Added proper type checking and error handling
 * - Added success audit logging
 * - Note: For production, consider loading from DB instead of hardcoding
 */

const PermissionsSchema = z.enum(['CREATE', 'READ', 'UPDATE', 'DELETE', 'LIST', 'EXPORT', 'IMPORT']);
const ModuleSchema = z.string().regex(/^[a-z_]+$/, 'Invalid module name').min(1).max(50);

// ===== PERMISSIONS MATRIX - Consider moving to database for runtime updates =====
const PERMISSIONS_MATRIX: Record<UserRole, Record<string, string[]>> = {
  ADMIN: {
    funcionarios: ['CREATE', 'READ', 'UPDATE', 'DELETE', 'EXPORT', 'IMPORT'],
    funcoes: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    system: ['READ', 'HEALTH_CHECK'],
    auditoria: ['READ', 'EXPORT'],
    treinamentos: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    compliance: ['READ', 'UPDATE'],
    dashboard: ['READ'],
    aeronaves: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    pasta_virtual: ['READ', 'UPDATE', 'DELETE'],
    simuladores: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    simulador: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    qualificacoes: ['CREATE', 'READ', 'UPDATE', 'DELETE', 'EXPORT', 'IMPORT'],
    certificados: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
  },
  COMPLIANCE: {
    funcionarios: ['READ', 'UPDATE'],
    funcoes: ['READ'],
    system: ['READ'],
    auditoria: ['READ', 'EXPORT'],
    treinamentos: ['READ', 'UPDATE'],
    compliance: ['READ', 'UPDATE'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['READ'],
    simuladores: ['READ'],
    simulador: ['READ'],
    qualificacoes: ['READ', 'EXPORT'],
    certificados: ['READ']
  },
  GESTOR: {
    funcionarios: ['READ', 'UPDATE'],
    funcoes: ['READ'],
    system: ['READ'],
    treinamentos: ['READ', 'UPDATE'],
    compliance: ['READ'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['READ', 'UPDATE'],
    simuladores: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    simulador: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
    qualificacoes: ['READ', 'EXPORT'],
    certificados: ['READ']
  },
  FUNCIONARIO: {
    funcionarios: ['READ'],
    funcoes: ['READ'],
    treinamentos: ['READ'],
    compliance: ['READ'],
    dashboard: ['READ'],
    aeronaves: ['READ'],
    pasta_virtual: ['READ', 'UPDATE'], // Fixed: was lowercase 'read'
    simuladores: ['READ'],
    simulador: ['READ', 'UPDATE'],
    qualificacoes: ['READ'],
    certificados: ['READ']
  },
  USUARIO: {
    dashboard: ['READ'],
    pasta_virtual: ['READ'],
    simulador: ['READ'],
    qualificacoes: ['READ'],
    certificados: ['READ']
  }
};

/**
 * Checks if a user has permission to perform an action on a module
 */
function hasPermission(user: User, module: string, action: string): boolean {
  if (!user.perfil || !PERMISSIONS_MATRIX[user.perfil]) {
    return false;
  }

  const modulePermissions = PERMISSIONS_MATRIX[user.perfil][module];
  return modulePermissions ? modulePermissions.includes(action) : false;
}

/**
 * Require specific permission middleware
 * @param modulo - Module/resource name (e.g., 'funcionarios', 'qualificacoes')
 * @param acao - Action (e.g., 'READ', 'CREATE', 'UPDATE', 'DELETE')
 * @param ownerIdField - Optional field name in context to check ownership
 */
export const requirePermission = (
  modulo: string,
  acao: string,
  options?: { ownerIdField?: string }
): MiddlewareHandler => {
  return async (c, next) => {
    const user = c.get('user') as User | null;
    
    // ===== AUTHENTICATION CHECK =====
    if (!user) {
      Logger.warn('Permission check failed: user not authenticated', {
        module: modulo,
        action: acao,
        path: c.req.path
      });
      
      return c.json({
        error: 'User not authenticated',
        code: 'UNAUTHORIZED'
      }, 401);
    }

    // ===== INPUT VALIDATION =====
    try {
      ModuleSchema.parse(modulo);
      PermissionsSchema.parse(acao);
    } catch (error) {
      Logger.error('Invalid permission check parameters', {
        module: modulo,
        action: acao,
        error
      });
      
      return c.json({
        error: 'Invalid request parameters',
        code: 'INVALID_INPUT'
      }, 400);
    }

    // ===== VALIDATE USER PROFILE =====
    if (!user.perfil || !PERMISSIONS_MATRIX[user.perfil]) {
      Logger.error('Invalid user profile in permission check', {
        userId: user.id,
        perfil: user.perfil,
        module: modulo,
        action: acao
      });
      
      return c.json({
        error: 'Invalid user profile',
        code: 'INVALID_PROFILE'
      }, 403);
    }

    // ===== CHECK PERMISSION =====
    if (!hasPermission(user, modulo, acao)) {
      Logger.warn('Permission check failed: insufficient permissions', {
        userId: user.id.toString(),
        userProfile: user.perfil,
        requiredPermission: `${modulo}:${acao}`,
        path: c.req.path
      });
      
      // ===== AUDIT: PERMISSION DENIED =====
      try {
        const db = c.env?.DB;
        if (db) {
          await db.prepare(`
            INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
            VALUES ('PERMISSION_CHECK_FAILED', ?, ?, ?, 'HIGH')
          `).bind(
            modulo,
            user.id,
            JSON.stringify({
              required: `${modulo}:${acao}`,
              user_profile: user.perfil,
              path: c.req.path,
              timestamp: new Date().toISOString()
            })
          ).run();
        }
      } catch (auditError) {
        Logger.error('Failed to audit permission denial', auditError);
      }
      
      return c.json({
        error: 'Insufficient permissions',
        required: `${modulo}:${acao}`,
        user_profile: user.perfil,
        code: 'FORBIDDEN'
      }, 403);
    }

    // ===== OWNER CHECK (if specified) =====
    if (options?.ownerIdField) {
      const resourceOwnerId = c.get(options.ownerIdField) as number | null;
      
      if (resourceOwnerId && resourceOwnerId !== user.id) {
        // Only admin can access resources owned by others (or users with ADMIN role)
        if (user.perfil !== 'ADMIN') {
          Logger.warn('Owner check failed', {
            userId: user.id.toString(),
            resourceOwnerId,
            module: modulo,
            action: acao
          });
          
          try {
            const db = c.env?.DB;
            if (db) {
              await db.prepare(`
                INSERT INTO auditoriaavancadav2 (action, module, user_id, details, severity)
                VALUES ('OWNER_CHECK_FAILED', ?, ?, ?, 'HIGH')
              `).bind(
                modulo,
                user.id,
                JSON.stringify({
                  required_owner_id: resourceOwnerId,
                  action: acao,
                  timestamp: new Date().toISOString()
                })
              ).run();
            }
          } catch (auditError) {
            Logger.error('Failed to audit owner check failure', auditError);
          }
          
          return c.json({
            error: 'Insufficient permissions',
            code: 'FORBIDDEN'
          }, 403);
        }
      }
    }

    // ===== AUDIT: PERMISSION GRANTED =====
    try {
      const db = c.env?.DB;
      if (db) {
        await db.prepare(`
          INSERT INTO auditoriaavancadav2 (action, module, user_id, details)
          VALUES ('PERMISSION_CHECK_PASSED', ?, ?, ?)
        `).bind(
          modulo,
          user.id,
          JSON.stringify({
            permission: `${modulo}:${acao}`,
            timestamp: new Date().toISOString()
          })
        ).run();
      }
    } catch (auditError) {
      Logger.error('Failed to audit permission grant', auditError);
    }

    Logger.debug('Permission check passed', {
      userId: user.id.toString(),
      userProfile: user.perfil,
      permission: `${modulo}:${acao}`,
      path: c.req.path
    });

    return await next();
  };
};

/**
 * Helper to validate if user has permission without middleware
 */
export function userHasPermission(user: User | null | undefined, module: string, action: string): boolean {
  if (!user) {
    return false;
  }

  try {
    ModuleSchema.parse(module);
    PermissionsSchema.parse(action);
  } catch {
    return false;
  }

  return hasPermission(user, module, action);
}
