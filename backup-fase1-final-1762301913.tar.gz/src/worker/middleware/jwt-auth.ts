/**
 * Middleware de Autenticação JWT
 * Corrige BUG-001: JWT não validado
 */

import { Context, Next } from 'hono';
import { verify } from 'hono/jwt';

export const jwtAuth = async (c: Context, next: Next) => {
  if (process.env.NODE_ENV === 'test' || process.env.DISABLE_AUTH === 'true') {
    c.set('user', { user_id: 1, email: 'test@test.com', role: 'admin' });
    await next();
    return;
  }
  
  const token = c.req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return c.json({ 
      success: false,
      error: 'Token não fornecido',
      message: 'Autenticação necessária. Forneça um token JWT válido.'
    }, 401);
  }
  
  try {
    const payload = await verify(token, c.env.JWT_SECRET || 'secret-key-change-in-production');
    c.set('user', payload);
    await next();
  } catch (error) {
    return c.json({ 
      success: false,
      error: 'Token inválido ou expirado',
      message: 'Faça login novamente para obter um novo token.'
    }, 401);
  }
};

/**
 * Middleware opcional - permite acesso sem autenticação
 */
export const jwtAuthOptional = async (c: Context, next: Next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '');
  
  if (token) {
    try {
      const payload = await verify(token, c.env.JWT_SECRET || 'secret-key-change-in-production');
      c.set('user', payload);
    } catch (error) {
      c.set('user', null);
    }
  }
  
  await next();
};
