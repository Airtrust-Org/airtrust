/**
 * Script de Recálculo de Datas de Realização
 * 
 * Calcula retroativamente a data_conclusao para qualificações
 * que só possuem data de vencimento (importadas de planilhas antigas)
 */

import { calcularDataRealizacao, TipoVencimento } from '../utils/calcularVencimento';

interface QualificacaoParaRecalcular {
  id: number;
  vencimento: string;
  validade_meses: number;
  vencimento_tipo: TipoVencimento;
}

/**
 * Recalcula data_conclusao para todas as qualificações que não possuem
 */
export async function recalcularTodasQualificacoes(db: any): Promise<{
  sucesso: boolean;
  total_calculadas: number;
  erros: string[];
}> {
  const erros: string[] = [];
  let total = 0;

  try {
    const result = await db.prepare(`
      SELECT 
        q.id,
        q.data_vencimento as vencimento,
        COALESCE(t.validade_meses, 12) as validade_meses,
        COALESCE(t.vencimento_tipo, 'DIA_EXATO') as vencimento_tipo
      FROM qualificacoes q
      LEFT JOIN qualificacoes t ON t.codigo = q.codigo
      WHERE q.data_conclusao IS NULL
        AND q.data_vencimento IS NOT NULL
        AND q.deleted_at IS NULL
    `).all();

    const qualificacoes = result.results as QualificacaoParaRecalcular[];


    for (const qual of qualificacoes) {
      try {
        const dataRealizacao = calcularDataRealizacao(
          qual.vencimento,
          qual.validade_meses,
          qual.vencimento_tipo
        );

        await db.prepare(`
          UPDATE qualificacoes 
          SET data_conclusao = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).bind(dataRealizacao, qual.id).run();

        total++;

        if (total % 100 === 0) {
        }
      } catch (error) {
        const msg = `Erro ao recalcular ID ${qual.id}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`;
        console.error(`[RECALCULO] ${msg}`);
        erros.push(msg);
      }
    }


    return {
      sucesso: true,
      total_calculadas: total,
      erros
    };

  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Erro desconhecido';
    console.error('[RECALCULO] Erro fatal:', msg);
    return {
      sucesso: false,
      total_calculadas: total,
      erros: [msg]
    };
  }
}

/**
 * Recalcula apenas qualificações de um funcionário específico
 */
export async function recalcularPorFuncionario(
  db: any,
  funcionarioId: number
): Promise<{
  sucesso: boolean;
  total_calculadas: number;
  erros: string[];
}> {
  const erros: string[] = [];
  let total = 0;

  try {
    const result = await db.prepare(`
      SELECT 
        q.id,
        q.data_vencimento as vencimento,
        COALESCE(t.validade_meses, 12) as validade_meses,
        COALESCE(t.vencimento_tipo, 'DIA_EXATO') as vencimento_tipo
      FROM qualificacoes q
      LEFT JOIN qualificacoes t ON t.codigo = q.codigo
      WHERE q.funcionario_id = ?
        AND q.data_conclusao IS NULL
        AND q.data_vencimento IS NOT NULL
        AND q.deleted_at IS NULL
    `).bind(funcionarioId).all();

    const qualificacoes = result.results as QualificacaoParaRecalcular[];

    for (const qual of qualificacoes) {
      try {
        const dataRealizacao = calcularDataRealizacao(
          qual.vencimento,
          qual.validade_meses,
          qual.vencimento_tipo
        );

        await db.prepare(`
          UPDATE qualificacoes 
          SET data_conclusao = ?,
              updated_at = datetime('now')
          WHERE id = ?
        `).bind(dataRealizacao, qual.id).run();

        total++;
      } catch (error) {
        const msg = `Erro ao recalcular ID ${qual.id}: ${error instanceof Error ? error.message : 'Erro desconhecido'}`;
        erros.push(msg);
      }
    }

    return {
      sucesso: true,
      total_calculadas: total,
      erros
    };

  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Erro desconhecido';
    return {
      sucesso: false,
      total_calculadas: total,
      erros: [msg]
    };
  }
}
