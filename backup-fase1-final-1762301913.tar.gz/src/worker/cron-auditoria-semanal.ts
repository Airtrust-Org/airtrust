import { Env } from './types';

interface InconsistenciaDetectada {
  tipo: string;
  severidade: 'CRITICA' | 'ALTA' | 'MEDIA' | 'BAIXA';
  descricao: string;
  tabela_afetada: string;
  registros_afetados: number;
  acao_corretiva?: string;
  dados_detalhes?: any;
}

export async function executarAuditoriaSemanal(env: Env): Promise<void> {
  
  const inconsistencias: InconsistenciaDetectada[] = [];
  const db = env.DB;
  
  try {
    const fichasOrfas = await db.prepare(`
      SELECT COUNT(*) as count
      FROM fichas_sessao fs
      LEFT JOIN agendamento_slots ags ON fs.agendamento_slot_id = ags.id
      WHERE ags.id IS NULL AND fs.deleted_at IS NULL
    `).first();

    if (fichasOrfas && fichasOrfas.count > 0) {
      inconsistencias.push({
        tipo: 'FICHAS_ORFAS',
        severidade: 'CRITICA',
        descricao: `${fichasOrfas.count} fichas de sessão sem slot de agendamento válido`,
        tabela_afetada: 'fichas_sessao',
        registros_afetados: fichasOrfas.count,
        acao_corretiva: 'Marcar fichas como excluídas ou recriar slots'
      });
    }

    const slotsDataInconsistente = await db.prepare(`
      SELECT COUNT(*) as count
      FROM agendamento_slots
      WHERE data_inicio >= data_fim
      AND status_slot != 'CANCELADO'
    `).first();

    if (slotsDataInconsistente && slotsDataInconsistente.count > 0) {
      inconsistencias.push({
        tipo: 'DATAS_INCONSISTENTES',
        severidade: 'ALTA',
        descricao: `${slotsDataInconsistente.count} slots com data de início >= data fim`,
        tabela_afetada: 'agendamento_slots',
        registros_afetados: slotsDataInconsistente.count,
        acao_corretiva: 'Corrigir datas ou cancelar slots'
      });
    }

    const statusInconsistente = await db.prepare(`
      SELECT COUNT(*) as count
      FROM fichas_sessao fs
      JOIN agendamento_slots ags ON fs.agendamento_slot_id = ags.id
      WHERE ags.status_slot = 'CANCELADO' 
      AND fs.status_workflow NOT IN ('CANCELADO', 'RASCUNHO')
    `).first();

    if (statusInconsistente && statusInconsistente.count > 0) {
      inconsistencias.push({
        tipo: 'STATUS_INCONSISTENTE',
        severidade: 'MEDIA',
        descricao: `${statusInconsistente.count} fichas com status incompatível com slot cancelado`,
        tabela_afetada: 'fichas_sessao',
        registros_afetados: statusInconsistente.count,
        acao_corretiva: 'Sincronizar status das fichas'
      });
    }

    const manobrasDuplicadas = await db.prepare(`
      SELECT sessao_template_id, manobra_catalogo_id, COUNT(*) as duplicatas
      FROM sessoes_template_manobras
      GROUP BY sessao_template_id, manobra_catalogo_id
      HAVING COUNT(*) > 1
    `).all();

    if (manobrasDuplicadas && manobrasDuplicadas.results.length > 0) {
      inconsistencias.push({
        tipo: 'MANOBRAS_DUPLICADAS',
        severidade: 'MEDIA',
        descricao: `${manobrasDuplicadas.results.length} sessões com manobras duplicadas`,
        tabela_afetada: 'sessoes_template_manobras',
        registros_afetados: manobrasDuplicadas.results.length,
        acao_corretiva: 'Remover duplicatas mantendo apenas uma referência'
      });
    }

    const instrutoresInexistentes = await db.prepare(`
      SELECT COUNT(*) as count
      FROM agendamento_slots ags
      LEFT JOIN funcionarios f ON ags.colaborador_id_instrutor = f.id
      WHERE f.id IS NULL OR f.is_instrutor = 0
    `).first();

    if (instrutoresInexistentes && instrutoresInexistentes.count > 0) {
      inconsistencias.push({
        tipo: 'INSTRUTORES_INVALIDOS',
        severidade: 'ALTA',
        descricao: `${instrutoresInexistentes.count} slots com instrutores inválidos`,
        tabela_afetada: 'agendamento_slots',
        registros_afetados: instrutoresInexistentes.count,
        acao_corretiva: 'Atribuir instrutores válidos ou cancelar slots'
      });
    }

    const certPendente = await db.prepare(`
      SELECT COUNT(*) as count
      FROM fichas_sessao
      WHERE status_workflow = 'CONCLUIDA'
      AND resultado_final = 'APROVADO'
      AND certificacao_automatica_executada = 0
      AND created_at < datetime('now', '-7 days')
    `).first();

    if (certPendente && certPendente.count > 0) {
      inconsistencias.push({
        tipo: 'CERTIFICACAO_PENDENTE',
        severidade: 'MEDIA',
        descricao: `${certPendente.count} fichas aprovadas sem certificação automática há mais de 7 dias`,
        tabela_afetada: 'fichas_sessao',
        registros_afetados: certPendente.count,
        acao_corretiva: 'Executar processo de certificação automática'
      });
    }

    let correctoriesAplicadas = 0;

    if (statusInconsistente && statusInconsistente.count > 0) {
      const correcaoResult = await db.prepare(`
        UPDATE fichas_sessao 
        SET status_workflow = 'CANCELADO', 
            updated_at = CURRENT_TIMESTAMP
        FROM agendamento_slots ags 
        WHERE fichas_sessao.agendamento_slot_id = ags.id 
        AND ags.status_slot = 'CANCELADO'
        AND fichas_sessao.status_workflow NOT IN ('CANCELADO')
      `).run();

      if (correcaoResult.success) {
        correctoriesAplicadas++;
      }
    }

    if (manobrasDuplicadas && manobrasDuplicadas.results.length > 0) {
      for (const duplicata of manobrasDuplicadas.results) {
        await db.prepare(`
          DELETE FROM sessoes_template_manobras 
          WHERE rowid NOT IN (
            SELECT MIN(rowid) 
            FROM sessoes_template_manobras 
            WHERE sessao_template_id = ? AND manobra_catalogo_id = ?
          )
          AND sessao_template_id = ? AND manobra_catalogo_id = ?
        `).bind(
          duplicata.sessao_template_id, duplicata.manobra_catalogo_id,
          duplicata.sessao_template_id, duplicata.manobra_catalogo_id
        ).run();
      }
      correctoriesAplicadas++;
    }

    if (certPendente && certPendente.count > 0) {
      const { processarCertificacaoAutomatica } = await import('./cron-certificacao-automatica');
      
      try {
        await processarCertificacaoAutomatica(env);
        correctoriesAplicadas++;
      } catch (error) {
        console.error('[CRON-AUDITORIA] Erro ao processar certificações:', error);
      }
    }

    const resumoAuditoria = {
      data_execucao: new Date().toISOString(),
      total_inconsistencias: inconsistencias.length,
      inconsistencias_criticas: inconsistencias.filter(i => i.severidade === 'CRITICA').length,
      inconsistencias_altas: inconsistencias.filter(i => i.severidade === 'ALTA').length,
      correcoes_aplicadas: correctoriesAplicadas,
      status: inconsistencias.filter(i => i.severidade === 'CRITICA').length > 0 ? 'ATENCAO_REQUERIDA' : 'OK'
    };

    await db.prepare(`
      INSERT INTO auditoria_limpeza_dados (
        operacao, tabela_afetada, registros_atualizados, 
        criterio_remocao, usuario_responsavel, status_operacao, observacoes
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      'AUDITORIA_SEMANAL_SIMULADORES',
      'multiplas_tabelas',
      correctoriesAplicadas,
      'Auditoria automática de integridade',
      'SISTEMA_AUDITORIA_SEMANAL',
      resumoAuditoria.status,
      JSON.stringify({
        resumo: resumoAuditoria,
        inconsistencias: inconsistencias
      })
    ).run();

    
    for (const inconsistencia of inconsistencias.filter(i => ['CRITICA', 'ALTA'].includes(i.severidade))) {
      console.warn(`[CRON-AUDITORIA] ${inconsistencia.severidade}: ${inconsistencia.descricao}`);
    }

    return;

  } catch (error) {
    console.error('[CRON-AUDITORIA] Erro durante auditoria semanal:', error);
    
    await db.prepare(`
      INSERT INTO auditoria_limpeza_dados (
        operacao, tabela_afetada, registros_removidos,
        criterio_remocao, usuario_responsavel, status_operacao, observacoes
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      'AUDITORIA_SEMANAL_SIMULADORES',
      'erro_execucao',
      0,
      'Erro durante execução da auditoria',
      'SISTEMA_AUDITORIA_SEMANAL',
      'ERRO',
      JSON.stringify({
        erro: error instanceof Error ? error.message : 'Erro desconhecido',
        timestamp: new Date().toISOString()
      })
    ).run();

    throw error;
  }
}

export async function executarCorrecaoManual(env: Env, tipoCorrecao: string): Promise<boolean> {
  const db = env.DB;
  
  try {
    switch (tipoCorrecao) {
      case 'LIMPAR_FICHAS_ORFAS':
        await db.prepare(`
          UPDATE fichas_sessao 
          SET deleted_at = CURRENT_TIMESTAMP
          WHERE agendamento_slot_id NOT IN (
            SELECT id FROM agendamento_slots
          )
        `).run();
        return true;

      case 'CORRIGIR_DATAS_SLOTS':
        await db.prepare(`
          UPDATE agendamento_slots 
          SET status_slot = 'CANCELADO'
          WHERE data_inicio >= data_fim 
          AND status_slot != 'CANCELADO'
        `).run();
        return true;

      case 'SINCRONIZAR_STATUS':
        await db.prepare(`
          UPDATE fichas_sessao 
          SET status_workflow = 'CANCELADO'
          FROM agendamento_slots ags
          WHERE fichas_sessao.agendamento_slot_id = ags.id
          AND ags.status_slot = 'CANCELADO'
          AND fichas_sessao.status_workflow != 'CANCELADO'
        `).run();
        return true;

      default:
        console.warn(`[CRON-AUDITORIA] Tipo de correção desconhecido: ${tipoCorrecao}`);
        return false;
    }
  } catch (error) {
    console.error(`[CRON-AUDITORIA] Erro na correção manual ${tipoCorrecao}:`, error);
    return false;
  }
}
