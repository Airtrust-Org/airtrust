import type { Env } from '../types';

export async function enviarNotificacoesVencimento(env: Env) {
  try {

    const em30Dias = new Date();
    em30Dias.setDate(em30Dias.getDate() + 30);
    const dataLimite = em30Dias.toISOString().split('T')[0];
    const hoje = new Date().toISOString().split('T')[0];

    const qualificacoesVencendo = await env.DB.prepare(`
      SELECT 
        q.*,
        f.nome as funcionario_nome,
        f.email as funcionario_email
      FROM qualificacoes q
      LEFT JOIN funcionarios f ON q.funcionario_id = f.id
      WHERE q.deleted_at IS NULL
        AND q.data_vencimento IS NOT NULL
        AND q.data_vencimento <= ?
        AND q.data_vencimento >= ?
        AND q.tipo IN ('EXAME', 'CHECK')
        AND f.email IS NOT NULL
    `).bind(dataLimite, hoje).all();

    let enviados = 0;
    const erros: string[] = [];

    for (const qual of qualificacoesVencendo.results as any[]) {
      const diasRestantes = Math.ceil(
        (new Date(qual.data_vencimento).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );

      const tipoLabel = qual.tipo === 'EXAME' ? 'Exame' : 'Check';
      const corHeader = qual.tipo === 'EXAME' ? '#E53E3E' : '#805AD5';
      const corAlert = qual.tipo === 'EXAME' ? '#FFF5F5' : '#FAF5FF';

      const emailBody = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8">
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background: ${corHeader}; color: white; padding: 20px; border-radius: 5px 5px 0 0; }
              .content { background: #f9f9f9; padding: 20px; border: 1px solid #ddd; }
              .footer { background: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; color: #666; }
              .alert { background: ${corAlert}; border-left: 4px solid ${corHeader}; padding: 15px; margin: 15px 0; }
              ul { padding-left: 20px; }
              li { margin: 8px 0; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h2 style="margin: 0;">⚠️ Alerta de Vencimento - AirTrust</h2>
              </div>
              <div class="content">
                <p>Olá <strong>${qual.funcionario_nome}</strong>,</p>
                <div class="alert">
                  <p style="margin: 0;"><strong>Seu ${tipoLabel} ${qual.codigo} está próximo do vencimento!</strong></p>
                </div>
                <ul>
                  <li><strong>Tipo:</strong> ${tipoLabel}</li>
                  <li><strong>Código:</strong> ${qual.codigo}</li>
                  <li><strong>Data de Vencimento:</strong> ${new Date(qual.data_vencimento).toLocaleDateString('pt-BR')}</li>
                  <li><strong>Dias Restantes:</strong> ${diasRestantes} dias</li>
                  ${qual.numero ? `<li><strong>Número:</strong> ${qual.numero}</li>` : ''}
                  ${qual.instrutor ? `<li><strong>Instrutor:</strong> ${qual.instrutor}</li>` : ''}
                </ul>
                <p><strong>Ação Necessária:</strong> Por favor, providencie a renovação o quanto antes para manter sua conformidade.</p>
              </div>
              <div class="footer">
                <p>Este é um email automático do sistema AirTrust. Não responda a este email.</p>
              </div>
            </div>
          </body>
        </html>
      `;

      try {
        if (env.RESEND_API_KEY) {
          const response = await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${env.RESEND_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              from: 'AirTrust <noreply@airtrust.com>',
              to: qual.funcionario_email,
              subject: `⚠️ ${tipoLabel} ${qual.codigo} vence em ${diasRestantes} dias`,
              html: emailBody,
            }),
          });

          if (response.ok) {
            enviados++;
          } else {
            erros.push(`Erro ao enviar para ${qual.funcionario_email}: ${response.statusText}`);
          }
        } else {
          enviados++;
        }
      } catch (emailError) {
        console.error(`Erro ao enviar email para ${qual.funcionario_email}:`, emailError);
        erros.push(`${qual.funcionario_email}: ${emailError}`);
      }
    }

    const totalRegistros = qualificacoesVencendo.results.length;
    
    if (erros.length > 0) {
    }

    return {
      success: true,
      enviados,
      total: totalRegistros,
      erros: erros.length,
    };
  } catch (error) {
    console.error('❌ Erro ao enviar notificações:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
    };
  }
}
