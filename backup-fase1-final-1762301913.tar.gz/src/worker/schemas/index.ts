import { z } from 'zod';


export const FuncionarioCreateSchema = z.object({
  nome: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres'),
  cpf: z.string().regex(/^\d{11}$/, 'CPF deve ter 11 dígitos'),
  email: z.string().email('Email inválido').optional().nullable(),
  telefone: z.string().optional().nullable(),
  matricula: z.string().min(1, 'Matrícula é obrigatória'),
  funcao: z.string().min(1, 'Função é obrigatória'),
  aeronave: z.string().optional().nullable(),
  data_nascimento: z.string().optional().nullable(),
  codigo_anac_instrutor: z.string().optional().nullable(),
  setor_id: z.number().int().positive().optional().nullable(),
});

export const FuncionarioUpdateSchema = FuncionarioCreateSchema.partial();

export type FuncionarioCreate = z.infer<typeof FuncionarioCreateSchema>;
export type FuncionarioUpdate = z.infer<typeof FuncionarioUpdateSchema>;


export const ParticipanteSchema = z.object({
  colaborador_id: z.number().int().positive('ID do colaborador inválido').optional(),
  funcionario_id: z.number().int().positive('ID do funcionário inválido').optional(),
  funcao: z.string().min(1, 'Função é obrigatória')
});

export const AgendamentoCreateSchema = z.object({
  simulador_id: z.number().int().positive('ID do simulador inválido'),
  instrutor_id: z.number().int().positive('ID do instrutor inválido'),
  template_id: z.number().int().positive('ID do template inválido'),
  data: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (formato: YYYY-MM-DD)'),
  hora_inicio: z.string().regex(/^\d{2}:\d{2}$/, 'Hora de início inválida (formato: HH:MM)'),
  hora_fim: z.string().regex(/^\d{2}:\d{2}$/, 'Hora de fim inválida (formato: HH:MM)').optional(),
  tipo_sessao: z.enum(['PC', 'OPC', 'LPC', 'DIFF']).optional(),
  observacoes: z.string().optional().nullable(),
  participantes: z.array(ParticipanteSchema).min(1, 'Pelo menos 1 participante é obrigatório').optional()
});

export const AgendamentoUpdateSchema = AgendamentoCreateSchema.partial().omit({ participantes: true }).extend({
  status: z.enum(['AGENDADO', 'CONFIRMADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO']).optional()
});

export type AgendamentoCreate = z.infer<typeof AgendamentoCreateSchema>;
export type AgendamentoUpdate = z.infer<typeof AgendamentoUpdateSchema>;


export const FichaCreateSchema = z.object({
  agendamento_slot_id: z.number().int().positive('ID do agendamento inválido'),
  colaborador_id_aluno: z.number().int().positive('ID do aluno inválido'),
  funcao_na_sessao: z.enum(['PF', 'PM', 'PC']).optional().default('PF'), // Aceita PF, PM e PC
  instrutor_id: z.number().int().positive('ID do instrutor inválido'),
  template_id: z.number().int().positive('Template ID é obrigatório').optional().nullable(),
  carga_horaria_total: z.number().positive().optional().default(2.0),
  carga_horaria_pf: z.number().positive().optional(),
  carga_horaria_pm: z.number().positive().optional(),
}).passthrough();

export const FichaUpdateSchema = z.object({
  status: z.enum(['PENDENTE', 'EM_ANDAMENTO', 'CONCLUIDA', 'CANCELADA']).optional(),
  aprovado: z.boolean().optional(),
  nota: z.number().min(0).max(10).optional(),
  observacoes_instrutor: z.string().optional().nullable(),
});

export type FichaCreate = z.infer<typeof FichaCreateSchema>;
export type FichaUpdate = z.infer<typeof FichaUpdateSchema>;


export function validateSchema<T>(schema: z.ZodSchema<T>, data: unknown) {
  const result = schema.safeParse(data);
  
  if (!result.success) {
    const errors = result.error.errors.map(err => ({
      field: err.path.join('.'),
      message: err.message
    }));
    
    return { success: false as const, errors };
  }
  
  return { success: true as const, data: result.data };
}
