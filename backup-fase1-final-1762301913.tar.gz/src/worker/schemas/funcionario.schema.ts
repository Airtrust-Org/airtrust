/**
 * Schema Zod para validação de Funcionário
 * Safety Critical - Operações Aeronaúticas
 */

import { z } from 'zod';

const cpfSchema = z.string().regex(/^\d{11}$/, 'CPF deve ter 11 dígitos').optional();

const telefoneSchema = z.string().regex(/^\d{10,11}$/, 'Telefone deve ter 10 ou 11 dígitos').optional();

const emailSchema = z.string().email('Email inválido').max(255);

const codigoANACSchema = z.string().regex(/^\d{6,7}$/, 'Código ANAC deve ter 6 ou 7 dígitos').optional();

const dataISOSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data deve estar no formato YYYY-MM-DD').optional();

const funcoesAeronauticas = ['PC', 'SIC', 'CMS', 'MMA', 'CMTE', 'COPILOTO'] as const;

const statusFuncionarioEnum = z.enum(['ATIVO', 'INATIVO', 'AFASTADO', 'DESLIGADO']);

const tipoSanguineoEnum = z.enum(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']);

/**
 * Schema para criação de funcionário
 */
export const CreateFuncionarioSchema = z.object({
  nome: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres').max(200),
  email: emailSchema,
  funcao: z.string().min(2).max(100),
  
  matricula: z.string().max(50).optional(),
  cpf: cpfSchema,
  codigo_anac: codigoANACSchema,
  base: z.string().max(100).optional(),
  contrato: z.string().max(100).optional(),
  telefone: telefoneSchema,
  status: z.string().max(50).optional(),
  
  cma_numero: z.string().max(50).optional(),
  cma_datavencimento: dataISOSchema,
  cma_status: z.string().max(50).optional(),
  aso_datavencimento: dataISOSchema,
  nivel_icao: z.string().max(50).optional(),
  nivel_icao_datavencimento: dataISOSchema,
  nivel_icao_status: z.string().max(50).optional(),
  
  is_instrutor: z.number().int().min(0).max(1).optional(),
  is_checador: z.number().int().min(0).max(1).optional(),
  
  aeronave_principal: z.string().max(100).optional(),
  avatar: z.string().max(500).optional(),
  anv: z.string().max(100).optional(),
  data_nascimento: dataISOSchema,
  licenca_aeronautica: z.string().max(100).optional(),
  codigo_canac: z.string().max(50).optional(),
  codigo_sispat: z.string().max(50).optional(),
  codigo_prestserv: z.string().max(50).optional(),
  data_admissao: dataISOSchema,
  
  status_funcionario: statusFuncionarioEnum.optional(),
  tipo_sanguineo: tipoSanguineoEnum.optional(),
  contato_emergencia_nome: z.string().min(3).max(200),
  contato_emergencia_parentesco: z.string().max(100).optional(),
  contato_emergencia_telefone: telefoneSchema.refine(val => val !== undefined, {
    message: 'Telefone de emergência obrigatório (Safety Critical)'
  })
}).strict(); // Rejeita campos extras

/**
 * Schema para atualização de funcionário
 */
export const UpdateFuncionarioSchema = CreateFuncionarioSchema.partial();

/**
 * Schema para importação CSV
 */
export const ImportFuncionarioSchema = z.object({
  csv: z.string().min(1, 'CSV não pode estar vazio').max(10 * 1024 * 1024, 'CSV muito grande (máximo 10MB)')
}).strict();

/**
 * Validação customizada: Código ANAC obrigatório para funções aeronáuticas
 */
export function validateCodigoANACObrigatorio(data: any): { valid: boolean; error?: string } {
  if (data.funcao && funcoesAeronauticas.includes(data.funcao.toUpperCase())) {
    if (!data.codigo_anac) {
      return {
        valid: false,
        error: 'Código ANAC obrigatório para função aeronáutica (Safety Critical)'
      };
    }
  }
  return { valid: true };
}

/**
 * Validação customizada: Telefone emergência diferente do pessoal
 */
export function validateTelefoneEmergenciaDiferente(data: any): { valid: boolean; error?: string } {
  if (data.telefone && data.contato_emergencia_telefone) {
    if (data.telefone === data.contato_emergencia_telefone) {
      return {
        valid: false,
        error: 'Telefone de emergência deve ser diferente do telefone pessoal'
      };
    }
  }
  return { valid: true };
}

/**
 * Validação customizada: Idade mínima 18 anos
 */
export function validateIdadeMinima(data: any): { valid: boolean; error?: string } {
  if (data.data_nascimento) {
    const nascimento = new Date(data.data_nascimento);
    const hoje = new Date();
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    const mes = hoje.getMonth() - nascimento.getMonth();
    
    if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
    
    if (idade < 18) {
      return {
        valid: false,
        error: `Funcionário deve ter pelo menos 18 anos (idade calculada: ${idade} anos)`
      };
    }
  }
  return { valid: true };
}

/**
 * Validação completa com todas as regras customizadas
 */
export function validateFuncionarioCompleto(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  const anac = validateCodigoANACObrigatorio(data);
  if (!anac.valid && anac.error) errors.push(anac.error);
  
  const tel = validateTelefoneEmergenciaDiferente(data);
  if (!tel.valid && tel.error) errors.push(tel.error);
  
  const idade = validateIdadeMinima(data);
  if (!idade.valid && idade.error) errors.push(idade.error);
  
  return {
    valid: errors.length === 0,
    errors
  };
}
