/**
 * src/worker/schemas/habilitacaoSchemas.ts
 * Validação de DTOs para Habilitações com Zod
 */

import { z } from 'zod';

/**
 * DTO para criar habilitação
 */
export const CreateHabilitacaoDTO = z
  .object({
    funcionario_id: z.number().int().positive('Funcionário inválido'),
    qualificacao_id: z.number().int().positive('Qualificação inválida'),
    data_conclusao: z.string().date('Data de conclusão inválida'),
    data_vencimento: z.string().date('Data de vencimento inválida'),
    resultado: z
      .enum(['PENDENTE', 'APROVADO', 'REPROVADO'])
      .default('PENDENTE'),
    timezone: z.string().default('America/Sao_Paulo'),
    observacoes: z.string().max(500).optional(),
  })
  .refine(
    (data) => {
      const conclusao = new Date(data.data_conclusao + 'T00:00:00');
      const vencimento = new Date(data.data_vencimento + 'T00:00:00');
      return vencimento > conclusao;
    },
    {
      message: 'Data de vencimento deve ser posterior à data de conclusão',
      path: ['data_vencimento'],
    }
  )
  .refine(
    (data) => {
      const conclusao = new Date(data.data_conclusao + 'T00:00:00');
      const vencimento = new Date(data.data_vencimento + 'T00:00:00');
      const dias = (vencimento.getTime() - conclusao.getTime()) / (1000 * 60 * 60 * 24);
      return dias > 0 && dias <= 3650; // Entre 1 dia e 10 anos
    },
    {
      message: 'Intervalo entre datas deve estar entre 1 dia e 10 anos',
      path: ['data_vencimento'],
    }
  );

export type CreateHabilitacaoDTOType = z.infer<typeof CreateHabilitacaoDTO>;

/**
 * DTO para atualizar habilitação (todos os campos opcionais)
 */
export const UpdateHabilitacaoDTO = z
  .object({
    funcionario_id: z.number().int().positive().optional(),
    qualificacao_id: z.number().int().positive().optional(),
    data_conclusao: z.string().date().optional(),
    data_vencimento: z.string().date().optional(),
    resultado: z
      .enum(['PENDENTE', 'APROVADO', 'REPROVADO'])
      .optional(),
    timezone: z.string().optional(),
    observacoes: z.string().max(500).optional(),
  });

export type UpdateHabilitacaoDTOType = z.infer<typeof UpdateHabilitacaoDTO>;

/**
 * Query parameters para listar habilitações
 */
export const ListHabilitacoesQueryDTO = z.object({
  page: z.coerce.number().int().positive('Página deve ser positiva').default(1),
  limit: z.coerce
    .number()
    .int()
    .min(1, 'Limite mínimo é 1')
    .max(100, 'Limite máximo é 100')
    .default(20),
  funcionario_id: z.coerce.number().int().positive().optional(),
  status: z
    .enum(['VÁLIDO', 'VENCENDO', 'VENCIDA'])
    .optional(),
  sort: z
    .enum(['data_conclusao', 'data_vencimento', 'created_at'])
    .default('created_at'),
  order: z.enum(['ASC', 'DESC']).default('DESC'),
  includeDeleted: z.coerce.boolean().default(false),
});

export type ListHabilitacoesQueryDTOType = z.infer<typeof ListHabilitacoesQueryDTO>;

/**
 * DTO para upload de certificado
 */
export const CertificadoUploadDTO = z.object({
  habilitacao_id: z.number().int().positive('Habilitação inválida'),
  tipo: z.enum(['PDF', 'JPG', 'PNG']),
});

export type CertificadoUploadDTOType = z.infer<typeof CertificadoUploadDTO>;

/**
 * Resposta padrão da API
 */
export const ApiResponseDTO = z.object({
  success: z.boolean(),
  data: z.unknown().optional(),
  error: z.string().optional(),
  code: z.string().optional(),
  timestamp: z.string().datetime().optional(),
});

export type ApiResponseDTOType = z.infer<typeof ApiResponseDTO>;

/**
 * Erro de validação Zod
 */
export const ValidationErrorDTO = z.object({
  success: z.literal(false),
  error: z.string(),
  code: z.literal('VALIDATION_ERROR'),
  details: z
    .array(
      z.object({
        path: z.string(),
        message: z.string(),
      })
    )
    .optional(),
});

export type ValidationErrorDTOType = z.infer<typeof ValidationErrorDTO>;

/**
 * Função auxiliar para formatar erros Zod
 */
export function formatZodErrors(
  errors: z.ZodError
): ValidationErrorDTOType {
  const details = errors.errors.map((err) => ({
    path: err.path.join('.') || 'root',
    message: err.message,
  }));

  return {
    success: false,
    error: 'Validação falhou',
    code: 'VALIDATION_ERROR',
    details,
  };
}
