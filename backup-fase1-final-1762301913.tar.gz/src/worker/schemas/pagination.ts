import { z } from 'zod';

/**
 * Schema de validação para paginação
 */
export const PaginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(1000).default(50),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['ASC', 'DESC']).default('DESC').optional(),
});

export type PaginationInput = z.infer<typeof PaginationSchema>;

/**
 * Response de paginação
 */
export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasMore: boolean;
  timestamp: string;
}

/**
 * Utilitário para calcular paginação
 */
export function calculatePagination(page: number, limit: number, total: number) {
  const totalPages = Math.ceil(total / limit);
  const hasMore = page < totalPages;
  const offset = (page - 1) * limit;

  return { page, limit, total, totalPages, hasMore, offset };
}
