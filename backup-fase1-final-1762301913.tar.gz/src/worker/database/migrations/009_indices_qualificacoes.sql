-- Migração: Adicionar índices para otimizar queries de qualificações
-- Data: 2025-11-01
-- Objetivo: Melhorar performance de consultas

-- Índice para buscar qualificações por funcionário
CREATE INDEX IF NOT EXISTS idx_qualificacoes_funcionario 
ON qualificacoes(funcionario_id) 
WHERE deleted_at IS NULL;

-- Índice para buscar por status e data de vencimento
CREATE INDEX IF NOT EXISTS idx_qualificacoes_status_vencimento 
ON qualificacoes(status, data_vencimento) 
WHERE deleted_at IS NULL;

-- Índice para buscar por tipo
CREATE INDEX IF NOT EXISTS idx_qualificacoes_tipo 
ON qualificacoes(tipo) 
WHERE deleted_at IS NULL;

-- Índice para buscar por código
CREATE INDEX IF NOT EXISTS idx_qualificacoes_codigo 
ON qualificacoes(codigo) 
WHERE deleted_at IS NULL;

-- Índice composto para queries complexas
CREATE INDEX IF NOT EXISTS idx_qualificacoes_funcionario_tipo 
ON qualificacoes(funcionario_id, tipo, is_renovada) 
WHERE deleted_at IS NULL;

-- Índice para ordenação por data de vencimento
CREATE INDEX IF NOT EXISTS idx_qualificacoes_vencimento_desc 
ON qualificacoes(data_vencimento DESC) 
WHERE deleted_at IS NULL;

-- Índice para buscar renovadas
CREATE INDEX IF NOT EXISTS idx_qualificacoes_renovada 
ON qualificacoes(is_renovada, funcionario_id, codigo) 
WHERE deleted_at IS NULL;

-- Índice para tipos de qualificações
CREATE INDEX IF NOT EXISTS idx_tipos_qualificacoes_codigo 
ON tipos_qualificacoes(codigo) 
WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_tipos_qualificacoes_tipo 
ON tipos_qualificacoes(tipo) 
WHERE deleted_at IS NULL;

-- Verificar índices criados
SELECT 
  name as index_name,
  tbl_name as table_name,
  sql as index_definition
FROM sqlite_master 
WHERE type = 'index' 
  AND tbl_name IN ('qualificacoes', 'tipos_qualificacoes')
  AND name LIKE 'idx_%'
ORDER BY tbl_name, name;
