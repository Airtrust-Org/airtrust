-- ========================================
-- MIGRATION 008: Verificar Migração Completa
-- Data: 19 de Outubro de 2025
-- ========================================

-- Verificar se todos os dados foram migrados corretamente
SELECT 
  'CMA' as tipo,
  (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND cma_data_vencimento IS NOT NULL) as total_origem,
  (SELECT COUNT(*) FROM exames WHERE tipo_exame = 'CMA' AND deleted_at IS NULL) as total_destino,
  CASE 
    WHEN (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND cma_data_vencimento IS NOT NULL) = 
         (SELECT COUNT(*) FROM exames WHERE tipo_exame = 'CMA' AND deleted_at IS NULL)
    THEN '✅ OK'
    ELSE '❌ ERRO'
  END as status

UNION ALL

SELECT 
  'ASO' as tipo,
  (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND aso_data_vencimento IS NOT NULL) as total_origem,
  (SELECT COUNT(*) FROM exames WHERE tipo_exame = 'ASO' AND deleted_at IS NULL) as total_destino,
  CASE 
    WHEN (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND aso_data_vencimento IS NOT NULL) = 
         (SELECT COUNT(*) FROM exames WHERE tipo_exame = 'ASO' AND deleted_at IS NULL)
    THEN '✅ OK'
    ELSE '❌ ERRO'
  END as status

UNION ALL

SELECT 
  'ICAO' as tipo,
  (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND nivel_icao_data_vencimento IS NOT NULL) as total_origem,
  (SELECT COUNT(*) FROM checks WHERE tipo_check = 'ICAO' AND deleted_at IS NULL) as total_destino,
  CASE 
    WHEN (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND nivel_icao_data_vencimento IS NOT NULL) = 
         (SELECT COUNT(*) FROM checks WHERE tipo_check = 'ICAO' AND deleted_at IS NULL)
    THEN '✅ OK'
    ELSE '❌ ERRO'
  END as status;
