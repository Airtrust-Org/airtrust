-- ========================================
-- MIGRATION 002: Criar Tabela de Exames
-- Data: 19 de Outubro de 2025
-- ========================================

-- Tabela para gerenciar exames médicos (CMA, ASO, etc.)
CREATE TABLE IF NOT EXISTS exames (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  tipo_exame VARCHAR(50) NOT NULL, -- 'CMA', 'ASO', 'TOXICOLOGICO', 'PSICOLOGICO'
  numero VARCHAR(100), -- Número do documento (ex: CMA-123456)
  data_realizacao DATE NOT NULL,
  data_vencimento DATE NOT NULL,
  resultado VARCHAR(50), -- 'APTO', 'INAPTO', 'APTO_COM_RESTRICAO'
  observacoes TEXT,
  arquivo_url VARCHAR(500), -- Link R2 para o arquivo PDF/imagem
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_exames_funcionario_id ON exames(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_exames_tipo_exame ON exames(tipo_exame);
CREATE INDEX IF NOT EXISTS idx_exames_data_vencimento ON exames(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_exames_deleted_at ON exames(deleted_at);
CREATE INDEX IF NOT EXISTS idx_exames_func_tipo ON exames(funcionario_id, tipo_exame);

-- Verificar criação
SELECT 'Tabela exames criada com sucesso!' as status;
