-- ========================================
-- MIGRATION 005: Migrar CMA para Exames
-- Data: 19 de Outubro de 2025
-- ========================================

-- Migrar dados de CMA para a tabela exames
INSERT INTO exames (
  funcionario_id,
  tipo_exame,
  numero,
  data_realizacao,
  data_vencimento,
  resultado,
  observacoes
)
SELECT 
  id as funcionario_id,
  'CMA' as tipo_exame,
  cma_numero as numero,
  COALESCE(DATE(cma_data_vencimento, '-12 months'), DATE('now', '-12 months')) as data_realizacao, -- Estimar data de realização (CMA vale 1 ano)
  cma_data_vencimento as data_vencimento,
  CASE 
    WHEN cma_status = 'valido' THEN 'APTO'
    WHEN cma_status = 'vencido' THEN 'APTO' -- Estava apto, mas venceu
    ELSE 'APTO'
  END as resultado,
  'Migrado automaticamente do módulo de funcionários' as observacoes
FROM funcionarios
WHERE deleted_at IS NULL
  AND cma_data_vencimento IS NOT NULL
  AND cma_numero IS NOT NULL
  AND cma_numero != '';

-- Verificar migração
SELECT 
  COUNT(*) as total_migrado,
  tipo_exame,
  COUNT(CASE WHEN resultado = 'APTO' THEN 1 END) as aptos
FROM exames
WHERE tipo_exame = 'CMA'
GROUP BY tipo_exame;
