-- ========================================
-- MIGRATION 004: Criar Backup de Vencimentos
-- Data: 19 de Outubro de 2025
-- ========================================

-- Backup dos dados que serão migrados
CREATE TABLE IF NOT EXISTS funcionarios_vencimentos_backup (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  matricula VARCHAR(50),
  nome VARCHAR(200),
  cma_numero VARCHAR(50),
  cma_data_vencimento DATE,
  cma_status VARCHAR(20),
  aso_data_vencimento DATE,
  nivel_icao VARCHAR(10),
  nivel_icao_data_vencimento DATE,
  backup_created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Fazer backup dos dados existentes
INSERT INTO funcionarios_vencimentos_backup (
  funcionario_id, matricula, nome,
  cma_numero, cma_data_vencimento, cma_status, aso_data_vencimento,
  nivel_icao, nivel_icao_data_vencimento
)
SELECT 
  id, matricula, nome,
  cma_numero, cma_data_vencimento, cma_status, aso_data_vencimento,
  nivel_icao, nivel_icao_data_vencimento
FROM funcionarios
WHERE deleted_at IS NULL;

-- Verificar backup
SELECT 
  COUNT(*) as total_backup,
  COUNT(CASE WHEN cma_data_vencimento IS NOT NULL THEN 1 END) as com_cma,
  COUNT(CASE WHEN aso_data_vencimento IS NOT NULL THEN 1 END) as com_aso,
  COUNT(CASE WHEN nivel_icao_data_vencimento IS NOT NULL THEN 1 END) as com_icao
FROM funcionarios_vencimentos_backup;
