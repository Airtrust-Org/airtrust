-- ========================================
-- MIGRATION 007: Migrar ICAO para Checks
-- Data: 19 de Outubro de 2025
-- ========================================

-- Migrar dados de Nível ICAO para a tabela checks
INSERT INTO checks (
  funcionario_id,
  tipo_check,
  nivel,
  data_realizacao,
  data_vencimento,
  resultado,
  observacoes
)
SELECT 
  id as funcionario_id,
  'ICAO' as tipo_check,
  nivel_icao as nivel,
  COALESCE(DATE(nivel_icao_data_vencimento, '-36 months'), DATE('now', '-36 months')) as data_realizacao, -- ICAO vale 3 anos
  nivel_icao_data_vencimento as data_vencimento,
  'APROVADO' as resultado,
  'Migrado automaticamente do módulo de funcionários' as observacoes
FROM funcionarios
WHERE deleted_at IS NULL
  AND nivel_icao IS NOT NULL
  AND nivel_icao_data_vencimento IS NOT NULL;

-- Verificar migração
SELECT 
  COUNT(*) as total_migrado,
  tipo_check,
  COUNT(CASE WHEN resultado = 'APROVADO' THEN 1 END) as aprovados,
  COUNT(DISTINCT nivel) as niveis_diferentes
FROM checks
WHERE tipo_check = 'ICAO'
GROUP BY tipo_check;
