-- ========================================
-- MIGRATION 006: Migrar ASO para Exames
-- Data: 19 de Outubro de 2025
-- ========================================

-- Migrar dados de ASO para a tabela exames
INSERT INTO exames (
  funcionario_id,
  tipo_exame,
  data_realizacao,
  data_vencimento,
  resultado,
  observacoes
)
SELECT 
  id as funcionario_id,
  'ASO' as tipo_exame,
  COALESCE(DATE(aso_data_vencimento, '-12 months'), DATE('now', '-12 months')) as data_realizacao, -- Estimar data de realização (ASO vale 1 ano)
  aso_data_vencimento as data_vencimento,
  'APTO' as resultado,
  'Migrado automaticamente do módulo de funcionários' as observacoes
FROM funcionarios
WHERE deleted_at IS NULL
  AND aso_data_vencimento IS NOT NULL;

-- Verificar migração
SELECT 
  COUNT(*) as total_migrado,
  tipo_exame,
  COUNT(CASE WHEN resultado = 'APTO' THEN 1 END) as aptos
FROM exames
WHERE tipo_exame = 'ASO'
GROUP BY tipo_exame;
