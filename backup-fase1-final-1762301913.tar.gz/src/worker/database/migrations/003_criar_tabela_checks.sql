-- ========================================
-- MIGRATION 003: Criar Tabela de Checks
-- Data: 19 de Outubro de 2025
-- ========================================

-- Tabela para gerenciar checks de proficiência (ICAO, PF, etc.)
CREATE TABLE IF NOT EXISTS checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  funcionario_id INTEGER NOT NULL,
  tipo_check VARCHAR(50) NOT NULL, -- 'ICAO', 'PF', 'PC', 'REQUALIFICACAO'
  nivel VARCHAR(50), -- Para ICAO: '4', '5', '6' | Para PF/PC: 'APROVADO', 'REPROVADO'
  data_realizacao DATE NOT NULL,
  data_vencimento DATE, -- Alguns checks não vencem (ex: PF)
  instrutor VARCHAR(200),
  resultado VARCHAR(50), -- 'APROVADO', 'REPROVADO', 'REQUALIFICACAO_NECESSARIA'
  observacoes TEXT,
  arquivo_url VARCHAR(500),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_checks_funcionario_id ON checks(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_checks_tipo_check ON checks(tipo_check);
CREATE INDEX IF NOT EXISTS idx_checks_data_vencimento ON checks(data_vencimento);
CREATE INDEX IF NOT EXISTS idx_checks_deleted_at ON checks(deleted_at);
CREATE INDEX IF NOT EXISTS idx_checks_func_tipo ON checks(funcionario_id, tipo_check);

-- Verificar criação
SELECT 'Tabela checks criada com sucesso!' as status;
