-- ========================================
-- ÍNDICES PARA OTIMIZAÇÃO DE PERFORMANCE
-- AirTrust v2 - Fase 3
-- ========================================

-- Índices para tabela funcionarios
CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cpf ON funcionarios(cpf);
CREATE INDEX IF NOT EXISTS idx_funcionarios_status ON funcionarios(status);
CREATE INDEX IF NOT EXISTS idx_funcionarios_setor ON funcionarios(setor);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cargo ON funcionarios(cargo);
CREATE INDEX IF NOT EXISTS idx_funcionarios_base ON funcionarios(base);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cma_status ON funcionarios(cma_status);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cma_vencimento ON funcionarios(cma_data_vencimento);
CREATE INDEX IF NOT EXISTS idx_funcionarios_aso_vencimento ON funcionarios(aso_data_vencimento);
CREATE INDEX IF NOT EXISTS idx_funcionarios_nivel_icao_vencimento ON funcionarios(nivel_icao_data_vencimento);
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at);
CREATE INDEX IF NOT EXISTS idx_funcionarios_created_at ON funcionarios(created_at);
CREATE INDEX IF NOT EXISTS idx_funcionarios_updated_at ON funcionarios(updated_at);

-- Índices para tabela qualificacoes
CREATE INDEX IF NOT EXISTS idx_qualificacoes_funcionario_id ON qualificacoes(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_categoria ON qualificacoes(categoria);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_data_validade ON qualificacoes(data_validade);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_deleted_at ON qualificacoes(deleted_at);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_created_at ON qualificacoes(created_at);

-- Índices para tabela sessoes_simulador
CREATE INDEX IF NOT EXISTS idx_sessoes_aluno_id ON sessoes_simulador(aluno_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_instrutor_id ON sessoes_simulador(instrutor_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_simulador_id ON sessoes_simulador(simulador_id);
CREATE INDEX IF NOT EXISTS idx_sessoes_data ON sessoes_simulador(data);
CREATE INDEX IF NOT EXISTS idx_sessoes_status ON sessoes_simulador(status);
CREATE INDEX IF NOT EXISTS idx_sessoes_deleted_at ON sessoes_simulador(deleted_at);

-- Índices para tabela auditoria
CREATE INDEX IF NOT EXISTS idx_auditoria_module ON auditoriaavancadav2(module);
CREATE INDEX IF NOT EXISTS idx_auditoria_action ON auditoriaavancadav2(action);
CREATE INDEX IF NOT EXISTS idx_auditoria_user_id ON auditoriaavancadav2(user_id);
CREATE INDEX IF NOT EXISTS idx_auditoria_timestamp ON auditoriaavancadav2(timestamp);
CREATE INDEX IF NOT EXISTS idx_auditoria_target_record_id ON auditoriaavancadav2(target_record_id);

-- Índices compostos para queries comuns
CREATE INDEX IF NOT EXISTS idx_funcionarios_setor_status ON funcionarios(setor, status);
CREATE INDEX IF NOT EXISTS idx_funcionarios_cargo_status ON funcionarios(cargo, status);
CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_status ON funcionarios(deleted_at, status);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_funcionario_validade ON qualificacoes(funcionario_id, data_validade);
CREATE INDEX IF NOT EXISTS idx_qualificacoes_deleted_validade ON qualificacoes(deleted_at, data_validade);

-- Índices para melhorar performance de buscas
CREATE INDEX IF NOT EXISTS idx_funcionarios_nome ON funcionarios(nome);
CREATE INDEX IF NOT EXISTS idx_funcionarios_email ON funcionarios(email);

-- Verificar índices criados
SELECT 
  name as indice,
  tbl_name as tabela,
  sql
FROM sqlite_master 
WHERE type='index' 
  AND name LIKE 'idx_%'
ORDER BY tbl_name, name;
