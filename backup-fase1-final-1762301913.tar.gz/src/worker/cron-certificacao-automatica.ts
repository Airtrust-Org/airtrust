import { Env } from './types';

export async function processarCertificacaoAutomatica(env: Env): Promise<void> {
  
  try {
    const db = env.DB;
    
    const fichasConcluidas = await db.prepare(`
      SELECT 
        fs.id, 
        fs.ficha_uuid,
        fs.colaborador_id_aluno,
        fs.sessao_template_id,
        fs.ciclo_executado,
        fs.nota,
        fs.resultado_final,
        st.treinamento_codigo,
        f.nome as aluno_nome,
        f.matricula as aluno_matricula
      FROM fichas_sessao fs
      JOIN sessoes_template st ON fs.sessao_template_id = st.id
      JOIN funcionarios f ON fs.colaborador_id_aluno = f.id
      WHERE fs.status_workflow = 'CONCLUIDA'
      AND fs.resultado_final = 'APROVADO'
      AND fs.certificacao_automatica_executada = 0
      AND fs.deleted_at IS NULL
    `).all();


    for (const ficha of fichasConcluidas.results || []) {
      try {
        const dataVencimento = new Date();
        dataVencimento.setFullYear(dataVencimento.getFullYear() + 1); // 1 ano de validade

        const certResult = await db.prepare(`
          INSERT INTO historico_certificacoes_v2 (
            funcionario_id, treinamento_id, data_conclusao, data_vencimento,
            instrutor, nota, observacoes, status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          ficha.colaborador_id_aluno,
          ficha.sessao_template_id,
          new Date().toISOString().split('T')[0],
          dataVencimento.toISOString().split('T')[0],
          'Sistema Simulador',
          ficha.nota,
          `Certificação automática via simulador. Ficha: ${ficha.ficha_uuid}`,
          'ATIVO'
        ).run();

        if (!certResult.success) {
          throw new Error('Erro ao criar certificação no histórico');
        }

        const certificacaoId = certResult.meta.last_row_id;

        await db.prepare(`
          INSERT INTO pasta_virtual_sync_log (
            funcionario_id, historico_cert_id, arquivo_original_url,
            nome_arquivo_auditavel, funcionario_nome, funcionario_matricula,
            treinamento_nome, treinamento_codigo, data_conclusao, data_vencimento,
            status_sincronizacao
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          ficha.colaborador_id_aluno,
          certificacaoId,
          `simulador://ficha/${ficha.ficha_uuid}`,
          `CERT_SIM_${ficha.ficha_uuid}_${ficha.aluno_matricula}.pdf`,
          ficha.aluno_nome,
          ficha.aluno_matricula,
          `Simulador - ${ficha.treinamento_codigo}`,
          ficha.treinamento_codigo,
          new Date().toISOString().split('T')[0],
          dataVencimento.toISOString().split('T')[0],
          'PENDENTE'
        ).run();

        await db.prepare(`
          UPDATE fichas_sessao 
          SET certificacao_automatica_executada = 1,
              certificacao_automatica_timestamp = CURRENT_TIMESTAMP
          WHERE id = ?
        `).bind(ficha.id).run();


      } catch (error) {
        console.error(`[CRON] Erro ao processar ficha ${ficha.ficha_uuid}:`, error);
        
        await db.prepare(`
          UPDATE fichas_sessao 
          SET certificacao_automatica_erro = ?
          WHERE id = ?
        `).bind(
          error instanceof Error ? error.message : 'Erro desconhecido',
          ficha.id
        ).run();
      }
    }


  } catch (error) {
    console.error('[CRON] Erro geral no processamento:', error);
    throw error;
  }
}
