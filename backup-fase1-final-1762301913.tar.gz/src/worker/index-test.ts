import { Hono } from 'hono';
import { cors } from 'hono/cors';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization']
}));

app.get('/', (c) => {
  return c.text('AirTrust API v2.0 - Funcionando!');
});

app.post('/api/v2/auth/login', async (c) => {
  
  try {
    const body = await c.req.json();
    
    const { email, senha } = body;
    
    if (email === 'admin@airtrust.com' && senha === 'admin123') {
      return c.json({
        success: true,
        token: 'token-fake-desenvolvimento-12345',
        user: {
          id: 1,
          name: 'Admin Sistema',
          email: 'admin@airtrust.com',
          perfil: 'ADMIN'
        }
      });
    } else {
      return c.json({
        success: false,
        error: 'Credenciais inválidas'
      }, 401);
    }
    
  } catch (error) {
    console.error('❌ ERRO:', error);
    return c.json({
      success: false,
      error: 'Erro: ' + (error instanceof Error ? error.message : String(error))
    }, 500);
  }
});

app.get('/api/v2/debug', (c) => {
  return c.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    message: 'Backend funcionando'
  });
});

export default app;
