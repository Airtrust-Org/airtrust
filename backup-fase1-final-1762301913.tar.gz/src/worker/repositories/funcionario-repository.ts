/**
 * Repository Pattern - Funcionários
 * Centraliza todas as operações de banco de dados
 * AirTrust v2 - Outubro 2025
 */

import { D1Database } from '@cloudflare/workers-types';
import { Logger } from '../utils/logger';

export interface FuncionarioDados {
  nome: string;
  matricula?: string;
  cpf?: string;
  codigo_anac?: string;
  funcao: string;
  base?: string;
  contrato?: string;
  telefone?: string;
  email?: string;
  status?: string;
  cma_numero?: string;
  cma_data_vencimento?: string;
  cma_datavencimento?: string;
  cma_status?: string;
  aso_data_vencimento?: string;
  aso_datavencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
  nivel_icao_datavencimento?: string;
  nivel_icao_status?: string;
  is_instrutor?: number;
  is_checador?: number;
  aeronave_principal?: string;
  avatar?: string;
  anv?: string;
  data_nascimento?: string;
  data_nasc?: string;
  licenca_aeronautica?: string;
  codigo_canac?: string;
  codigo_sispat?: string;
  codigo_prestserv?: string;
  data_admissao?: string;
  contato_emergencia_nome?: string;
  contato_emergencia_parentesco?: string;
  contato_emergencia_telefone?: string;
}

export interface FiltrosFuncionario {
  funcao?: string;
  status?: string;
  base?: string;
  search?: string;
}

export class FuncionarioRepository {
  constructor(private db: D1Database) {}

  /**
   * Listar funcionários ativos com filtros e paginação
   */
  async listar(filtros?: FiltrosFuncionario, page = 1, limit = 50) {
    let query = `
      SELECT * FROM funcionarios 
      WHERE deleted_at IS NULL
    `;

    const params: any[] = [];

    if (filtros?.funcao) {
      query += ` AND funcao = ?`;
      params.push(filtros.funcao);
    }

    if (filtros?.status) {
      query += ` AND status = ?`;
      params.push(filtros.status);
    }

    if (filtros?.base) {
      query += ` AND base = ?`;
      params.push(filtros.base);
    }

    if (filtros?.search) {
      query += ` AND (nome LIKE ? OR matricula LIKE ? OR cpf LIKE ?)`;
      const searchParam = `%${filtros.search}%`;
      params.push(searchParam, searchParam, searchParam);
    }

    query += ` ORDER BY nome ASC LIMIT ? OFFSET ?`;
    const offset = (page - 1) * limit;
    params.push(limit, offset);

    const result = await this.db.prepare(query).bind(...params).all();

    let countQuery = `SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL`;
    const countParams: any[] = [];

    if (filtros?.funcao) {
      countQuery += ` AND funcao = ?`;
      countParams.push(filtros.funcao);
    }

    if (filtros?.status) {
      countQuery += ` AND status = ?`;
      countParams.push(filtros.status);
    }

    if (filtros?.base) {
      countQuery += ` AND base = ?`;
      countParams.push(filtros.base);
    }

    if (filtros?.search) {
      countQuery += ` AND (nome LIKE ? OR matricula LIKE ? OR cpf LIKE ?)`;
      const searchParam = `%${filtros.search}%`;
      countParams.push(searchParam, searchParam, searchParam);
    }

    const totalResult = await this.db.prepare(countQuery).bind(...countParams).first();
    const total = (totalResult?.total as number) || 0;

    return {
      data: result.results || [],
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    };
  }

  /**
   * Buscar funcionário por ID
   */
  async buscarPorId(id: number) {
    return await this.db.prepare(`
      SELECT * FROM funcionarios
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();
  }

  /**
   * Verificar se matrícula já existe
   */
  async matriculaExiste(matricula: string, excluirId?: number): Promise<boolean> {
    let query = `SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL`;
    const params: any[] = [matricula];

    if (excluirId) {
      query += ` AND id != ?`;
      params.push(excluirId);
    }

    const result = await this.db.prepare(query).bind(...params).first();
    return !!result;
  }

  /**
   * Verificar se CPF já existe
   */
  async cpfExiste(cpf: string, excluirId?: number): Promise<boolean> {
    let query = `SELECT id FROM funcionarios WHERE cpf = ? AND deleted_at IS NULL`;
    const params: any[] = [cpf];

    if (excluirId) {
      query += ` AND id != ?`;
      params.push(excluirId);
    }

    const result = await this.db.prepare(query).bind(...params).first();
    return !!result;
  }

  /**
   * Verificar se email já existe
   */
  async emailExiste(email: string, excluirId?: number): Promise<boolean> {
    let query = `SELECT id FROM funcionarios WHERE email = ? AND deleted_at IS NULL`;
    const params: any[] = [email];

    if (excluirId) {
      query += ` AND id != ?`;
      params.push(excluirId);
    }

    const result = await this.db.prepare(query).bind(...params).first();
    return !!result;
  }

  /**
   * Criar funcionário
   * NOTA: Usa apenas colunas que existem na tabela
   */
  async criar(dados: FuncionarioDados) {
    const now = new Date().toISOString();

    const result = await this.db.prepare(`
      INSERT INTO funcionarios (
        nome, matricula, cpf, codigo_anac, funcao, base, contrato,
        telefone, email, status, is_instrutor, is_checador,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      dados.nome,
      dados.matricula || null,
      dados.cpf || null,
      dados.codigo_anac || null,
      dados.funcao,
      dados.base || 'SBRJ',
      dados.contrato || 'CLT',
      dados.telefone || null,
      dados.email,
      dados.status || 'ATIVO',
      dados.is_instrutor || 0,
      dados.is_checador || 0,
      now,
      now
    ).run();

    return {
      id: result.meta.last_row_id,
      ...dados
    };
  }

  /**
   * Atualizar funcionário
   */
  async atualizar(id: number, dados: Partial<FuncionarioDados>) {
    const now = new Date().toISOString();

    await this.db.prepare(`
      UPDATE funcionarios SET
        nome = COALESCE(?, nome),
        matricula = COALESCE(?, matricula),
        cpf = COALESCE(?, cpf),
        codigo_anac = COALESCE(?, codigo_anac),
        funcao = COALESCE(?, funcao),
        base = COALESCE(?, base),
        contrato = COALESCE(?, contrato),
        telefone = COALESCE(?, telefone),
        email = COALESCE(?, email),
        status = COALESCE(?, status),
        is_instrutor = COALESCE(?, is_instrutor),
        is_checador = COALESCE(?, is_checador),
        updated_at = ?
      WHERE id = ? AND deleted_at IS NULL
    `).bind(
      dados.nome || null,
      dados.matricula || null,
      dados.cpf || null,
      dados.codigo_anac || null,
      dados.funcao || null,
      dados.base || null,
      dados.contrato || null,
      dados.telefone || null,
      dados.email || null,
      dados.status || null,
      dados.is_instrutor !== undefined ? dados.is_instrutor : null,
      dados.is_checador !== undefined ? dados.is_checador : null,
      now,
      id
    ).run();

    return { success: true };
  }

  /**
   * Soft delete de funcionário com backup
   */
  async excluir(id: number, userId?: number, ip?: string) {
    const funcionario = await this.buscarPorId(id);
    
    if (!funcionario) {
      throw new Error('Funcionário não encontrado ou já foi excluído');
    }

    try {
      await this.db.prepare(`
        INSERT INTO funcionarios_backup 
        (funcionario_id, operacao, dados_antes, user_id, ip, timestamp)
        VALUES (?, 'SOFT_DELETE', ?, ?, ?, datetime('now'))
      `).bind(
        id,
        JSON.stringify(funcionario),
        userId || null,
        ip || 'unknown'
      ).run();
    } catch (error) {
      Logger.warn('Backup falhou ao excluir funcionário', { id, error });
    }

    const result = await this.db.prepare(`
      UPDATE funcionarios
      SET deleted_at = datetime('now'), 
          updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).run();

    if (result.meta.changes === 0) {
      throw new Error('Falha ao excluir funcionário - nenhuma linha afetada');
    }

    const verificacao = await this.db.prepare(`
      SELECT id, nome, deleted_at FROM funcionarios WHERE id = ?
    `).bind(id).first();

    if (verificacao && !verificacao.deleted_at) {
      throw new Error('Exclusão não persistiu no banco de dados');
    }

    return { success: true, id };
  }

  /**
   * Importação em lote
   */
  async criarLote(registros: FuncionarioDados[], batchSize = 100) {
    const sucesso: number[] = [];
    const erros: Array<{ dados: FuncionarioDados; erro: string }> = [];

    for (let i = 0; i < registros.length; i += batchSize) {
      const batch = registros.slice(i, i + batchSize);

      for (const dados of batch) {
        try {
          const resultado = await this.criar(dados);
          sucesso.push(resultado.id as number);
        } catch (error: any) {
          erros.push({
            dados,
            erro: error.message || 'Erro desconhecido'
          });
        }
      }
    }

    return { sucesso, erros };
  }
}
