/// <reference types="@cloudflare/workers-types" />

import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { secureHeaders } from 'hono/secure-headers';
import { ZodError } from 'zod';

import app from './routes/index';

import { securityMiddleware } from './middleware/security-middleware';
import { Logger } from './utils/logger';
import { AppError } from './utils/AppError';
import { globalErrorHandler, withD1Error } from './middleware/global-error-handler';

import type { Env } from './types/index';

import { criarBackupCompleto, limparBackupsAntigos } from './utils/backup-utils';

import { enviarNotificacoesVencimento } from './jobs/notificacoes';

import { invalidateCache } from './utils/cache-qualificacoes';
import { ensureSchemaSyncMigration } from './migrations/ensure-schema-sync';
// import { fixRenovadasExistentes } from './migrations/fix-renovadas-existentes';

const worker = new Hono<{ Bindings: Env }>();

// Handler RAW para upload de CERTIFICADOS - ANTES de qualquer middleware
worker.post('/api/v2/certificados/upload', async (c) => {
  try {
    console.log('📤 [CERTIFICADO-UPLOAD] Iniciando upload');

    const formData = await c.req.formData();
    const arquivo = formData.get('arquivo') as File;
    const habilitacaoId = Number(formData.get('habilitacao_id'));
    const funcionarioId = Number(formData.get('funcionario_id'));
    const qualificacaoId = Number(formData.get('qualificacao_id'));

    console.log('📋 [CERTIFICADO-UPLOAD] Dados recebidos:', {
      arquivo: arquivo?.name,
      habilitacaoId,
      funcionarioId,
      qualificacaoId,
    });

    if (!arquivo || !habilitacaoId || !funcionarioId || !qualificacaoId) {
      console.error('❌ [CERTIFICADO-UPLOAD] Dados faltando:', {
        arquivo: !!arquivo,
        habilitacaoId,
        funcionarioId,
        qualificacaoId,
      });
      return c.json(
        {
          success: false,
          error: 'Dados obrigatórios faltando',
        },
        400,
      );
    }

    const r2 = c.env.AIRTRUST_STORAGE;
    const db = c.env.DB;

    if (!r2) {
      return c.json({ success: false, error: 'R2 storage não configurado' }, 500);
    }

    // Buscar dados da habilitação
    const hab = (await db
      .prepare(
        `
      SELECT h.*, f.nome as funcionario_nome, q.nome as qualificacao_nome
      FROM habilitacoes h
      LEFT JOIN funcionarios f ON h.funcionario_id = f.id
      LEFT JOIN qualificacoes q ON h.qualificacao_id = q.id
      WHERE h.id = ?
    `,
      )
      .bind(habilitacaoId)
      .first()) as {
      id: number;
      funcionario_id: number;
      qualificacao_id: number;
      data_conclusao: string;
      funcionario_nome?: string;
      qualificacao_nome?: string;
    } | null;

    if (!hab) {
      return c.json({ success: false, error: 'Habilitação não encontrada' }, 404);
    }

    // Normalizar nome (underline dentro de nomes, traço entre elementos)
    const normalizarParte = (str: string) =>
      str
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, '_')
        .replace(/[^a-z0-9_]/g, '')
        .replace(/_+/g, '_')
        .replace(/^_|_$/g, '');

    const nomeNormalizado = normalizarParte(hab.funcionario_nome || 'funcionario');
    const qualificacaoNorm = normalizarParte(hab.qualificacao_nome || 'qualificacao');
    const dataNorm = hab.data_conclusao
      ? hab.data_conclusao.split('T')[0]
      : new Date().toISOString().split('T')[0];
    const nomeArquivo = `${nomeNormalizado}-${qualificacaoNorm}-${dataNorm}.pdf`;

    // Upload para R2 - organizado por funcionário (BUG-002: parseInt para evitar float)
    const funcionarioIdInt = parseInt(String(funcionarioId), 10);
    const caminhoR2 = `certificados/${funcionarioIdInt}/${nomeArquivo}`;
    const buf = await arquivo.arrayBuffer();
    await r2.put(caminhoR2, buf, {
      httpMetadata: {
        contentType: 'application/pdf',
        contentDisposition: `attachment; filename="${nomeArquivo}"`,
      },
    });

    // Registrar no banco
    const resultado = await db
      .prepare(
        `
      INSERT INTO certificados (
        habilitacao_id, funcionario_id, qualificacao_id,
        arquivo_url, arquivo_nome, arquivo_tamanho, arquivo_hash,
        numero_certificado, tipo, data_emissao,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `,
      )
      .bind(
        habilitacaoId,
        funcionarioId,
        qualificacaoId,
        caminhoR2,
        nomeArquivo,
        buf.byteLength,
        '',
        `CERT-${habilitacaoId}-${Date.now()}`,
        'upload',
        new Date().toISOString().split('T')[0],
      )
      .run();

    console.log('✅ [CERTIFICADO-UPLOAD] Upload concluído');

    return c.json({
      success: true,
      message: 'Certificado enviado com sucesso',
      data: { id: resultado.meta.last_row_id },
    });
  } catch (error: unknown) {
    console.error('❌ [CERTIFICADO-UPLOAD] Erro:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro ao fazer upload';
    return c.json({ success: false, error: errorMessage }, 500);
  }
});

// Handler RAW para upload de qualificações - ANTES de qualquer middleware
worker.post('/api/v2/qualificacoes/upload-certificado', async (c) => {
  try {
    console.log('📤 [UPLOAD] Iniciando upload de certificado');

    // Parsear body manualmente para evitar problemas com Content-Type (solução do dia 29)
    let formData: FormData;
    try {
      formData = await c.req.formData();
      console.log('✅ [UPLOAD] formData() funcionou');
    } catch {
      // Se formData() falhar, tentar parseBody()
      console.log('⚠️ [UPLOAD] formData() falhou, tentando parseBody()');
      const body = await c.req.parseBody({ all: true });

      // Converter para FormData manualmente
      formData = new FormData();
      for (const [key, value] of Object.entries(body)) {
        if (Array.isArray(value)) {
          value.forEach((v) => formData.append(key, v as unknown as string | Blob));
        } else {
          formData.append(key, value as unknown as string | Blob);
        }
      }
      console.log('✅ [UPLOAD] parseBody() funcionou');
    }

    const file = formData.get('file') as File;
    const funcionarioId = formData.get('funcionarioId')?.toString() || 'sem-funcionario';
    const qualificacaoId = formData.get('qualificacaoId')?.toString();

    if (!file) {
      return c.json({ success: false, error: 'Arquivo obrigatório' }, 400);
    }

    const r2 = c.env.AIRTRUST_STORAGE;
    if (!r2) {
      return c.json({ success: false, error: 'R2 não configurado' }, 500);
    }

    const now = Date.now();
    const sanitizedName = file.name.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const r2Path = `qualificacoes/${funcionarioId}/${now}_${sanitizedName}`;

    const buf = await file.arrayBuffer();
    await r2.put(r2Path, buf, {
      httpMetadata: {
        contentType: file.type || 'application/pdf',
        contentDisposition: `attachment; filename="${sanitizedName}"`,
      },
      customMetadata: {
        funcionario_id: funcionarioId,
        uploaded_at: new Date().toISOString(),
      },
    });

    console.log('✅ [UPLOAD] Upload no R2 concluído:', r2Path);

    // Atualizar qualificação com arquivo_url se qualificacaoId foi fornecido
    if (qualificacaoId && c.env.DB) {
      try {
        await c.env.DB.prepare(
          `
          UPDATE qualificacoes 
          SET arquivo_url = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `,
        )
          .bind(r2Path, qualificacaoId)
          .run();
        console.log('✅ [UPLOAD] arquivo_url salvo na qualificação:', qualificacaoId);
      } catch (dbError: unknown) {
        console.error('❌ [UPLOAD] Erro ao salvar no banco:', dbError);
      }
    }

    return c.json({
      success: true,
      url: r2Path,
      path: r2Path,
      filename: sanitizedName,
    });
  } catch (error: unknown) {
    console.error('❌ [RAW-UPLOAD] Erro:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro ao fazer upload';
    return c.json({ success: false, error: errorMessage }, 500);
  }
});

// ✅ NEW: Health check endpoint (Fase 1 - Stability)
worker.get('/api/health', async (c) => {
  const startTime = Date.now();
  const checks: Record<string, any> = {};

  try {
    // D1 latency test with retry
    const d1Start = Date.now();
    await withD1Error(() => c.env.DB.prepare('SELECT 1 as test').bind().first(), {
      operationName: 'HEALTH_D1_CHECK',
    });
    const d1Latency = Date.now() - d1Start;

    checks.d1 = {
      ok: true,
      latency_ms: d1Latency,
      status: d1Latency < 500 ? 'healthy' : d1Latency < 1000 ? 'degraded' : 'slow',
    };

    const totalTime = Date.now() - startTime;
    const isHealthy = checks.d1.status === 'healthy' && totalTime < 1000;

    return c.json(
      {
        success: true,
        status: isHealthy ? 'healthy' : 'degraded',
        checks,
        timestamp: new Date().toISOString(),
        response_time_ms: totalTime,
      },
      200,
    );
  } catch (error) {
    const totalTime = Date.now() - startTime;
    Logger.error('Health check failed', error as Error);
    return c.json(
      {
        success: false,
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown',
        response_time_ms: totalTime,
      },
      503,
    );
  }
});

// Legacy health endpoint for compatibility
worker.get('/health', async (c) => {
  try {
    const dbTest = (await c.env.DB.prepare('SELECT 1 as test').bind().first()) as {
      test: number;
    } | null;
    const dbOk = dbTest && (dbTest as { test: number }).test === 1;

    const tables = await c.env.DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('funcionarios', 'qualificacoes', 'exames', 'checks')",
    )
      .bind()
      .all();

    return c.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      version: '2.0.0',
      db: {
        connected: dbOk,
        tables: tables.results?.length || 0,
        expected: 4,
      },
      environment: c.env.ENVIRONMENT || 'development',
    });
  } catch (error) {
    return c.json(
      {
        status: 'error',
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Unknown error',
        db: { connected: false },
      },
      500,
    );
  }
});

// ================================
// MIDDLEWARE GLOBAL (Em Ordem de Execução)
// ================================

// 1️⃣ PRIMEIRO: Global error handler com retry e logging estruturado
worker.use('*', globalErrorHandler());

// 2️⃣ Aplicar secureHeaders apenas para rotas que NÃO são upload
worker.use('*', async (c, next) => {
  if (c.req.path === '/api/v2/qualificacoes/upload-certificado') {
    console.log('⏭️ [MIDDLEWARE] Pulando secureHeaders para upload');
    return next();
  }

  const middleware = secureHeaders({
    contentSecurityPolicy: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      objectSrc: ["'none'"],
    },
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: false,
  });

  return middleware(c, next);
});

worker.use(
  '*',
  cors({
    origin: (origin) => {
      if (!origin) return '*'; // Requests sem origin (ex: Postman)

      const allowedOrigins = [
        'http://localhost:5173',
        'http://localhost:3000',
        'https://521c8b4c.airtrust.pages.dev',
        'https://main.airtrust.pages.dev',
        'https://airtrust.pages.dev',
        'https://airtrust.com.br',
        'https://www.airtrust.com.br',
      ];

      return allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
    },
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization'],
    credentials: true,
  }),
);

worker.use(
  '*',
  logger((message) => {
    Logger.info(message);
  }),
);

worker.use('*', securityMiddleware);

worker.use('*', async (c, next) => {
  const url = new URL(c.req.url);

  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/health') ||
    url.pathname.startsWith('/cron/')
  ) {
    return next();
  }

  Logger.info(`[ASSETS] Tentando servir: ${url.pathname}`);

  try {
    const asset = await c.env.ASSETS.fetch(c.req.raw);
    Logger.info(`[ASSETS] Status: ${asset.status}`);

    if (asset.status === 200) {
      const headers = new Headers(asset.headers);

      if (url.pathname === '/' || url.pathname.endsWith('.html')) {
        headers.set(
          'Cache-Control',
          'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
        );
        headers.set('Pragma', 'no-cache');
        headers.set('Expires', '0');
        headers.set('Surrogate-Control', 'no-store');
        headers.set('Clear-Site-Data', '"cache"');
        return new Response(asset.body, {
          status: asset.status,
          statusText: asset.statusText,
          headers,
        });
      }

      if (url.pathname.endsWith('.js') || url.pathname.endsWith('.css')) {
        headers.set('Cache-Control', 'no-cache, must-revalidate, max-age=0');
        return new Response(asset.body, {
          status: asset.status,
          statusText: asset.statusText,
          headers,
        });
      }

      return asset;
    }

    if (asset.status === 404) {
      Logger.info(`[ASSETS] 404 - Tentando SPA fallback`);
      const indexUrl = new URL(c.req.url);
      indexUrl.pathname = '/';
      const indexAsset = await c.env.ASSETS.fetch(indexUrl);

      if (indexAsset.status === 200) {
        return new Response(indexAsset.body, {
          headers: {
            'Content-Type': 'text/html',
            'Cache-Control': 'no-store, no-cache, must-revalidate',
          },
        });
      }
    }
  } catch (e) {
    Logger.error('[ASSETS] Erro:', e);
  }

  return next();
});

worker.onError((err: unknown, c) => {
  const isAppError = err instanceof AppError;
  const isZodError = err instanceof ZodError;

  Logger.error('Global error handler', err, {
    path: c.req.path,
    method: c.req.method,
    userAgent: c.req.header('user-agent'),
    ip: c.req.header('x-forwarded-for') || 'unknown',
    errorType: isAppError ? 'AppError' : isZodError ? 'ZodError' : 'Unknown',
  });

  // Erro de aplicação com status code conhecido
  if (isAppError) {
    const obj = {
      success: false,
      error: err.message,
      code: err.code,
    };
    const status = err.statusCode;
    // Hono precisa do status como number literal
    return new Response(JSON.stringify(obj), {
      status,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Erro de validação Zod
  if (isZodError) {
    return c.json(
      {
        success: false,
        error: 'Erro de validação',
        code: 'VALIDATION_ERROR',
        details: err.errors,
      },
      400,
    );
  }

  // Erro genérico
  return c.json(
    {
      success: false,
      error: 'Erro interno do servidor',
      timestamp: new Date().toISOString(),
    },
    500,
  );
});

worker.route('/', app);

worker.get('/cron/auditoria-semanal', async (c) => {
  try {
    Logger.info('Executing weekly audit cron job');

    return c.json({
      success: true,
      message: 'Auditoria semanal executada',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    Logger.error('Weekly audit cron job failed', error);
    return c.json({ success: false, error: 'Falha na auditoria semanal' }, 500);
  }
});

worker.get('/cron/certificacao-automatica', async (c) => {
  try {
    Logger.info('Executing automatic certification cron job');

    return c.json({
      success: true,
      message: 'Certificação automática executada',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    Logger.error('Automatic certification cron job failed', error);
    return c.json({ success: false, error: 'Falha na certificação automática' }, 500);
  }
});

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    // Interceptar uploads ANTES do Hono processar
    if (request.method === 'POST' && url.pathname === '/api/v2/qualificacoes/upload-certificado') {
      console.log('🎯 [INTERCEPTOR] Processando upload fora do Hono');

      try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const funcionarioId = formData.get('funcionarioId')?.toString() || 'sem-funcionario';
        const qualificacaoId = formData.get('qualificacaoId')?.toString();

        if (!file) {
          return new Response(
            JSON.stringify({
              success: false,
              error: 'Arquivo obrigatório',
            }),
            {
              status: 400,
              headers: { 'Content-Type': 'application/json' },
            },
          );
        }

        const r2 = env.AIRTRUST_STORAGE;
        if (!r2) {
          return new Response(
            JSON.stringify({
              success: false,
              error: 'R2 não configurado',
            }),
            {
              status: 500,
              headers: { 'Content-Type': 'application/json' },
            },
          );
        }

        // Buscar dados da qualificação e funcionário para criar nome correto
        let nomeArquivo = file.name.replace(/[^a-zA-Z0-9_.-]/g, '_');

        if (qualificacaoId && env.DB) {
          try {
            const qualificacao = (await env.DB.prepare(
              `
              SELECT 
                q.nome as qualificacao_nome,
                q.codigo as qualificacao_codigo,
                q.data_conclusao,
                f.nome as funcionario_nome
              FROM qualificacoes q
              INNER JOIN funcionarios f ON f.id = q.funcionario_id
              WHERE q.id = ?
            `,
            )
              .bind(qualificacaoId)
              .first()) as {
              qualificacao_nome?: string;
              qualificacao_codigo?: string;
              data_conclusao?: string;
              funcionario_nome?: string;
            } | null;

            if (qualificacao) {
              // Função para normalizar texto removendo acentos
              const normalizar = (texto: string) => {
                return texto
                  .normalize('NFD') // Decompõe caracteres acentuados
                  .replace(/[\u0300-\u036f]/g, '') // Remove marcas diacríticas
                  .replace(/[^a-zA-Z0-9]/g, '_') // Substitui caracteres especiais por _
                  .replace(/_+/g, '_') // Remove underscores duplicados
                  .replace(/^_|_$/g, ''); // Remove underscores do início e fim
              };

              const funcionarioNome = normalizar((qualificacao.funcionario_nome || '') as string);
              const qualificacaoNome = normalizar(
                (qualificacao.qualificacao_nome ||
                  qualificacao.qualificacao_codigo ||
                  '') as string,
              );
              const dataRealizado = qualificacao.data_conclusao
                ? (qualificacao.data_conclusao as string).replace(/[^0-9]/g, '')
                : new Date()
                    .toISOString()
                    .split('T')[0]
                    .replace(/[^0-9]/g, '');
              nomeArquivo = `${funcionarioNome}-${qualificacaoNome}-${dataRealizado}.pdf`;
              console.log('📝 [INTERCEPTOR] Nome do arquivo gerado:', nomeArquivo);
            }
          } catch (err) {
            console.warn('⚠️ [INTERCEPTOR] Erro ao buscar dados para nome do arquivo:', err);
          }
        }

        const now = Date.now();
        const r2Path = `qualificacoes/${funcionarioId}/${now}_${nomeArquivo}`;

        const buf = await file.arrayBuffer();
        await r2.put(r2Path, buf, {
          httpMetadata: {
            contentType: 'application/pdf',
            contentDisposition: `attachment; filename="${nomeArquivo}"`,
          },
          customMetadata: {
            funcionario_id: funcionarioId,
            qualificacao_id: qualificacaoId || '',
            uploaded_at: new Date().toISOString(),
            original_filename: nomeArquivo,
          },
        });

        console.log('✅ [INTERCEPTOR] Upload no R2 concluído:', r2Path);

        // Atualizar qualificação com arquivo_url
        console.log('🔍 [INTERCEPTOR] Dados para UPDATE:', {
          qualificacaoId,
          r2Path,
          hasDB: !!env.DB,
        });

        if (qualificacaoId && env.DB) {
          try {
            const result = await env.DB.prepare(
              `
              UPDATE qualificacoes 
              SET arquivo_url = ?, updated_at = CURRENT_TIMESTAMP
              WHERE id = ?
            `,
            )
              .bind(r2Path, qualificacaoId)
              .run();

            console.log('✅ [INTERCEPTOR] arquivo_url salvo na qualificação:', qualificacaoId);
            console.log('📊 [INTERCEPTOR] Resultado do UPDATE:', result);

            // Verificar se realmente salvou
            const verificacao = await env.DB.prepare(
              `
              SELECT id, arquivo_url FROM qualificacoes WHERE id = ?
            `,
            )
              .bind(qualificacaoId)
              .first();
            console.log('🔍 [INTERCEPTOR] Verificação após UPDATE:', verificacao);

            // Invalidar cache de qualificações
            invalidateCache('qualificacoes:');
            console.log('🗑️ [INTERCEPTOR] Cache de qualificações invalidado');
          } catch (dbError: any) {
            console.error('❌ [INTERCEPTOR] Erro ao salvar no banco:', dbError);
          }
        } else {
          console.warn('⚠️ [INTERCEPTOR] qualificacaoId não fornecido, arquivo_url não foi salvo');
        }

        return new Response(
          JSON.stringify({
            success: true,
            url: r2Path,
            path: r2Path,
            filename: nomeArquivo,
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*',
            },
          },
        );
      } catch (error: any) {
        console.error('❌ [INTERCEPTOR] Erro:', error);
        return new Response(
          JSON.stringify({
            success: false,
            error: error.message,
          }),
          {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
          },
        );
      }
    }

    // Para todas as outras rotas, usar o Hono normalmente
    Logger.setProduction(env.ENVIRONMENT === 'production');

    // Executar migração de sincronização de schema se necessário
    try {
      await ensureSchemaSyncMigration(env.DB);

      // MIGRATION JÁ EXECUTADA - COMENTADO PARA NÃO RODAR NOVAMENTE
      /*
      const migrationCheck = await env.DB.prepare(
        "SELECT valor FROM system_config WHERE chave = 'migration_renovadas_v1' LIMIT 1",
      )
        .bind()
        .first()
        .catch(() => null);

      if (!migrationCheck) {
        Logger.info('🔄 Executando migration: fix-renovadas-existentes');
        await fixRenovadasExistentes(env.DB as any);

        await env.DB.prepare(
          "INSERT OR REPLACE INTO system_config (chave, valor, updated_at) VALUES ('migration_renovadas_v1', 'executed', CURRENT_TIMESTAMP)",
        )
          .bind()
          .run()
          .catch(() => {
            Logger.warn(
              'Tabela system_config não existe, migration será executada novamente no próximo deploy',
            );
          });
      }
      */
    } catch (error) {
      Logger.warn('Erro ao sincronizar schema', error as any);
    }

    return worker.fetch(request, env, ctx);
  },

  async scheduled(event: any, env: any, ctx: any) {
    Logger.setProduction(env.ENVIRONMENT === 'production');

    switch (event.cron) {
      case '0 3 * * *': // Todo dia às 3h da manhã - BACKUP + NOTIFICAÇÕES
        Logger.info('Running automatic backup and notifications scheduled event');
        try {
          const resultado = await criarBackupCompleto(env, 'Backup automático diário');
          Logger.info('Backup automático concluído', { backup_id: resultado.id });

          const configResult = await env.DB.prepare(
            'SELECT valor FROM backup_configuracoes WHERE chave = ?',
          )
            .bind('backup_retencao_dias')
            .first();

          const retencaoDias = parseInt((configResult?.valor as string) || '30');

          const removidos = await limparBackupsAntigos(env, retencaoDias);
          Logger.info('Backups antigos removidos', { total: removidos });

          ctx.waitUntil(enviarNotificacoesVencimento(env));
        } catch (error) {
          Logger.error('Erro no backup automático', error);
        }
        break;

      case '0 0 * * 0': // Todo domingo à meia-noite
        Logger.info('Running weekly audit scheduled event');
        break;

      case '6 0 * * *': // Todo dia às 00:06 UTC - RECÁLCULO DE QUALIFICAÇÕES
        Logger.info('🔄 Iniciando recálculo automático de qualificações');
        try {
          // Recalcular status de todas as qualificações
          const result = await env.DB.prepare(
            `
            UPDATE qualificacoes 
            SET updated_at = CURRENT_TIMESTAMP
            WHERE deleted_at IS NULL
              AND is_renovada = 0
              AND data_vencimento IS NOT NULL
          `,
          ).run();

          Logger.info('✅ Recálculo de qualificações concluído', {
            total_atualizado: result.meta.changes,
          });

          // Buscar qualificações críticas (vencidas ou vencendo)
          const criticas = await env.DB.prepare(
            `
            SELECT COUNT(*) as total
            FROM qualificacoes
            WHERE deleted_at IS NULL
              AND is_renovada = 0
              AND data_vencimento IS NOT NULL
              AND julianday(data_vencimento) - julianday('now') <= 30
          `,
          ).first();

          Logger.info('⚠️ Qualificações críticas detectadas', {
            total: (criticas as any)?.total || 0,
          });
        } catch (error) {
          Logger.error('❌ Erro no recálculo de qualificações', error);
        }
        break;

      case '0 2 * * *': // Todo dia às 2h da manhã
        Logger.info('Running daily certification check');
        break;

      default:
        Logger.warn('Unknown scheduled event', { cron: event.cron });
    }
  },
};
