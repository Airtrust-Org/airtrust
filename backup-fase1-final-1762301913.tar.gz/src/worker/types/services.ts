// Common types for services
/* eslint-disable @typescript-eslint/no-explicit-any */

import type { Habilitacao as HabilitacaoCore } from './index';

export interface BaseEntity {
  id?: number;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
}

export interface QueryResult<T> {
  total: number;
  data: T[];
}

export interface ServiceConfig {
  table: string;
  db: Record<string, any>; // D1 Database
}

// Habilitações - Use o core type
export interface CreateHabilitacaoInput {
  funcionario_id: number;
  qualificacao_id: number;
  data_conclusao: string;
  data_vencimento: string;
  resultado?: 'APROVADO' | 'REPROVADO' | 'PENDENTE';
  status?: 'ATIVA' | 'VENCIDA' | 'SUSPENSA';
  nota_final?: number;
  observacoes?: string;
  instrutor?: string;
  timezone?: string;
  eh_renovada?: boolean;
  habilitacao_anterior_id?: number;
}

export type UpdateHabilitacaoInput = Partial<CreateHabilitacaoInput>;

// Re-export do core
export type Habilitacao = HabilitacaoCore;

// Qualificações
export interface CreateQualificacaoInput {
  nome: string;
  descricao?: string;
  ativa?: boolean;
  categoria?: string;
}

export type UpdateQualificacaoInput = Partial<CreateQualificacaoInput>;

export interface Qualificacao extends BaseEntity {
  nome: string;
  descricao?: string;
  ativa: boolean;
  categoria?: string;
}

// Certificados
export interface Certificado extends BaseEntity {
  habilitacao_id: number;
  funcionario_id: number;
  qualificacao_id: number;
  empresa_id: number;
  url: string;
  data_emissao: string;
}

// Empresa Config
export interface EmpresaConfig extends BaseEntity {
  empresa_id: number;
  nome?: string;
  logo_url?: string;
  cor_primaria?: string;
  cor_secundaria?: string;
  endereco?: string;
  telefone?: string;
  email?: string;
}

// Worker types
export interface WorkerEnv {
  DB: Record<string, any>; // D1 Database
  R2_BUCKET?: Record<string, any>;
  R2_DOMAIN?: string;
  ENVIRONMENT: 'development' | 'production';
}

export interface WorkerContext {
  waitUntil(promise: Promise<Record<string, any>>): void;
  passThroughOnException(): void;
}
