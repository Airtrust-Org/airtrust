/**
 * Tipos do contexto Hono
 */

import { Context } from 'hono';
import type { UserRole } from './index';

export interface UserContext {
  id: number;
  email: string;
  nome: string;
  perfil: UserRole; // Updated to use UserRole which includes all roles
}

export interface AppVariables {
  user?: UserContext;
}

export type AppContext = {
  Bindings: Env;
  Variables: AppVariables;
};

export type HonoContext = Context<AppContext>;
