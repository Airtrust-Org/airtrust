// REFATORADO: tipos_qualificacoes → qualificacoes (master/padrão)
// REFATORADO: qualificacoes → habilitacoes (instância por funcionário)

/** Qualificação Master - Define o tipo, validade e conteúdo padrão */
export interface Qualificacao {
  id: number;
  nome: string;
  codigo: string;
  categoria: 'Nenhuma' | 'Profissional' | 'Periódico' | 'Especial';
  descricao?: string;
  carga_horaria: number;
  conteudo_programatico?: string;
  validade_meses: number;
  tipo_vencimento: 'Dia Exato' | 'Aniversário' | 'Mês Seguinte';
  created_at: string;
  updated_at?: string;
  deleted_at?: string;
}

// Re-exportar Habilitacao unificada de index.ts
export { Habilitacao } from './index';
