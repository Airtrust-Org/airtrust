import 'hono';

declare module 'hono' {
  interface ContextVariableMap {
    user: {
      id: number;
      nome: string;
      email: string;
      perfil: 'ADMIN' | 'COMPLIANCE' | 'USUARIO';
      cpf?: string;
      matricula?: string;
    };
  }
}
