/// <reference types="@cloudflare/workers-types" />

export interface Env {
  DB: D1Database;
  R2_BUCKET?: R2Bucket;
  BUCKET?: R2Bucket;
  CERTIFICATES?: R2Bucket;
  CERTIFICADOS?: R2Bucket;
  BACKUPS?: R2Bucket;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;
  CLOUDFLARE_API_TOKEN?: string;
  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_ENDPOINT?: string;
  R2_BUCKET_NAME?: string;
  R2_ACCOUNT_ID?: string;
  ALERT_WEBHOOK?: string;
  JWT_SECRET?: string;
}

declare global {
  type Env = {
    DB: D1Database;
    R2_BUCKET?: R2Bucket;
    BUCKET?: R2Bucket;
    CERTIFICATES?: R2Bucket;
    CERTIFICADOS?: R2Bucket;
    BACKUPS?: R2Bucket;
    MOCHA_USERS_SERVICE_API_KEY?: string;
    MOCHA_USERS_SERVICE_API_URL?: string;
    CLOUDFLARE_API_TOKEN?: string;
    R2_ACCESS_KEY_ID?: string;
    R2_SECRET_ACCESS_KEY?: string;
    R2_ENDPOINT?: string;
    R2_BUCKET_NAME?: string;
    R2_ACCOUNT_ID?: string;
    ALERT_WEBHOOK?: string;
    JWT_SECRET?: string;
  };
}
