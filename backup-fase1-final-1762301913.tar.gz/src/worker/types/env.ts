export interface Env {
  DB: D1Database;
  
  AIRTRUST_STORAGE: R2Bucket;
  
  ENVIRONMENT: string;
  
  // Feature flags de segurança
  ENABLE_DEV_AUTH_BYPASS?: string;
  LGPD_ENDPOINT_ENABLED?: string;
  HARD_DELETE_ENABLED?: string;
  RATE_LIMIT_IMPORT_ENABLED?: string;
}
