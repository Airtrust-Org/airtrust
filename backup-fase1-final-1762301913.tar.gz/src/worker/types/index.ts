export type UserRole = 'ADMIN' | 'COMPLIANCE' | 'GESTOR' | 'FUNCIONARIO' | 'USUARIO';

export interface User {
  id: number;
  nome: string;
  name: string; // Alias para nome (compatibilidade)
  email: string;
  perfil: UserRole; // Updated to use UserRole which includes FUNCIONARIO, GESTOR
  cpf?: string;
  matricula?: string;
  funcionario_id?: number;
  equipe?: string;
}

export interface DatabaseUser extends User {
  email: string;
  password_hash: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export type FuncionarioStatus = 'ATIVO' | 'INATIVO' | 'LICENCA' | 'DEMITIDO';
export type CertificacaoStatus = 'VALIDO' | 'VENCIDO' | 'VENCENDO' | 'NAO_APLICAVEL';

export interface Funcionario {
  id: number;
  nome: string;
  matricula?: string;
  cpf?: string;
  codigo_anac?: string;
  funcao: string;
  base?: string;
  contrato?: string;
  telefone?: string;
  email?: string;
  status: FuncionarioStatus;
  cma_numero?: string;
  cma_data_vencimento?: string;
  cma_status?: CertificacaoStatus;
  aso_data_vencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
  nivel_icao_status?: CertificacaoStatus;
  is_instrutor: boolean;
  is_checador: boolean;
  aeronave_principal?: string;
  avatar?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface CreateFuncionarioRequest {
  nome: string;
  matricula?: string;
  cpf?: string;
  codigo_anac?: string;
  funcao: string;
  base?: string;
  contrato?: string;
  telefone?: string;
  email?: string;
  status?: FuncionarioStatus;
  cma_numero?: string;
  cma_data_vencimento?: string;
  aso_data_vencimento?: string;
  nivel_icao?: string;
  nivel_icao_data_vencimento?: string;
  is_instrutor?: boolean;
  is_checador?: boolean;
  aeronave_principal?: string;
}

export interface UpdateFuncionarioRequest extends Partial<CreateFuncionarioRequest> {
  id: number;
}

// ========================================
// HABILITAÇÕES
// ========================================

export interface Habilitacao {
  // IDs e FKs
  id: number;
  funcionario_id: number;
  qualificacao_id: number;
  empresa_id?: number;

  // Datas
  data_conclusao: string;
  data_vencimento: string;

  // Status
  resultado?: 'APROVADO' | 'REPROVADO' | 'PENDENTE';
  status?: 'ATIVA' | 'VENCIDA' | 'SUSPENSA';

  // Dados
  nota_final?: number;
  instrutor?: string;
  observacoes?: string;
  certificado_url?: string;
  timezone?: string;

  // Renovação
  eh_renovada?: boolean;
  renovada_em?: string | null;
  habilitacao_anterior_id?: number | null;

  // Auditoria
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;

  // Dados enriched (via JOINs)
  funcionario_nome?: string;
  funcionario_matricula?: string;
  qualificacao_nome?: string;
  qualificacao_codigo?: string;
  categoria_nome?: string;
  validade_meses?: number;
  status_computado?: string; // VÁLIDO/VENCENDO/VENCIDA
  dias_para_vencimento?: number;
}

// ========================================
// QUALIFICAÇÕES
// ========================================

export interface Qualificacao {
  id: number;
  nome: string;
  codigo: string;
  descricao?: string;
  ativa: boolean;
  empresa_id: number;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
}

export interface Funcao {
  id: number;
  nome: string;
  descricao?: string;
  categoria?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export type TipoCertificacao = 'MEDICO' | 'PROFICIENCIA' | 'TREINAMENTO' | 'HABILITACAO' | 'OUTRO';

export interface Certificacao {
  id: number;
  funcionario_id: number;
  tipo: TipoCertificacao;
  nome: string;
  codigo?: string;
  data_emissao: string;
  data_vencimento?: string;
  orgao_emissor?: string;
  numero_certificado?: string;
  status: CertificacaoStatus;
  observacoes?: string;
  arquivo_url?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface CreateCertificacaoRequest {
  funcionario_id: number;
  tipo: TipoCertificacao;
  nome: string;
  codigo?: string;
  data_emissao: string;
  data_vencimento?: string;
  orgao_emissor?: string;
  numero_certificado?: string;
  observacoes?: string;
}

export type TipoArquivo = 'CERTIFICADO' | 'DOCUMENTO' | 'FOTO' | 'OUTRO';
export type StatusArquivo = 'ativo' | 'removido' | 'processando';

export interface ArquivoPastaVirtual {
  id: number;
  funcionario_id: number;
  nome_original: string;
  nome_arquivo: string;
  tipo: TipoArquivo;
  tamanho: number;
  url: string;
  status: StatusArquivo;
  uploaded_by: string;
  created_at: string;
  updated_at?: string;
}

export type AcaoAuditoria =
  | 'LOGIN'
  | 'LOGOUT'
  | 'LOGIN_FAILED'
  | 'CREATE'
  | 'UPDATE'
  | 'DELETE'
  | 'VIEW'
  | 'UPLOAD'
  | 'DOWNLOAD'
  | 'EXPORT'
  | 'IMPORT'
  | 'BACKUP'
  | 'RESTORE';

export type NivelCriticidade = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface AuditLog {
  id?: number;
  sessao_id?: string;
  usuario_id: string;
  usuario_nome: string;
  ip_address?: string;
  user_agent?: string;
  acao: AcaoAuditoria;
  recurso: string;
  recurso_id?: string;
  dados_antes?: string;
  dados_depois?: string;
  resultado: 'SUCCESS' | 'FAILURE' | 'ERROR';
  duracao_ms?: number;
  timestamp: string;
  nivel_criticidade: NivelCriticidade;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp?: string;
}

export interface PaginatedResponse<T = unknown> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

export interface ValidationError {
  field: string;
  message: string;
  value?: unknown;
}

export interface ApiErrorResponse extends ApiResponse {
  code?: string;
  details?: ValidationError[];
}

export interface CloudflareD1Database {
  prepare(query: string): {
    bind(...values: unknown[]): {
      first(): Promise<Record<string, unknown> | null>;
      all(): Promise<{ results: Record<string, unknown>[] }>;
      run(): Promise<{ meta: { last_row_id: number; changes: number } }>;
    };
  };
}

export interface CloudflareR2Bucket {
  get(key: string): Promise<R2Object | null>;
  put(key: string, value: ArrayBuffer | string, options?: R2PutOptions): Promise<R2Object>;
  delete(key: string): Promise<void>;
}

export interface R2Object {
  key: string;
  size: number;
  etag: string;
  httpEtag: string;
  uploaded: Date;
  httpMetadata?: R2HTTPMetadata;
  customMetadata?: Record<string, string>;
  body: ReadableStream;
  writeHttpMetadata(headers: Headers): void;
}

export interface R2PutOptions {
  httpMetadata?: R2HTTPMetadata;
  customMetadata?: Record<string, string>;
}

export interface R2HTTPMetadata {
  contentType?: string;
  contentLanguage?: string;
  contentDisposition?: string;
  contentEncoding?: string;
  cacheControl?: string;
  expires?: Date;
}

export interface Env {
  DB: CloudflareD1Database;
  ASSETS: Fetcher; // Assets binding para servir frontend
  AIRTRUST_STORAGE?: CloudflareR2Bucket; // Primary R2 bucket for storage
  R2_BUCKET?: CloudflareR2Bucket;
  BUCKET?: CloudflareR2Bucket; // Alias para R2 Bucket nativo
  CERTIFICATES?: CloudflareR2Bucket; // R2 Bucket para certificados
  BACKUPS?: CloudflareR2Bucket; // R2 Bucket para backups

  ENVIRONMENT?: 'development' | 'staging' | 'production';
  ENABLE_DEV_AUTH_BYPASS?: 'true' | 'false'; // Security: dev bypass for local development only

  R2_ACCESS_KEY_ID?: string;
  R2_SECRET_ACCESS_KEY?: string;
  R2_BUCKET_NAME?: string;
  R2_ENDPOINT?: string;

  CLOUDFLARE_API_TOKEN?: string;
  MOCHA_USERS_SERVICE_API_KEY?: string;
  MOCHA_USERS_SERVICE_API_URL?: string;

  JWT_SECRET?: string;

  RESEND_API_KEY?: string;

  REDIS_URL?: string;
  REDIS_TOKEN?: string;

  SENTRY_DSN?: string;

  ALERT_WEBHOOK?: string;

  _schema_synced?: boolean;
  _emergency_fix_executed?: boolean;
  _diagnostics?: Record<string, unknown>;
}

export interface Simulador {
  id: number;
  nome: string;
  modelo: string;
  fabricante?: string;
  status: 'ATIVO' | 'MANUTENCAO' | 'INATIVO';
  localizacao?: string;
  capacidade_maxima: number;
  observacoes?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface AgendamentoSimulador {
  id: number;
  simulador_id: number;
  instrutor_id: number;
  data_inicio: string;
  data_fim: string;
  tipo_sessao: 'TREINAMENTO' | 'AVALIACAO' | 'RECORRENTE';
  status: 'AGENDADO' | 'EM_ANDAMENTO' | 'CONCLUIDO' | 'CANCELADO';
  observacoes?: string;
  participantes: number[];
  created_at: string;
  updated_at: string;
}

export interface SystemHealth {
  status: 'healthy' | 'unhealthy' | 'degraded';
  timestamp: string;
  environment: string;
  services: Record<string, 'ok' | 'error' | 'warning'>;
  uptime: number;
}

export interface BackupInfo {
  id: string;
  created_at: string;
  size: number;
  status: 'creating' | 'completed' | 'failed';
  type: 'full' | 'incremental';
  created_by: string;
}

// ========================================
// DATABASE & ENVIRONMENT TYPES
// ========================================

export interface D1Database {
  prepare(sql: string): D1PreparedStatement;
}

export interface D1PreparedStatement {
  bind(...params: (string | number | null | boolean)[]): D1PreparedStatement;
  first<T = unknown>(): Promise<T | undefined>;
  all<T = unknown>(): Promise<{ results: T[] }>;
  run(): Promise<{ success: boolean; meta: { duration: number; last_row_id: number } }>;
}

export interface WorkerEnv {
  DB: D1Database;
  R2_BUCKET?: {
    put(
      key: string,
      value: ArrayBuffer | ReadableStream<Uint8Array> | Buffer,
      options?: { httpMetadata?: Record<string, unknown>; customMetadata?: Record<string, string> },
    ): Promise<Record<string, unknown>>;
    get(key: string): Promise<Record<string, unknown>>;
    delete(key: string): Promise<void>;
  };
  R2_DOMAIN?: string;
  JWT_SECRET: string;
  ENVIRONMENT: 'development' | 'production';
}

export interface RequestContext {
  env: WorkerEnv;
  ctx?: Record<string, unknown>;
}

// ========================================
// INPUT/OUTPUT TYPES
// ========================================

export interface CreateHabilitacaoInput {
  funcionario_id: number;
  qualificacao_id: number;
  empresa_id: number;
  data_conclusao: string;
  data_vencimento: string;
  status?: 'ATIVA' | 'VENCIDA' | 'SUSPENSA';
}

export interface UpdateHabilitacaoInput {
  data_conclusao?: string;
  data_vencimento?: string;
  status?: 'ATIVA' | 'VENCIDA' | 'SUSPENSA';
  certificado_url?: string;
}

export interface CreateQualificacaoInput {
  nome: string;
  codigo: string;
  descricao?: string;
  ativa?: boolean;
}

export interface UpdateQualificacaoInput {
  nome?: string;
  codigo?: string;
  descricao?: string;
  ativa?: boolean;
}

export interface EmpresaConfig {
  id: number;
  empresa_id: number;
  nome: string;
  logo_url?: string;
  cor_primaria: string;
  cor_secundaria: string;
  template_certificado?: string;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
}

export interface GenerateCertificadoInput {
  habilitacao_id: number;
  empresa_id: number;
}

// ========================================
// API RESPONSE TYPES
// ========================================

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  code?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

// ========================================
// ERROR CLASS
// ========================================

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly details?: Record<string, unknown>;

  constructor(
    statusCode: number,
    message: string,
    code: string,
    details?: Record<string, unknown>,
  ) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.name = 'AppError';
  }
}
