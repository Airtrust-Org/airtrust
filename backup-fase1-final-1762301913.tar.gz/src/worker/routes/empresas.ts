import { Hono } from 'hono';
import { ZodError } from 'zod';
import type { Env } from '../types/index';
import { EmpresasService } from '../services/empresasService';
import { EmpresasConfigService } from '../services/empresasConfigService';
import { CertificadosService } from '../services/certificadosService';
import { R2Service } from '../utils/r2Service';
import {
  CreateEmpresaDTO,
  UpdateEmpresaDTO,
  EmpresaResponseDTO
} from '../dtos/empresas';
import {
  UpdateEmpresaConfigDTO,
  EmpresaConfigResponseDTO
} from '../dtos/empresasConfig';
import {
  CreateCertificadoDTO,
  UpdateCertificadoDTO,
  CertificadoResponseDTO
} from '../dtos/certificados';

export function empresasRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  // GET / - Listar com paginação
  router.get('/', async (c) => {
    const service = new EmpresasService(c.env.DB);
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '50');
    const result = await service.getAll(page, limit);
    return c.json({
      success: true,
      data: result.data,
      page,
      total: result.total,
      timestamp: new Date().toISOString()
    });
  });

  // POST / - Criar novo
  router.post('/', async (c) => {
    const service = new EmpresasService(c.env.DB);
    const body = await c.req.json();
    const dados = CreateEmpresaDTO.parse(body);
    const created = await service.create(dados as Record<string, unknown>);
    const response = EmpresaResponseDTO.parse(created);
    return c.json({ success: true, data: response }, 201);
  });

  // GET /:id/config - Obter configurações da empresa
  router.get('/:id/config', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));

      if (isNaN(empresa_id)) {
        return c.json(
          { success: false, error: 'ID inválido', code: 'INVALID_ID' },
          400
        );
      }

      const service = new EmpresasConfigService(c.env.DB);
      const config = await service.getOrCreateDefault(empresa_id);

      const response = EmpresaConfigResponseDTO.parse(config);
      return c.json({
        success: true,
        data: response,
        timestamp: new Date().toISOString(),
      });
    } catch {
      return c.json(
        { success: false, error: 'Erro ao obter configuração', code: 'INTERNAL_ERROR' },
        500
      );
    }
  });

  // PUT /:id/config - Atualizar configurações da empresa
  router.put('/:id/config', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));

      if (isNaN(empresa_id)) {
        return c.json(
          { success: false, error: 'ID inválido', code: 'INVALID_ID' },
          400
        );
      }

      const body = await c.req.json();
      const dados = UpdateEmpresaConfigDTO.parse(body);

      const service = new EmpresasConfigService(c.env.DB);
      await service.upsert(empresa_id, dados as Record<string, unknown>);

      return c.json({
        success: true,
        message: 'Configuração salva com sucesso',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json(
          {
            success: false,
            error: 'Erro de validação',
            code: 'VALIDATION_ERROR',
            details: error.errors,
          },
          400
        );
      }

      return c.json(
        { success: false, error: 'Erro ao salvar configuração', code: 'INTERNAL_ERROR' },
        500
      );
    }
  });

  // POST /:id/logo/upload - Upload de logo
  router.post('/:id/logo/upload', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));

      if (isNaN(empresa_id)) {
        return c.json(
          { success: false, error: 'ID inválido', code: 'INVALID_ID' },
          400
        );
      }

      const formData = await c.req.formData();
      const file = formData.get('logo') as File;

      if (!file) {
        return c.json(
          { success: false, error: 'Arquivo logo é obrigatório', code: 'LOGO_REQUIRED' },
          400
        );
      }

      // Validar tipo de arquivo
      const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        return c.json(
          {
            success: false,
            error: 'Formato deve ser PNG, JPEG ou WebP',
            code: 'INVALID_FORMAT',
          },
          400
        );
      }

      // Validar tamanho (5MB máximo)
      const maxSize = 5 * 1024 * 1024;
      if (file.size > maxSize) {
        return c.json(
          { success: false, error: 'Arquivo não pode exceder 5MB', code: 'FILE_TOO_LARGE' },
          400
        );
      }

      // Upload para R2
      const buffer = Buffer.from(await file.arrayBuffer());
      const r2Service = new R2Service(c.env);

      const fileExtension = file.type.split('/')[1];
      const fileName = `logos/empresa-${empresa_id}-${Date.now()}.${fileExtension}`;
      const logoUrl = await r2Service.uploadImage(fileName, buffer, file.type);

      // Salvar URL na config
      const configService = new EmpresasConfigService(c.env.DB);
      await configService.upsert(empresa_id, { logo_url: logoUrl } as Record<string, unknown>);

      return c.json(
        {
          success: true,
          data: { logo_url: logoUrl },
          timestamp: new Date().toISOString(),
        },
        200
      );
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Erro ao fazer upload';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'UPLOAD_ERROR',
        },
        500
      );
    }
  });

  // GET /:id - Obter um
  router.get('/:id', async (c) => {
    const service = new EmpresasService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    const item = await service.getById(id);
    const response = EmpresaResponseDTO.parse(item);
    return c.json({ success: true, data: response });
  });

  // PUT /:id - Atualizar
  router.put('/:id', async (c) => {
    const service = new EmpresasService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    const body = await c.req.json();
    const dados = UpdateEmpresaDTO.parse(body);
    const updated = await service.update(id, dados as Record<string, unknown>);
    const response = EmpresaResponseDTO.parse(updated);
    return c.json({ success: true, data: response });
  });

  // DELETE /:id - Deletar
  router.delete('/:id', async (c) => {
    const service = new EmpresasService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    await service.delete(id);
    return c.json({ success: true });
  });

  // ============= CERTIFICADOS =============

  // POST /:id/certificados - Gerar novo certificado
  router.post('/:id/certificados', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));

      if (isNaN(empresa_id)) {
        return c.json(
          { success: false, error: 'ID de empresa inválido', code: 'INVALID_ID' },
          400
        );
      }

      const body = await c.req.json();
      const dados = CreateCertificadoDTO.parse(body);

      const service = new CertificadosService(c.env.DB, c.env);
      const certificado = await service.gerarComPDF({
        habilitacao_id: dados.habilitacao_id,
        empresa_id,
        funcionario_id: dados.funcionario_id,
        qualificacao_id: dados.qualificacao_id,
      });

      const response = CertificadoResponseDTO.parse(certificado);
      return c.json({ success: true, data: response }, 201);
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json(
          {
            success: false,
            error: 'Erro de validação',
            code: 'VALIDATION_ERROR',
            details: error.errors,
          },
          400
        );
      }

      const errorMsg = error instanceof Error ? error.message : 'Erro ao gerar certificado';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'CERTIFICATE_ERROR',
        },
        500
      );
    }
  });

  // GET /:id/certificados - Listar certificados da empresa
  router.get('/:id/certificados', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));

      if (isNaN(empresa_id)) {
        return c.json(
          { success: false, error: 'ID de empresa inválido', code: 'INVALID_ID' },
          400
        );
      }

      const page = parseInt(c.req.query('page') || '1');
      const limit = parseInt(c.req.query('limit') || '50');

      const service = new CertificadosService(c.env.DB);
      const result = await service.getWithFilter(
        { empresa_id },
        page,
        limit
      );

      return c.json({
        success: true,
        data: result.data,
        page,
        total: result.total,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro ao listar certificados';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'LIST_ERROR',
        },
        500
      );
    }
  });

  // GET /:id/certificados/:certId - Obter certificado específico
  router.get('/:id/certificados/:certId', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));
      const cert_id = parseInt(c.req.param('certId'));

      if (isNaN(empresa_id) || isNaN(cert_id)) {
        return c.json(
          { success: false, error: 'IDs inválidos', code: 'INVALID_ID' },
          400
        );
      }

      const service = new CertificadosService(c.env.DB);
      const certificado = await service.getById(cert_id);

      if (!certificado || certificado.empresa_id !== empresa_id) {
        return c.json(
          { success: false, error: 'Certificado não encontrado', code: 'NOT_FOUND' },
          404
        );
      }

      const response = CertificadoResponseDTO.parse(certificado);
      return c.json({
        success: true,
        data: response,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro ao obter certificado';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'GET_ERROR',
        },
        500
      );
    }
  });

  // PUT /:id/certificados/:certId - Atualizar certificado
  router.put('/:id/certificados/:certId', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));
      const cert_id = parseInt(c.req.param('certId'));

      if (isNaN(empresa_id) || isNaN(cert_id)) {
        return c.json(
          { success: false, error: 'IDs inválidos', code: 'INVALID_ID' },
          400
        );
      }

      const body = await c.req.json();
      const dados = UpdateCertificadoDTO.parse(body);

      const service = new CertificadosService(c.env.DB);
      const certificado = await service.getById(cert_id);

      if (!certificado || certificado.empresa_id !== empresa_id) {
        return c.json(
          { success: false, error: 'Certificado não encontrado', code: 'NOT_FOUND' },
          404
        );
      }

      const updated = await service.update(cert_id, dados as Record<string, unknown>);
      const response = CertificadoResponseDTO.parse(updated);

      return c.json({
        success: true,
        data: response,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return c.json(
          {
            success: false,
            error: 'Erro de validação',
            code: 'VALIDATION_ERROR',
            details: error.errors,
          },
          400
        );
      }

      const errorMsg = error instanceof Error ? error.message : 'Erro ao atualizar certificado';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'UPDATE_ERROR',
        },
        500
      );
    }
  });

  // DELETE /:id/certificados/:certId - Revogar certificado
  router.delete('/:id/certificados/:certId', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));
      const cert_id = parseInt(c.req.param('certId'));

      if (isNaN(empresa_id) || isNaN(cert_id)) {
        return c.json(
          { success: false, error: 'IDs inválidos', code: 'INVALID_ID' },
          400
        );
      }

      const service = new CertificadosService(c.env.DB);
      const certificado = await service.getById(cert_id);

      if (!certificado || certificado.empresa_id !== empresa_id) {
        return c.json(
          { success: false, error: 'Certificado não encontrado', code: 'NOT_FOUND' },
          404
        );
      }

      await service.revogar(cert_id);

      return c.json({
        success: true,
        message: 'Certificado revogado com sucesso',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro ao revogar certificado';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'DELETE_ERROR',
        },
        500
      );
    }
  });

  // GET /:id/certificados/funcionario/:funcId - Listar certificados por funcionário
  router.get('/:id/certificados/funcionario/:funcId', async (c) => {
    try {
      const empresa_id = parseInt(c.req.param('id'));
      const funcionario_id = parseInt(c.req.param('funcId'));

      if (isNaN(empresa_id) || isNaN(funcionario_id)) {
        return c.json(
          { success: false, error: 'IDs inválidos', code: 'INVALID_ID' },
          400
        );
      }

      const page = parseInt(c.req.query('page') || '1');
      const limit = parseInt(c.req.query('limit') || '50');

      const service = new CertificadosService(c.env.DB);
      const result = await service.getWithFilter(
        { empresa_id, funcionario_id },
        page,
        limit
      );

      return c.json({
        success: true,
        data: result.data,
        page,
        total: result.total,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro ao listar certificados';
      return c.json(
        {
          success: false,
          error: errorMsg,
          code: 'LIST_ERROR',
        },
        500
      );
    }
  });

  return router;
}
