
import { Hono } from 'hono';
import { Env } from '../types/index';

const simuladoresComplete = new Hono<{ Bindings: Env }>();

simuladoresComplete.post('/sessoes', async (c) => {
  try {
    const { simulador_id, funcionario_id, instrutor_id, data_hora, duracao, tipo_sessao } = await c.req.json();

    if (!simulador_id || !funcionario_id || !instrutor_id || !data_hora) {
      return c.json({ success: false, error: 'Campos obrigatórios faltando' }, 400);
    }

    const db = c.env.DB;

    const conflito = await db.prepare(`
      SELECT id FROM sessoes_simulador
      WHERE simulador_id = ?
        AND date(data_hora) = date(?)
        AND status != 'cancelado'
        AND deleted_at IS NULL
    `).bind(simulador_id, data_hora).first();

    if (conflito) {
      return c.json({ success: false, error: 'Horário já reservado' }, 400);
    }

    const result = await db.prepare(`
      INSERT INTO sessoes_simulador (
        simulador_id, funcionario_id, instrutor_id, data_hora,
        duracao, tipo_sessao, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'agendado', datetime('now'))
    `).bind(simulador_id, funcionario_id, instrutor_id, data_hora, duracao || 60, tipo_sessao || 'treinamento').run();

    return c.json({
      success: true,
      data: { id: result.meta.last_row_id }
    });

  } catch (error) {
    console.error('[SESSOES POST] Erro:', error);
    return c.json({ success: false, error: 'Erro ao criar sessão' }, 500);
  }
});

simuladoresComplete.get('/sessoes/funcionario/:id', async (c) => {
  try {
    const funcionarioId = c.req.param('id');
    const db = c.env.DB;

    const { results } = await db.prepare(`
      SELECT 
        s.*,
        sim.nome as simulador_nome,
        i.nome as instrutor_nome
      FROM sessoes_simulador s
      LEFT JOIN simuladores sim ON s.simulador_id = sim.id
      LEFT JOIN funcionarios i ON s.instrutor_id = i.id
      WHERE s.funcionario_id = ? AND s.deleted_at IS NULL
      ORDER BY s.data_hora DESC
    `).bind(funcionarioId).all();

    return c.json({ success: true, data: results });

  } catch (error) {
    console.error('[SESSOES GET] Erro:', error);
    return c.json({ success: false, error: 'Erro ao buscar sessões' }, 500);
  }
});

simuladoresComplete.put('/sessoes/:id/finalizar', async (c) => {
  try {
    const sessaoId = c.req.param('id');
    const { manobras, nota, observacoes, aprovado } = await c.req.json();

    const db = c.env.DB;

    await db.prepare(`
      UPDATE sessoes_simulador
      SET status = 'concluido',
          nota = ?,
          observacoes = ?,
          aprovado = ?,
          data_conclusao = datetime('now'),
          updated_at = datetime('now')
      WHERE id = ?
    `).bind(nota, observacoes, aprovado ? 1 : 0, sessaoId).run();

    if (manobras && Array.isArray(manobras)) {
      for (const manobra of manobras) {
        await db.prepare(`
          INSERT INTO manobras_sessao (
            sessao_id, manobra_nome, executada, nota, observacoes
          ) VALUES (?, ?, ?, ?, ?)
        `).bind(
          sessaoId,
          manobra.nome,
          manobra.executada ? 1 : 0,
          manobra.nota || 0,
          manobra.observacoes || ''
        ).run();
      }
    }

    return c.json({ success: true });

  } catch (error) {
    console.error('[SESSOES FINALIZAR] Erro:', error);
    return c.json({ success: false, error: 'Erro ao finalizar sessão' }, 500);
  }
});

simuladoresComplete.get('/relatorios/horas/:funcionarioId', async (c) => {
  try {
    const funcionarioId = c.req.param('funcionarioId');
    const db = c.env.DB;

    const { results } = await db.prepare(`
      SELECT 
        sim.nome as simulador,
        COUNT(*) as total_sessoes,
        SUM(s.duracao) as total_minutos,
        AVG(s.nota) as media_notas,
        SUM(CASE WHEN s.aprovado = 1 THEN 1 ELSE 0 END) as aprovados
      FROM sessoes_simulador s
      JOIN simuladores sim ON s.simulador_id = sim.id
      WHERE s.funcionario_id = ? AND s.status = 'concluido'
      GROUP BY sim.id, sim.nome
    `).bind(funcionarioId).all();

    return c.json({ success: true, data: results });

  } catch (error) {
    console.error('[RELATORIOS] Erro:', error);
    return c.json({ success: false, error: 'Erro ao gerar relatório' }, 500);
  }
});

export default simuladoresComplete;
