import { Hono } from 'hono';
import { Logger } from '../utils/logger';
import { Env } from '../types/index';

const pastaVirtual = new Hono<{ Bindings: Env }>();

/**
 * GET /pasta-virtual
 * Lista todos os arquivos da pasta virtual
 */
pastaVirtual.get('/', async (c) => {
  try {
    const certificacoes = await c.env.DB.prepare(
      `
      SELECT * FROM qualificacoes 
      WHERE deleted_at IS NULL 
      LIMIT 100
    `,
    ).all();

    return c.json({
      success: true,
      data: certificacoes.results || [],
      total: certificacoes.results?.length || 0,
    });
  } catch (error) {
    console.error('Erro ao listar pasta virtual:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao carregar pasta virtual',
        arquivos: [],
      },
      500,
    );
  }
});

/**
 * GET /pasta-virtual/:funcionarioId
 * Lista arquivos da pasta virtual de um funcionário
 */
pastaVirtual.get('/:funcionarioId', async (c) => {
  const startTime = Date.now();

  try {
    const funcionarioId = c.req.param('funcionarioId');

    Logger.info('Accessing pasta virtual', {
      funcionarioId,
    });

    // CERTIFICADOS NOVOS (tabela certificados)
    const certificadosNovos = await c.env.DB.prepare(
      `
      SELECT 
        c.id,
        f.matricula as funcionario_matricula,
        q.nome as nome,
        q.codigo,
        'certificado' as tipo,
        c.data_emissao as dataUpload,
        COALESCE(CAST(c.arquivo_tamanho / 1024.0 / 1024.0 AS TEXT), '0') || 'MB' as tamanho,
        CASE 
          WHEN c.deleted_at IS NULL THEN 'sincronizado'
          ELSE 'deletado'
        END as status,
        q.categoria,
        h.data_vencimento,
        CASE 
          WHEN h.data_vencimento IS NULL THEN NULL
          WHEN julianday(h.data_vencimento) - julianday('now') < 0 THEN 'vencido'
          ELSE CAST(julianday(h.data_vencimento) - julianday('now') AS INTEGER)
        END as diasParaVencimento,
        c.arquivo_url,
        c.arquivo_nome
      FROM certificados c
      JOIN habilitacoes h ON c.habilitacao_id = h.id AND h.deleted_at IS NULL
      JOIN funcionarios f ON h.funcionario_id = f.id AND f.deleted_at IS NULL
      LEFT JOIN qualificacoes q ON h.qualificacao_id = q.id AND q.deleted_at IS NULL
      WHERE f.id = ? AND c.deleted_at IS NULL
      ORDER BY c.created_at DESC
      LIMIT 50
    `,
    )
      .bind(funcionarioId)
      .all();

    // Tabelas legacy removidas - apenas certificados novos
    const todosCertificados = certificadosNovos.results || [];

    Logger.audit('PASTA_VIRTUAL_ACCESSED', 'system', {
      funcionarioId,
      certificadosNovos: certificadosNovos.results?.length || 0,
      total: todosCertificados.length,
    });

    return c.json({
      success: true,
      arquivos: todosCertificados,
    });
  } catch (error) {
    Logger.error('Error accessing pasta virtual', error, {
      funcionarioId: c.req.param('funcionarioId'),
    });

    return c.json(
      {
        success: false,
        error: 'Erro ao carregar pasta virtual',
        arquivos: [],
      },
      500,
    );
  } finally {
    Logger.performance('pasta-virtual/access', startTime);
  }
});

/**
 * POST /pasta-virtual/upload
 * Upload de arquivo para pasta virtual
 */
pastaVirtual.post('/upload', async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const funcionarioId = formData.get('funcionarioId') as string;
    const tipo = formData.get('tipo') as string;
    // TODO: const user = c.get('user'); // Auth disabled in dev

    if (!file || !funcionarioId || !tipo) {
      return c.json(
        {
          success: false,
          error: 'Arquivo, funcionário e tipo são obrigatórios',
        },
        400,
      );
    }

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      return c.json(
        {
          success: false,
          error: 'Tipo de arquivo não permitido. Use PDF, JPEG ou PNG.',
        },
        400,
      );
    }

    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      return c.json(
        {
          success: false,
          error: 'Arquivo muito grande. Máximo 10MB.',
        },
        400,
      );
    }

    const timestamp = Date.now();
    const extension = file.name.split('.').pop();
    const fileName = `${funcionarioId}_${tipo}_${timestamp}.${extension}`;

    const fileUrl = `/uploads/${fileName}`;

    const now = new Date().toISOString();
    const result = await c.env.DB.prepare(
      `
      INSERT INTO pasta_virtual_arquivos (
        funcionario_id, nome_original, nome_arquivo, tipo, 
        tamanho, url, status, uploaded_by, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
    )
      .bind(
        funcionarioId,
        file.name,
        fileName,
        tipo,
        file.size,
        fileUrl,
        'ativo',
        user?.id || 'system',
        now,
      )
      .run();

    Logger.audit('FILE_UPLOADED', user?.id || 'system', {
      funcionarioId,
      fileName: file.name,
      tipo,
      size: file.size,
    });

    return c.json({
      success: true,
      arquivo: {
        id: result.meta.last_row_id,
        nome: file.name,
        tipo,
        tamanho: file.size,
        url: fileUrl,
        status: 'ativo',
      },
      message: 'Arquivo enviado com sucesso',
    });
  } catch (error) {
    Logger.error('Error uploading file', error);

    return c.json(
      {
        success: false,
        error: 'Erro ao fazer upload do arquivo',
      },
      500,
    );
  }
});

/**
 * DELETE /pasta-virtual/:arquivoId
 * Remove arquivo da pasta virtual
 */
pastaVirtual.delete('/:arquivoId', async (c) => {
  try {
    const arquivoId = parseInt(c.req.param('arquivoId'));
    // TODO: const user = c.get('user'); // Auth disabled in dev

    if (isNaN(arquivoId)) {
      return c.json({ success: false, error: 'ID inválido' }, 400);
    }

    const arquivo = await c.env.DB.prepare(
      `
      SELECT * FROM pasta_virtual_arquivos WHERE id = ? AND status = 'ativo'
    `,
    )
      .bind(arquivoId)
      .first();

    if (!arquivo) {
      return c.json({ success: false, error: 'Arquivo não encontrado' }, 404);
    }

    const now = new Date().toISOString();
    await c.env.DB.prepare(
      `
      UPDATE pasta_virtual_arquivos 
      SET status = 'removido', updated_at = ? 
      WHERE id = ?
    `,
    )
      .bind(now, arquivoId)
      .run();

    Logger.audit('FILE_DELETED', user?.id || 'system', {
      arquivoId,
      fileName: arquivo.nome_original,
      funcionarioId: arquivo.funcionario_id,
    });

    return c.json({
      success: true,
      message: 'Arquivo removido com sucesso',
    });
  } catch (error) {
    Logger.error('Error deleting file', error, {
      arquivoId: c.req.param('arquivoId'),
    });

    return c.json(
      {
        success: false,
        error: 'Erro ao remover arquivo',
      },
      500,
    );
  }
});

export default pastaVirtual;
