import { Hono } from 'hono';
import { Env } from '../types/index';

const auditoria = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/auditoria
 * Listar logs de auditoria
 */
auditoria.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const limit = parseInt(c.req.query('limit') || '50');
    
    const { results } = await db.prepare(`
      SELECT 
        id,
        tabela_afetada,
        operacao,
        usuario_id,
        detalhes,
        created_at
      FROM auditoria
      ORDER BY created_at DESC
      LIMIT ?
    `).bind(limit).all();
    
    return c.json({
      success: true,
      data: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar auditoria:', error);
    return c.json({
      success: true,
      data: []
    });
  }
});

export default auditoria;
