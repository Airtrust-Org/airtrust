import { Hono } from 'hono';
import { Env } from '../types/index';

const importacoes = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/importacoes
 * Listar histórico de importações
 */
importacoes.get('/', async (c) => {
  try {
    const db = c.env.DB;
    const limit = parseInt(c.req.query('limit') || '50');
    const tipo = c.req.query('tipo');
    
    let query = `
      SELECT 
        id,
        batch_id,
        tipo_importacao,
        usuario_nome,
        arquivo_nome,
        total_linhas,
        linhas_sucesso,
        linhas_erro,
        tempo_processamento_ms,
        status,
        created_at
      FROM importacoes_log
    `;
    
    const params = [];
    if (tipo) {
      query += ` WHERE tipo_importacao = ?`;
      params.push(tipo);
    }
    
    query += ` ORDER BY created_at DESC LIMIT ?`;
    params.push(limit);
    
    const { results } = await db.prepare(query).bind(...params).all();
    
    return c.json({
      success: true,
      data: results || [],
      total: results?.length || 0
    });
  } catch (error) {
    console.error('[API] Erro ao buscar importações:', error);
    return c.json({
      success: true,
      data: [],
      total: 0
    });
  }
});

export default importacoes;
