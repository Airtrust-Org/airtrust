import { Hono } from 'hono';
import { Env } from '../types/index';

const relatorios = new Hono<{ Bindings: Env }>();

relatorios.use('*', async (c, next) => {
  if (c.req.method === 'GET') {
    c.header('Cache-Control', 'public, max-age=60, stale-while-revalidate=30');
  }
  await next();
});

/**
 * GET /api/v2/relatorios/certificacoes-mes
 * Certificações concluídas por mês (últimos 12 meses)
 */
relatorios.get('/certificacoes-mes', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        strftime('%Y-%m', data_conclusao) as mes,
        COUNT(*) as total
      FROM certificacoesv3
      WHERE data_conclusao >= date('now', '-12 months')
        AND data_conclusao IS NOT NULL
      GROUP BY mes
      ORDER BY mes ASC
    `).all();
    
    return c.json({
      success: true,
      dados: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar certificações por mês:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar dados'
    }, 500);
  }
});

/**
 * GET /api/v2/relatorios/compliance-setor
 * Taxa de compliance por setor
 */
relatorios.get('/compliance-setor', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        f.setor,
        COUNT(DISTINCT f.id) as total_funcionarios,
        COUNT(DISTINCT cert.id) as total_certificacoes,
        SUM(CASE WHEN cert.status_compliance = 'VALIDO' THEN 1 ELSE 0 END) as validas,
        ROUND(
          CAST(SUM(CASE WHEN cert.status_compliance = 'VALIDO' THEN 1 ELSE 0 END) AS FLOAT) / 
          NULLIF(COUNT(DISTINCT cert.id), 0) * 100, 
          1
        ) as taxa_compliance
      FROM funcionarios f
      LEFT JOIN certificacoesv3 cert ON f.id = cert.funcionario_id
      WHERE f.deleted_at IS NULL
        AND f.setor IS NOT NULL
        AND f.setor != ''
      GROUP BY f.setor
      ORDER BY f.setor
    `).all();
    
    return c.json({
      success: true,
      dados: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar compliance por setor:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar dados'
    }, 500);
  }
});

/**
 * GET /api/v2/relatorios/simuladores-uso
 * Top 5 simuladores mais usados
 */
relatorios.get('/simuladores-uso', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        s.nome,
        COUNT(ses.id) as total_sessoes
      FROM simuladores s
      LEFT JOIN sessoes_simulador ses ON s.id = ses.simulador_id
      WHERE s.deleted_at IS NULL
      GROUP BY s.id, s.nome
      ORDER BY total_sessoes DESC
      LIMIT 5
    `).all();
    
    return c.json({
      success: true,
      dados: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar uso de simuladores:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar dados'
    }, 500);
  }
});

/**
 * GET /api/v2/relatorios/treinamentos-categoria
 * Distribuição de treinamentos por categoria
 */
relatorios.get('/treinamentos-categoria', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        categoria,
        COUNT(*) as total
      FROM catalogotreinamentosv2
      WHERE categoria IS NOT NULL
        AND categoria != ''
      GROUP BY categoria
      ORDER BY total DESC
    `).all();
    
    return c.json({
      success: true,
      dados: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar treinamentos por categoria:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar dados'
    }, 500);
  }
});

/**
 * GET /api/v2/relatorios/evolucao-funcionarios
 * Evolução do número de funcionários ao longo do tempo
 */
relatorios.get('/evolucao-funcionarios', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as mes,
        COUNT(*) as novos,
        (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL AND created_at <= date(f.mes || '-01', '+1 month', '-1 day')) as total_acumulado
      FROM funcionarios f
      WHERE created_at >= date('now', '-12 months')
      GROUP BY mes
      ORDER BY mes ASC
    `).all();
    
    return c.json({
      success: true,
      dados: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar evolução de funcionários:', error);
    return c.json({
      success: true,
      dados: []
    });
  }
});

/**
 * GET /api/v2/relatorios/resumo
 * Resumo executivo com métricas gerais
 */
relatorios.get('/resumo', async (c) => {
  try {
    const db = c.env.DB;
    
    const resumo = await db.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM funcionarios WHERE deleted_at IS NULL) as total_funcionarios,
        (SELECT COUNT(*) FROM certificacoesv3) as total_certificacoes,
        (SELECT COUNT(*) FROM simuladores WHERE deleted_at IS NULL) as total_simuladores,
        (SELECT COUNT(*) FROM sessoes_simulador) as total_sessoes,
        (SELECT COUNT(*) FROM catalogotreinamentosv2) as total_treinamentos
    `).first();
    
    return c.json({
      success: true,
      resumo
    });
  } catch (error) {
    console.error('[API] Erro ao buscar resumo:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar resumo'
    }, 500);
  }
});

/**
 * GET /api/v2/relatorios/dashboard-executivo
 * Métricas consolidadas (baseadas em qualificacoes/sessoes)
 */
relatorios.get('/dashboard-executivo', async (c) => {
  try {
    const db = c.env.DB;

    const totalFuncionarios = await (db.prepare(`
      SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL
    `) as any).first();

    const totalQualificacoesAtivas = await (db.prepare(`
      SELECT COUNT(*) as total 
      FROM qualificacoes 
      WHERE deleted_at IS NULL AND COALESCE(is_renovada, 0) = 0
    `) as any).first();

    const vencimentosProximos30 = await (db.prepare(`
      SELECT COUNT(*) as total 
      FROM qualificacoes 
      WHERE deleted_at IS NULL 
        AND COALESCE(is_renovada, 0) = 0 
        AND data_vencimento IS NOT NULL
        AND date(data_vencimento) BETWEEN date('now') AND date('now','+30 days')
    `) as any).first();

    const vencidas = await (db.prepare(`
      SELECT COUNT(*) as total 
      FROM qualificacoes 
      WHERE deleted_at IS NULL 
        AND COALESCE(is_renovada, 0) = 0 
        AND data_vencimento IS NOT NULL
        AND date(data_vencimento) < date('now')
    `) as any).first();

    const complianceRate = await (db.prepare(`
      SELECT 
        ROUND(
          CAST(SUM(CASE WHEN data_vencimento IS NULL OR date(data_vencimento) >= date('now') THEN 1 ELSE 0 END) AS REAL)
          / NULLIF(COUNT(*), 0) * 100.0, 0
        ) as taxa
      FROM qualificacoes
      WHERE deleted_at IS NULL AND COALESCE(is_renovada, 0) = 0
    `) as any).first();

    const distribuicaoQualificacoes = await (db.prepare(`
      SELECT codigo as tipo, COUNT(*) as total
      FROM qualificacoes
      WHERE deleted_at IS NULL AND COALESCE(is_renovada, 0) = 0
      GROUP BY codigo
      ORDER BY total DESC
      LIMIT 10
    `) as any).all();

    const tendenciaMensal = await (db.prepare(`
      SELECT 
        strftime('%Y-%m', COALESCE(data_conclusao, data_conclusao)) as mes,
        COUNT(*) as total_certificacoes
      FROM qualificacoes
      WHERE deleted_at IS NULL
        AND COALESCE(data_conclusao, data_conclusao) >= date('now','-12 months')
      GROUP BY mes
      ORDER BY mes ASC
    `) as any).all();

    const topInstrutores = await (db.prepare(`
      SELECT instrutor, COUNT(*) as total_certificacoes, ROUND(AVG(COALESCE(nota, 0)),2) as media_notas
      FROM qualificacoes
      WHERE deleted_at IS NULL 
        AND instrutor IS NOT NULL AND instrutor != ''
        AND COALESCE(data_conclusao, data_conclusao) >= date('now','-6 months')
      GROUP BY instrutor
      ORDER BY total_certificacoes DESC
      LIMIT 5
    `) as any).all();

    const taxaAprovacaoPorTipo = await (db.prepare(`
      SELECT codigo, 
        COUNT(*) as total,
        SUM(CASE WHEN COALESCE(nota,0) >= 7.0 THEN 1 ELSE 0 END) as aprovados,
        ROUND(CAST(SUM(CASE WHEN COALESCE(nota,0) >= 7.0 THEN 1 ELSE 0 END) AS REAL) / NULLIF(COUNT(*),0) * 100.0, 1) as taxa_aprovacao
      FROM qualificacoes
      WHERE deleted_at IS NULL AND nota IS NOT NULL
      GROUP BY codigo
      ORDER BY total DESC
      LIMIT 10
    `) as any).all();

    return c.json({
      success: true,
      data: {
        metricas_gerais: {
          total_funcionarios: (totalFuncionarios as any)?.total || 0,
          total_qualificacoes_ativas: (totalQualificacoesAtivas as any)?.total || 0,
          vencimentos_proximos_30_dias: (vencimentosProximos30 as any)?.total || 0,
          certificacoes_vencidas: (vencidas as any)?.total || 0,
          taxa_compliance: (complianceRate as any)?.taxa || 0
        },
        distribuicao_qualificacoes: (distribuicaoQualificacoes as any)?.results || [],
        tendencia_mensal: (tendenciaMensal as any)?.results || [],
        top_instrutores: (topInstrutores as any)?.results || [],
        taxa_aprovacao_por_tipo: (taxaAprovacaoPorTipo as any)?.results || []
      }
    });
  } catch (error: any) {
    return c.json({ success: false, error: error.message || 'Erro ao montar dashboard' }, 500);
  }
});

/**
 * GET /api/v2/relatorios/simuladores
 * Consolida métricas de sessões
 */
relatorios.get('/simuladores', async (c) => {
  try {
    const db = c.env.DB;

    const totalSessoes = await (db.prepare(`
      SELECT COUNT(*) as total FROM sessoes_simulador
    `) as any).first();

    const horasTotais = await (db.prepare(`
      SELECT ROUND(SUM(COALESCE(duracao,0)) / 60.0, 2) as horas_totais FROM sessoes_simulador
    `) as any).first();

    const taxaAprovacao = await (db.prepare(`
      SELECT ROUND(CAST(SUM(CASE WHEN LOWER(COALESCE(resultado_final,'')) = 'aprovado' THEN 1 ELSE 0 END) AS REAL) / NULLIF(COUNT(*),0) * 100.0, 0) as taxa
      FROM sessoes_simulador
    `) as any).first();

    const sessoesPorSimulador = await (db.prepare(`
      SELECT s.nome as simulador,
             COUNT(ss.id) as total_sessoes,
             ROUND(SUM(COALESCE(ss.duracao,0)) / 60.0, 2) as horas_totais
      FROM sessoes_simulador ss
      JOIN simuladores s ON ss.simulador_id = s.id
      GROUP BY s.id, s.nome
      ORDER BY total_sessoes DESC
    `) as any).all();

    return c.json({
      success: true,
      data: {
        total_sessoes: (totalSessoes as any)?.total || 0,
        horas_totais: (horasTotais as any)?.horas_totais || 0,
        taxa_aprovacao: (taxaAprovacao as any)?.taxa || 0,
        sessoes_por_simulador: (sessoesPorSimulador as any)?.results || []
      }
    });
  } catch (error: any) {
    return c.json({ success: false, error: error.message || 'Erro ao consolidar simuladores' }, 500);
  }
});

/**
 * GET /api/v2/relatorios/exportar-csv?tipo=qualificacoes
 */
relatorios.get('/exportar-csv', async (c) => {
  try {
    const tipo = c.req.query('tipo') || 'qualificacoes';
    const db = c.env.DB;

    if (tipo !== 'qualificacoes') {
      return c.json({ success: false, error: 'Tipo não suportado' }, 400);
    }

    const res = await (db.prepare(`
      SELECT 
        q.id,
        f.matricula,
        f.nome as funcionario,
        q.tipo,
        q.codigo,
        q.data_conclusao,
        q.data_conclusao,
        q.data_vencimento,
        q.instrutor,
        q.nota,
        q.is_renovada
      FROM qualificacoes q
      LEFT JOIN funcionarios f ON f.id = q.funcionario_id
      WHERE q.deleted_at IS NULL
      ORDER BY COALESCE(q.data_conclusao, q.data_conclusao) DESC
    `) as any).all();

    const rows = (res as any)?.results || [];
    const headers = rows.length ? Object.keys(rows[0]) : [];
    const csvHeader = headers.join(',');
    const csvRows = rows.map((r: any) => headers.map((h: string) => {
      const v = r[h];
      const s = v === null || v === undefined ? '' : String(v).replace(/"/g, '""');
      return `"${s}"`;
    }).join(',')).join('\n');
    const csv = `${csvHeader}\n${csvRows}`;

    return new Response(csv, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="relatorio-${tipo}-${Date.now()}.csv"`
      }
    });
  } catch (error: any) {
    return c.json({ success: false, error: error.message || 'Erro ao exportar' }, 500);
  }
});

export default relatorios;
