import { Hono } from 'hono';
import { Env } from '../types/index';

const dashboard = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/dashboard
 * Dashboard principal com estatísticas gerais
 */
dashboard.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const funcionarios = await db.prepare(`
      SELECT COUNT(*) as total FROM funcionarios WHERE deleted_at IS NULL
    `).bind().first();
    
    const qualificacoes = await db.prepare(`
      SELECT COUNT(*) as total FROM qualificacoes WHERE deleted_at IS NULL
    `).bind().first();
    
    const exames = await db.prepare(`
      SELECT COUNT(*) as total FROM qualificacoes WHERE tipo = 'EXAME' AND deleted_at IS NULL
    `).bind().first();
    
    const checks = await db.prepare(`
      SELECT COUNT(*) as total FROM qualificacoes WHERE tipo = 'CHECK' AND deleted_at IS NULL
    `).bind().first();
    
    return c.json({
      success: true,
      data: {
        funcionarios: (funcionarios as any)?.total || 0,
        qualificacoes: (qualificacoes as any)?.total || 0,
        exames: (exames as any)?.total || 0,
        checks: (checks as any)?.total || 0
      }
    });
  } catch (error) {
    console.error('[API] Erro ao buscar dashboard:', error);
    return c.json({
      success: true,
      data: { funcionarios: 0, qualificacoes: 0, exames: 0, checks: 0 }
    });
  }
});

/**
 * GET /api/v2/dashboard/status-certificacoes
 * Status de Certificações
 */
dashboard.get('/status-certificacoes', async (c) => {
  try {
    const stats = {
      total: 0,
      ativas: 0,
      vencidas: 0,
      vencendo: 0
    };

    return c.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('[API] Erro ao buscar status certificações:', error);
    return c.json({
      success: true,
      data: { total: 0, ativas: 0, vencidas: 0, vencendo: 0 }
    });
  }
});

/**
 * GET /api/v2/dashboard/treinamentos-criticos
 * Treinamentos Críticos
 */
dashboard.get('/treinamentos-criticos', async (c) => {
  try {
    const data = [
      {
        id: 'cat-001',
        nome: 'CRM - Crew Resource Management',
        tipo: 'OPERACIONAL',
        total_treinados: 0,
        obrigatorio: 1
      },
      {
        id: 'cat-002',
        nome: 'Dangerous Goods',
        tipo: 'SEGURANCA',
        total_treinados: 0,
        obrigatorio: 1
      }
    ];

    return c.json({
      success: true,
      data
    });
  } catch (error) {
    console.error('[API] Erro ao buscar treinamentos críticos:', error);
    return c.json({
      success: true,
      data: []
    });
  }
});

/**
 * GET /api/v2/dashboard/rastreabilidade
 * Rastreabilidade de Documentos
 */
dashboard.get('/rastreabilidade', async (c) => {
  try {
    const stats = {
      total: 0,
      ativos: 0,
      inativos: 0,
      pendentes: 0
    };

    return c.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('[API] Erro ao buscar rastreabilidade:', error);
    return c.json({
      success: true,
      data: { total: 0, ativos: 0, inativos: 0, pendentes: 0 }
    });
  }
});

/**
 * GET /api/v2/dashboard/metricas
 * Métricas agregadas por setor, cargo e temporal
 */
dashboard.get('/metricas', async (c) => {
  const db = c.env.DB;
  
  try {
    const setorMetrics = await db
      .prepare(`
        SELECT 
          setor,
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'ativo' THEN 1 END) as ativos,
          COUNT(CASE WHEN cma_status = 'valido' THEN 1 END) as cma_validos,
          AVG(CASE 
            WHEN cma_data_vencimento >= DATE('now') THEN 1 
            ELSE 0 
          END) * 100 as compliance_cma
        FROM funcionarios
        WHERE deleted_at IS NULL
        GROUP BY setor
        ORDER BY setor
      `)
      .bind()
      .all();
    
    const cargoMetrics = await db
      .prepare(`
        SELECT 
          cargo,
          COUNT(*) as total,
          COUNT(DISTINCT f.id) as funcionarios,
          COUNT(q.id) as certificacoes_totais,
          COUNT(CASE WHEN q.data_vencimento >= DATE('now') THEN 1 END) as certificacoes_validas
        FROM funcionarios f
        LEFT JOIN qualificacoes q ON f.id = q.funcionario_id AND q.deleted_at IS NULL
        WHERE f.deleted_at IS NULL
        GROUP BY cargo
        ORDER BY total DESC
      `)
      .bind()
      .all();
    
    const temporalMetrics = await db
      .prepare(`
        SELECT 
          strftime('%Y-%m', created_at) as mes,
          COUNT(*) as novos_funcionarios
        FROM funcionarios
        WHERE deleted_at IS NULL
          AND created_at >= DATE('now', '-6 months')
        GROUP BY mes
        ORDER BY mes
      `)
      .bind()
      .all();
    
    return c.json({
      success: true,
      data: {
        por_setor: setorMetrics.results,
        por_cargo: cargoMetrics.results,
        temporal: temporalMetrics.results,
      },
    });
  } catch (error: any) {
    console.error('[DASHBOARD] Erro ao buscar métricas:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

/**
 * GET /api/v2/dashboard/graficos/:tipo
 * Dados para gráficos específicos
 */
dashboard.get('/graficos/:tipo', async (c) => {
  const db = c.env.DB;
  const tipo = c.req.param('tipo');
  
  try {
    let query = '';
    let params: any[] = [];
    
    switch (tipo) {
      case 'compliance-mensal':
        query = `
          SELECT 
            strftime('%Y-%m', created_at) as mes,
            COUNT(*) as total,
            COUNT(CASE WHEN cma_status = 'valido' THEN 1 END) as conformes,
            (COUNT(CASE WHEN cma_status = 'valido' THEN 1 END) * 100.0 / COUNT(*)) as percentual
          FROM funcionarios
          WHERE deleted_at IS NULL
            AND created_at >= DATE('now', '-12 months')
          GROUP BY mes
          ORDER BY mes
        `;
        break;
      
      case 'certificacoes-categoria':
        query = `
          SELECT 
            categoria,
            COUNT(*) as total,
            COUNT(CASE WHEN data_vencimento >= DATE('now') THEN 1 END) as validas,
            COUNT(CASE WHEN data_vencimento < DATE('now') THEN 1 END) as vencidas
          FROM qualificacoes
          WHERE deleted_at IS NULL
          GROUP BY categoria
          ORDER BY total DESC
        `;
        break;
      
      case 'funcionarios-setor':
        query = `
          SELECT 
            setor,
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'ativo' THEN 1 END) as ativos,
            COUNT(CASE WHEN status = 'inativo' THEN 1 END) as inativos
          FROM funcionarios
          WHERE deleted_at IS NULL
          GROUP BY setor
          ORDER BY total DESC
        `;
        break;
      
      case 'funcionarios-cargo':
        query = `
          SELECT 
            cargo,
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'ativo' THEN 1 END) as ativos
          FROM funcionarios
          WHERE deleted_at IS NULL
          GROUP BY cargo
          ORDER BY total DESC
          LIMIT 10
        `;
        break;
      
      default:
        return c.json({ success: false, error: 'Tipo de gráfico inválido' }, 400);
    }
    
    const result = await db.prepare(query).bind(...params).all();
    
    return c.json({
      success: true,
      tipo,
      data: result.results,
    });
  } catch (error: any) {
    console.error('[DASHBOARD] Erro ao gerar gráfico:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default dashboard;
