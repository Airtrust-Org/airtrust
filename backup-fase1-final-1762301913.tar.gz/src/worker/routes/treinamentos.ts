import { Hono } from 'hono';
import { Env } from '../types/index';

const treinamentos = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/treinamentos/dashboard
 * Dashboard de Treinamentos
 */
treinamentos.get('/dashboard', async (c) => {
  try {
    
    const stats = {
      total: 2,
      ativos: 2,
      vencendo: 0,
      vencidos: 0
    };

    return c.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('[API] Erro ao buscar dashboard:', error);
    return c.json({
      success: false,
      error: 'Erro ao carregar dashboard'
    }, 500);
  }
});

/**
 * GET /api/v2/treinamentos/catalogo-treinamentos
 * Catálogo de Treinamentos
 */
treinamentos.get('/catalogo-treinamentos', async (c) => {
  try {
    const db = c.env.DB;
    
    const query = db.prepare(`
      SELECT 
        id,
        codigo,
        nome,
        descricao,
        categoria,
        duracao_horas,
        validade_meses,
        obrigatorio,
        ativo,
        created_at
      FROM catalogo_treinamentos
      WHERE deleted_at IS NULL AND ativo = 1
      ORDER BY nome ASC
    `);
    const { results } = await query.bind().all();

    return c.json({
      success: true,
      data: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar catálogo de treinamentos:', error);
    return c.json({
      success: true,
      data: []
    }, 200);
  }
});

/**
 * GET /api/v2/treinamentos
 * Lista todos os treinamentos
 */
treinamentos.get('/', async (c) => {
  try {
    return c.json({
      success: true,
      data: [],
      message: 'Use /api/v2/treinamentos para listar treinamentos'
    });
  } catch (error) {
    console.error('[TREINAMENTOS] Erro:', error);
    return c.json({ success: false, error: 'Erro ao carregar treinamentos' }, 500);
  }
});

/**
 * GET /api/v2/treinamentos/dropdown
 * Dropdown de treinamentos para formulários
 */
treinamentos.get('/dropdown', async (c) => {
  try {
    const db = c.env.DB;
    
    const query = db.prepare(`
      SELECT 
        id,
        codigo,
        nome,
        carga_horaria,
        tipo
      FROM catalogo_treinamentos_v2
      WHERE deleted_at IS NULL
      ORDER BY nome ASC
    `);
    const { results } = await query.bind().all();
    
    return c.json({
      success: true,
      data: results.map((t: any) => ({
        id: t.id,
        codigo: t.codigo,
        nome: t.nome,
        carga_horaria: t.carga_horaria,
        label: `${t.nome} (${t.codigo}) - ${t.carga_horaria || 0}h`
      }))
    });
    
  } catch (error) {
    console.error('[TREINAMENTOS DROPDOWN] Erro:', error);
    return c.json({ success: false, error: 'Erro ao carregar dropdown' }, 500);
  }
});

/**
 * POST /api/v2/treinamentos
 * Criar novo treinamento
 */
treinamentos.post('/', async (c) => {
  try {
    const body = await c.req.json();
    const db = c.env.DB;
    
    if (!body.codigo || !body.nome || !body.categoria || !body.periodicidade) {
      return c.json({
        success: false,
        error: 'Campos obrigatórios: codigo, nome, categoria, periodicidade'
      }, 400);
    }

    const existing = await db.prepare(
      'SELECT id FROM catalogo_treinamentos_v2 WHERE codigo = ? AND deleted_at IS NULL'
    ).bind(body.codigo).first();

    if (existing) {
      return c.json({
        success: false,
        error: 'Código já cadastrado'
      }, 400);
    }

    const now = new Date().toISOString();
    
    const result = await db.prepare(`
      INSERT INTO catalogo_treinamentos_v2 (
        codigo, nome, categoria, periodicidade, tipo, carga_horaria, 
        descricao, obrigatorio, ativo, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      body.codigo,
      body.nome,
      body.categoria,
      body.periodicidade,
      body.tipo || 'TEORICO',
      body.carga_horaria || 0,
      body.descricao || '',
      body.obrigatorio || 0,
      1, // ativo
      now,
      now
    ).run();

    return c.json({
      success: true,
      data: {
        id: result.meta.last_row_id,
        ...body
      }
    });
  } catch (error) {
    console.error('[TREINAMENTOS POST] Erro:', error);
    return c.json({
      success: false,
      error: 'Erro ao criar treinamento'
    }, 500);
  }
});

/**
 * PUT /api/v2/treinamentos/:id
 * Atualizar treinamento
 */
treinamentos.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();
    const db = c.env.DB;
    
    const existing = await db.prepare(
      'SELECT id FROM catalogo_treinamentos_v2 WHERE id = ? AND deleted_at IS NULL'
    ).bind(id).first();

    if (!existing) {
      return c.json({
        success: false,
        error: 'Treinamento não encontrado'
      }, 404);
    }

    const now = new Date().toISOString();
    
    await db.prepare(`
      UPDATE catalogo_treinamentos_v2
      SET codigo = ?, nome = ?, categoria = ?, periodicidade = ?,
          tipo = ?, carga_horaria = ?, descricao = ?, obrigatorio = ?,
          updated_at = ?
      WHERE id = ?
    `).bind(
      body.codigo,
      body.nome,
      body.categoria,
      body.periodicidade,
      body.tipo || 'TEORICO',
      body.carga_horaria || 0,
      body.descricao || '',
      body.obrigatorio || 0,
      now,
      id
    ).run();

    return c.json({
      success: true,
      data: { id, ...body }
    });
  } catch (error) {
    console.error('[TREINAMENTOS PUT] Erro:', error);
    return c.json({
      success: false,
      error: 'Erro ao atualizar treinamento'
    }, 500);
  }
});

/**
 * DELETE /api/v2/treinamentos/:id
 * Deletar treinamento (soft delete)
 */
treinamentos.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    const now = new Date().toISOString();
    
    await db.prepare(`
      UPDATE catalogo_treinamentos_v2
      SET deleted_at = ?, ativo = 0
      WHERE id = ?
    `).bind(now, id).run();

    return c.json({
      success: true,
      data: { id }
    });
  } catch (error) {
    console.error('[TREINAMENTOS DELETE] Erro:', error);
    return c.json({
      success: false,
      error: 'Erro ao deletar treinamento'
    }, 500);
  }
});

export default treinamentos;
