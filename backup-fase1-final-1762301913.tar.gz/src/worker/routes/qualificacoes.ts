import { Hono } from 'hono';
import type { Env } from '../types/index';
import { QualificacoesService } from '../services/qualificacoesService';
import {
  CreateQualificacaoDTO,
  UpdateQualificacaoDTO,
  QualificacaoResponseDTO,
} from '../dtos/qualificacoes';

export function qualificacoesRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  // GET /qualificacoes - Listar todas
  router.get('/', async (c) => {
    const service = new QualificacoesService(c.env.DB);
    const categoria = c.req.query('categoria');
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '50');

    if (categoria) {
      const result = await service.getByCategoria(categoria, page, limit);
      return c.json({
        success: true,
        data: result.data,
        page,
        total: result.total,
        timestamp: new Date().toISOString(),
      });
    }

    const result = await service.getAll(page, limit);
    return c.json({
      success: true,
      data: result.data,
      page,
      total: result.total,
      timestamp: new Date().toISOString(),
    });
  });

  // POST /qualificacoes - Criar nova
  router.post('/', async (c) => {
    const service = new QualificacoesService(c.env.DB);
    const body = await c.req.json();
    const dados = CreateQualificacaoDTO.parse(body);

    const createData: Record<string, unknown> = {
      nome: dados.nome,
      codigo: dados.codigo,
      categoria: dados.categoria,
      descricao: dados.descricao,
      carga_horaria: dados.carga_horaria,
      validade_meses: dados.validade_meses,
      ativo: true,
    };
    Object.keys(createData).forEach((k) => createData[k] === undefined && delete createData[k]);

    const created = await service.create(createData);
    const response = QualificacaoResponseDTO.parse(created);
    return c.json({ success: true, data: response }, 201);
  });

  // GET /qualificacoes/:id - Obter específica
  router.get('/:id', async (c) => {
    const service = new QualificacoesService(c.env.DB);
    const id = c.req.param('id'); // Aceita string ou number

    const qual = await service.getById(id);
    const response = QualificacaoResponseDTO.parse(qual);
    return c.json({ success: true, data: response });
  });

  // PUT /qualificacoes/:id - Atualizar
  router.put('/:id', async (c) => {
    const service = new QualificacoesService(c.env.DB);
    const id = c.req.param('id'); // Aceita string ou number
    const body = await c.req.json();
    const dados = UpdateQualificacaoDTO.parse(body);

    const updateData: Record<string, unknown> = {
      nome: dados.nome,
      codigo: dados.codigo,
      categoria: dados.categoria,
      descricao: dados.descricao,
      carga_horaria: dados.carga_horaria,
      validade_meses: dados.validade_meses,
      ativo: dados.ativo,
    };
    Object.keys(updateData).forEach((k) => updateData[k] === undefined && delete updateData[k]);

    const updated = await service.update(id, updateData);
    const response = QualificacaoResponseDTO.parse(updated);
    return c.json({ success: true, data: response });
  });

  // DELETE /qualificacoes/:id - Deletar (soft)
  router.delete('/:id', async (c) => {
    const service = new QualificacoesService(c.env.DB);
    const id = c.req.param('id'); // Aceita string ou number

    await service.delete(id);
    return c.json({ success: true });
  });

  return router;
}
