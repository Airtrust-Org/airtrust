import { Hono } from 'hono';
import type { Env } from '../types/index';

export function categoriasQualificacoesRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  // GET /categorias-qualificacoes - Listar todas
  router.get('/', async (c) => {
    try {
      const result = await (c.env.DB as any)
        .prepare(`
          SELECT 
            id,
            nome,
            codigo,
            descricao,
            cor,
            created_at,
            updated_at
          FROM categorias_qualificacoes
          WHERE deleted_at IS NULL
          ORDER BY nome ASC
        `)
        .all();

      return c.json({
        success: true,
        data: result.results || [],
      });
    } catch (error) {
      console.error('Erro GET categorias-qualificacoes:', error);
      return c.json({ error: 'Erro ao listar categorias', success: false }, 500);
    }
  });

  // GET /categorias-qualificacoes/:id - Obter específica
  router.get('/:id', async (c) => {
    try {
      const id = parseInt(c.req.param('id'));
      if (isNaN(id)) return c.json({ error: 'ID inválido' }, 400);

      const result = await (c.env.DB as any)
        .prepare(`
          SELECT * FROM categorias_qualificacoes
          WHERE id = ? AND deleted_at IS NULL
        `)
        .bind(id)
        .first();

      return result
        ? c.json({ success: true, data: result })
        : c.json({ error: 'Categoria não encontrada' }, 404);
    } catch (error) {
      console.error('Erro GET categoria/:id:', error);
      return c.json({ error: 'Erro ao buscar categoria' }, 500);
    }
  });

  return router;
}
