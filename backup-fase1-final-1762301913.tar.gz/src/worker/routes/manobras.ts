import { Hono } from 'hono';
import { Env } from '../types/index';

const manobras = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/simuladores/manobras
 * Listar manobras
 */
manobras.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        id,
        codigo,
        nome,
        descricao,
        categoria,
        nivel_dificuldade,
        duracao_estimada,
        pontuacao_minima,
        ordem,
        created_at,
        updated_at
      FROM manobras
      ORDER BY ordem ASC, codigo ASC
    `).bind().all();

    return c.json({
      success: true,
      data: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar manobras:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar manobras'
    }, 500);
  }
});

/**
 * POST /api/v2/simuladores/manobras
 * Criar manobra
 */
manobras.post('/', async (c) => {
  try {
    const body = await c.req.json();
    const db = c.env.DB;
    
    const id = crypto.randomUUID();

    await db.prepare(`
      INSERT INTO manobras (
        id, codigo, nome, descricao, categoria, 
        duracao_minutos, nivel_dificuldade, ativa
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `).bind(
      id, 
      body.codigo, 
      body.nome, 
      body.descricao || null, 
      body.categoria || null,
      body.duracao_minutos || null, 
      body.nivel_dificuldade || null
    ).run();

    return c.json({
      success: true,
      data: { id, ...body }
    });
  } catch (error) {
    console.error('[API] Erro ao criar manobra:', error);
    return c.json({
      success: false,
      error: 'Erro ao criar manobra'
    }, 500);
  }
});

/**
 * PUT /api/v2/simuladores/manobras/:id
 * Atualizar manobra
 */
manobras.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();
    const db = c.env.DB;
    
    await db.prepare(`
      UPDATE manobras
      SET codigo = ?, nome = ?, descricao = ?, categoria = ?, 
          duracao_minutos = ?, nivel_dificuldade = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      body.codigo, 
      body.nome, 
      body.descricao || null, 
      body.categoria || null,
      body.duracao_minutos || null, 
      body.nivel_dificuldade || null,
      id
    ).run();

    return c.json({
      success: true,
      data: { id, ...body }
    });
  } catch (error) {
    console.error('[API] Erro ao atualizar manobra:', error);
    return c.json({
      success: false,
      error: 'Erro ao atualizar manobra'
    }, 500);
  }
});

/**
 * DELETE /api/v2/simuladores/manobras/:id
 * Deletar manobra (soft delete)
 */
manobras.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const db = c.env.DB;
    
    await db.prepare(`
      UPDATE manobras
      SET deleted_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(id).run();

    return c.json({
      success: true,
      data: { id }
    });
  } catch (error) {
    console.error('[API] Erro ao deletar manobra:', error);
    return c.json({
      success: false,
      error: 'Erro ao deletar manobra'
    }, 500);
  }
});

export default manobras;
