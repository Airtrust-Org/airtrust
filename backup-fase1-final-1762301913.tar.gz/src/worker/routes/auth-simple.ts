
import { Hono } from 'hono';
import { Env } from '../types/index';

const authRouter = new Hono<{ Bindings: Env }>();

authRouter.post('/login', async (c) => {
  
  try {
    const body = await c.req.json();
    
    const { email, senha } = body;
    
    if (!email || !senha) {
      return c.json({ 
        success: false, 
        error: 'Email e senha são obrigatórios' 
      }, 400);
    }
    
    const db = c.env.DB;
    
    if (!db) {
      console.error('❌ DB não disponível!');
      return c.json({
        success: false,
        error: 'Banco de dados não disponível'
      }, 500);
    }
    
    
    let user;
    try {
      user = await db.prepare(`
        SELECT id, email, password_hash, nome, perfil
        FROM usuarios
        WHERE email = ?
      `).bind(email).first();
    } catch (dbError) {
      console.error('❌ Erro na query:', dbError);
      return c.json({
        success: false,
        error: 'Erro ao buscar usuário: ' + (dbError instanceof Error ? dbError.message : String(dbError))
      }, 500);
    }

    if (!user) {
      return c.json({
        success: false,
        error: 'Credenciais inválidas'
      }, 401);
    }
    
    
    const bcrypt = await import('bcryptjs');
    const senhaValida = await bcrypt.compare(senha, user.password_hash as string);
    
    
    if (!senhaValida) {
      return c.json({
        success: false,
        error: 'Credenciais inválidas'
      }, 401);
    }
    
    const { sign } = await import('hono/jwt');
    // Use standard 'sub' claim and include alg explicitly in payload to match verifyToken expectations
    const nowSec = Math.floor(Date.now() / 1000);
    const token = await sign(
      {
        sub: String(user.id),
        email: user.email,
        perfil: user.perfil,
        iat: nowSec,
        exp: nowSec + 60 * 60 * 24, // 24h
        alg: 'HS256'
      },
      c.env.JWT_SECRET || 'dev-secret-key'
    );
    
    
    return c.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.nome,
        email: user.email,
        perfil: user.role
      }
    });
    
  } catch (error) {
    console.error('❌ ERRO:', error);
    return c.json({
      success: false,
      error: 'Erro interno: ' + (error instanceof Error ? error.message : String(error))
    }, 500);
  }
});

authRouter.get('/profile', async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({
        success: false,
        error: 'Token não fornecido'
      }, 401);
    }

    const token = authHeader.substring(7);
    
    const { verify } = await import('hono/jwt');
    const payload = await verify(token, c.env.JWT_SECRET || 'dev-secret-key');
    
    const db = c.env.DB;
    // use payload.sub (normalized by AuthService.verifyToken) as the canonical user id
    const userId = (payload as any).sub || (payload as any).id;
    const user = await db.prepare(`
      SELECT id, email, nome, perfil
      FROM usuarios
      WHERE id = ?
    `).bind(userId).first();

    if (!user) {
      return c.json({
        success: false,
        error: 'Usuário não encontrado'
      }, 404);
    }

    return c.json({
      success: true,
      user: {
        id: user.id,
        name: user.nome,
        email: user.email,
        perfil: user.role
      }
    });

  } catch (error) {
    console.error('❌ ERRO /profile:', error);
    return c.json({
      success: false,
      error: 'Token inválido'
    }, 401);
  }
});

export default authRouter;
