import { Hono } from 'hono';
import { Logger } from '../utils/logger';
import { Env } from '../types/index';
import { authMiddleware } from '../middleware/auth';

const sistema = new Hono<{ Bindings: Env }>();

sistema.use('/backup/*', authMiddleware);
sistema.use('/audit/*', authMiddleware);

/**
 * GET /sistema/health
 * Health check detalhado do sistema
 */
sistema.get('/health', async (c) => {
  try {
    const startTime = Date.now();
    const checks = [];
    
    try {
      await c.env.DB.prepare('SELECT 1').bind().first();
      checks.push({ check: 'Database Connection', status: 'OK' });
    } catch (error) {
      checks.push({ check: 'Database Connection', status: 'FAIL', error: String(error) });
      Logger.error('Database health check failed', error);
    }

    const tables = ['funcionarios', 'qualificacoes', 'simuladores', 'treinamentos'];
    for (const table of tables) {
      try {
        await c.env.DB.prepare(`SELECT COUNT(*) as count FROM ${table}`).bind().first();
        checks.push({ table, status: 'OK' });
      } catch (error) {
        checks.push({ table, status: 'FAIL', error: String(error) });
      }
    }

    const allOk = checks.every(c => c.status === 'OK' || c.status === 'WARN');
    const health = {
      status: allOk ? 'HEALTHY' : 'UNHEALTHY',
      checks,
      timestamp: new Date().toISOString(),
      environment: c.env?.ENVIRONMENT || 'development',
      uptime: Date.now() - startTime
    };

    return c.json({
      success: true,
      data: health
    });

  } catch (error) {
    Logger.error('Health check error', error);
    return c.json({
      success: false,
      error: 'Health check failed',
      data: {
        status: 'ERROR',
        checks: [],
        timestamp: new Date().toISOString(),
        environment: 'unknown'
      }
    }, 500);
  }
});

/**
 * GET /sistema/info
 * Informações do sistema (público)
 */
sistema.get('/info', async (c) => {
  try {
    const database_stats: Record<string, number | string> = {};
    
    try {
      const funcionariosCount = await c.env.DB.prepare('SELECT COUNT(*) as count FROM funcionarios').bind().first();
      database_stats.funcionarios = (funcionariosCount as any)?.count || 0;
      
      const qualificacoesCount = await c.env.DB.prepare('SELECT COUNT(*) as count FROM qualificacoes').bind().first();
      database_stats.qualificacoes = (qualificacoesCount as any)?.count || 0;
      
      const simuladoresCount = await c.env.DB.prepare('SELECT COUNT(*) as count FROM simuladores').bind().first();
      database_stats.simuladores = (simuladoresCount as any)?.count || 0;
      
      const treinamentosCount = await c.env.DB.prepare('SELECT COUNT(*) as count FROM treinamentos').bind().first();
      database_stats.treinamentos = (treinamentosCount as any)?.count || 0;
    } catch (error) {
      Logger.error('Error fetching database stats', error);
    }

    return c.json({
      success: true,
      data: {
        system: 'AirTrust',
        version: '2.0.0',
        environment: c.env?.ENVIRONMENT || 'development',
        timestamp: new Date().toISOString(),
        database_stats,
        endpoints: {
          auth: '/api/v2/auth',
          funcionarios: '/api/funcionarios',
          qualificacoes: '/api/v2/qualificacoes',
          simuladores: '/api/v2/simuladores',
          pastaVirtual: '/api/v2/pasta-virtual',
          sistema: '/api/v2/sistema'
        }
      }
    });
  } catch (error) {
    Logger.error('System info error', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar informações do sistema'
    }, 500);
  }
});

/**
 * POST /sistema/backup
 * Criar backup do sistema
 */
sistema.post('/backup', async (c) => {
  try {
    const user = c.get('user');
    
    if (user?.perfil !== 'ADMIN') {
      return c.json({
        success: false,
        error: 'Acesso negado. Apenas administradores podem criar backups.'
      }, 403);
    }

    Logger.audit('BACKUP_REQUESTED', user.id);

    return c.json({
      success: true,
      message: 'Backup em desenvolvimento',
      backupId: `backup_${Date.now()}`
    });

  } catch (error) {
    Logger.error('Backup creation error', error);
    return c.json({
      success: false,
      error: 'Erro ao criar backup'
    }, 500);
  }
});

/**
 * GET /sistema/audit
 * Logs de auditoria
 */
sistema.get('/audit', async (c) => {
  try {
    const user = c.get('user');
    
    if (!['ADMIN', 'COMPLIANCE'].includes(user?.perfil || '')) {
      return c.json({
        success: false,
        error: 'Acesso negado'
      }, 403);
    }

    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '50');
    const offset = (page - 1) * limit;

    Logger.audit('AUDIT_LOGS_ACCESSED', user.id, { page, limit });

    return c.json({
      success: true,
      data: [],
      message: 'Logs de auditoria em desenvolvimento',
      pagination: { page, limit, total: 0, pages: 0 }
    });

  } catch (error) {
    Logger.error('Audit logs error', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar logs de auditoria'
    }, 500);
  }
});

export default sistema;
