import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  try {
    const result = await c.env.DB.prepare(`SELECT * FROM aeronaves WHERE deleted_at IS NULL ORDER BY id DESC`).all();
    return c.json({ success: true, data: result.results || [] });
  } catch (error: any) {
    console.error('[AERONAVES] Erro:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.get('/list', async (c) => {
  try {
    const result = await c.env.DB.prepare(`SELECT * FROM aeronaves WHERE deleted_at IS NULL ORDER BY id DESC`).all();
    return c.json({ success: true, data: result.results || [] });
  } catch (error: any) {
    console.error('[AERONAVES] Erro:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.post('/', async (c) => {
  try {
    const body = await c.req.json();
    const codigo = `AER${Date.now()}`;
    await c.env.DB.prepare(`INSERT INTO aeronaves (codigo, modelo, fabricante, status) VALUES (?, ?, ?, 'ATIVO')`).bind(codigo, body.modelo || 'Sem modelo', body.fabricante || null).run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[AERONAVES] Erro POST:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();
    const modelo = body.modelo || body.nome || 'Sem modelo';
    await c.env.DB.prepare(`UPDATE aeronaves SET modelo = ?, fabricante = ?, updated_at = datetime('now') WHERE id = ?`).bind(modelo, body.fabricante || null, id).run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[AERONAVES] Erro PUT:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    await c.env.DB.prepare(`UPDATE aeronaves SET deleted_at = datetime('now') WHERE id = ?`).bind(id).run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[AERONAVES] Erro DELETE:', error);
    return c.json({ error: String(error) }, 500);
  }
});

export default app;
