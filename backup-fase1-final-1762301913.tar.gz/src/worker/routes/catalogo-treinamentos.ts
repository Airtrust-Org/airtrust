/**
 * ═══════════════════════════════════════════════════════════════════════════
 * ROTAS: CATÁLOGO DE TREINAMENTOS
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { Hono } from 'hono';
import { Env } from '../types/index';

const catalogoApp = new Hono<{ Bindings: Env }>();

catalogoApp.get('/', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM treinamentos
      WHERE deleted_at IS NULL
      ORDER BY codigo
    `).bind().all();

    return c.json({ success: true, data: results || [] });
  } catch (error) {
    console.error('Erro ao listar catálogo:', error);
    return c.json({ error: 'Erro ao listar catálogo' }, 500);
  }
});

catalogoApp.get('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const result = await c.env.DB.prepare(`
      SELECT * FROM treinamentos 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).first();

    if (!result) {
      return c.json({ error: 'Treinamento não encontrado' }, 404);
    }

    return c.json(result);
  } catch (error) {
    console.error('Erro ao buscar treinamento:', error);
    return c.json({ error: 'Erro ao buscar treinamento' }, 500);
  }
});

catalogoApp.post('/', async (c) => {
  try {
    const data = await c.req.json();

    if (!data.codigo || !data.nome) {
      return c.json({ error: 'Código e nome são obrigatórios' }, 400);
    }

    const existe = await c.env.DB.prepare(`
      SELECT id FROM catalogotreinamentosv2 
      WHERE codigo = ? AND deletado_em IS NULL
    `).bind(data.codigo).first();

    if (existe) {
      return c.json({ error: 'Código já cadastrado' }, 400);
    }

    await c.env.DB.prepare(`
      INSERT INTO catalogotreinamentosv2 
      (codigo, nome, descricao, periodicidade, intervalo_meses, carga_horaria, tipo, obrigatorio_para_funcoes, exige_certificado, exige_instrutor)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      data.codigo,
      data.nome,
      data.descricao || null,
      data.periodicidade || 'UNICO',
      data.intervalo_meses || 0,
      data.carga_horaria || 0,
      data.tipo || 'TREINAMENTO',
      data.obrigatorio_para_funcoes || '',
      data.exige_certificado !== false ? 1 : 0,
      data.exige_instrutor === true ? 1 : 0
    ).run();

    await c.env.DB.prepare(`
      INSERT INTO auditlogs (usuario, acao, modulo, detalhes, data)
      VALUES (?, ?, ?, ?, datetime('now'))
    `).bind(
      'SISTEMA',
      'CREATE',
      'Catálogo Treinamentos',
      `Treinamento ${data.codigo} criado`
    ).run();

    return c.json({ success: true, message: 'Treinamento criado com sucesso' });
  } catch (error) {
    console.error('Erro ao criar treinamento:', error);
    return c.json({ error: 'Erro ao criar treinamento' }, 500);
  }
});

catalogoApp.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const data = await c.req.json();

    await c.env.DB.prepare(`
      UPDATE catalogotreinamentosv2 
      SET nome = ?, descricao = ?, periodicidade = ?, intervalo_meses = ?, 
          carga_horaria = ?, tipo = ?, obrigatorio_para_funcoes = ?,
          exige_certificado = ?, exige_instrutor = ?, atualizado_em = datetime('now')
      WHERE id = ? AND deletado_em IS NULL
    `).bind(
      data.nome,
      data.descricao || null,
      data.periodicidade,
      data.intervalo_meses,
      data.carga_horaria,
      data.tipo,
      data.obrigatorio_para_funcoes,
      data.exige_certificado ? 1 : 0,
      data.exige_instrutor ? 1 : 0,
      id
    ).run();

    return c.json({ success: true, message: 'Treinamento atualizado com sucesso' });
  } catch (error) {
    console.error('Erro ao atualizar treinamento:', error);
    return c.json({ error: 'Erro ao atualizar treinamento' }, 500);
  }
});

catalogoApp.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');

    await c.env.DB.prepare(`
      UPDATE catalogotreinamentosv2 
      SET deletado_em = datetime('now')
      WHERE id = ?
    `).bind(id).run();

    return c.json({ success: true, message: 'Treinamento excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir treinamento:', error);
    return c.json({ error: 'Erro ao excluir treinamento' }, 500);
  }
});

export default catalogoApp;
