import { Hono } from 'hono';
import { Env } from '../types/index';

import pastaVirtual from './pasta-virtual';
import sistema from './sistema';
import compliance from './compliance';
import manobras from './manobras';
import dashboard from './dashboard';
import importRouter from './import';
import notificacoes from './notificacoes';
import authComplete from './auth-simple';
import backupRoutes from './backup';
import relatorios from './relatorios';
import setores from './setores';
import aeronaves from './aeronaves';
import importFuncionarios from './import-funcionarios';
import auditoria from './auditoria';
import importacoesLog from './importacoes';
import manobrasV2 from '../api/v2/manobras';
// import certificadosStorage from '../api/v2/certificados-storage'; // DEPRECATED - usar /api/v2/qualificacoes/upload-certificado

import treinamentosApi from '../api/v2/treinamentos';
import importacoes from '../api/v2/importacoes';
// import qualificacoes from '../api/v2/qualificacoes';

import exames from '../api/v2/exames';
import lgpd from '../api/v2/lgpd';
import health from '../api/v2/health';
import simuladoresConsolidado from '../api/v2/simuladores-consolidado/index';
import simuladorAgendamentoAirtrust from '../api/v2/simulador-agendamento-airtrust';
import limparDados from '../api/v2/admin/limpar-dados';
import templates from '../api/v2/templates';

// NOVAS ROTAS - REFATORAÇÃO QUALIFICACOES (PHASE 3)
import { qualificacoesRoutes } from '../routes/qualificacoes';
import { habilitacoesRoutes } from '../routes/habilitacoes';
import { categoriasQualificacoesRoutes } from '../routes/categorias-qualificacoes';
import empresaCertificadoConfig from './v2/empresa-certificado-config';

// REFACTORED ROUTES - ARCHITECTURAL REFACTORING
import { funcionariosRoutes } from '../routes/funcionarios';
import { certificadosRoutes } from '../routes/certificados';
import certificadosV2 from './v2/certificados'; // Rotas v2 com upload/gerar
import { simuladoresRoutes } from '../routes/simuladores';
import { categoriasRoutes } from '../routes/categorias';
import { funcoesRoutes } from '../routes/funcoes';
import { empresasRoutes } from '../routes/empresas';

import { rateLimiter } from '../middleware/rate-limiter';
import { invalidateCache } from '../utils/cache';
import { metricsMiddleware, getMetrics } from '../middleware/metrics';
import { checkRole } from '../middleware/rbac-containment';

const app = new Hono<{ Bindings: Env }>();

app.route('/api/v2/funcionarios/import', importFuncionarios);

app.route('/api/v2/funcionarios', funcionariosRoutes());

app.delete('/api/v2/funcionarios/:id', async (c) => {
  const id = parseInt(c.req.param('id'));

  try {
    if (isNaN(id) || !c.env?.DB) {
      return c.json({ success: false, error: 'ID inválido ou DB indisponível' }, 400);
    }

    const funcionario = await c.env.DB.prepare(
      'SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL',
    )
      .bind(id)
      .first();

    if (!funcionario) {
      return c.json({ success: false, error: 'Funcionário não encontrado' }, 404);
    }

    const result = await c.env.DB.prepare(
      "UPDATE funcionarios SET deleted_at = datetime('now'), updated_at = datetime('now') WHERE id = ? AND deleted_at IS NULL",
    )
      .bind(id)
      .run();

    if (result.meta.changes === 0) {
      return c.json({ success: false, error: 'Falha ao excluir' }, 500);
    }

    invalidateCache('dashboard:', 'delete');
    invalidateCache('funcionarios:', 'delete');

    return c.json({ success: true, message: 'Funcionário excluído', id }, 200);
  } catch (error: unknown) {
    const err = error as Error;
    return c.json({ success: false, error: err.message }, 500);
  }
});

app.use('/api/v2/importacoes/*', rateLimiter({ windowMs: 3600000, maxRequests: 10 })); // 10 requests per hour for imports
app.use('/api/v2/funcionarios/import/*', rateLimiter({ windowMs: 3600000, maxRequests: 10 })); // 10 requests per hour for imports

app.use('*', async (c, next) => {
  await rateLimiter({ windowMs: 60000, maxRequests: 100 })(c, next);
});

app.use('*', async (c, next) => {
  const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:5173',
    'https://airtrust.com.br',
    'https://www.airtrust.com.br',
    'https://521c8b4c.airtrust.pages.dev',
    'https://main.airtrust.pages.dev',
    'https://airtrust.pages.dev',
    'https://0199d03e-fe13-77d7-a6e7-7d94d446894b.airtrust.workers.dev',
  ];

  const origin = c.req.header('origin') || '';

  const isAllowed =
    (origin && allowedOrigins.includes(origin)) ||
    /^https:\/\/[a-z0-9]{32,}\.airtrust\.pages\.dev$/.test(origin) ||
    /^https:\/\/[a-z0-9]{8,}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}\.airtrust\.workers\.dev$/.test(
      origin,
    );

  if (isAllowed) {
    c.header('Access-Control-Allow-Origin', origin);
    c.header('Access-Control-Allow-Credentials', 'true');
  } else if (!origin) {
    c.header('Access-Control-Allow-Origin', allowedOrigins[0]);
  }

  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  c.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (c.req.method === 'OPTIONS') {
    return new Response(null, { status: 204 });
  }

  return await next();
});

app.use('*', async (c, next) => {
  c.header(
    'Content-Security-Policy',
    "default-src 'self'; connect-src 'self' https:; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
  );
  c.header('X-Frame-Options', 'DENY');
  c.header('X-Content-Type-Options', 'nosniff');
  c.header('Referrer-Policy', 'no-referrer');
  await next();
});

app.use('*', async (c, next) => {
  await next();
  const p = c.req.path;
  if (p.endsWith('.js')) c.header('Content-Type', 'application/javascript; charset=utf-8');
  else if (p.endsWith('.css')) c.header('Content-Type', 'text/css; charset=utf-8');
  else if (p.endsWith('.html')) c.header('Content-Type', 'text/html; charset=utf-8');
});

app.use('*', async (_c, next) => {
  await next();
});

app.use('/assets/*', async (c) => {
  try {
    const response = await c.env.ASSETS.fetch(c.req.raw);

    if (response.ok) {
      const contentType = response.headers.get('Content-Type') || 'application/javascript';
      return new Response(response.body, {
        status: response.status,
        headers: {
          'Content-Type': contentType,
          // Cache agressivo pois os assets têm hash único (cache busting)
          'Cache-Control': 'public, max-age=31536000, immutable',
          // Adicionar ETag baseado no hash do arquivo
          ETag: `"${c.req.path.split('-').pop()?.split('.')[0] || Date.now()}"`,
          // Permitir que o navegador valide com If-None-Match
          Vary: 'Accept-Encoding',
        },
      });
    }

    return c.text('Asset not found', 404);
  } catch (e) {
    console.error('Asset error:', c.req.path, e);
    return c.text('Asset not found', 404);
  }
});

app.get('/health', (c) =>
  c.json({
    status: 'healthy',
    version: '2.0.0',
    timestamp: new Date().toISOString(),
    environment: c.env?.ENVIRONMENT || 'development',
  }),
);

app.get('/api/health', (c) =>
  c.json({
    status: 'healthy',
    version: '2.0.0',
    timestamp: new Date().toISOString(),
    environment: c.env?.ENVIRONMENT || 'development',
  }),
);

app.get('/api/v2/version', (c) =>
  c.json({
    version: Date.now(),
    deployed_at: new Date().toISOString(),
    environment: c.env?.ENVIRONMENT || 'production',
  }),
);

app.route('/api/v2/auth', authComplete);

app.route('/api/v2/funcoes', funcoesRoutes());
app.route('/api/v2/setores', setores);
app.route('/api/v2/aeronaves', aeronaves);
app.route('/api/v2/empresas', empresasRoutes());
// app.route('/api/v2/empresas-novo', empresasRouter); // DEPRECATED - use /api/v2/empresas

// app.route('/api/v2/certificados-storage', certificadosStorage); // DEPRECATED - usar /api/v2/qualificacoes/upload-certificado

app.route('/api/v2/compliance', compliance);

// 🔒 ROTA CRÍTICA 1: LGPD - RBAC aplicado
app.use('/api/v2/lgpd', checkRole(['ADMIN', 'DPO']));
app.route('/api/v2/lgpd', lgpd);

app.route('/api/v2/treinamentos', treinamentosApi);

app.route('/api/v2/dashboard', dashboard);
app.route('/api/v2/sistema', sistema);
app.route('/api/v2/health', health);

// 🔒 ROTA CRÍTICA 2: AUDITORIA - RBAC aplicado
app.use('/api/v2/auditoria', checkRole(['ADMIN', 'AUDITOR']));
app.route('/api/v2/auditoria', auditoria);

app.route('/api/v2/importacoes', importacoesLog);

// app.route('/api/v2/fichas', fichasPdf); // REMOVED - deleted
app.route('/api/v2/manobras', manobrasV2); // Manobras com ordenamento
app.route('/api/v2/simuladores/manobras', manobras);
// app.route('/api/v2/simuladores-consolidado', categoriasManobras); // REMOVED - deleted
app.route('/api/v2/simuladores-consolidado', simuladoresConsolidado);
app.route('/api/v2/simuladores', simuladoresRoutes());
app.route('/api/v2/simulador', simuladorAgendamentoAirtrust); // Genérico POR ÚLTIMO

app.route('/api/v2/pasta-virtual', pastaVirtual);

app.route('/api/v2/qualificacoes', qualificacoesRoutes()); // Qualificações (master)
app.route('/api/v2/habilitacoes', habilitacoesRoutes()); // Habilitações (instance)
app.route('/api/v2/certificados', certificadosV2); // Certificados V2 (upload/gerar com UUID)
app.route('/api/v2/certificados-basic', certificadosRoutes()); // Certificados básico (CRUD simples)
app.route('/api/v2/categorias', categoriasRoutes()); // Categorias (refactored)
app.route('/api/v2/categorias-qualificacoes', categoriasQualificacoesRoutes()); // Categorias de qualificações

app.route('/api/v2/empresa-certificado-config', empresaCertificadoConfig); // Configuração de certificados por empresa

app.route('/api/v2/exames', exames); // Endpoint principal (GET)

// 🔒 ROTA CRÍTICA 3: BACKUP - RBAC aplicado
app.use('/api/admin/backup', checkRole(['ADMIN']));
app.route('/api/admin/backup', backupRoutes);
app.route('/api/v2/admin/limpar-dados', limparDados);

app.route('/api/v2', importacoes);

// 🔒 ROTA CRÍTICA 4: IMPORT - RBAC + Rate Limit aplicados
app.use('/api/v2/import', checkRole(['ADMIN']));
app.use('/api/v2/import', rateLimiter({ windowMs: 3600000, maxRequests: 10 })); // 10 requests/hora
app.route('/api/v2/import', importRouter);

app.route('/api/v2/relatorios', relatorios);

app.route('/api/v2/templates', templates);

app.route('/api/v2/notificacoes', notificacoes);

app.get('/api/v2/metrics', (c) => c.json(getMetrics()));
app.use('*', metricsMiddleware);

app.notFound(async (c) => {
  const path = c.req.path;

  if (path.startsWith('/api/')) {
    return c.json(
      {
        success: false,
        error: 'Endpoint não encontrado',
        path: path,
        method: c.req.method,
      },
      404,
    );
  }

  if (path.startsWith('/assets/')) {
    return c.text('Asset not found', 404);
  }

  try {
    const baseUrl = new URL(c.req.url);
    baseUrl.pathname = '/';
    const asset = await c.env.ASSETS.fetch(baseUrl);

    return new Response(asset.body, {
      headers: {
        'Content-Type': 'text/html',
        'Cache-Control': 'no-store, no-cache, must-revalidate',
      },
    });
  } catch (e) {
    console.error('SPA fallback error:', e);
    return c.json(
      {
        success: false,
        error: 'Página não encontrada',
        path: path,
        details: e instanceof Error ? e.message : 'Unknown error',
      },
      404,
    );
  }
});

app.onError((err, c) => {
  console.error('Global error handler:', err);
  return c.json(
    {
      success: false,
      error: 'Erro interno do servidor',
      message: err.message,
    },
    500,
  );
});

export default app;
