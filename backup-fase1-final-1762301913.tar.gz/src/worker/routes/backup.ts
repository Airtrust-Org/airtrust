/**
 * ═══════════════════════════════════════════════════════════════════════════
 * ROTAS DE BACKUP/RESTORE - 8 Endpoints Completos
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { Hono } from 'hono';
import { Env } from '../types';
import {
  criarBackupCompleto,
  restaurarBackup,
  limparBackupsAntigos,
  verificarIntegridade,
} from '../utils/backup-utils';

const backup = new Hono<{ Bindings: Env }>();

/**
 * 1. POST /api/admin/backup/criar
 * Cria backup manual sob demanda
 */
backup.post('/criar', async (c) => {
  try {
    const body = await c.req.json();
    const { tipo = 'completo', descricao } = body;

    if (tipo !== 'completo' && tipo !== 'incremental') {
      return c.json(
        {
          success: false,
          error: 'Tipo inválido. Use "completo" ou "incremental"',
        },
        400
      );
    }

    const resultado = await criarBackupCompleto(c.env, descricao);

    const urlDownload = `/api/admin/backup/${resultado.id}/download`;

    return c.json({
      success: true,
      backup: {
        id: resultado.id,
        tamanho: resultado.tamanho,
        tamanho_mb: Math.round((resultado.tamanho / 1024 / 1024) * 100) / 100,
        duracao: resultado.duracao,
        hash_md5: resultado.hash,
        total_tabelas: resultado.total_tabelas,
        total_registros: resultado.total_registros,
        total_arquivos: resultado.total_arquivos,
        url_download: urlDownload,
      },
    });
  } catch (error) {
    console.error('Erro ao criar backup:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao criar backup',
      },
      500
    );
  }
});

/**
 * 2. GET /api/admin/backup/listar
 * Lista todos backups disponíveis
 */
backup.get('/listar', async (c) => {
  try {
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');
    const offset = (page - 1) * limit;

    const totalResult = await c.env.DB.prepare(
      'SELECT COUNT(*) as total FROM backups'
    ).first();
    const total = (totalResult?.total as number) || 0;

    const backups = await c.env.DB.prepare(
      `SELECT 
        id, data, tipo, tamanho, hash_md5, status, duracao_segundos,
        descricao, total_tabelas, total_registros, total_arquivos,
        criado_por, criado_em, verificado_em
       FROM backups 
       ORDER BY criado_em DESC 
       LIMIT ? OFFSET ?`
    )
      .bind(limit, offset)
      .all();

    const backupsFormatados = backups.results.map((b: any) => ({
      id: b.id,
      data: b.data,
      tipo: b.tipo,
      tamanho: b.tamanho,
      tamanho_mb: Math.round((b.tamanho / 1024 / 1024) * 100) / 100,
      hash_md5: b.hash_md5,
      status: b.status,
      duracao_segundos: b.duracao_segundos,
      descricao: b.descricao,
      total_tabelas: b.total_tabelas,
      total_registros: b.total_registros,
      total_arquivos: b.total_arquivos,
      criado_por: b.criado_por,
      criado_em: b.criado_em,
      verificado: b.verificado_em !== null,
      verificado_em: b.verificado_em,
    }));

    return c.json({
      success: true,
      backups: backupsFormatados,
      total,
      page,
      limit,
      total_pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Erro ao listar backups:', error);
    return c.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : 'Erro ao listar backups',
      },
      500
    );
  }
});

/**
 * 3. GET /api/admin/backup/:id/download
 * Gera URL assinada R2 para download seguro
 */
backup.get('/:id/download', async (c) => {
  try {
    const backupId = c.req.param('id');

    const backupInfo = await c.env.DB.prepare(
      'SELECT * FROM backups WHERE id = ?'
    )
      .bind(backupId)
      .first();

    if (!backupInfo) {
      return c.json(
        {
          success: false,
          error: 'Backup não encontrado',
        },
        404
      );
    }

    const obj = await c.env.BUCKET.get(backupInfo.r2_path as string);
    if (!obj) {
      return c.json(
        {
          success: false,
          error: 'Arquivo de backup não encontrado',
        },
        404
      );
    }

    return new Response(obj.body, {
      headers: {
        'Content-Type': 'application/gzip',
        'Content-Disposition': `attachment; filename="${backupId}.backup.gz"`,
        'Content-Length': obj.size.toString(),
      },
    });
  } catch (error) {
    console.error('Erro ao baixar backup:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao baixar backup',
      },
      500
    );
  }
});

/**
 * 4. POST /api/admin/backup/:id/restore
 * Restaura sistema a partir de backup
 */
backup.post('/:id/restore', async (c) => {
  try {
    const backupId = c.req.param('id');
    const body = await c.req.json();
    const { confirmar = false, restaurar_arquivos = false } = body;

    if (!confirmar) {
      return c.json(
        {
          success: false,
          error:
            'Confirmação necessária. Envie { confirmar: true } para prosseguir',
        },
        400
      );
    }

    const executadoPor = 'ADMIN';


    await restaurarBackup(backupId, c.env, restaurar_arquivos, executadoPor);

    return c.json({
      success: true,
      message: 'Restore concluído com sucesso',
      backup_id: backupId,
      restaurou_arquivos: restaurar_arquivos,
    });
  } catch (error) {
    console.error('Erro ao restaurar backup:', error);
    return c.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : 'Erro ao restaurar backup',
      },
      500
    );
  }
});

/**
 * 5. DELETE /api/admin/backup/:id
 * Remove backup específico
 */
backup.delete('/:id', async (c) => {
  try {
    const backupId = c.req.param('id');

    const backupInfo = await c.env.DB.prepare(
      'SELECT * FROM backups WHERE id = ?'
    )
      .bind(backupId)
      .first();

    if (!backupInfo) {
      return c.json(
        {
          success: false,
          error: 'Backup não encontrado',
        },
        404
      );
    }

    await c.env.BUCKET.delete(backupInfo.r2_path as string);

    await c.env.DB.prepare('DELETE FROM backups WHERE id = ?')
      .bind(backupId)
      .run();

    await c.env.DB.prepare(
      `INSERT INTO auditlogs (usuario, acao, modulo, detalhes, data)
       VALUES (?, ?, ?, ?, ?)`
    )
      .bind(
        'ADMIN',
        'DELETE_BACKUP',
        'Sistema',
        JSON.stringify({ backup_id: backupId }),
        new Date().toISOString()
      )
      .run();

    return c.json({
      success: true,
      message: 'Backup removido com sucesso',
      backup_id: backupId,
    });
  } catch (error) {
    console.error('Erro ao remover backup:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao remover backup',
      },
      500
    );
  }
});

/**
 * 6. GET /api/admin/backup/:id/verificar
 * Verifica integridade do backup
 */
backup.get('/:id/verificar', async (c) => {
  try {
    const backupId = c.req.param('id');

    const resultado = await verificarIntegridade(backupId, c.env);

    return c.json({
      success: true,
      backup_id: backupId,
      integro: resultado.integro,
      hash_esperado: resultado.hashEsperado,
      hash_atual: resultado.hashAtual,
      mensagem: resultado.integro
        ? 'Backup íntegro e válido'
        : 'ATENÇÃO: Backup corrompido!',
    });
  } catch (error) {
    console.error('Erro ao verificar backup:', error);
    return c.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : 'Erro ao verificar backup',
      },
      500
    );
  }
});

/**
 * 7. POST /api/admin/backup/agendar
 * Configura backup automático
 */
backup.post('/agendar', async (c) => {
  try {
    const body = await c.req.json();
    const {
      periodicidade = 'diario',
      hora = '03:00',
      retencao_dias = 30,
      ativo = true,
    } = body;

    if (!['diario', 'semanal'].includes(periodicidade)) {
      return c.json(
        {
          success: false,
          error: 'Periodicidade inválida. Use "diario" ou "semanal"',
        },
        400
      );
    }

    if (!/^\d{2}:\d{2}$/.test(hora)) {
      return c.json(
        {
          success: false,
          error: 'Formato de hora inválido. Use HH:MM (ex: 03:00)',
        },
        400
      );
    }

    await c.env.DB.prepare(
      `UPDATE backup_configuracoes 
       SET valor = ?, atualizado_em = ?, atualizado_por = ?
       WHERE chave = ?`
    )
      .bind(ativo ? 'true' : 'false', new Date().toISOString(), 'ADMIN', 'backup_automatico_ativo')
      .run();

    await c.env.DB.prepare(
      `UPDATE backup_configuracoes 
       SET valor = ?, atualizado_em = ?, atualizado_por = ?
       WHERE chave = ?`
    )
      .bind(hora, new Date().toISOString(), 'ADMIN', 'backup_hora_execucao')
      .run();

    await c.env.DB.prepare(
      `UPDATE backup_configuracoes 
       SET valor = ?, atualizado_em = ?, atualizado_por = ?
       WHERE chave = ?`
    )
      .bind(retencao_dias.toString(), new Date().toISOString(), 'ADMIN', 'backup_retencao_dias')
      .run();

    const [hh, mm] = hora.split(':').map(Number);
    const proximaExecucao = new Date();
    proximaExecucao.setHours(hh, mm, 0, 0);

    if (proximaExecucao <= new Date()) {
      proximaExecucao.setDate(proximaExecucao.getDate() + 1);
    }

    return c.json({
      success: true,
      agendamento: {
        ativo,
        periodicidade,
        hora,
        retencao_dias,
        proxima_execucao: proximaExecucao.toISOString(),
      },
    });
  } catch (error) {
    console.error('Erro ao agendar backup:', error);
    return c.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : 'Erro ao agendar backup',
      },
      500
    );
  }
});

/**
 * 8. GET /api/admin/backup/status
 * Retorna status atual do sistema backup
 */
backup.get('/status', async (c) => {
  try {
    const ultimoBackup = await c.env.DB.prepare(
      `SELECT id, data, tamanho, status, duracao_segundos, criado_em
       FROM backups 
       WHERE status = 'concluido'
       ORDER BY criado_em DESC 
       LIMIT 1`
    ).first();

    const configs = await c.env.DB.prepare(
      `SELECT chave, valor FROM backup_configuracoes 
       WHERE chave IN (
         'backup_automatico_ativo',
         'backup_hora_execucao',
         'backup_retencao_dias',
         'backup_total_realizados'
       )`
    ).all();

    const configMap: Record<string, string> = {};
    configs.results.forEach((c: any) => {
      configMap[c.chave] = c.valor;
    });

    const stats = await c.env.DB.prepare(
      `SELECT * FROM v_backup_estatisticas`
    ).first();

    const hora = configMap.backup_hora_execucao || '03:00';
    const [hh, mm] = hora.split(':').map(Number);
    const proximoAgendado = new Date();
    proximoAgendado.setHours(hh, mm, 0, 0);

    if (proximoAgendado <= new Date()) {
      proximoAgendado.setDate(proximoAgendado.getDate() + 1);
    }

    return c.json({
      success: true,
      status: {
        ultimo_backup: ultimoBackup
          ? {
              id: ultimoBackup.id,
              data: ultimoBackup.data,
              tamanho: ultimoBackup.tamanho,
              tamanho_mb:
                Math.round(
                  ((ultimoBackup.tamanho as number) / 1024 / 1024) * 100
                ) / 100,
              sucesso: ultimoBackup.status === 'concluido',
              duracao_segundos: ultimoBackup.duracao_segundos,
            }
          : null,
        proximo_agendado:
          configMap.backup_automatico_ativo === 'true'
            ? proximoAgendado.toISOString()
            : null,
        automatico_ativo: configMap.backup_automatico_ativo === 'true',
        hora_execucao: hora,
        retencao_dias: parseInt(configMap.backup_retencao_dias || '30'),
        total_backups: (stats?.total_backups as number) || 0,
        backups_concluidos: (stats?.backups_concluidos as number) || 0,
        backups_falhos: (stats?.backups_falhos as number) || 0,
        espaco_usado_mb: (stats?.tamanho_total_mb as number) || 0,
        total_realizados: parseInt(configMap.backup_total_realizados || '0'),
      },
    });
  } catch (error) {
    console.error('Erro ao buscar status:', error);
    return c.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Erro ao buscar status',
      },
      500
    );
  }
});

export default backup;
