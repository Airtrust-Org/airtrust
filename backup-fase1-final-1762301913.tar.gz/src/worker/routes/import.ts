
import { Hono } from 'hono';
import { Env } from '../types/index';

const importRouter = new Hono<{ Bindings: Env }>();

/**
 * POST /api/v2/import/funcionarios
 * Importar funcionários via CSV
 */
importRouter.post('/funcionarios', async (c) => {
  try {
    const body = await c.req.json();
    const { dados } = body;

    if (!dados || !Array.isArray(dados)) {
      return c.json({
        success: false,
        error: 'Dados inválidos. Envie um array de funcionários.'
      }, 400);
    }

    const db = c.env.DB;
    const sucessos: Array<{ linha: number; id: number }> = [];
    const erros: Array<{ linha: number; erro: string }> = [];

    for (let i = 0; i < dados.length; i++) {
      const linha = i + 2; // +2 porque linha 1 é header e array começa em 0
      const funcionario = dados[i];

      try {
        if (!funcionario.nome || funcionario.nome.trim() === '') {
          erros.push({ linha, erro: 'Nome é obrigatório' });
          continue;
        }

        if (!funcionario.cpf || funcionario.cpf.trim() === '') {
          erros.push({ linha, erro: 'CPF é obrigatório' });
          continue;
        }

        if (!funcionario.matricula || funcionario.matricula.trim() === '') {
          erros.push({ linha, erro: 'Matrícula é obrigatória' });
          continue;
        }

        const existente = await db.prepare(
          'SELECT id FROM funcionarios WHERE cpf = ? OR matricula = ? AND deleted_at IS NULL'
        ).bind(funcionario.cpf, funcionario.matricula).first();

        if (existente) {
          erros.push({ linha, erro: 'CPF ou matrícula já cadastrados' });
          continue;
        }

        const result = await db.prepare(`
          INSERT INTO funcionarios (
            nome, nome_guerra, cpf, matricula, email, telefone,
            funcao, aeronave, status, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `).bind(
          funcionario.nome.trim(),
          funcionario.nome_guerra?.trim() || null,
          funcionario.cpf.trim(),
          funcionario.matricula.trim(),
          funcionario.email?.trim() || null,
          funcionario.telefone?.trim() || null,
          funcionario.funcao?.trim() || 'Não especificado',
          funcionario.aeronave?.trim() || null,
          funcionario.status || 'ativo'
        ).run();

        if (result.meta.last_row_id) {
          sucessos.push({ linha, id: result.meta.last_row_id });
        }

      } catch (error) {
        console.error(`[IMPORT] Erro linha ${linha}:`, error);
        erros.push({ 
          linha, 
          erro: error instanceof Error ? error.message : 'Erro desconhecido' 
        });
      }
    }

    return c.json({
      success: true,
      importados: sucessos.length,
      erros: erros.length,
      total: dados.length,
      detalhes: {
        sucessos,
        erros
      }
    });

  } catch (error) {
    console.error('[IMPORT FUNCIONARIOS] Erro:', error);
    return c.json({
      success: false,
      error: 'Erro ao processar importação',
      details: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

/**
 * GET /api/v2/import/template/funcionarios
 * Download template CSV
 */
importRouter.get('/template/funcionarios', async (c) => {
  const csv = `nome,nome_guerra,cpf,matricula,email,telefone,funcao,aeronave,status
João Silva,João,12345678900,F001,joao@exemplo.com,11999999999,Piloto,A320,ativo
Maria Santos,Maria,98765432100,F002,maria@exemplo.com,11988888888,Copiloto,B737,ativo`;

  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="template_funcionarios.csv"'
    }
  });
});

export default importRouter;
