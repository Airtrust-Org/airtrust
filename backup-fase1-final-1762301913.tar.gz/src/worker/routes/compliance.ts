import { Hono } from 'hono';
import { Env } from '../types/index';

const compliance = new Hono<{ Bindings: Env }>();

/**
 * GET /api/v2/compliance - Endpoint principal (compatibilidade)
 */
compliance.get('/', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        cs.*,
        f.nome as funcionario_nome,
        f.matricula
      FROM compliance_status cs
      JOIN funcionarios f ON cs.funcionario_id = f.id
      WHERE f.deleted_at IS NULL
      ORDER BY cs.dias_para_vencimento ASC
      LIMIT 100
    `).bind().all();
    
    return c.json({
      success: true,
      data: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar compliance:', error);
    return c.json({
      success: true,
      data: []
    });
  }
});

/**
 * GET /api/v2/compliance/dashboard
 * Estatísticas gerais do dashboard
 */
compliance.get('/dashboard', async (c) => {
  try {
    const db = c.env.DB;
    
    const stats = await db.prepare(`
      SELECT 
        COUNT(DISTINCT f.id) as total_funcionarios,
        COUNT(DISTINCT q.id) as total_qualificacoes,
        SUM(CASE WHEN q.status = 'ATIVO' THEN 1 ELSE 0 END) as total_ativas,
        SUM(CASE WHEN date(q.data_vencimento) < date('now') THEN 1 ELSE 0 END) as total_vencidas
      FROM funcionarios f
      LEFT JOIN qualificacoes q ON f.id = q.funcionario_id AND q.deleted_at IS NULL
      WHERE f.deleted_at IS NULL
    `).bind().first();
    
    const porSetor = await db.prepare(`
      SELECT 
        f.setor,
        COUNT(DISTINCT f.id) as total,
        COUNT(DISTINCT cert.id) as total_cert,
        SUM(CASE WHEN cert.status_compliance = 'VALIDO' THEN 1 ELSE 0 END) as validas,
        ROUND(CAST(SUM(CASE WHEN cert.status_compliance = 'VALIDO' THEN 1 ELSE 0 END) AS FLOAT) / 
              NULLIF(COUNT(DISTINCT cert.id), 0) * 100, 2) as taxa_compliance
      FROM funcionarios f
      LEFT JOIN certificacoesv3 cert ON f.id = cert.funcionario_id
      WHERE f.deleted_at IS NULL
      GROUP BY f.setor
      ORDER BY f.setor
    `).all();
    
    return c.json({
      success: true,
      stats,
      por_setor: porSetor.results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar dashboard:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar dashboard de compliance'
    }, 500);
  }
});

/**
 * GET /api/v2/compliance/matriz
 * Matriz de compliance por funcionário
 */
compliance.get('/matriz', async (c) => {
  try {
    const db = c.env.DB;
    const { setor, funcao } = c.req.query();
    
    let whereClause = "WHERE f.deleted_at IS NULL";
    if (setor) whereClause += ` AND f.setor = '${setor}'`;
    if (funcao) whereClause += ` AND f.funcao_id = '${funcao}'`;
    
    const { results } = await db.prepare(`
      SELECT 
        f.id,
        f.nome,
        f.matricula,
        f.funcao_id,
        fn.nome as funcao_nome,
        f.setor,
        COUNT(DISTINCT cert.id) as total_cert,
        SUM(CASE WHEN cert.status_compliance = 'VALIDO' THEN 1 ELSE 0 END) as validas,
        SUM(CASE WHEN cert.status_compliance = 'VENCENDO' THEN 1 ELSE 0 END) as vencendo,
        SUM(CASE WHEN cert.status_compliance = 'VENCIDO' THEN 1 ELSE 0 END) as vencidas
      FROM funcionarios f
      LEFT JOIN funcoes fn ON f.funcao_id = fn.id
      LEFT JOIN certificacoesv3 cert ON f.id = cert.funcionario_id
      ${whereClause}
      GROUP BY f.id, f.nome, f.matricula, f.funcao_id, fn.nome, f.setor
      ORDER BY f.nome ASC
    `).all();

    return c.json({
      success: true,
      funcionarios: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar matriz:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar matriz de compliance'
    }, 500);
  }
});

/**
 * GET /api/v2/compliance/alertas
 * Alertas de vencimento (próximos 30 dias + vencidos)
 */
compliance.get('/alertas', async (c) => {
  try {
    const db = c.env.DB;
    
    const { results } = await db.prepare(`
      SELECT 
        f.id,
        f.nome,
        f.matricula,
        f.setor,
        cert.codigo_treinamento,
        cert.nome_treinamento,
        cert.data_vencimento,
        cert.status_compliance,
        julianday(cert.data_vencimento) - julianday('now') as dias_restantes
      FROM funcionarios f
      JOIN certificacoesv3 cert ON f.id = cert.funcionario_id
      WHERE f.deleted_at IS NULL
        AND cert.status_compliance IN ('VENCENDO', 'VENCIDO')
      ORDER BY cert.data_vencimento ASC
      LIMIT 50
    `).all();

    return c.json({
      success: true,
      alertas: results || []
    });
  } catch (error) {
    console.error('[API] Erro ao buscar alertas:', error);
    return c.json({
      success: false,
      error: 'Erro ao buscar alertas'
    }, 500);
  }
});

export default compliance;
