import { Hono } from 'hono';
import type { Env } from '../../types';

const app = new Hono<{ Bindings: Env }>();

// Funções auxiliares
function gerarNumeroCertificado(habilitacaoId: number): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `CERT-${habilitacaoId}-${timestamp}-${random}`;
}

async function calcularHash(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

interface DadosPDF {
  funcionario: string;
  matricula: string;
  qualificacao: string;
  codigo: string;
  data_inicio: string;
  data_conclusao: string;
  data_vencimento: string;
  numero_certificado: string;
  conteudo_programatico?: string;
}

async function gerarPDF(dados: DadosPDF): Promise<Buffer> {
  // Gerar PDF mínimo mas VÁLIDO
  const linhas = [
    'CERTIFICADO',
    '',
    `Certificamos que ${dados.funcionario} concluiu com aproveitamento`,
    `o treinamento em ${dados.qualificacao}.`,
    '',
    `Matrícula: ${dados.matricula}`,
    `Código: ${dados.codigo}`,
    `Certificado Nº: ${dados.numero_certificado}`,
    '',
    `Data de Conclusão: ${new Date(dados.data_conclusao).toLocaleDateString('pt-BR')}`,
    `Data de Validade: ${new Date(dados.data_vencimento).toLocaleDateString('pt-BR')}`,
    '',
    `Assinado digitalmente em ${new Date().toLocaleDateString('pt-BR')}`,
  ];

  // Construir stream de conteúdo com quebras de linha
  let streamContent = 'BT\n/F1 12 Tf\n50 750 Td\n';

  for (const linha of linhas) {
    const textoEscapado = linha.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
    streamContent += `(${textoEscapado}) Tj\n0 -20 Td\n`;
  }

  streamContent += 'ET';

  // Calcular tamanho do stream
  const streamBytes = Buffer.from(streamContent, 'utf-8');
  const streamLength = streamBytes.length;

  // Construir PDF com offsets corretos
  let pdf = '%PDF-1.4\n';
  const objects: string[] = [];

  // Objeto 1: Catalog
  objects[0] = '<< /Type /Catalog /Pages 2 0 R >>';

  // Objeto 2: Pages
  objects[1] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';

  // Objeto 3: Page
  objects[2] =
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >> >>';

  // Objeto 4: Stream
  objects[3] = `<< /Length ${streamLength} >>\nstream\n${streamContent}\nendstream`;

  // Calcular offsets
  const offsets: number[] = [];
  let currentOffset = pdf.length;

  for (let i = 0; i < objects.length; i++) {
    offsets[i] = currentOffset;
    const objStr = `${i + 1} 0 obj\n${objects[i]}\nendobj\n`;
    pdf += objStr;
    currentOffset += objStr.length;
  }

  // Xref table
  const xrefOffset = currentOffset;
  pdf += 'xref\n';
  pdf += `0 ${objects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';

  for (let i = 0; i < objects.length; i++) {
    pdf += `${offsets[i].toString().padStart(10, '0')} 00000 n \n`;
  }

  // Trailer
  pdf += 'trailer\n';
  pdf += `<< /Size ${objects.length + 1} /Root 1 0 R >>\n`;
  pdf += 'startxref\n';
  pdf += `${xrefOffset}\n`;
  pdf += '%%EOF';

  return Buffer.from(pdf, 'utf-8');
}

// GET: Listar certificados de uma qualificação
app.get('/qualificacao/:id', async (c) => {
  try {
    const db = c.env.DB as any;
    const qualificacaoId = c.req.param('id');

    const certs = await db
      .prepare(
        `
        SELECT 
          id, arquivo_nome, arquivo_url, tipo,
          data_emissao, created_at
        FROM certificados
        WHERE qualificacao_id = ? AND deleted_at IS NULL
        ORDER BY created_at DESC
      `,
      )
      .bind(qualificacaoId)
      .all();

    return c.json({ success: true, data: certs.results || [] });
  } catch (error) {
    console.error('Erro ao listar:', error);
    return c.json({ success: false, error: 'Erro ao listar certificados' }, 500);
  }
});

// GET: Listar certificados de uma habilitação
app.get('/habilitacao/:id', async (c) => {
  try {
    const db = c.env.DB as any;
    const habilitacaoId = c.req.param('id'); // Aceita UUID string

    const certs = await db
      .prepare(
        `
        SELECT 
          id, arquivo_nome, arquivo_url, tipo,
          data_emissao, created_at
        FROM certificados
        WHERE habilitacao_id = ? AND deleted_at IS NULL
        ORDER BY created_at DESC
      `,
      )
      .bind(habilitacaoId)
      .all();

    return c.json({ success: true, data: certs.results || [] });
  } catch (error) {
    console.error('Erro ao listar:', error);
    return c.json({ success: false, error: 'Erro ao listar certificados' }, 500);
  }
});

// POST: Upload de arquivo (versão robusta)
app.post('/upload', async (c) => {
  try {
    const db = c.env.DB as any;
    const r2 = c.env.AIRTRUST_STORAGE as any;

    // Receber FormData usando c.req.raw.formData() diretamente
    let formData: FormData;
    try {
      formData = await c.req.raw.formData();
    } catch (formError) {
      console.error('[UPLOAD] FormData parse error:', formError);
      return c.json(
        {
          success: false,
          error: 'Erro ao processar arquivo',
          details: 'Content-Type deve ser multipart/form-data',
        },
        400,
      );
    }

    const habilitacaoId = formData.get('habilitacao_id') as string; // Aceita UUID string
    const funcionarioId = Number(formData.get('funcionario_id'));
    const qualificacaoId = Number(formData.get('qualificacao_id'));
    const arquivo = formData.get('arquivo') as File;

    if (!arquivo || !habilitacaoId || !funcionarioId || !qualificacaoId) {
      return c.json(
        {
          success: false,
          error: 'Dados obrigatórios faltando',
          required: ['arquivo', 'habilitacao_id', 'funcionario_id', 'qualificacao_id'],
          received: {
            arquivo: arquivo ? 'ok' : 'faltando',
            habilitacao_id: habilitacaoId || 'faltando',
            funcionario_id: funcionarioId || 'faltando',
            qualificacao_id: qualificacaoId || 'faltando',
          },
        },
        400,
      );
    }

    // Buscar habilitação com joins corretos
    const hab = await db
      .prepare(
        `
        SELECT 
          h.id,
          h.funcionario_id,
          h.qualificacao_id,
          f.nome as funcionario_nome,
          f.matricula,
          q.nome as qualificacao_nome,
          q.codigo as qualificacao_codigo,
          q.conteudo_programatico
        FROM habilitacoes h
        LEFT JOIN funcionarios f ON h.funcionario_id = f.id
        LEFT JOIN qualificacoes q ON h.qualificacao_id = q.id
        WHERE h.id = ? AND h.deleted_at IS NULL
      `,
      )
      .bind(habilitacaoId)
      .first();

    if (!hab) {
      return c.json({ success: false, error: 'Habilitação não encontrada' }, 404);
    }

    // Processar arquivo
    const arrayBuffer = await arquivo.arrayBuffer();
    const tamanho = arrayBuffer.byteLength;
    const hash = await calcularHash(arrayBuffer);

    // Normalizar nome (underline dentro de nomes, traço entre elementos)
    const normalizarParte = (str: string) =>
      str
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, '_')
        .replace(/[^a-z0-9_]/g, '')
        .replace(/_+/g, '_')
        .replace(/^_|_$/g, '');

    const nomeNormalizado = normalizarParte(hab.funcionario_nome || 'funcionario');
    const qualificacaoNorm = normalizarParte(hab.qualificacao_nome || 'qualificacao');
    const dataNorm = arquivo.lastModified
      ? new Date(arquivo.lastModified).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0];
    const nomeArquivo = `${nomeNormalizado}-${qualificacaoNorm}-${dataNorm}.pdf`;

    // Enviar para R2 - organizado por funcionário (BUG-002: parseInt para evitar float)
    const funcionarioIdInt = parseInt(String(funcionarioId), 10);
    const caminhoR2 = `certificados/${funcionarioIdInt}/${nomeArquivo}`;
    await r2.put(caminhoR2, arrayBuffer, {
      httpMetadata: {
        contentType: 'application/pdf',
        contentDisposition: `attachment; filename="${nomeArquivo}"`,
      },
    });

    // Registrar no banco
    const resultado = await db
      .prepare(
        `
        INSERT INTO certificados (
          habilitacao_id, funcionario_id, qualificacao_id,
          arquivo_url, arquivo_nome,
          arquivo_tamanho, arquivo_hash, numero_certificado, tipo, data_emissao,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `,
      )
      .bind(
        habilitacaoId,
        hab.funcionario_id,
        hab.qualificacao_id,
        caminhoR2,
        nomeArquivo,
        tamanho,
        hash,
        `CERT-${habilitacaoId}-${Date.now()}`,
        'upload',
        new Date().toISOString().split('T')[0],
      )
      .run();

    return c.json({
      success: true,
      message: 'Certificado enviado com sucesso',
      data: { id: resultado.meta.last_row_id },
    });
  } catch (error) {
    console.error('Upload error:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao fazer upload',
        details: error instanceof Error ? error.message : 'Desconhecido',
      },
      500,
    );
  }
});

// POST: Gerar certificado
app.post('/:habilitacao_id/gerar', async (c) => {
  try {
    const db = c.env.DB as any;
    const r2 = c.env.AIRTRUST_STORAGE as any;
    const habilitacaoId = c.req.param('habilitacao_id'); // Aceita UUID string

    // Body para extrair funcionario_id
    const body = (await c.req.json().catch(() => ({}))) as any;
    const funcionarioId = body.funcionario_id;

    if (!funcionarioId) {
      return c.json({ success: false, error: 'funcionario_id obrigatório' }, 400);
    }

    // Buscar dados com joins corretos
    const hab = await db
      .prepare(
        `
        SELECT 
          h.id,
          h.funcionario_id,
          h.qualificacao_id,
          h.empresa_id,
          h.data_conclusao,
          h.data_vencimento,
          f.nome as funcionario_nome,
          f.matricula,
          q.nome as qualificacao_nome,
          q.codigo as qualificacao_codigo,
          q.conteudo_programatico
        FROM habilitacoes h
        LEFT JOIN funcionarios f ON h.funcionario_id = f.id
        LEFT JOIN qualificacoes q ON h.qualificacao_id = q.id
        WHERE h.id = ? AND h.funcionario_id = ? AND h.deleted_at IS NULL
      `,
      )
      .bind(habilitacaoId, funcionarioId)
      .first();

    if (!hab) {
      return c.json(
        { success: false, error: 'Habilitação, qualificação ou funcionário não encontrado' },
        404,
      );
    }

    // Buscar logo da empresa
    const empresaConfig = await db
      .prepare('SELECT logo_r2_url FROM empresa_certificado_config WHERE empresa_id = ?')
      .bind(hab.empresa_id || 1)
      .first();

    // Gerar PDF
    const pdfBuffer = await gerarPDF({
      funcionario: hab.funcionario_nome || 'Não informado',
      matricula: hab.matricula || 'N/A',
      qualificacao: hab.qualificacao_nome || 'Qualificação',
      codigo: hab.qualificacao_codigo || 'CERT',
      data_inicio: hab.data_conclusao || new Date().toISOString(), // Usar data_conclusao como início
      data_conclusao: hab.data_conclusao || new Date().toISOString(),
      data_vencimento: hab.data_vencimento || new Date().toISOString(),
      numero_certificado: gerarNumeroCertificado(habilitacaoId),
      conteudo_programatico: hab.conteudo_programatico,
    });

    // Processar PDF
    const tamanho = pdfBuffer.length;
    const hash = await calcularHash(pdfBuffer.buffer);

    // Normalizar nome (underline dentro de nomes, traço entre elementos)
    const normalizarParte = (str: string) =>
      str
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, '_')
        .replace(/[^a-z0-9_]/g, '')
        .replace(/_+/g, '_')
        .replace(/^_|_$/g, '');

    const nomeNormalizado = normalizarParte(hab.funcionario_nome || 'certificado');
    const qualificacaoNorm = normalizarParte(hab.qualificacao_nome || 'qualificacao');
    const dataNorm = hab.data_conclusao
      ? hab.data_conclusao.split('T')[0]
      : new Date().toISOString().split('T')[0];
    const nomeArquivo = `${nomeNormalizado}-${qualificacaoNorm}-${dataNorm}.pdf`;

    // Enviar para R2 - organizado por funcionário (BUG-002: parseInt para evitar float)
    const funcionarioIdInt = parseInt(String(hab.funcionario_id), 10);
    const caminhoR2 = `certificados/${funcionarioIdInt}/${nomeArquivo}`;
    await r2.put(caminhoR2, pdfBuffer, {
      httpMetadata: {
        contentType: 'application/pdf',
        contentDisposition: `attachment; filename="${nomeArquivo}"`,
      },
    });

    // Registrar no banco
    const resultado = await db
      .prepare(
        `
        INSERT INTO certificados (
          habilitacao_id, funcionario_id, qualificacao_id,
          arquivo_url, arquivo_nome,
          arquivo_tamanho, arquivo_hash, numero_certificado, tipo, data_emissao,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `,
      )
      .bind(
        habilitacaoId,
        hab.funcionario_id,
        hab.qualificacao_id,
        caminhoR2,
        nomeArquivo,
        tamanho,
        hash,
        `CERT-${habilitacaoId}-${Date.now()}`,
        'gerado',
        hab.data_conclusao || new Date().toISOString().split('T')[0],
      )
      .run();

    return c.json({
      success: true,
      message: 'Certificado gerado com sucesso',
      data: { id: resultado.meta.last_row_id },
    });
  } catch (error) {
    console.error('Generate error:', error);
    return c.json(
      {
        success: false,
        error: 'Erro ao gerar certificado',
        details: error instanceof Error ? error.message : 'Desconhecido',
      },
      500,
    );
  }
});

// DELETE: Deletar certificado
app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB as any;
    const certId = Number(c.req.param('id'));

    const cert = await db
      .prepare('SELECT * FROM certificados WHERE id = ? AND deleted_at IS NULL')
      .bind(certId)
      .first();

    if (!cert) {
      return c.json({ success: false, error: 'Certificado não encontrado' }, 404);
    }

    // Soft delete
    await db
      .prepare('UPDATE certificados SET deleted_at = datetime("now") WHERE id = ?')
      .bind(certId)
      .run();

    return c.json({ success: true, message: 'Certificado deletado com sucesso' });
  } catch (error: any) {
    console.error('DELETE error:', error);
    return c.json({ success: false, error: error.message }, 500);
  }
});

// GET: Download
app.get('/download/:id', async (c) => {
  try {
    const db = c.env.DB as any;
    const r2 = c.env.AIRTRUST_STORAGE as any;
    const certId = Number(c.req.param('id'));

    const cert = await db
      .prepare('SELECT * FROM certificados WHERE id = ? AND deleted_at IS NULL')
      .bind(certId)
      .first();

    if (!cert) {
      return c.json({ success: false, error: 'Certificado não encontrado' }, 404);
    }

    const arquivo = await r2.get(cert.arquivo_url);
    if (!arquivo) {
      return c.json({ success: false, error: 'Arquivo não disponível' }, 404);
    }

    const buffer = await arquivo.arrayBuffer();

    return new Response(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${cert.arquivo_nome}"`,
        'Content-Length': buffer.byteLength.toString(),
        'Cache-Control': 'no-cache, no-store, must-revalidate',
      },
    });
  } catch (error) {
    console.error('Download error:', error);
    return c.json({ success: false, error: 'Erro ao fazer download' }, 500);
  }
});

// DELETE: Revogar (soft delete)
app.delete('/:id', async (c) => {
  try {
    const db = c.env.DB as any;
    const certId = Number(c.req.param('id'));

    await db
      .prepare("UPDATE certificados SET deleted_at = datetime('now') WHERE id = ?")
      .bind(certId)
      .run();

    return c.json({ success: true, message: 'Certificado revogado' });
  } catch (error) {
    return c.json({ success: false, error: 'Erro ao revogar' }, 500);
  }
});

export default app;
