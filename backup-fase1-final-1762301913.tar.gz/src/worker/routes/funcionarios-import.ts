/**
 * Rota de Importação de Funcionários via Excel
 * Cloudflare Workers + Hono + D1 + Zod + SheetJS
 */

import { Hono } from 'hono';
import * as XLSX from 'xlsx';
import { z } from 'zod';
import type { Env } from '../types/index';

const app = new Hono<{ Bindings: Env }>();

const FuncionarioSchema = z.object({
  nome: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres'),
  matricula: z.union([z.string(), z.number()]).transform(v => String(v || 'XXXXX')).optional(),
  cpf: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  codigo_anac: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  funcao: z.string().optional(),
  base: z.string().nullable().optional(),
  contrato: z.string().optional(),
  telefone: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  email: z.string().optional(),
  status: z.string().optional(),
  guerra: z.string().optional(),
  data_nascimento: z.union([z.date(), z.string(), z.null()]).transform(v => v ? String(v) : null).optional(),
  licenca_aeronautica: z.string().optional(),
  codigo_canac: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  codigo_sispat: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  codigo_prestserv: z.union([z.string(), z.number(), z.null()]).transform(v => v ? String(v) : null).optional(),
  data_admissao: z.union([z.date(), z.string(), z.null()]).transform(v => v ? String(v) : null).optional(),
  anv: z.string().optional(),
  cma_numero: z.string().optional(),
  cma_data_vencimento: z.union([z.date(), z.string(), z.null()]).transform(v => v ? String(v) : null).optional(),
  cma_status: z.string().optional(),
  aso_data_vencimento: z.union([z.date(), z.string(), z.null()]).transform(v => v ? String(v) : null).optional(),
  nivel_icao: z.string().optional(),
  nivel_icao_data_vencimento: z.union([z.date(), z.string(), z.null()]).transform(v => v ? String(v) : null).optional(),
  nivel_icao_status: z.string().optional(),
  is_instrutor: z.union([z.number(), z.boolean(), z.string(), z.null()]).transform(v => v ? 1 : 0).optional(),
  is_checador: z.union([z.number(), z.boolean(), z.string(), z.null()]).transform(v => v ? 1 : 0).optional(),
  aeronave_principal: z.string().optional(),
  setor: z.string().optional()
});

type FuncionarioRow = z.infer<typeof FuncionarioSchema>;

/**
 * POST /api/v2/funcionarios/import
 * Importar funcionários via arquivo Excel (multipart/form-data)
 */
app.post('/import', async (c) => {
  try {
    const contentType = c.req.header('content-type') || '';
    
    if (!contentType.includes('multipart/form-data')) {
      return c.json({ 
        erro: 'Content-Type deve ser multipart/form-data' 
      }, 415);
    }

    const form = await c.req.parseBody();
    const file = form['file'] as File;

    if (!file) {
      return c.json({ erro: 'Arquivo não enviado' }, 400);
    }

    const fileName = file.name.toLowerCase();
    if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
      return c.json({ 
        erro: 'Formato não suportado. Use .xlsx ou .xls' 
      }, 415);
    }

    const MAX_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      return c.json({ 
        erro: 'Arquivo muito grande. Máximo: 5 MB' 
      }, 413);
    }


    const arrayBuffer = await file.arrayBuffer();
    const buf = new Uint8Array(arrayBuffer);

    const wb = XLSX.read(buf, { type: 'array' });
    
    if (wb.SheetNames.length === 0) {
      return c.json({ erro: 'Arquivo Excel sem planilhas' }, 400);
    }

    const ws = wb.Sheets[wb.SheetNames[0]];
    
    const rows = XLSX.utils.sheet_to_json(ws, { defval: null }) as any[];

    if (rows.length === 0) {
      return c.json({ erro: 'Arquivo vazio ou sem dados' }, 400);
    }


    const validRows: FuncionarioRow[] = [];
    const errors: Array<{ linha: number; erro: string }> = [];

    for (let i = 0; i < rows.length; i++) {
      const linha = i + 2; // +2 porque linha 1 é header
      try {
        if (!rows[i].matricula) {
          rows[i].matricula = 'XXXXX';
        }
        
        const validated = FuncionarioSchema.parse(rows[i]);
        validRows.push(validated);
      } catch (err) {
        if (err instanceof z.ZodError) {
          const msgs = err.errors.map(e => `${e.path.join('.')}: ${e.message}`).join('; ');
          errors.push({ linha, erro: msgs });
        } else {
          errors.push({ linha, erro: String(err) });
        }
      }
    }


    const db = c.env.DB;
    let inseridos = 0;
    let atualizados = 0;

    for (const row of validRows) {
      try {
        const existing = await db.prepare(
          'SELECT id FROM funcionarios WHERE matricula = ? AND deleted_at IS NULL'
        ).bind(row.matricula).first();

        if (existing) {
          await db.prepare(`
            UPDATE funcionarios 
            SET nome = ?, cpf = ?, email = ?, funcao = ?, base = ?, updated_at = datetime('now')
            WHERE matricula = ? AND deleted_at IS NULL
          `).bind(
            row.nome,
            row.cpf,
            row.email || null,
            row.funcao,
            row.setor,
            row.matricula
          ).run();
          atualizados++;
        } else {
          await db.prepare(`
            INSERT INTO funcionarios (
              matricula, nome, cpf, email, funcao, base, status,
              created_at, updated_at, deleted_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'ATIVO', datetime('now'), datetime('now'), NULL)
          `).bind(
            row.matricula,
            row.nome,
            row.cpf,
            row.email || null,
            row.funcao,
            row.setor
          ).run();
          inseridos++;
        }
      } catch (dbErr) {
        console.error('[IMPORT] Erro ao inserir/atualizar:', dbErr);
        errors.push({ 
          linha: validRows.indexOf(row) + 2, 
          erro: dbErr instanceof Error ? dbErr.message : 'Erro no banco de dados' 
        });
      }
    }

    const userId = 'SYSTEM'; // TODO: Obter do contexto de autenticação
    const ipOrigem = c.req.header('cf-connecting-ip') || 'unknown';
    const userAgent = c.req.header('user-agent') || 'unknown';
    
    try {
      await db.prepare(`
        INSERT INTO auditoria_avancada_v2 (
          tabela, acao, registro_id, usuario_id, dados_anteriores,
          ip_address, user_agent, timestamp
        ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(
        'funcionarios',
        'IMPORT',
        null,
        userId,
        JSON.stringify({ 
          arquivo: file.name, 
          total: validRows.length + errors.length, 
          inseridos, 
          atualizados, 
          erros: errors.length 
        }),
        ipOrigem,
        userAgent
      ).run();
    } catch (auditErr) {
      console.error('[IMPORT] Erro ao registrar auditoria:', auditErr);
    }


    return c.json({
      inseridos,
      atualizados,
      errors: errors,
      preview: validRows.slice(0, 10),
      total: validRows.length + errors.length
    });

  } catch (error) {
    console.error('[IMPORT] Erro geral:', error);
    return c.json({ 
      erro: error instanceof Error ? error.message : 'Erro ao processar arquivo',
      detalhes: error instanceof Error ? error.stack : undefined
    }, 500);
  }
});

export default app;
