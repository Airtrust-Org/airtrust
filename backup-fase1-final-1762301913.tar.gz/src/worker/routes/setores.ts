import { Hono } from 'hono';

const app = new Hono<{ Bindings: Env }>();

app.get('/', async (c) => {
  try {
    const result = await c.env.DB.prepare(`SELECT * FROM setores WHERE deleted_at IS NULL ORDER BY id DESC`).all();
    return c.json({ success: true, data: result.results || [] });
  } catch (error: any) {
    console.error('[SETORES] Erro:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.get('/list', async (c) => {
  try {
    const result = await c.env.DB.prepare(`SELECT * FROM setores WHERE deleted_at IS NULL ORDER BY id DESC`).all();
    return c.json({ success: true, data: result.results || [] });
  } catch (error: any) {
    console.error('[SETORES] Erro:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.post('/', async (c) => {
  try {
    const body = await c.req.json();
    const codigo = `SET${Date.now()}`;
    await c.env.DB.prepare(`INSERT INTO setores (codigo, nome, ativo) VALUES (?, ?, 1)`).bind(codigo, body.nome || 'Sem nome').run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[SETORES] Erro POST:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.put('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();
    await c.env.DB.prepare(`UPDATE setores SET nome = ?, descricao = ?, updated_at = datetime('now') WHERE id = ?`).bind(body.nome, body.descricao || null, id).run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[SETORES] Erro PUT:', error);
    return c.json({ error: String(error) }, 500);
  }
});

app.delete('/:id', async (c) => {
  try {
    const id = c.req.param('id');
    await c.env.DB.prepare(`UPDATE setores SET deleted_at = datetime('now') WHERE id = ?`).bind(id).run();
    return c.json({ success: true });
  } catch (error: any) {
    console.error('[SETORES] Erro DELETE:', error);
    return c.json({ error: String(error) }, 500);
  }
});

export default app;
