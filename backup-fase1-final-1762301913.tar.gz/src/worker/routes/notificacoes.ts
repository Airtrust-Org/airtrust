import { Hono } from 'hono';
import { Env } from '../types/index';
import { authMiddleware } from '../middleware/auth';

const notificacoes = new Hono<{ Bindings: Env }>();

notificacoes.use('*', authMiddleware);

/**
 * GET /notificacoes/qualificacoes-vencendo
 * Lista qualificações que estão vencendo
 */
notificacoes.get('/qualificacoes-vencendo', async (c) => {
  try {
    const db = c.env.DB;
    const dias = parseInt(c.req.query('dias') || '30');
    
    const result = await db.prepare(`
      SELECT 
        q.*,
        f.nome as funcionario_nome,
        f.email as funcionario_email,
        CAST((julianday(q.data_vencimento) - julianday('now')) AS INTEGER) as dias_restantes
      FROM qualificacoes q
      INNER JOIN funcionarios f ON q.funcionario_id = f.id
      WHERE q.deleted_at IS NULL
        AND f.deleted_at IS NULL
        AND q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+' || ? || ' days')
      ORDER BY dias_restantes ASC
    `).bind(dias).all();
    
    return c.json({
      success: true,
      notificacoes: result.results || [],
      total: result.results?.length || 0
    });
  } catch (error) {
    console.error('[NOTIFICACOES] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      notificacoes: [],
      total: 0
    }, 500);
  }
});

/**
 * POST /notificacoes/enviar-alertas
 * Envia alertas por email (preparado para Resend)
 */
notificacoes.post('/enviar-alertas', async (c) => {
  try {
    const db = c.env.DB;
    
    const result = await db.prepare(`
      SELECT 
        q.*,
        f.nome as funcionario_nome,
        f.email as funcionario_email,
        CAST((julianday(q.data_vencimento) - julianday('now')) AS INTEGER) as dias_restantes
      FROM qualificacoes q
      INNER JOIN funcionarios f ON q.funcionario_id = f.id
      WHERE q.deleted_at IS NULL
        AND f.deleted_at IS NULL
        AND q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days')
    `).all();
    
    const alertas = result.results || [];
    let enviados = 0;
    
    for (const alerta of alertas) {
      
      
      enviados++;
    }
    
    await db.prepare(`
      INSERT INTO auditlogs (usuario_id, acao, tabela, descricao)
      VALUES (?, ?, ?, ?)
    `).bind(
      0, // Sistema
      'ENVIO_ALERTAS',
      'qualificacoes',
      `Alertas enviados: ${enviados} notificações`
    ).run();
    
    return c.json({
      success: true,
      message: `${enviados} alertas processados (logs gerados)`,
      alertas_enviados: enviados,
      detalhes: alertas.map((a: any) => ({
        funcionario: a.funcionario_nome,
        categoria: a.categoria,
        dias_restantes: a.dias_restantes
      }))
    });
  } catch (error) {
    console.error('[NOTIFICACOES ENVIAR] Erro:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro ao enviar alertas'
    }, 500);
  }
});

/**
 * GET /notificacoes/resumo
 * Resumo de notificações pendentes
 */
notificacoes.get('/resumo', async (c) => {
  try {
    const db = c.env.DB;
    
    const [vencendo7, vencendo30, vencidas] = await Promise.all([
      db.prepare(`
        SELECT COUNT(*) as total
        FROM qualificacoes q
        WHERE q.deleted_at IS NULL
          AND q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+7 days')
      `).first(),
      
      db.prepare(`
        SELECT COUNT(*) as total
        FROM qualificacoes q
        WHERE q.deleted_at IS NULL
          AND q.data_vencimento BETWEEN DATE('now') AND DATE('now', '+30 days')
      `).first(),
      
      db.prepare(`
        SELECT COUNT(*) as total
        FROM qualificacoes q
        WHERE q.deleted_at IS NULL
          AND q.data_vencimento < DATE('now')
      `).first()
    ]);
    
    return c.json({
      success: true,
      resumo: {
        vencendo_7_dias: (vencendo7 as any)?.total || 0,
        vencendo_30_dias: (vencendo30 as any)?.total || 0,
        vencidas: (vencidas as any)?.total || 0
      }
    });
  } catch (error) {
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, 500);
  }
});

export default notificacoes;
