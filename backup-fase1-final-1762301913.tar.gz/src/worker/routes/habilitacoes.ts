import { Hono } from 'hono';
import { ZodError } from 'zod';
import { HabilitacoesService } from '../services/habilitacoesService';
import type { Env } from '../types/index';

export function habilitacoesRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  /**
   * GET /api/v2/habilitacoes
   * Lista com paginação e filtros
   */
  router.get('/', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);

      // Validação de query params
      const pageRaw = c.req.query('page') || '1';
      const limitRaw = c.req.query('limit') || '20';
      const page = Math.max(1, parseInt(pageRaw, 10) || 1);
      const limit = Math.max(1, parseInt(limitRaw, 10) || 20);
      const funcionario_id = c.req.query('funcionario_id');
      const qualificacao_id = c.req.query('qualificacao_id');
      const status = c.req.query('status');
      const search = c.req.query('search');

      const result = await service.listar({
        page,
        limit,
        funcionario_id: funcionario_id ? parseInt(funcionario_id) : undefined,
        qualificacao_id: qualificacao_id || undefined, // Não fazer parseInt - aceita UUID string
        status,
        search,
      });

      return c.json({
        success: true,
        data: result.data,
        pagination: result.pagination,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /habilitacoes:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao listar habilitações',
          details: err instanceof Error ? err.message : 'Unknown error',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/habilitacoes/stats
   * Estatísticas para dashboard
   */
  router.get('/stats', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);
      const stats = await service.obterEstatisticas();

      return c.json({
        success: true,
        data: stats,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /habilitacoes/stats:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao obter estatísticas',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/habilitacoes/qualificacoes
   * Dropdown de qualificações
   */
  router.get('/qualificacoes', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);
      const qualificacoes = await service.obterQualificacoesDisponiveis();

      return c.json({
        success: true,
        data: qualificacoes,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /habilitacoes/qualificacoes:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao obter qualificações',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/habilitacoes/funcionarios
   * Dropdown de funcionários
   */
  router.get('/funcionarios', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);
      const funcionarios = await service.obterFuncionariosComHabilitacoes();

      return c.json({
        success: true,
        data: funcionarios,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /habilitacoes/funcionarios:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao obter funcionários',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/habilitacoes/:id
   * Obter habilitação completa por ID
   */
  router.get('/:id', async (c) => {
    try {
      const db = c.env.DB as any;
      const id = c.req.param('id');

      const hab = await db
        .prepare(
          `
        SELECT 
          h.id, h.funcionario_id, h.qualificacao_id,
          h.data_conclusao, h.data_vencimento, h.status, h.resultado,
          f.nome as funcionario_nome, f.matricula,
          q.nome as qualificacao_nome, q.codigo as qualificacao_codigo,
          q.categoria, q.validade_meses
        FROM habilitacoes h
        LEFT JOIN funcionarios f ON h.funcionario_id = f.id
        LEFT JOIN qualificacoes q ON h.qualificacao_id = q.id
        WHERE h.id = ? AND h.deleted_at IS NULL
      `,
        )
        .bind(id)
        .first();

      if (!hab) {
        return c.json(
          {
            success: false,
            error: 'Habilitação não encontrada',
          },
          404,
        );
      }

      return c.json({
        success: true,
        data: hab,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /habilitacoes/:id:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao obter habilitação',
          details: err instanceof Error ? err.message : 'Unknown error',
        },
        500,
      );
    }
  });

  /**
   * GET /api/v2/habilitacoes/:funcionarioId/:qualificacaoId/renovacoes
   * Histórico de renovações
   */
  router.get('/:funcionarioId/:qualificacaoId/renovacoes', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);
      const funcionarioId = parseInt(c.req.param('funcionarioId'));
      const qualificacaoId = parseInt(c.req.param('qualificacaoId'));

      if (isNaN(funcionarioId) || isNaN(qualificacaoId)) {
        return c.json(
          {
            success: false,
            error: 'IDs inválidos',
          },
          400,
        );
      }

      const historico = await service.obterHistoricoRenovacoes(funcionarioId, qualificacaoId);

      return c.json({
        success: true,
        data: historico,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ GET /renovacoes:', err);
      return c.json(
        {
          success: false,
          error: 'Erro ao obter histórico',
        },
        500,
      );
    }
  });

  /**
   * POST /api/v2/habilitacoes
   * Criar nova habilitação
   *
   * Lógica:
   * - Backend calcula data_vencimento a partir de data_conclusao + validade_meses
   * - Detecta e armazena timezone do usuário
   * - Detecta renovação automática (marca anterior como renovada)
   */
  router.post('/', async (c) => {
    try {
      const service = new HabilitacoesService(c.env.DB);
      const body = await c.req.json();

      // Validar campos obrigatórios MÍNIMOS
      if (!body.funcionario_id || !body.qualificacao_id || !body.data_conclusao) {
        return c.json(
          {
            success: false,
            error: 'Campos obrigatórios: funcionario_id, qualificacao_id, data_conclusao',
          },
          400,
        );
      }

      // Extrair timezone do frontend (enviado no body)
      const userTimezone = body.timezone;

      const userId = 1; // TODO: Extrair do JWT
      const result = await service.criar(body, userId, userTimezone);

      return c.json(
        {
          success: true,
          data: result,
          timestamp: new Date().toISOString(),
        },
        201,
      );
    } catch (err) {
      console.error('❌ POST /habilitacoes:', err);
      // Diferenciar entre erro de validação e erro de servidor
      const isValidationError =
        err instanceof Error &&
        (err.message.includes('validation') ||
          err.message.includes('Zod') ||
          err.message.includes('obrigatório'));

      return c.json(
        {
          success: false,
          error: err instanceof Error ? err.message : 'Erro ao criar habilitação',
          code: isValidationError ? 'VALIDATION_ERROR' : 'CREATE_ERROR',
        },
        isValidationError ? 400 : 500,
      );
    }
  });

  /**
   * PUT /api/v2/habilitacoes/:id
   * Atualizar habilitação
   */
  router.put('/:id', async (c) => {
    try {
      const id = c.req.param('id');
      if (!id || typeof id !== 'string' || id.trim().length === 0) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new HabilitacoesService(c.env.DB);
      const body = await c.req.json();
      const userId = 1; // TODO: Extrair do JWT

      const result = await service.atualizar(id, body, userId);
      if (!result) {
        return c.json({ success: false, error: 'Habilitação não encontrada' }, 404);
      }

      return c.json({
        success: true,
        data: result,
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ PUT /habilitacoes/:id:', err);
      return c.json(
        {
          success: false,
          error: err instanceof Error ? err.message : 'Erro ao atualizar',
          code: 'UPDATE_ERROR',
        },
        500,
      );
    }
  });

  /**
   * DELETE /api/v2/habilitacoes/:id
   * Deletar (soft delete) habilitação
   */
  router.delete('/:id', async (c) => {
    try {
      const id = c.req.param('id');
      if (!id || typeof id !== 'string' || id.trim().length === 0) {
        return c.json({ success: false, error: 'ID inválido' }, 400);
      }

      const service = new HabilitacoesService(c.env.DB);
      const userId = 1; // TODO: Extrair do JWT

      const result = await service.deletar(id, userId);
      if (!result) {
        return c.json({ success: false, error: 'Habilitação não encontrada' }, 404);
      }

      return c.json({
        success: true,
        data: { id, deletado: true },
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('❌ DELETE /habilitacoes/:id:', err);
      return c.json(
        {
          success: false,
          error: err instanceof Error ? err.message : 'Erro ao deletar',
          code: 'DELETE_ERROR',
        },
        500,
      );
    }
  });

  return router;
}
