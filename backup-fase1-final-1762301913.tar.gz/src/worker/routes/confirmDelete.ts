/**
 * src/worker/routes/confirmDelete.ts
 * Rota para delete com confirmação via token
 */

import { Hono } from 'hono';
import crypto from 'crypto';
import { z } from 'zod';
import type { D1Database } from '../types';
import { AuditLogger } from '../utils/auditLogger';
import { getAuditContext } from '../middleware/auditMiddleware';

const DeleteRequestSchema = z.object({
  tabela: z.enum(['habilitacoes', 'funcionarios', 'qualificacoes', 'agendamentos']),
  registro_id: z.number().int().positive(),
});

export function createConfirmDeleteRouter(db: D1Database) {
  const router = new Hono();
  const auditLogger = new AuditLogger(db);

  /**
   * POST /api/v2/delete-request
   * Gerar token de confirmação para delete
   */
  router.post('/delete-request', async (context) => {
    try {
      const auditContext = getAuditContext(context);
      const userId = (context as any).get?.('userId') as number ?? 0;

      if (!userId || !auditContext) {
        return context.json({ success: false, error: 'Não autenticado' }, 401);
      }

      const dados = DeleteRequestSchema.parse(await context.req.json());

      // Verificar que o registro existe
      const registro = await db
        .prepare(`SELECT id FROM ${dados.tabela} WHERE id = ? AND deleted_at IS NULL`)
        .bind(dados.registro_id)
        .first();

      if (!registro) {
        return context.json({ success: false, error: 'Registro não encontrado' }, 404);
      }

      // Gerar token
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutos

      await db
        .prepare(
          `
          INSERT INTO delete_requests (usuario_id, tabela, registro_id, token, expires_at)
          VALUES (?, ?, ?, ?, ?)
        `
        )
        .bind(userId, dados.tabela, dados.registro_id, token, expiresAt.toISOString())
        .run();

      // Auditar geração de token
      await auditLogger.log(userId, 'CREATE', 'delete_requests', dados.registro_id);

      return context.json({
        success: true,
        confirm_token: token,
        expires_at: expiresAt.toISOString(),
        message: 'Token gerado. Este token expira em 5 minutos.',
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return context.json({
          success: false,
          error: 'Validação falhou',
          details: error.errors.map((e) => ({
            path: e.path.join('.'),
            message: e.message,
          })),
        }, 400);
      }

      console.error('❌ Erro ao criar delete request:', error);
      return context.json({ success: false, error: error.message }, 500);
    }
  });

  /**
   * DELETE /api/v2/habilitacoes/:id
   * Com validação de token de confirmação
   */
  router.delete('/habilitacoes/:id', async (context) => {
    try {
      const userId = (context as any).get?.('userId') as number ?? 0;
      const id = parseInt(context.req.param('id'));
      const confirmToken = context.req.header('X-Confirm-Token');

      if (!userId) {
        return context.json({ success: false, error: 'Não autenticado' }, 401);
      }

      if (!confirmToken) {
        return context.json(
          {
            success: false,
            error: 'Token de confirmação obrigatório',
            hint: 'Faça POST em /delete-request primeiro',
          },
          400
        );
      }

      // Validar token
      const deleteRequest = await db
        .prepare(
          `
          SELECT * FROM delete_requests
          WHERE registro_id = ? 
            AND tabela = 'habilitacoes'
            AND token = ? 
            AND expires_at > CURRENT_TIMESTAMP
            AND confirmado = 0
        `
        )
        .bind(id, confirmToken)
        .first() as any;

      if (!deleteRequest) {
        return context.json(
          { success: false, error: 'Token inválido ou expirado', code: 'INVALID_TOKEN' },
          403
        );
      }

      // Obter dados antes do delete
      const habilitacao = await db
        .prepare(
          'SELECT * FROM habilitacoes WHERE id = ? AND deleted_at IS NULL'
        )
        .bind(id)
        .first();

      if (!habilitacao) {
        return context.json(
          { success: false, error: 'Habilitação não encontrada', code: 'NOT_FOUND' },
          404
        );
      }

      // Executar soft delete
      await db
        .prepare('UPDATE habilitacoes SET deleted_at = CURRENT_TIMESTAMP WHERE id = ?')
        .bind(id)
        .run();

      // Auditar delete
      await auditLogger.log(userId, 'DELETE', 'habilitacoes', id, habilitacao, null);

      // Marcar token como usado
      await db
        .prepare('UPDATE delete_requests SET confirmado = 1 WHERE id = ?')
        .bind(deleteRequest.id)
        .run();

      return context.json({
        success: true,
        data: {
          message: 'Habilitação deletada com sucesso',
          id,
          deletedAt: new Date().toISOString(),
        },
        code: 'DELETED_SUCCESS',
      });
    } catch (error: any) {
      console.error('❌ Erro ao deletar habilitação:', error);
      return context.json({ success: false, error: error.message }, 500);
    }
  });

  /**
   * DELETE /api/v2/funcionarios/:id
   * Delete com confirmação para funcionários
   */
  router.delete('/funcionarios/:id', async (context) => {
    try {
      const userId = (context as any).get?.('userId') as number ?? 0;
      const id = parseInt(context.req.param('id'));
      const confirmToken = context.req.header('X-Confirm-Token');

      if (!userId) {
        return context.json({ success: false, error: 'Não autenticado' }, 401);
      }

      if (!confirmToken) {
        return context.json(
          { success: false, error: 'Token de confirmação obrigatório' },
          400
        );
      }

      // Validar token
      const deleteRequest = await db
        .prepare(
          `
          SELECT * FROM delete_requests
          WHERE registro_id = ? 
            AND tabela = 'funcionarios'
            AND token = ? 
            AND expires_at > CURRENT_TIMESTAMP
            AND confirmado = 0
        `
        )
        .bind(id, confirmToken)
        .first();

      if (!deleteRequest) {
        return context.json({ success: false, error: 'Token inválido ou expirado' }, 403);
      }

      // Obter dados antes do delete
      const funcionario = await db
        .prepare('SELECT * FROM funcionarios WHERE id = ? AND deleted_at IS NULL')
        .bind(id)
        .first();

      if (!funcionario) {
        return context.json({ success: false, error: 'Funcionário não encontrado' }, 404);
      }

      // Executar soft delete
      await db
        .prepare('UPDATE funcionarios SET deleted_at = CURRENT_TIMESTAMP WHERE id = ?')
        .bind(id)
        .run();

      // Auditar
      await auditLogger.log(userId, 'DELETE', 'funcionarios', id, funcionario, null);

      // Marcar token como usado
      await db
        .prepare('UPDATE delete_requests SET confirmado = 1 WHERE id = ?')
        .bind((deleteRequest as any).id)
        .run();

      return context.json({
        success: true,
        data: {
          message: 'Funcionário deletado com sucesso',
          id,
        },
      });
    } catch (error: any) {
      console.error('❌ Erro ao deletar funcionário:', error);
      return context.json({ success: false, error: error.message }, 500);
    }
  });

  return router;
}
