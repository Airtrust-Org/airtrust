import { Hono } from 'hono';
import type { Env } from '../types/index';
import { FuncoesService } from '../services/funcoesService';
import {
  CreateFuncaoDTO,
  UpdateFuncaoDTO,
  FuncaoResponseDTO
} from '../dtos/funcoes';

export function funcoesRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  // GET / - Listar com paginação
  router.get('/', async (c) => {
    const service = new FuncoesService(c.env.DB);
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '50');
    const result = await service.getAll(page, limit);
    return c.json({
      success: true,
      data: result.data,
      page,
      total: result.total,
      timestamp: new Date().toISOString()
    });
  });

  // POST / - Criar novo
  router.post('/', async (c) => {
    const service = new FuncoesService(c.env.DB);
    const body = await c.req.json();
    const dados = CreateFuncaoDTO.parse(body);
    const created = await service.create(dados as Record<string, unknown>);
    const response = FuncaoResponseDTO.parse(created);
    return c.json({ success: true, data: response }, 201);
  });

  // GET /:id - Obter um
  router.get('/:id', async (c) => {
    const service = new FuncoesService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    const item = await service.getById(id);
    const response = FuncaoResponseDTO.parse(item);
    return c.json({ success: true, data: response });
  });

  // PUT /:id - Atualizar
  router.put('/:id', async (c) => {
    const service = new FuncoesService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    const body = await c.req.json();
    const dados = UpdateFuncaoDTO.parse(body);
    const updated = await service.update(id, dados as Record<string, unknown>);
    const response = FuncaoResponseDTO.parse(updated);
    return c.json({ success: true, data: response });
  });

  // DELETE /:id - Deletar
  router.delete('/:id', async (c) => {
    const service = new FuncoesService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    await service.delete(id);
    return c.json({ success: true });
  });

  return router;
}
