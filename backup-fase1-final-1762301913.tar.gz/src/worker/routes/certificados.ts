import { Hono } from 'hono';
import type { Env } from '../types/index';
import { CertificadosService } from '../services/certificadosService';
import {
  CreateCertificadoDTO,
  CertificadoResponseDTO
} from '../dtos/certificados';

export function certificadosRoutes() {
  const router = new Hono<{ Bindings: Env }>();

  // GET / - Listar com paginação
  router.get('/', async (c) => {
    const service = new CertificadosService(c.env.DB);
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '50');
    const result = await service.getAll(page, limit);
    return c.json({
      success: true,
      data: result.data,
      page,
      total: result.total,
      timestamp: new Date().toISOString()
    });
  });

  // POST /gerar - Gerar novo com logo integrado
  router.post('/gerar', async (c) => {
    const service = new CertificadosService(c.env.DB);
    const body = await c.req.json();
    
    const dados = {
      habilitacao_id: body.habilitacao_id,
      empresa_id: body.empresa_id,
      funcionario_id: body.funcionario_id,
      qualificacao_id: body.qualificacao_id,
    };
    
    const certificado = await service.gerar(dados);
    return c.json({ success: true, data: certificado, message: 'Certificado gerado com sucesso' }, 201);
  });

  // POST / - Criar novo
  router.post('/', async (c) => {
    const service = new CertificadosService(c.env.DB);
    const body = await c.req.json();
    const dados = CreateCertificadoDTO.parse(body);
    const created = await service.create(dados as Record<string, unknown>);
    const response = CertificadoResponseDTO.parse(created);
    return c.json({ success: true, data: response }, 201);
  });

  // GET /:id - Obter um
  router.get('/:id', async (c) => {
    const service = new CertificadosService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    const item = await service.getById(id);
    const response = CertificadoResponseDTO.parse(item);
    return c.json({ success: true, data: response });
  });

  // DELETE /:id - Deletar
  router.delete('/:id', async (c) => {
    const service = new CertificadosService(c.env.DB);
    const id = parseInt(c.req.param('id'));
    await service.delete(id);
    return c.json({ success: true });
  });

  return router;
}
