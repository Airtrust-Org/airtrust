import { Hono } from 'hono';
import type { Env } from '../types/index';
import { formatarCPF, formatarTelefone, formatarNome, converterDataExcel } from '../utils/formatters';

const app = new Hono<{ Bindings: Env }>();

function limparValor(valor: any): string {
  if (valor === null || valor === undefined) return '';
  if (typeof valor === 'number') return valor.toString();
  if (typeof valor === 'string') return valor.trim();
  try {
    return String(valor).trim();
  } catch {
    return '';
  }
}

app.post('/', async (c) => {
  const startTime = Date.now();

  try {
    if (!c.env?.DB) {
      return c.json({ erro: 'DB não configurado' }, 500);
    }

    const body = await c.req.json();
    const { funcionarios } = body;

    if (!funcionarios || !Array.isArray(funcionarios) || funcionarios.length === 0) {
      return c.json({ erro: 'Dados inválidos ou vazios' }, 400);
    }


    let inseridos = 0;
    let atualizados = 0;
    const errors: any[] = [];
    const preview: any[] = [];

    const matriculas = funcionarios.map(f => limparValor(f.matricula || Date.now())).filter(Boolean);
    const placeholders = matriculas.map(() => '?').join(',');
    const { results: existentes } = await c.env.DB.prepare(
      `SELECT matricula FROM funcionarios WHERE matricula IN (${placeholders})`
    ).bind(...matriculas).all();
    
    const matriculasExistentes = new Set(existentes.map((r: any) => r.matricula));

    for (let i = 0; i < funcionarios.length; i++) {
      const func = funcionarios[i];
      const linhaNum = i + 2;

      try {
        const nome = formatarNome(func.nome);
        const matricula = limparValor(func.matricula || Date.now());
        const cpf = formatarCPF(func.cpf);
        const email = limparValor(func.email).toLowerCase();
        const telefone = formatarTelefone(func.telefone);
        const codigo_anac = limparValor(func.codigo_anac);
        const codigo_canac = limparValor(func.codigo_canac);
        const funcao = limparValor(func.funcao).toUpperCase();
        const base = formatarNome(func.base);
        const contrato = limparValor(func.contrato).toUpperCase();
        const status = limparValor(func.status || 'ATIVO').toUpperCase();
        const guerra = formatarNome(func.guerra);
        const data_nascimento = converterDataExcel(func.data_nascimento);
        const data_admissao = converterDataExcel(func.data_admissao);
        const licenca_aeronautica = limparValor(func.licenca_aeronautica).toUpperCase();
        const anv = limparValor(func.anv).toUpperCase();
        const codigo_sispat = limparValor(func.codigo_sispat);
        const codigo_prestserv = limparValor(func.codigo_prestserv);
        const cma_numero = limparValor(func.cma_numero);
        const cma_data_vencimento = converterDataExcel(func.cma_data_vencimento);
        const cma_status = limparValor(func.cma_status).toUpperCase();
        const aso_data_vencimento = converterDataExcel(func.aso_data_vencimento);
        const nivel_icao = limparValor(func.nivel_icao).toUpperCase();
        const nivel_icao_data_vencimento = converterDataExcel(func.nivel_icao_data_vencimento);
        const nivel_icao_status = limparValor(func.nivel_icao_status).toUpperCase();
        const aeronave_principal = limparValor(func.aeronave_principal).toUpperCase();
        const is_instrutor = func.is_instrutor || 0;
        const is_checador = func.is_checador || 0;

        if (!nome || nome.length < 2) {
          throw new Error('Nome obrigatório (mínimo 2 caracteres)');
        }

        const existe = matriculasExistentes.has(matricula);

        if (existe) {
          await c.env.DB.prepare(`
            UPDATE funcionarios 
            SET nome = ?, cpf = ?, email = ?, telefone = ?, 
                codigo_anac = ?, codigo_canac = ?, funcao = ?, base = ?, contrato = ?,
                status = ?, guerra = ?, data_nascimento = ?, data_admissao = ?, 
                licenca_aeronautica = ?, anv = ?,
                codigo_sispat = ?, codigo_prestserv = ?,
                cma_numero = ?, cma_data_vencimento = ?, cma_status = ?,
                aso_data_vencimento = ?, nivel_icao = ?, nivel_icao_data_vencimento = ?, nivel_icao_status = ?,
                aeronave_principal = ?, is_instrutor = ?, is_checador = ?,
                updated_at = datetime('now')
            WHERE matricula = ?
          `).bind(
            nome, cpf, email, telefone, codigo_anac, codigo_canac, funcao, base, contrato,
            status, guerra, data_nascimento, data_admissao, licenca_aeronautica, anv,
            codigo_sispat, codigo_prestserv, cma_numero, cma_data_vencimento, cma_status,
            aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
            aeronave_principal, is_instrutor, is_checador, matricula
          ).run();
          
          atualizados++;
        } else {
          await c.env.DB.prepare(`
            INSERT INTO funcionarios (
              nome, matricula, cpf, email, telefone, codigo_anac, codigo_canac, funcao, base, contrato,
              status, guerra, data_nascimento, data_admissao, licenca_aeronautica, anv,
              codigo_sispat, codigo_prestserv, cma_numero, cma_data_vencimento, cma_status,
              aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
              aeronave_principal, is_instrutor, is_checador, created_at, updated_at
            ) VALUES (
              ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
              datetime('now'), datetime('now')
            )
          `).bind(
            nome, matricula, cpf, email, telefone, codigo_anac, codigo_canac, funcao, base, contrato,
            status, guerra, data_nascimento, data_admissao, licenca_aeronautica, anv,
            codigo_sispat, codigo_prestserv, cma_numero, cma_data_vencimento, cma_status,
            aso_data_vencimento, nivel_icao, nivel_icao_data_vencimento, nivel_icao_status,
            aeronave_principal, is_instrutor, is_checador
          ).run();
          
          inseridos++;
        }

        if (preview.length < 5) {
          preview.push({ nome, matricula });
        }

      } catch (err: any) {
        errors.push({ 
          linha: linhaNum, 
          erro: err.message
        });
      }
    }

    const duracao = Date.now() - startTime;
    const resultado = {
      sucesso: true,
      inseridos,
      atualizados,
      erros: errors.length,
      detalhes: errors.slice(0, 10),
      preview,
      total: funcionarios.length
    };


    return c.json(resultado, 200);

  } catch (error: any) {
    console.error('[IMPORT] ❌ Erro fatal:', error.message);
    return c.json({
      sucesso: false,
      erro: error.message || 'Erro ao processar importação'
    }, 500);
  }
});

export default app;
