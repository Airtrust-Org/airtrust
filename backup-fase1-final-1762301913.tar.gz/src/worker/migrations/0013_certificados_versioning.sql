-- Migration 0013: Certificados Versionamento & Histórico
-- Data: 4 de Novembro de 2025

ALTER TABLE certificados ADD COLUMN IF NOT EXISTS versao INTEGER DEFAULT 1;
ALTER TABLE certificados ADD COLUMN IF NOT EXISTS certificado_anterior_id INTEGER;

CREATE TABLE IF NOT EXISTS certificados_historico (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  certificado_id INTEGER NOT NULL,
  habilitacao_id INTEGER NOT NULL,
  versao INTEGER NOT NULL,
  nome_arquivo TEXT NOT NULL,
  url_r2 TEXT NOT NULL,
  tipo TEXT NOT NULL,
  tamanho_bytes INTEGER,
  hash_sha256 TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criado_por INTEGER,
  FOREIGN KEY (certificado_id) REFERENCES certificados(id),
  FOREIGN KEY (habilitacao_id) REFERENCES habilitacoes(id),
  FOREIGN KEY (criado_por) REFERENCES usuarios(id)
);

CREATE INDEX IF NOT EXISTS idx_certificados_historico_cert ON certificados_historico(certificado_id);
CREATE INDEX IF NOT EXISTS idx_certificados_historico_hab ON certificados_historico(habilitacao_id);
CREATE INDEX IF NOT EXISTS idx_certificados_historico_versao ON certificados_historico(versao);
CREATE INDEX IF NOT EXISTS idx_certificados_versao ON certificados(versao);

-- Trigger para arquivar versão anterior
CREATE TRIGGER IF NOT EXISTS tr_certificados_archive_version
BEFORE INSERT ON certificados
FOR EACH ROW
BEGIN
  INSERT INTO certificados_historico (
    certificado_id, habilitacao_id, versao, nome_arquivo, url_r2, tipo, tamanho_bytes, hash_sha256, criado_por
  ) 
  SELECT id, habilitacao_id, versao, nome_arquivo, url_r2, tipo, tamanho_bytes, hash_sha256, created_by
  FROM certificados
  WHERE habilitacao_id = NEW.habilitacao_id
  ORDER BY versao DESC
  LIMIT 1;
END;
