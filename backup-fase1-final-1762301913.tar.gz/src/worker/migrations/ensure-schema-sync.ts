/**
 * MIGRAÇÃO AUTOMÁTICA DE SINCRONIZAÇÃO DE SCHEMA
 * Executa automaticamente no startup para garantir que produção
 * tenha o mesmo schema que desenvolvimento
 */

export async function ensureSchemaSyncMigration(db: any): Promise<void> {
  try {
    const schemaResult = await db
      .prepare(
        `
      PRAGMA table_info(funcionarios)
    `,
      )
      .all();

    const schemaInfo = schemaResult.results || [];
    const hasDeletedAt = schemaInfo.some((col: any) => col.name === 'deleted_at');

    if (!hasDeletedAt) {
      await db
        .prepare(
          `
        ALTER TABLE funcionarios ADD COLUMN deleted_at TIMESTAMP
      `,
        )
        .run();
    } else {
    }

    await ensureDeletedAtInTable(db, 'funcoes');
    await ensureDeletedAtInTable(db, 'catalogo_treinamentos_v2');
    await ensureDeletedAtInTable(db, 'historico_certificacoes_v2');

    // Adicionar novos campos na tabela habilitacoes
    await ensureHabilitacoesColumns(db);

    await createIndexesSafely(db);

    await cleanInconsistentData(db);
  } catch (error) {
    console.error('❌ Erro na migração de sincronização:', error);
  }
}

async function ensureDeletedAtInTable(db: any, tableName: string): Promise<void> {
  try {
    const schemaResult = await db
      .prepare(
        `
      PRAGMA table_info(${tableName})
    `,
      )
      .all();

    const schemaInfo = schemaResult.results || [];
    const hasDeletedAt = schemaInfo.some((col: any) => col.name === 'deleted_at');

    if (!hasDeletedAt) {
      await db
        .prepare(
          `
        ALTER TABLE ${tableName} ADD COLUMN deleted_at TIMESTAMP
      `,
        )
        .run();
    } else {
    }
  } catch (error) {
    console.warn(`⚠️ Erro ao verificar tabela ${tableName}:`, error);
  }
}

async function ensureHabilitacoesColumns(db: any): Promise<void> {
  try {
    const schemaResult = await db
      .prepare(
        `
      PRAGMA table_info(habilitacoes)
    `,
      )
      .all();

    const schemaInfo = schemaResult.results || [];
    const columns = schemaInfo.map((col: any) => col.name);

    // Verificar e adicionar coluna timezone
    if (!columns.includes('timezone')) {
      console.log('➕ Adicionando coluna timezone em habilitacoes');
      await db
        .prepare(
          `
        ALTER TABLE habilitacoes ADD COLUMN timezone VARCHAR(50) DEFAULT 'UTC'
      `,
        )
        .run();
    }

    // Verificar e adicionar coluna instrutor
    if (!columns.includes('instrutor')) {
      console.log('➕ Adicionando coluna instrutor em habilitacoes');
      await db
        .prepare(
          `
        ALTER TABLE habilitacoes ADD COLUMN instrutor VARCHAR(255)
      `,
        )
        .run();
    }

    // Verificar e adicionar coluna certificado_url
    if (!columns.includes('certificado_url')) {
      console.log('➕ Adicionando coluna certificado_url em habilitacoes');
      await db
        .prepare(
          `
        ALTER TABLE habilitacoes ADD COLUMN certificado_url TEXT
      `,
        )
        .run();
    }

    // Verificar e adicionar coluna renovada_em
    if (!columns.includes('renovada_em')) {
      console.log('➕ Adicionando coluna renovada_em em habilitacoes');
      await db
        .prepare(
          `
        ALTER TABLE habilitacoes ADD COLUMN renovada_em DATETIME
      `,
        )
        .run();
    }

    // Verificar e adicionar coluna habilitacao_anterior_id
    if (!columns.includes('habilitacao_anterior_id')) {
      console.log('➕ Adicionando coluna habilitacao_anterior_id em habilitacoes');
      await db
        .prepare(
          `
        ALTER TABLE habilitacoes ADD COLUMN habilitacao_anterior_id INTEGER
      `,
        )
        .run();
    }

    // Criar índices se não existirem
    const indexQueries = [
      'CREATE INDEX IF NOT EXISTS idx_habilitacoes_timezone ON habilitacoes(timezone)',
      'CREATE INDEX IF NOT EXISTS idx_habilitacoes_instrutor ON habilitacoes(instrutor)',
      'CREATE INDEX IF NOT EXISTS idx_habilitacoes_anterior ON habilitacoes(habilitacao_anterior_id)',
      'CREATE INDEX IF NOT EXISTS idx_habilitacoes_certificado_url ON habilitacoes(certificado_url)',
    ];

    for (const indexSQL of indexQueries) {
      try {
        await db.prepare(indexSQL).run();
      } catch (error) {
        console.warn('⚠️ Erro ao criar índice habilitacoes:', error);
      }
    }

    console.log('✅ Tabela habilitacoes sincronizada');
  } catch (error) {
    console.warn(`⚠️ Erro ao sincronizar habilitacoes:`, error);
  }
}

async function createIndexesSafely(db: any): Promise<void> {
  const indexes = [
    'CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at ON funcionarios(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_funcionarios_matricula ON funcionarios(matricula) WHERE deleted_at IS NULL',
    'CREATE INDEX IF NOT EXISTS idx_funcoes_deleted_at ON funcoes(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_catalogo_treinamentos_deleted_at ON catalogo_treinamentos_v2(deleted_at)',
    'CREATE INDEX IF NOT EXISTS idx_historico_certificacoes_deleted_at ON historico_certificacoes_v2(deleted_at)',
  ];

  for (const indexSQL of indexes) {
    try {
      await db.prepare(indexSQL).run();
    } catch (error) {
      console.warn('⚠️ Erro ao criar índice:', error);
    }
  }
}

async function cleanInconsistentData(db: any): Promise<void> {
  try {
    const cleanupQueries = [
      "UPDATE funcionarios SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE funcoes SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE catalogo_treinamentos_v2 SET deleted_at = NULL WHERE deleted_at = ''",
      "UPDATE historico_certificacoes_v2 SET deleted_at = NULL WHERE deleted_at = ''",
    ];

    for (const query of cleanupQueries) {
      try {
        await db.prepare(query).run();
      } catch (error) {
        console.warn('⚠️ Erro na limpeza de dados:', error);
      }
    }
  } catch (error) {
    console.warn('⚠️ Erro na limpeza geral:', error);
  }
}

/**
 * Verificação de saúde do schema após migração
 */
export async function validateSchemaHealth(db: any): Promise<boolean> {
  try {
    await db
      .prepare(
        `
      SELECT COUNT(*) as total, 
             COUNT(CASE WHEN deleted_at IS NULL THEN 1 END) as ativos,
             COUNT(CASE WHEN deleted_at IS NOT NULL THEN 1 END) as deletados
      FROM funcionarios
    `,
      )
      .first();

    return true;
  } catch (error) {
    console.error('❌ Schema health check falhou:', error);
    return false;
  }
}
