-- Migration: 0010_expandir_tabela_certificados.sql

-- Se a tabela não existir, criar completa:
CREATE TABLE IF NOT EXISTS certificados (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  -- Relacionamentos
  habilitacao_id INTEGER NOT NULL,
  empresa_id INTEGER NOT NULL,
  qualificacao_id INTEGER,
  funcionario_id INTEGER NOT NULL,
  
  -- Dados do certificado
  numero_certificado TEXT UNIQUE NOT NULL,
  titulo TEXT NOT NULL DEFAULT 'Certificado de Conclusão',
  descricao TEXT,
  
  -- Logo e branding
  logo_url TEXT,
  template_tipo TEXT DEFAULT 'default',
  cor_primaria TEXT DEFAULT '#0066cc',
  cor_secundaria TEXT DEFAULT '#333333',
  
  -- Armazenamento
  r2_key TEXT,
  r2_url TEXT,
  arquivo_local TEXT,
  
  -- Datas
  data_emissao DATE NOT NULL,
  data_validade DATE,
  
  -- Status
  status TEXT DEFAULT 'ativo',
  
  -- Assinatura
  assinado BOOLEAN DEFAULT FALSE,
  assinatura_digital TEXT,
  
  -- Auditoria
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP DEFAULT NULL,
  
  -- Foreign keys
  FOREIGN KEY(habilitacao_id) REFERENCES habilitacoes(id),
  FOREIGN KEY(empresa_id) REFERENCES empresas(id),
  FOREIGN KEY(funcionario_id) REFERENCES funcionarios(id),
  FOREIGN KEY(created_by) REFERENCES usuarios(id)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_cert_numero ON certificados(numero_certificado);
CREATE INDEX IF NOT EXISTS idx_cert_funcionario ON certificados(funcionario_id);
CREATE INDEX IF NOT EXISTS idx_cert_empresa ON certificados(empresa_id);
CREATE INDEX IF NOT EXISTS idx_cert_status ON certificados(status);
CREATE INDEX IF NOT EXISTS idx_cert_data_emissao ON certificados(data_emissao);

-- Se a tabela já existe, adicionar colunas faltantes
-- (comentado, descomente se necessário)
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS logo_url TEXT DEFAULT NULL;
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS template_tipo TEXT DEFAULT 'default';
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS cor_primaria TEXT DEFAULT '#0066cc';
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS cor_secundaria TEXT DEFAULT '#333333';
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS r2_key TEXT DEFAULT NULL;
-- ALTER TABLE certificados ADD COLUMN IF NOT EXISTS r2_url TEXT DEFAULT NULL;
