-- Migration 0017: Adicionar campos timezone, instrutor e certificado_url à tabela habilitacoes
-- Date: 2025-11-04

-- Adicionar coluna timezone (com default UTC)
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS timezone VARCHAR(50) DEFAULT 'UTC';

-- Adicionar coluna instrutor
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS instrutor VARCHAR(255);

-- Adicionar coluna certificado_url (para armazenar URL do certificado gerado)
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS certificado_url TEXT;

-- Adicionar coluna renovada_em (data quando foi renovada)
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS renovada_em DATETIME;

-- Adicionar coluna habilitacao_anterior_id (para rastrear renovações)
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS habilitacao_anterior_id INTEGER;

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_habilitacoes_timezone ON habilitacoes(timezone);
CREATE INDEX IF NOT EXISTS idx_habilitacoes_instrutor ON habilitacoes(instrutor);
CREATE INDEX IF NOT EXISTS idx_habilitacoes_anterior ON habilitacoes(habilitacao_anterior_id);
CREATE INDEX IF NOT EXISTS idx_habilitacoes_certificado_url ON habilitacoes(certificado_url);

-- Comentários
-- NOTAS:
-- - timezone: Armazena o timezone do evento (ex: America/Sao_Paulo, UTC)
-- - instrutor: Nome do instrutor responsável (se aplicável)
-- - certificado_url: URL completa do certificado armazenado em R2
-- - renovada_em: Timestamp quando foi renovada
-- - habilitacao_anterior_id: FK apontando para a habilitação anterior (para renovações)
