-- Migration 0014: Auditoria Detalhada & Delete Requests
-- Data: 4 de Novembro de 2025

CREATE TABLE IF NOT EXISTS auditoria_detalhada (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  acao TEXT NOT NULL CHECK(acao IN ('CREATE', 'UPDATE', 'DELETE', 'READ')),
  tabela TEXT NOT NULL,
  registro_id INTEGER NOT NULL,
  dados_antes TEXT,
  dados_depois TEXT,
  ip_address TEXT DEFAULT 'unknown',
  user_agent TEXT DEFAULT 'unknown',
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS delete_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL,
  tabela TEXT NOT NULL,
  registro_id INTEGER NOT NULL,
  token TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  confirmado BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Índices para auditoria
CREATE INDEX IF NOT EXISTS idx_auditoria_usuario ON auditoria_detalhada(usuario_id);
CREATE INDEX IF NOT EXISTS idx_auditoria_tabela ON auditoria_detalhada(tabela);
CREATE INDEX IF NOT EXISTS idx_auditoria_timestamp ON auditoria_detalhada(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_auditoria_acao ON auditoria_detalhada(acao);

-- Índices para delete requests
CREATE INDEX IF NOT EXISTS idx_delete_requests_token ON delete_requests(token);
CREATE INDEX IF NOT EXISTS idx_delete_requests_usuario ON delete_requests(usuario_id);
CREATE INDEX IF NOT EXISTS idx_delete_requests_expired ON delete_requests(expires_at) WHERE confirmado = 0;

-- Limpar delete requests expirados (housekeeping)
CREATE TRIGGER IF NOT EXISTS tr_delete_requests_cleanup
AFTER INSERT ON delete_requests
BEGIN
  DELETE FROM delete_requests 
  WHERE expires_at < CURRENT_TIMESTAMP 
  AND confirmado = 0
  AND id NOT IN (SELECT id FROM delete_requests ORDER BY id DESC LIMIT 1000);
END;
