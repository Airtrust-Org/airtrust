-- Migration: 0009_criar_tabela_empresa_config.sql

CREATE TABLE IF NOT EXISTS empresa_config (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  
  -- Relacionamentos
  empresa_id INTEGER NOT NULL UNIQUE,
  
  -- Configurações básicas
  nome TEXT NOT NULL DEFAULT 'Empresa',
  descricao TEXT,
  
  -- Logo e branding
  logo_url TEXT DEFAULT NULL,
  logo_s3_key TEXT DEFAULT NULL,
  logo_tipo TEXT DEFAULT 'png',
  logo_largura INTEGER DEFAULT 200,
  logo_altura INTEGER DEFAULT 100,
  
  -- Cores do certificado
  cor_primaria TEXT DEFAULT '#0066cc',
  cor_secundaria TEXT DEFAULT '#333333',
  cor_acento TEXT DEFAULT '#FF6B35',
  
  -- Template do certificado
  template_certificado TEXT DEFAULT 'default',
  assinatura_digital BOOLEAN DEFAULT FALSE,
  assinatura_url TEXT DEFAULT NULL,
  
  -- Configurações de emissão
  emitir_automatico BOOLEAN DEFAULT TRUE,
  intervalo_dias INTEGER DEFAULT 365,
  
  -- Dados de contato
  email_contato TEXT,
  telefone TEXT,
  website TEXT,
  endereco TEXT,
  
  -- Registro
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP DEFAULT NULL,
  
  -- Foreign key
  FOREIGN KEY(empresa_id) REFERENCES empresas(id)
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_empresa_config_empresa_id ON empresa_config(empresa_id);
CREATE INDEX IF NOT EXISTS idx_empresa_config_deleted_at ON empresa_config(deleted_at);

-- Trigger para atualizar updated_at
CREATE TRIGGER IF NOT EXISTS trigger_empresa_config_updated_at
AFTER UPDATE ON empresa_config
BEGIN
  UPDATE empresa_config SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
