/**
 * Migration: Aplicar lógica de renovadas em habilitações existentes
 *
 * Para cada funcionário + qualificação:
 * 1. Ordenar habilitações por data_conclusao ASC
 * 2. Primeira = ativa (eh_renovada=FALSE)
 * 3. Demais = renovadas (eh_renovada=TRUE, habilitacao_anterior_id = anterior)
 */

import type { D1Database } from '@cloudflare/workers-types';

export async function fixRenovadasExistentes(db: D1Database): Promise<void> {
  console.log('🔧 Iniciando correção de renovadas existentes...');

  try {
    // 1. Obter todos os grupos (funcionario_id, qualificacao_id)
    const grupos = await db
      .prepare(
        `
        SELECT DISTINCT funcionario_id, qualificacao_id
        FROM habilitacoes
        WHERE deleted_at IS NULL
        GROUP BY funcionario_id, qualificacao_id
        HAVING COUNT(*) > 1
        ORDER BY funcionario_id, qualificacao_id
      `,
      )
      .all();

    console.log(`📊 Encontrados ${grupos.results?.length || 0} grupos com duplicatas`);

    let totalProcessados = 0;
    let totalRenovadas = 0;

    for (const grupo of grupos.results || []) {
      const { funcionario_id, qualificacao_id } = grupo as any;

      // 2. Buscar todas habilitações deste grupo ordenadas por data_conclusao
      const habilitacoes = await db
        .prepare(
          `
          SELECT id, data_conclusao, eh_renovada, habilitacao_anterior_id
          FROM habilitacoes
          WHERE funcionario_id = ?
            AND qualificacao_id = ?
            AND deleted_at IS NULL
          ORDER BY 
            CASE WHEN data_conclusao IS NULL THEN 1 ELSE 0 END,
            data_conclusao ASC,
            created_at ASC
        `,
        )
        .bind(funcionario_id, qualificacao_id)
        .all();

      const lista = habilitacoes.results || [];
      if (lista.length < 2) continue;

      console.log(
        `  📋 Processando grupo: funcionario=${funcionario_id}, qualificacao=${qualificacao_id} (${lista.length} habilitações)`,
      );

      // 3. Primeira habilitação = original (não renovada)
      const primeira = lista[0] as any;

      // Se já está marcada como renovada, resetar
      if (primeira.eh_renovada) {
        await db
          .prepare(
            `
            UPDATE habilitacoes
            SET 
              eh_renovada = FALSE,
              renovada_em = NULL,
              habilitacao_anterior_id = NULL,
              updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `,
          )
          .bind(primeira.id)
          .run();
        console.log(`    ✅ Resetada primeira habilitação: ${primeira.id}`);
      }

      // 4. Demais = renovações
      for (let i = 1; i < lista.length; i++) {
        const atual = lista[i] as any;
        const anterior = lista[i - 1] as any;

        // Marcar como renovada e vincular à anterior
        const resultado = await db
          .prepare(
            `
            UPDATE habilitacoes
            SET 
              eh_renovada = TRUE,
              renovada_em = COALESCE(renovada_em, updated_at, created_at),
              habilitacao_anterior_id = ?,
              updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `,
          )
          .bind(anterior.id, atual.id)
          .run();

        if (resultado.success) {
          totalRenovadas++;
          console.log(`    ♻️  Marcada como renovada: ${atual.id} -> anterior: ${anterior.id}`);
        }
      }

      totalProcessados++;
    }

    console.log(
      `✅ Migração concluída! ${totalProcessados} grupos processados, ${totalRenovadas} habilitações marcadas como renovadas`,
    );
  } catch (error) {
    console.error('❌ Erro ao aplicar renovadas:', error);
    throw error;
  }
}
