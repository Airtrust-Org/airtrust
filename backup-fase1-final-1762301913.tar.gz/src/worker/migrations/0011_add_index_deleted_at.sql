-- Migration: Add index on deleted_at for soft delete queries
-- Purpose: Optimize queries filtering soft-deleted records
-- Date: 2025-11-04

-- Create indexes on deleted_at columns for main tables that use soft delete
CREATE INDEX IF NOT EXISTS idx_habilitacoes_deleted_at 
ON habilitacoes(deleted_at);

CREATE INDEX IF NOT EXISTS idx_qualificacoes_deleted_at 
ON qualificacoes(deleted_at);

CREATE INDEX IF NOT EXISTS idx_funcionarios_deleted_at 
ON funcionarios(deleted_at);

CREATE INDEX IF NOT EXISTS idx_certificados_deleted_at 
ON certificados(deleted_at);

CREATE INDEX IF NOT EXISTS idx_treinamentos_deleted_at 
ON treinamentos(deleted_at);

-- These indexes significantly improve performance of queries like:
-- SELECT * FROM habilitacoes WHERE deleted_at IS NULL
-- Without indexes, D1 performs full table scans

-- Status: Applied
