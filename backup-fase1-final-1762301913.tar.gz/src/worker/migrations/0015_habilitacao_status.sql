-- Migration 0015: Habilitacao Status Computado
-- Data: 4 de Novembro de 2025

-- Adicionar coluna de status se não existir
ALTER TABLE habilitacoes ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'VÁLIDO';

-- Criar view com cálculo de status
CREATE VIEW IF NOT EXISTS v_habilitacoes_com_status AS
SELECT 
  h.*,
  CASE 
    WHEN h.deleted_at IS NOT NULL THEN 'DELETADA'
    WHEN h.data_vencimento > DATE('now') THEN 'VÁLIDO'
    WHEN h.data_vencimento <= DATE('now') AND h.data_vencimento > DATE('now', '-30 days') THEN 'VENCENDO'
    ELSE 'VENCIDA'
  END as status_computado
FROM habilitacoes h
WHERE h.deleted_at IS NULL;

-- Criar índice para consultas por status
CREATE INDEX IF NOT EXISTS idx_habilitacoes_status ON habilitacoes(status);

-- Trigger para atualizar status ao inserir
CREATE TRIGGER IF NOT EXISTS tr_habilitacoes_insert_status
AFTER INSERT ON habilitacoes
BEGIN
  UPDATE habilitacoes 
  SET status = CASE 
    WHEN NEW.data_vencimento > DATE('now') THEN 'VÁLIDO'
    WHEN NEW.data_vencimento <= DATE('now') AND NEW.data_vencimento > DATE('now', '-30 days') THEN 'VENCENDO'
    ELSE 'VENCIDA'
  END
  WHERE id = NEW.id;
END;

-- Trigger para atualizar status ao modificar data_vencimento
CREATE TRIGGER IF NOT EXISTS tr_habilitacoes_update_status
AFTER UPDATE OF data_vencimento ON habilitacoes
BEGIN
  UPDATE habilitacoes 
  SET status = CASE 
    WHEN NEW.data_vencimento > DATE('now') THEN 'VÁLIDO'
    WHEN NEW.data_vencimento <= DATE('now') AND NEW.data_vencimento > DATE('now', '-30 days') THEN 'VENCENDO'
    ELSE 'VENCIDA'
  END
  WHERE id = NEW.id;
END;

-- Stored procedure para recalcular status em lote (executar periodicamente)
-- SELECT COUNT(*) FROM habilitacoes WHERE status != CASE 
--   WHEN data_vencimento > DATE('now') THEN 'VÁLIDO'
--   WHEN data_vencimento <= DATE('now') AND data_vencimento > DATE('now', '-30 days') THEN 'VENCENDO'
--   ELSE 'VENCIDA' END;
