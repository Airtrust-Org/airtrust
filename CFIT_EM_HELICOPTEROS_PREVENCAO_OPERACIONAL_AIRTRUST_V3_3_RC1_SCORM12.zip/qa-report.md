# RC1 — Pré-flight local

- Reconstruído do zero o conteúdo CFIT, com shell AirTrust V3.3 de NR26 RC5.
- 37 unidades, 4 capítulos, 4 avaliações de dez itens e aprovação mínima de 80% cada.
- 37 fotografias contextuais reais provenientes de Wikimedia Commons e Pexels, registradas com autor/licença; uso único de cada imagem, sem SVG esquemático.
- Playwright local: preview sem writes, percurso completo, cenário bloqueia resposta insegura, avaliação com 5 alternativas, resume parcial, quatro capítulos 100%, score 100%, LMSInitialize 1x, LMSFinish 1x, zero chamada após Finish, sem erro JS; mouse, toque e teclado em cenários; bloqueio seguro de estado legado de outro curso.
- 6 viewports sem overflow horizontal e com tipografia mínima 14px; fold-fit desktop 100% nas telas 1468×836 e 1366×768 (28 telas editoriais elegíveis).
- PENDENTE/NÃO EXECUTADO: Quality Gate runtime real AirTrust (runner NOT_SUPPORTED no gate estático) e validação corporativa de SOP/RFM vigentes. Testes locais não equivalem a publicação certificada.
