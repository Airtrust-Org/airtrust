(function(){
'use strict';
const C=window.COURSE_DATA,S=C.slides,T=S.length,PASS=C.masteryScore||80;
const $=s=>document.querySelector(s),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[c]));
const ok=v=>v===true||String(v).toLowerCase()==='true';
const qa=new URLSearchParams(location.search).get('qa')==='1';
let sessionEnding=false,legacyConflict=false,view=0,active=0,mode='journey',done=new Set(),scenario={},quizzes={},gateSeen=new Set(),previewSeen=new Set(),courseCompleted=false,finishRequested=false,initialized=false,pendingConfirmation=false;
function slide(i=view){return S[i]}
function quiz(s){if(!quizzes[s.id])quizzes[s.id]={answers:Array(10).fill(null),evaluated:false,score:0,passed:false,q:0};return quizzes[s.id]}
function safeGet(k){try{return window.Scorm?.get(k)||''}catch(e){return''}}
function safeSet(k,v){try{return ok(window.Scorm?.set(k,String(v)))}catch(e){return false}}
function commit(){try{return ok(window.Scorm?.commit())}catch(e){return false}}
function assessSlides(){return S.filter(x=>x.kind==='assessment')}
function allQuizzesPassed(){return assessSlides().every(x=>quizzes[x.id]?.passed===true)}
function completionReady(){return done.size===T && allQuizzesPassed()}
function score(){const q=assessSlides().map(x=>quizzes[x.id]?.score);return q.every(Number.isFinite)?Math.round(q.reduce((a,b)=>a+b,0)/q.length):null}
function state(){return JSON.stringify({v:3,p:C.courseId,s:active,d:[...done],sc:scenario,mq:quizzes,g:[...gateSeen],c:courseCompleted})}
function readOnly(){return qa||mode==='preview'||mode==='review'||courseCompleted}
function modeFor(i){if(legacyConflict)return'preview';if(courseCompleted)return'review';return i===active?'journey':(done.has(i)?'review':'preview')}
function restore(){
 const status=String(safeGet('cmi.core.lesson_status')||'').toLowerCase();
 let o;try{o=JSON.parse(safeGet('cmi.suspend_data')||'null')}catch(e){o=null}
 const same=!!o&&o.v===3&&o.p===C.courseId&&Array.isArray(o.d)&&typeof o.mq==='object';
 // Critical: replacing an older CFIT must not interpret its 41/41 as completion of this 37-unit course.
 if(same){active=Math.max(0,Math.min(T-1,Number(o.s||0)));done=new Set(o.d.map(Number).filter(i=>i>=0&&i<T));scenario=o.sc||{};quizzes=o.mq||{};gateSeen=new Set(Array.isArray(o.g)?o.g:[]);courseCompleted=o.c===true&&/passed|completed/.test(status)}
 if(/passed|completed/.test(status)&&!same){legacyConflict=true;active=0;view=0;done=new Set();mode='preview'}
 else mode=courseCompleted?'review':'journey';
 view=active;
}
function emitDiag(){
 const missing=S.filter((_,i)=>!done.has(i)).map(x=>x.id),mods=assessSlides().map(s=>({module:s.module,assessment:s.id,scoreRaw:quizzes[s.id]?.evaluated?quizzes[s.id].score:null,masteryScore:PASS,passed:quizzes[s.id]?.passed===true}));
 const nDone=mods.filter(x=>x.passed).length;
 const payload={courseId:C.courseId,currentSlide:{id:slide().id,index:view,title:slide().title},slides:{totalRequired:T,completedRequired:done.size,missing},assessment:{required:mods.length,completed:nDone,scoreRaw:score(),masteryScore:PASS,passed:allQuizzesPassed(),incomplete:mods.filter(x=>!x.passed).map(x=>x.assessment)},moduleResults:mods,packageStatus:{lessonStatus:courseCompleted?'passed':'incomplete',finishRequested},updatedAt:new Date().toISOString()};
 try{parent!==window&&parent.postMessage({type:'AIRTRUST_COMPLETION_DIAGNOSTICS_V1',payload},'*')}catch(e){}
 window.__AIRTRUST_LAST_DIAGNOSTIC__=payload;
}
function persist(){
 if(qa||mode!=='journey'||window.Scorm?.isFinished?.())return mode!=='journey';
 const data=state();if(data.length>3900){console.error('SUSPEND_DATA_LIMIT');return false}
 if(!safeSet('cmi.suspend_data',data))return false;
 if(!safeSet('cmi.core.lesson_location',(active+1)+'/'+T))return false;
 if(!safeSet('cmi.core.lesson_status',courseCompleted?'passed':'incomplete'))return false;
 if(courseCompleted){const pts=score();if(pts!==null){if(!safeSet('cmi.core.score.min','0')||!safeSet('cmi.core.score.max','100')||!safeSet('cmi.core.score.raw',String(pts)))return false}}
 const result=commit();emitDiag();return result;
}
function gateProgress(s){const items=s.gateItems||[],seen=items.filter((_,i)=>gateSeen.has(s.id+':'+i)).length;return{required:items.length,seen,complete:!items.length||items.length===seen}}
function introBody(s){
 if(s.steps)return'<div class="steps">'+s.steps.map((x,i)=>'<div class="step"><span>'+(i+1)+'</span><b>'+esc(x)+'</b></div>').join('')+'</div>';
 if(s.columns)return'<div class="columns">'+s.columns.map(c=>'<section class="card"><h3>'+esc(c.title)+'</h3><p>'+esc(c.text)+'</p></section>').join('')+'</div>';
 return '<div class="body-list">'+(s.body||[]).map(x=>'<div class="body-item">'+esc(x)+'</div>').join('')+'</div>';
}
function meta(s){return'<div class="meta-strip"><span class="chip">'+esc(s.module)+'</span><span class="chip">'+esc(s.sourceRefs.join(' · '))+'</span></div>'}
function renderLesson(s){
 const k=s.composition||'editorial-right',title='<div class="eyebrow">'+esc(s.eyebrow)+'</div><h1>'+esc(s.title)+'</h1>',lead='<p class="lead">'+esc(s.lead)+'</p>',pic='<figure class="visual"><img src="'+esc(s.media)+'" alt="'+esc(s.visualAlt)+'"></figure>';
 const rows=(s.body||[]).map((x,i)=>'<div class="editorial-row"><span class="editorial-number">'+String(i+1).padStart(2,'0')+'</span><span>'+esc(x)+'</span></div>').join('');
 if(s.layout==='cover')return'<section class="screen active cover-screen composition-'+k+'" data-unit="'+s.id+'"><div class="page"><div class="screen-grid"><div class="copy">'+title+lead+meta(s)+'</div>'+pic+'</div></div></section>';
 if(s.layout==='chapter-opener')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="chapter-page"><figure class="chapter-photo"><img src="'+esc(s.media)+'" alt="'+esc(s.visualAlt)+'"></figure><div class="chapter-copy">'+title+lead+introBody(s)+meta(s)+'</div></div></section>';
 if(s.layout==='checklist')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="checklist-page"><div class="checklist-band">'+pic+'<div class="checklist-header">'+title+lead+'</div></div><div class="checklist-lines">'+(s.body||[]).map((x,i)=>'<div class="checklist-entry"><span class="checkmark" aria-hidden="true">✓</span><span>'+esc(x)+'</span></div>').join('')+'</div>'+meta(s)+'</div></section>';
 if(s.layout==='comparison')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="comparison-page"><header class="comparison-head">'+title+lead+'</header><div class="comparison-content"><div class="comparison-notes">'+rows+'</div>'+pic+'</div>'+meta(s)+'</div></section>';
 if(s.layout==='process')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="process-page"><div class="process-feature">'+pic+'<div class="process-intro">'+title+lead+'</div></div><div class="process-steps">'+rows+meta(s)+'</div></div></section>';
 if(s.layout==='visual-explainer')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="explainer-page"><div class="explainer-photo">'+pic+'</div><div class="explainer-copy">'+title+lead+'<div class="explainer-points">'+rows+'</div>'+meta(s)+'</div></div></section>';
 if(s.layout==='synthesis')return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="synthesis-page">'+pic+'<div class="synthesis-copy">'+title+lead+'<div class="synthesis-points">'+rows+'</div>'+meta(s)+'</div></div></section>';
 return'<section class="screen active composition-'+k+'" data-unit="'+s.id+'"><div class="page"><div class="screen-grid"><div class="copy">'+title+lead+introBody(s)+meta(s)+'</div>'+pic+'</div></div></section>';
}
function renderScenario(s){
 const selected=scenario[s.id],opts=s.options.map((o,i)=>'<button type="button" class="option '+(selected===i?(o[1]?'selected correct':'selected incorrect'):'')+'" data-opt="'+i+'" '+(mode!=='journey'?'disabled':'')+' aria-pressed="'+(selected===i)+'"><span class="letter">'+('ABCDE'[i])+'</span><b>'+esc(o[0])+'</b></button>').join('');
 const feedback=selected==null?'<strong>Decida antes de continuar</strong><span>Escolha a ação que preserva as barreiras de prevenção.</span>':'<strong>'+(s.options[selected][1]?'Decisão adequada':'Essa decisão amplia o risco')+'</strong><span>'+esc(s.options[selected][2])+'</span>';
 return'<section class="screen scenario-screen active composition-'+esc(s.composition||'scenario-balance')+'" data-unit="'+s.id+'"><div class="scenario-page"><div class="scenario-copy"><div class="eyebrow">'+esc(s.eyebrow)+'</div><h1>'+esc(s.title)+'</h1><p class="lead">'+esc(s.lead)+'</p><img class="scenario-photo" src="'+esc(s.media)+'" alt="'+esc(s.visualAlt)+'">'+meta(s)+'</div><div class="decision"><h2>'+esc(s.question)+'</h2><div class="options">'+opts+'</div><div class="feedback" aria-live="polite">'+feedback+'</div></div></div></section>'
}
function renderAssessment(s){
 const q=quiz(s);q.q=Math.max(0,Math.min(Number(q.q||0),9));
 const item=s.questions[q.q],answered=q.answers.filter(x=>x!=null).length,locked=mode!=='journey'||(q.evaluated&&q.passed);
 const opts=item.options.map((x,i)=>'<button class="answer '+(q.answers[q.q]===i?'selected':'')+'" data-answer="'+i+'" '+(locked?'disabled':'')+'><span>'+('ABCDE'[i])+'</span><b>'+esc(x)+'</b></button>').join('');
 let feedback='Selecione uma alternativa. Antes de concluir, revise suas dez respostas.';
 if(q.evaluated){const correct=q.answers[q.q]===item.answer;feedback='<strong class="'+(q.passed?'result-pass':'result-fail')+'">'+(q.passed?'Aprovado':'Ainda não aprovado')+' — '+q.score+'%</strong><span>'+esc(item.explain)+'</span>'+(correct?'':'<span>Esta questão deve ser revista no próximo estudo.</span>')}
 else if(q.answers[q.q]!=null)feedback='Resposta registrada. Você pode alterá-la antes de concluir.';
 return'<section class="screen active" data-unit="'+s.id+'"><div class="assessment-page"><header class="assessment-head"><div><div class="eyebrow">'+esc(s.eyebrow)+'</div><h1>'+esc(s.title)+'</h1><p class="lead">'+esc(s.lead)+'</p></div><div class="mastery"><span>CRITÉRIO</span><strong>'+PASS+'%</strong><span>QUESTÕES</span><strong>10</strong></div></header><div class="assessment-layout"><div class="question-panel"><div class="qmeta"><span>Questão '+(q.q+1)+' de 10</span><span>'+(q.answers[q.q]===null?'Não respondida':'Respondida')+'</span></div><h2 class="question-text">'+esc(item.q)+'</h2><div class="answer-options">'+opts+'</div></div><aside class="assessment-side"><div class="score-grid"><div><small>Respondidas</small><strong>'+answered+'/10</strong></div><div><small>Resultado</small><strong>'+(q.evaluated?q.score+'%':'—')+'</strong></div></div><div class="assessment-feedback" aria-live="polite">'+feedback+'</div><figure class="assessment-photo"><img src="'+esc(s.media)+'" alt="'+esc(s.visualAlt)+'"></figure><div class="qnav"><button id="qPrev" class="qbtn" '+(q.q===0?'disabled':'')+'>← Questão anterior</button><button id="qNext" class="qbtn" '+(q.q===9?'disabled':'')+'>Próxima questão →</button></div></aside></div></div></section>'
}
function banner(){if(legacyConflict)return'<div class="preview-banner"><strong>Nova versão — matrícula anterior</strong><span>Este registro pertence a outro pacote. Para cursar a nova edição, o AirTrust deve gerar matrícula e ciclo próprios. Nenhum progresso antigo será reaproveitado.</span></div>';return mode==='preview'&&!qa?'<div class="preview-banner"><strong>PRÉ-VISUALIZAÇÃO — somente leitura</strong><span>Nenhuma resposta, nota ou progresso é registrado.</span><button type="button" class="ref-btn" id="returnJourney">Voltar ao ponto atual</button></div>':''}
function render(){
 const s=slide();
 $('#viewport').innerHTML=banner()+(s.kind==='scenario'?renderScenario(s):s.kind==='assessment'?renderAssessment(s):renderLesson(s));
 $('#count').textContent=(view+1)+'/'+T;
 const pct=Math.round(done.size/T*100);$('#topProgressText').textContent=pct+'% concluído';$('#topProgressFill').style.width=pct+'%';
 bindScreen();syncNext();menu();emitDiag();
}
function bindScreen(){
 $('#returnJourney')?.addEventListener('click',()=>{view=active;mode=courseCompleted?'review':'journey';render()});
 document.querySelectorAll('[data-opt]').forEach(b=>b.addEventListener('click',()=>{if(mode!=='journey')return;scenario[slide().id]=Number(b.dataset.opt);render();persist()}));
 document.querySelectorAll('[data-answer]').forEach(b=>b.addEventListener('click',()=>{if(mode!=='journey')return;const q=quiz(slide());if(q.evaluated)return;q.answers[q.q]=Number(b.dataset.answer);render();persist()}));
 $('#qPrev')?.addEventListener('click',()=>{quiz(slide()).q=Math.max(0,quiz(slide()).q-1);render()});
 $('#qNext')?.addEventListener('click',()=>{quiz(slide()).q=Math.min(9,quiz(slide()).q+1);render()});
}
function canAdvance(){const s=slide();if(mode!=='journey')return false;if(s.kind==='scenario')return scenario[s.id]!=null&&s.options[scenario[s.id]][1]===true;if(s.kind==='assessment')return quiz(s).passed===true;return gateProgress(s).complete}
function evaluate(){
 const s=slide(),q=quiz(s);if(!q.answers.every(x=>x!=null)||mode!=='journey')return;
 q.score=Math.round(q.answers.reduce((n,x,i)=>n+(x===s.questions[i].answer?1:0),0)*10);q.evaluated=true;q.passed=q.score>=PASS;persist();render();
}
function retry(){const s=slide();quizzes[s.id]={answers:Array(10).fill(null),evaluated:false,score:0,passed:false,q:0};persist();render()}
function advance(){
 if(legacyConflict)return;
 if(mode==='preview'){view=active;mode=courseCompleted?'review':'journey';render();return}
 if(mode!=='journey'||!canAdvance())return;
 done.add(active);
 if(active<T-1){active++;view=active;persist();render();return}
 if(!allQuizzesPassed())return;
 courseCompleted=true;
 if(!persist()){courseCompleted=false;render();$('#gateStatus').textContent='Falha no registro — tente novamente';return}
 finishRequested=true;emitDiag();const finished=ok(window.Scorm?.finish?.());
 pendingConfirmation=finished;
 mode='review';
 render();
 $('#gateStatus').textContent=finished?'Avaliação aprovada — aguardando confirmação do AirTrust':'Não foi possível confirmar o encerramento SCORM';
}
function syncNext(){
 const s=slide(),n=$('#next');
 if(legacyConflict){n.textContent='Matrícula nova necessária';n.disabled=true;n.onclick=null;return}n.disabled=false;
 if(mode==='preview'){n.textContent='Voltar ao ponto atual';n.onclick=advance;return}
 if(mode==='review'){n.textContent=courseCompleted?'Rever treinamento':'Retornar à jornada';n.disabled=courseCompleted;n.onclick=()=>{view=active;mode='journey';render()};return}
 if(s.kind==='scenario'&&!canAdvance()){n.textContent='Escolha a decisão segura';n.disabled=true;n.onclick=null;return}
 if(s.kind==='assessment'){
  const q=quiz(s);
  if(q.evaluated&&!q.passed){n.textContent='Nova tentativa';n.onclick=retry;return}
  if(q.passed){n.textContent='Continuar →';n.onclick=advance;return}
  const all=q.answers.every(x=>x!=null);n.textContent=all?'Concluir avaliação':'Responda às dez questões';n.disabled=!all;n.onclick=all?evaluate:null;return;
 }
 n.textContent=view===T-1?'Concluir treinamento':'Continuar →';n.onclick=advance;
}
function menu(){
 const list=$('#drawerList');
 $('#drawerProgress').textContent=done.size+' de '+T+' unidades concluídas · '+Math.round(done.size/T*100)+'%';
 list.innerHTML=S.map((s,i)=>'<button class="drawer-item '+(done.has(i)?'done ':'')+(i===view?'selected ':'')+(i===active?'journey ':'')+(i>active&&!done.has(i)?'future':'')+'" data-i="'+i+'"><span class="num">'+(done.has(i)?'✓':i+1)+'</span><strong>'+esc(s.title)+'<small>'+esc(s.module)+(i>active&&!done.has(i)?' · prévia':'')+'</small></strong></button>').join('');
 list.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{view=Number(b.dataset.i);mode=modeFor(view);render()});
}
function showRefs(){
 $('#refList').innerHTML=C.sources.map(r=>'<div class="ref"><strong>'+esc(r.label)+'</strong><span>'+esc(r.detail)+'</span></div>').join('')+'<div class="governance-note">Fontes internacionais sustentam critérios gerais. Para altitudes, mínimos, perfis e respostas específicas prevalecem documentação controlada Costa do Sol, cartas, RFM e SOP vigentes. Fotografias são contexto editorial, não evidência técnica.</div>';
 $('#modalBg').classList.add('open');
}
function init(){
 if(initialized)return;initialized=true;const params=new URLSearchParams(location.search);
 if(qa){view=Math.max(0,Math.min(T-1,Number(params.get('slide')||1)-1));active=0;mode='preview'}else restore();
 $('#menuBtn').onclick=()=>{$('#drawer').classList.add('open');$('#backdrop').classList.add('open');$('#drawer').setAttribute('aria-hidden','false')};
 const closeMenu=()=>{$('#drawer').classList.remove('open');$('#backdrop').classList.remove('open');$('#drawer').setAttribute('aria-hidden','true')};
 $('#drawerClose').onclick=closeMenu;$('#backdrop').onclick=closeMenu;
 $('#refBtn').onclick=showRefs;$('#modalClose').onclick=()=>$('#modalBg').classList.remove('open');
 $('#prev').onclick=()=>{if(view>0){view--;mode=modeFor(view);render()}};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('#modalBg').classList.remove('open');closeMenu()}});
 // A SCORM session must perform an initial Commit even if the learner does not advance.
 // This is lifecycle persistence, not an implicit completion.
 if(!qa && mode==='journey')persist();
 render();
 window.__AIRTRUST_PLAYER_TEST__={getState:()=>({view,active,mode,done:[...done],scenario,quizzes,courseCompleted,completionReady:completionReady(),stateLength:state().length}),show:i=>{view=Math.max(0,Math.min(T-1,i));mode=modeFor(view);render()},force:(i,m='journey')=>{active=view=Math.max(0,Math.min(T-1,i));mode=m;render()},persist,advance,quiz,evaluate,finishRequested:()=>finishRequested};
}
window.addEventListener('DOMContentLoaded',init);
// A session is different from course completion: leaving with an incomplete
// course must still call LMSFinish once, preserving progress via exit=suspend.
// The official AirTrust browser QA dispatches these events synchronously.
function closeScormSession(){
 if(sessionEnding||window.Scorm?.isFinished?.()||!window.Scorm?.isInitialized?.())return;
 sessionEnding=true;
 // Never allow preview to mark interactions complete or move the journey.
 if(!qa && mode==='journey' && !courseCompleted && !legacyConflict)persist();
 // Exiting an unfinished course is not failure or approval.
 if(!courseCompleted)safeSet('cmi.core.exit','suspend');
 commit();
 window.Scorm?.finish?.();
}
for(const event of ['beforeunload','pagehide','unload'])window.addEventListener(event,closeScormSession);
})();