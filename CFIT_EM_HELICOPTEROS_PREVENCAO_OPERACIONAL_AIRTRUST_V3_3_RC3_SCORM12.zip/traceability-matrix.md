# Rastreabilidade

| Unidade | Família | Fontes | Recurso |
|---|---|---|---|
| cfit26_01 — CFIT em Helicópteros | cover | FAA-HFH, EASA-RMT0708 | media/contexto-01.jpg |
| cfit26_02 — O helicóptero pode estar controlado — e ainda em perigo | comparison | FAA-HFH | media/contexto-02.jpg |
| cfit26_03 — A posição tem duas dimensões de risco | visual-explainer | FAA-HFH | media/contexto-03.jpg |
| cfit26_04 — Por que helicópteros exigem atenção específica | editorial-briefing | FAA-HFH, EASA-RMT0708 | media/contexto-04.jpg |
| cfit26_05 — A ameaça raramente chega sozinha | process | FAA-HFH, EASA-HE8 | media/contexto-05.jpg |
| cfit26_06 — Prevenção começa antes da partida | checklist | FAA-HFH, EASA-HE2, EASA-HE13 | media/contexto-06.jpg |
| cfit26_07 — Cenário — saída costeira com teto em queda | scenario | FAA-HFH, EASA-HE13 | media/contexto-07.jpg |
| cfit26_08 — Quatro perguntas antes de continuar | checklist | FAA-HFH, EASA-HE8 | media/contexto-08.jpg |
| cfit26_09 — Avaliação — capítulo 1 | assessment | FAA-HFH, EASA-HE8, EASA-HE9 | media/contexto-09.jpg |
| cfit26_10 — Quando o cenário deixa de ser uma referência confiável | chapter-opener | FAA-HFH | media/contexto-10.jpg |
| cfit26_11 — Noite sobre o mar: menos pistas, maior exigência | visual-explainer | FAA-HFH | media/contexto-11.jpg |
| cfit26_12 — Mar muito calmo e horizonte pouco definido | comparison | FAA-HFH | media/contexto-12.jpg |
| cfit26_13 — VMC que se deteriora e IMC inadvertido | process | FAA-HFH, EASA-HE13 | media/contexto-13.jpg |
| cfit26_14 — A meteorologia muda durante a missão | editorial-briefing | EASA-HE13, EASA-HE2 | media/contexto-14.jpg |
| cfit26_15 — Cenário — aproximação offshore ao anoitecer | scenario | FAA-HFH, EASA-HE8 | media/contexto-15.jpg |
| cfit26_16 — Altura sobre a superfície não é altitude publicada | comparison | FAA-HFH | media/contexto-16.jpg |
| cfit26_17 — Obstáculos podem desaparecer no contraste | checklist | FAA-HFH, EASA-RMT0708 | media/contexto-17.jpg |
| cfit26_18 — Avaliação — capítulo 2 | assessment | FAA-HFH, EASA-HE8, EASA-HE9 | media/contexto-18.jpg |
| cfit26_19 — Barreiras precisam funcionar juntas | chapter-opener | EASA-HE8, EASA-HE9 | media/contexto-19.jpg |
| cfit26_20 — A rota deve prever o que pode dar errado | process | FAA-HFH, EASA-HE2 | media/contexto-20.jpg |
| cfit26_21 — Mínimos não são metas de precisão | editorial-briefing | FAA-HFH | media/contexto-21.jpg |
| cfit26_22 — Cross-check: trajetória real versus trajetória esperada | comparison | FAA-HFH, EASA-HE8 | media/contexto-22.jpg |
| cfit26_23 — Automação: saber o que ela está fazendo agora | visual-explainer | EASA-HE9 | media/contexto-23.jpg |
| cfit26_24 — Alertas de terreno: barreira, não autorização | editorial-briefing | EASA-RMT0708, FAA-HFH | media/contexto-24.jpg |
| cfit26_25 — CRM: transformar dúvida em intervenção | checklist | EASA-HE8, EASA-HE2 | media/contexto-25.jpg |
| cfit26_26 — Cenário — perfil automático não corresponde ao previsto | scenario | EASA-HE9, EASA-HE8 | media/contexto-26.jpg |
| cfit26_27 — Avaliação — capítulo 3 | assessment | FAA-HFH, EASA-HE8, EASA-HE9 | media/contexto-27.jpg |
| cfit26_28 — A melhor decisão acontece antes do limite | chapter-opener | FAA-HFH, EASA-HE2 | media/contexto-28.jpg |
| cfit26_29 — Go / no-go é reavaliado em voo | process | FAA-HFH, EASA-HE8 | media/contexto-29.jpg |
| cfit26_30 — Pressão operacional distorce o julgamento | comparison | FAA-HFH, EASA-HE2 | media/contexto-30.jpg |
| cfit26_31 — Cenário — trecho marítimo sem horizonte confiável | scenario | FAA-HFH, EASA-HE13 | media/contexto-31.jpg |
| cfit26_32 — Cenário — descida fora do perfil previsto | scenario | FAA-HFH, EASA-RMT0708 | media/contexto-32.jpg |
| cfit26_33 — Treinar a descontinuação é treinar prevenção | checklist | EASA-HE8, EASA-HE2 | media/contexto-33.jpg |
| cfit26_34 — Uma ferramenta de briefing que cabe na operação | checklist | FAA-HFH, EASA-HE8 | media/contexto-34.jpg |
| cfit26_35 — Transferir o aprendizado para o próximo voo | synthesis | FAA-HFH, EASA-HE9 | media/contexto-35.jpg |
| cfit26_36 — Avaliação — capítulo 4 | assessment | FAA-HFH, EASA-HE8, EASA-HE9 | media/contexto-36.jpg |
| cfit26_37 — Síntese operacional — interromper a cadeia antes do conflito | synthesis | FAA-HFH, EASA-HE8, EASA-RMT0708 | media/contexto-37.jpg |