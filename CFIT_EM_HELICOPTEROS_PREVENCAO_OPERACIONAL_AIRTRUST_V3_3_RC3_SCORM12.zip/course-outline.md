# CFIT em Helicópteros — Arquitetura editorial

- 1 · Reconhecer o risco: Como o CFIT se forma, o que o diferencia de perda de controle e quais sinais devem mobilizar a tripulação.
- 2 · Visibilidade e ambiente: Noite, mar de baixo contraste, IMC inadvertido, relevo e obstáculos: quando as referências externas deixam de ser confiáveis.
- 3 · Barreiras de proteção: Planejamento, altitudes, monitoramento, automação, alertas e CRM como camadas complementares, nunca isoladas.
- 4 · Decidir antes da margem acabar: Aplicação operacional em cenários de helicóptero, mudanças de condição, critérios de descontinuação e síntese.

37 unidades, quatro avaliações de dez questões, mínimo 80% por capítulo. Aplicabilidade: pilotos de helicóptero com ênfase costeira/offshore; não ensina manobra ou mínimo específicos sem SOP/RFM.
