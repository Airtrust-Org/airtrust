# Fontes técnicas

- **FAA-HFH** — FAA — Helicopter Flying Handbook (FAA-H-8083-21B): Capítulos 11, 12, 13; prevenção de CFIT, riscos de voo noturno e tomada de decisão. https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/helicopter_flying_handbook
- **EASA-HE2** — EASA/EHEST HE2 — Helicopter Airmanship: Decisão, preparação, avaliação de riscos e armadilhas operacionais. https://www.easa.europa.eu/en/document-library/general-publications/ehest-leaflet-he-2-helicopter-airmanship
- **EASA-HE8** — EASA/EHEST HE8 — Threat and Error Management: Gerenciamento de ameaças, erros e barreiras operacionais. https://www.easa.europa.eu/en/document-library/general-publications/ehest-leaflet-he-8-principles-threat-and-error-management
- **EASA-HE9** — EASA/EHEST HE9 — Automation and Flight Path Management: Automação, consciência de modos e monitoramento de trajetória. https://www.easa.europa.eu/en/document-library/general-publications/ehest-leaflet-he-9-automation-and-flight-path-management
- **EASA-HE13** — EASA/EHEST HE13 — Weather Threat for VMC Flights: Deterioração das condições visuais e critérios para a decisão. https://www.easa.europa.eu/en/document-library/safety-promotion/helicopter
- **EASA-RMT0708** — EASA RMT.0708 — Prevention of CFIT with helicopters / HTAWS: Conflito com terreno/obstáculos, proteção HTAWS e contexto offshore. https://www.easa.europa.eu/en/document-library/terms-of-reference-and-rulemaking-group-compositions/tor-rmt0708

Normas e mínimos da operação Costa do Sol dependem da confirmação da revisão documental vigente. Este treinamento não substitui SOP, RFM, QRH, cartas ou procedimentos aprovados.
