var Scorm=(function(){
  var api=null, initialized=false, finished=false;
  function find(w){
    var n=0;
    while(w && n<10){
      try{
        if(w.API) return w.API;
        if(w.parent && w.parent !== w){ w=w.parent; } else { break; }
      }catch(e){ break; }
      n++;
    }
    return null;
  }
  try{
    api=find(window);
    if(!api && window.opener) api=find(window.opener);
  }catch(e){ api=null; }
  function raw(method,args){
    try{
      if(api && typeof api[method]==='function') return api[method].apply(api,args||[]);
      return '';
    }catch(e){ return ''; }
  }
  function ok(v){ return v===true || String(v).toLowerCase()==='true'; }
  function guarded(method,args,afterFinishValue){
    if(finished) return typeof afterFinishValue==='undefined' ? 'false' : afterFinishValue;
    return raw(method,args);
  }
  return {
    available:function(){ return !!api; },
    isInitialized:function(){ return initialized; },
    isFinished:function(){ return finished; },
    init:function(){
      if(finished) return 'false';
      if(initialized) return 'true';
      var r=raw('LMSInitialize',['']);
      if(ok(r)) initialized=true;
      return r;
    },
    set:function(k,v){ return guarded('LMSSetValue',[String(k),String(v)],'false'); },
    get:function(k){ return guarded('LMSGetValue',[String(k)],''); },
    commit:function(){ return guarded('LMSCommit',[''],'false'); },
    finish:function(){
      if(finished) return 'true';
      var r=raw('LMSFinish',['']);
      if(ok(r)) finished=true;
      return r;
    },
    getLastError:function(){ return guarded('LMSGetLastError',[],''); },
    getErrorString:function(code){ return guarded('LMSGetErrorString',[String(code||'')],''); },
    getDiagnostic:function(code){ return guarded('LMSGetDiagnostic',[String(code||'')],''); }
  };
})();
Scorm.init();
