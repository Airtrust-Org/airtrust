# Composition Plan — CFIT em Helicópteros V3.3 RC3

Visual grammar from SGSO Segurança Operacional e Gestão de Riscos (SMS/SO) and NR26 RC5.
37 real, licensed contextual photographs, each used once; zero technical SVG or fabricated instruments.
No new interaction gates; four 10-question assessments and 80% mastery unchanged.

| Slide | Family | Composition | Local photo |
|---|---|---|---|
| 1/37 | cover | cover | media/contexto-01.jpg |
| 2/37 | comparison | comparison-cards | media/contexto-02.jpg |
| 3/37 | visual-explainer | explainer-wide-left | media/contexto-03.jpg |
| 4/37 | editorial-briefing | editorial-left | media/contexto-04.jpg |
| 5/37 | process | process-lateral | media/contexto-05.jpg |
| 6/37 | checklist | checklist-band | media/contexto-06.jpg |
| 7/37 | scenario | scenario-balance | media/contexto-07.jpg |
| 8/37 | checklist | checklist-band-flipped | media/contexto-08.jpg |
| 9/37 | assessment | assessment-original | media/contexto-09.jpg |
| 10/37 | chapter-opener | chapter-photographic | media/contexto-10.jpg |
| 11/37 | visual-explainer | explainer-wide-right | media/contexto-11.jpg |
| 12/37 | comparison | comparison-tall | media/contexto-12.jpg |
| 13/37 | process | process-lateral-flipped | media/contexto-13.jpg |
| 14/37 | editorial-briefing | editorial-right | media/contexto-14.jpg |
| 15/37 | scenario | scenario-image-top | media/contexto-15.jpg |
| 16/37 | comparison | comparison-cards | media/contexto-16.jpg |
| 17/37 | checklist | checklist-band | media/contexto-17.jpg |
| 18/37 | assessment | assessment-original | media/contexto-18.jpg |
| 19/37 | chapter-opener | chapter-photographic | media/contexto-19.jpg |
| 20/37 | process | process-lateral | media/contexto-20.jpg |
| 21/37 | editorial-briefing | editorial-left | media/contexto-21.jpg |
| 22/37 | comparison | comparison-tall | media/contexto-22.jpg |
| 23/37 | visual-explainer | explainer-wide-left | media/contexto-23.jpg |
| 24/37 | editorial-briefing | editorial-right | media/contexto-24.jpg |
| 25/37 | checklist | checklist-band-flipped | media/contexto-25.jpg |
| 26/37 | scenario | scenario-balance | media/contexto-26.jpg |
| 27/37 | assessment | assessment-original | media/contexto-27.jpg |
| 28/37 | chapter-opener | chapter-photographic | media/contexto-28.jpg |
| 29/37 | process | process-lateral-flipped | media/contexto-29.jpg |
| 30/37 | comparison | comparison-cards | media/contexto-30.jpg |
| 31/37 | scenario | scenario-image-top | media/contexto-31.jpg |
| 32/37 | scenario | scenario-balance | media/contexto-32.jpg |
| 33/37 | checklist | checklist-band | media/contexto-33.jpg |
| 34/37 | checklist | checklist-band-flipped | media/contexto-34.jpg |
| 35/37 | synthesis | synthesis-dark | media/contexto-35.jpg |
| 36/37 | assessment | assessment-original | media/contexto-36.jpg |
| 37/37 | synthesis | synthesis-dark | media/contexto-37.jpg |
