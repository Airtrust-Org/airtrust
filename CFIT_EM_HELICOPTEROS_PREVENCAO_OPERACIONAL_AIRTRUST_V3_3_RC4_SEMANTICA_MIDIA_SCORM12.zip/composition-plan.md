# Composition Plan — CFIT em Helicópteros V3.3 RC4

Visual grammar from SGSO Segurança Operacional e Gestão de Riscos (SMS/SO) and NR26 RC5.
20 verified contextual photographs used once; 17 photoless editorial pages. No irrelevant landscape, schematic SVG or fabricated instrument.
No new interaction gates; four 10-question assessments and 80% mastery unchanged.

| Slide | Family | Composition | Local photo |
|---|---|---|---|
| 1/37 | cover | cover | media/contexto-01.jpg |
| 2/37 | comparison | comparison-cards | media/contexto-02.jpg |
| 3/37 | visual-explainer | explainer-wide-left | Sem fotografia |
| 4/37 | editorial-briefing | editorial-left | media/contexto-29.jpg |
| 5/37 | process | process-lateral | media/contexto-23.jpg |
| 6/37 | checklist | checklist-band | Sem fotografia |
| 7/37 | scenario | scenario-balance | media/contexto-07.jpg |
| 8/37 | checklist | checklist-band-flipped | Sem fotografia |
| 9/37 | assessment | assessment-original | Sem fotografia |
| 10/37 | chapter-opener | chapter-photographic | media/contexto-36.jpg |
| 11/37 | visual-explainer | explainer-wide-right | media/contexto-39.jpg |
| 12/37 | comparison | comparison-tall | media/contexto-30.jpg |
| 13/37 | process | process-lateral-flipped | media/contexto-32.jpg |
| 14/37 | editorial-briefing | editorial-right | media/contexto-08.jpg |
| 15/37 | scenario | scenario-image-top | media/contexto-15.jpg |
| 16/37 | comparison | comparison-cards | media/contexto-16.jpg |
| 17/37 | checklist | checklist-band | media/contexto-41.jpg |
| 18/37 | assessment | assessment-original | Sem fotografia |
| 19/37 | chapter-opener | chapter-photographic | Sem fotografia |
| 20/37 | process | process-lateral | media/contexto-22.jpg |
| 21/37 | editorial-briefing | editorial-left | media/contexto-21.jpg |
| 22/37 | comparison | comparison-tall | Sem fotografia |
| 23/37 | visual-explainer | explainer-wide-left | Sem fotografia |
| 24/37 | editorial-briefing | editorial-right | Sem fotografia |
| 25/37 | checklist | checklist-band-flipped | Sem fotografia |
| 26/37 | scenario | scenario-balance | Sem fotografia |
| 27/37 | assessment | assessment-original | Sem fotografia |
| 28/37 | chapter-opener | chapter-photographic | media/contexto-28.jpg |
| 29/37 | process | process-lateral-flipped | media/contexto-35.jpg |
| 30/37 | comparison | comparison-cards | Sem fotografia |
| 31/37 | scenario | scenario-image-top | media/contexto-31.jpg |
| 32/37 | scenario | scenario-balance | media/contexto-05.jpg |
| 33/37 | checklist | checklist-band | Sem fotografia |
| 34/37 | checklist | checklist-band-flipped | Sem fotografia |
| 35/37 | synthesis | synthesis-dark | Sem fotografia |
| 36/37 | assessment | assessment-original | Sem fotografia |
| 37/37 | synthesis | synthesis-dark | media/contexto-33.jpg |
